"""Optional cached TMDB enrichment; Stremio metadata remains usable offline."""
import hashlib
from addon_state import get_addon
from lib.cache_policy import open_cache, read_policy


def lookup(meta, operation):
    key = get_addon().getSetting('tmdb_api_key').strip()
    if not key:
        return None
    policy = read_policy()
    cache = open_cache('metadata', policy)
    cache_key = 'tmdb-v1:' + hashlib.sha256(key.encode()).hexdigest() + ':' + operation + ':' + str(meta.get('type')) + ':' + str(meta.get('id'))
    try:
        cached = cache.get(cache_key) if cache else None
        if cached is not None:
            return cached
        from tmdb_metadata import credits, recommendations, certificate_gb
        result = (certificate_gb(meta, key) if operation == 'certificate_gb' else
                  recommendations(meta, key) if operation == 'recommendations' else credits(meta, key, operation))
        if cache:
            cache.put(cache_key, result, policy['metadata'])
        return result
    except Exception:
        return None


def people(meta, role='cast'):
    from metadata_bridge import people as provider_people, _merge_people
    base = provider_people(meta, role)
    extra = lookup(meta, role) or []
    # Keep provider order and supplement missing portraits and specific jobs.
    return _merge_people(base + extra)


def age_enrich(meta):
    result = dict(meta)
    value = lookup(meta, 'certificate_gb')
    if value:
        result.update(certificate_gb=value, certificate_country='GB')
    return result


def recommendations(meta, providers=()):
    from metadata_bridge import recommendations as catalog_recommendations
    rows = lookup(meta, 'recommendations')
    return rows if rows else catalog_recommendations(meta, providers)


def episode_scores(meta, season, rows):
    from lib.mdblist import enrich_episodes
    rows = enrich_episodes(meta, season, rows)
    addon=get_addon();key=addon.getSetting('tmdb_api_key').strip()
    if not key or addon.getSetting('episode_rating_tmdb')=='false' or addon.getSetting('rating_tmdb')=='false':return rows
    cache_key='episode-ratings:'+hashlib.sha256(key.encode()).hexdigest()+':'+str(meta.get('id'))+':'+str(season)
    try:
        policy=read_policy();cache=open_cache('metadata',policy)
        scores=cache.get(cache_key) if cache else None
        if scores is None:
            from tmdb_metadata import season_ratings
            scores=season_ratings(meta,season,key)
            if cache:cache.put(cache_key,scores,policy['metadata'])
        by_number={e['episode']:e['tmdbRating'] for e in scores}
        return [dict(r,tmdbRating=by_number.get(r.get('episode') or r.get('number'),r.get('tmdbRating'))) for r in rows]
    except Exception:return rows
