"""Fast IMDb title autocomplete with a Cinemeta fallback."""
from concurrent.futures import ThreadPoolExecutor
import re
from search_match import normalized, relevance, search_artwork, searchable_title, title_relevance
from urllib.parse import quote
from protocol import fetch, resource_url

HOME = 'https://v3-cinemeta.strem.io/manifest.json'


def ranked(query, rows, limit=8):
    output, seen = [], set()
    for row in rows:
        if not searchable_title(row):continue
        score = title_relevance(query,row)
        key = (row.get('type'),row.get('id'))
        if score is None or not row.get('id') or key in seen:continue
        seen.add(key);output.append((score,len(output),dict(row,poster=search_artwork(row))))
    return [row for _,_,row in sorted(output,key=lambda r:r[:2])][:limit]


def imdb_titles(payload):
    types = {'movie':'movie','tvMovie':'movie','tvSeries':'series','tvMiniSeries':'series'}
    rows=[]
    for row in payload.get('d',[]) if isinstance(payload,dict) else []:
        if not isinstance(row,dict) or row.get('qid') not in types:continue
        if not re.fullmatch(r'tt[0-9]+',str(row.get('id',''))):continue
        image=row.get('i') if isinstance(row.get('i'),dict) else {}
        rows.append({'id':row['id'],'type':types[row['qid']],'name':row.get('l') or '',
                     'year':row.get('y') or '', 'poster':image.get('imageUrl') or ''})
    return rows


def lookup(query, fetcher=None, imdb_fetcher=None):
    term = normalized(str(query or '')[:200])
    if len(term) < 2:return []
    imdb_fetcher = imdb_fetcher or (lambda url:fetch(url,timeout=2))
    try:
        rows=ranked(term,imdb_titles(imdb_fetcher('https://v3.sg.media-imdb.com/suggestion/' + quote(term[0].lower(),safe='') + '/' + quote(term,safe='') + '.json')))
        if rows:return rows
    except Exception:pass
    fetcher = fetcher or (lambda url:fetch(url,timeout=3))
    def request(kind):
        try:
            data = fetcher(resource_url(HOME,'catalog',kind,'top',{'search':term}))
            return [dict(row,type=kind) for row in data.get('metas',[])[:40] if isinstance(row,dict) and row.get('type',kind)==kind]
        except Exception:return []
    with ThreadPoolExecutor(max_workers=2) as pool:
        batches = list(pool.map(request,('movie','series')))
    return ranked(term,[row for batch in batches for row in batch])


def entries(query, history, matches=()):
    key = normalized(query)
    rows = [{'query':r['name'],'name':r['name'],
             'subtitle':('Exact match · ' if title_relevance(query,r)==0 else '') + ('Movie' if r['type']=='movie' else 'Series') + (' · '+str(r.get('year') or r.get('releaseInfo') or '')[:14] if r.get('year') or r.get('releaseInfo') else ''),
             'poster':r.get('poster') or '', 'kind':'title', 'exact':title_relevance(query,r)==0,
             'meta':dict(r)} for r in ranked(query,matches)] if key else []
    seen = {normalized(row['query']) for row in rows}
    for value in history:
        if isinstance(value,str) and (not key or relevance(query,value) is not None) and normalized(value) not in seen:
            rows.append({'query':value,'name':value,'subtitle':'','poster':'','kind':'recent'})
            seen.add(normalized(value))
    return rows[:5]
