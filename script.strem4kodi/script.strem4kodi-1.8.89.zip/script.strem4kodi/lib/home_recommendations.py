"""Local Home suggestions with bounded, single-flight background TMDB refresh."""
import hashlib
import re
import threading
import time
from datetime import date
from pathlib import Path

_lock = threading.Lock()
_running = set()
RANKING_VERSION = 2


def completed(row):
    """A playback timestamp alone also covers checkpoints and marking unwatched."""
    state = row.get('state') or {}
    if not state.get('lastWatched'):
        return False
    try:
        offset = max(0, float(state.get('timeOffset') or 0))
        duration = max(0, float(state.get('duration') or 0))
    except (TypeError, ValueError):
        return False
    if duration and offset >= duration * .90:
        return True
    if offset > 1:
        return False
    if state.get('flaggedWatched'):
        return True
    # Completed episodes advance to the next aired episode at a 1ms sentinel
    # and clear flaggedWatched on that next episode.
    return row.get('type') == 'series' and offset == 1 and bool(state.get('timesWatched'))


def identities(row):
    kind = row.get('type')
    return {(kind, str(row.get(field))) for field in ('id', '_id', 'imdb_id', 'moviedb_id')
            if row.get(field)}


def recent(library):
    rows = [dict(row, id=row.get('id') or row.get('_id')) for row in library
            if row.get('type') in ('movie', 'series') and completed(row)]
    rows.sort(key=lambda row: (str(row['state']['lastWatched']), row.get('type'), str(row.get('id'))), reverse=True)
    seen, result = set(), []
    for row in rows:
        keys = identities(row)
        if keys and not keys & seen:
            seen.update(keys)
            result.append(row)
    return result[:5]


def genres(row):
    """TMDB details and discovery responses use different genre shapes."""
    values = row.get('genre_ids') or [item.get('id') for item in row.get('genres') or []
                                     if isinstance(item, dict)]
    return {str(value) for value in values if value}


def relevance(row, seed_genres, rank):
    """Genre fit dominates provider order; confidence is a small tie-breaker."""
    candidate_genres = genres(row)
    overlap = seed_genres & candidate_genres
    fit = len(overlap) / len(seed_genres | candidate_genres) if seed_genres and candidate_genres else 0
    try:
        votes = max(0, float(row.get('vote_count') or 0))
        rating = min(10, max(0, float(row.get('vote_average') or 0)))
        quality = rating / 10 * votes / (votes + 100)
    except (TypeError, ValueError):
        quality = 0
    return 4 * fit + 1 / (rank + 1) + .5 * quality


def build(library, key, fetcher):
    """At most five seeds, four discovery calls per seed and ten ID lookups."""
    from tmdb_metadata import identity, request, photo
    watched = set().union(*(identities(row) for row in library if completed(row)))
    candidate_groups, preferred = [], []
    had_error = False
    id_budget = 10
    today = date.today().isoformat()
    for seed in recent(library):
        try:
            resolved = identity(seed, key, fetcher)
            if not resolved:
                continue
            kind, tid = resolved
            watched.add((seed['type'], tid))
            sequel = None
            seed_genres = genres(seed)
            if kind == 'movie':
                details = request(key, 'movie/' + tid, fetcher)
                seed_genres = genres(details) or seed_genres
                collection = details.get('belongs_to_collection') or {}
                cid = str(collection.get('id') or '')
                if re.fullmatch(r'[1-9]\d*', cid):
                    parts = request(key, 'collection/' + cid, fetcher).get('parts') or []
                    parts = sorted((r for r in parts if isinstance(r, dict)),
                                   key=lambda r: str(r.get('release_date') or '9999'))
                    after = False
                    for row in parts:
                        if str(row.get('id')) == tid:
                            after = True
                            continue
                        if (after and not row.get('adult') and row.get('release_date') and row['release_date'] <= today
                                and ('movie', str(row.get('id'))) not in watched):
                            if id_budget <= 0:
                                break
                            id_budget -= 1
                            imdb = request(key, 'movie/' + str(row.get('id')) + '/external_ids', fetcher).get('imdb_id')
                            if re.fullmatch(r'tt\d+', str(imdb or '')) and ('movie', imdb) not in watched:
                                sequel = (kind, dict(row, _imdb=imdb))
                                break
            if sequel:
                preferred.append(sequel)
            else:
                if kind != 'movie':
                    try:
                        seed_genres = genres(request(key, kind + '/' + tid, fetcher)) or seed_genres
                    except Exception:
                        # Metadata enrichment must not suppress discovery results.
                        had_error = True
                rows = request(key, kind + '/' + tid + '/similar', fetcher).get('results') or []
                candidate_groups.append([(kind, row, relevance(row, seed_genres, rank))
                                         for rank, row in enumerate(rows[:20]) if isinstance(row, dict)
                                         and (not seed_genres or not genres(row) or seed_genres & genres(row))])
        except Exception:
            had_error = True
            continue
    # Combine corroboration across seeds before spending the external-ID budget.
    # A repeated row within one provider response is not independent support.
    ranked = {}
    for group in candidate_groups:
        group_seen = set()
        for kind, row, score in group:
            candidate_key = (kind, str(row.get('id') or ''))
            if candidate_key in group_seen:
                continue
            group_seen.add(candidate_key)
            if candidate_key in ranked:
                old_kind, old_row, best, support = ranked[candidate_key]
                ranked[candidate_key] = (kind, row if score > best else old_row,
                                         max(best, score), support + 1)
            else:
                ranked[candidate_key] = (kind, row, score, 1)
    candidates = [(kind, row) for kind, row, score, support in
                  sorted(ranked.values(), key=lambda value: value[2] + .75 * (value[3] - 1), reverse=True)]
    result, seen = [], set(watched)
    # Converting at most ten candidates bounds external-ID requests even when
    # the supplier returns invalid IDs or already-watched IMDb identities.
    for kind, row in preferred + candidates:
        if len(result) >= 10:
            break
        tid = str(row.get('id') or '')
        media = 'movie' if kind == 'movie' else 'series'
        released = str(row.get('release_date') or row.get('first_air_date') or '')
        if (not re.fullmatch(r'[1-9]\d*', tid) or row.get('adult') or
                not released or released > today or (media, tid) in seen):
            continue
        try:
            imdb = row.get('_imdb')
            if not imdb:
                if id_budget <= 0:
                    continue
                id_budget -= 1
                imdb = request(key, kind + '/' + tid + '/external_ids', fetcher).get('imdb_id')
            if not re.fullmatch(r'tt\d+', str(imdb or '')) or (media, imdb) in seen:
                continue
            seen.update(((media, tid), (media, imdb)))
            result.append(dict(id=imdb, imdb_id=imdb, moviedb_id=tid, type=media,
                               name=row.get('title') or row.get('name') or '',
                               poster=photo(row.get('poster_path')), released=released,
                               year=released[:4], description=row.get('overview') or ''))
        except Exception:
            had_error = True
            continue
    if not result and had_error:
        raise RuntimeError('Recommendation lookup failed; keep the previous cache')
    return result


def sections(directory, state):
    """Return persisted cards immediately; never perform HTTP on the Home thread."""
    from account import Store
    from addon_state import get_addon
    library = state.get('library') or []
    key = get_addon().getSetting('tmdb_api_key').strip()
    if not recent(library):
        return []
    namespace = hashlib.sha256((str(state.get('token') or '') + key).encode()).hexdigest()
    signature = hashlib.sha256(repr((RANKING_VERSION,
                                    [(row.get('type'), row.get('id'), row['state'].get('lastWatched'))
                                     for row in recent(library)])).encode()).hexdigest()
    store = Store(Path(directory) / ('home-recommendations-' + namespace))
    try:
        cached = store.load()
    except Exception:
        cached = {}
    from lib.home_state import HomeState
    shared = None
    try:
        shared = HomeState(directory, state.get('token'))
        record = shared.snapshot().get('recommendations', {})
    except Exception:
        record = {}
    if record.get('signature') == signature and record.get('updated', 0) > float(cached.get('created') or 0):
        cached = {'created': record['updated'], 'signature': signature, 'items': record['items']}
    watched = set().union(*(identities(row) for row in library if completed(row)))
    rows = [row for row in cached.get('items', []) if isinstance(row, dict)
            and not identities(row) & watched][:10]
    if (key and (cached.get('signature') != signature or time.time() - float(cached.get('created') or 0) >= 3600)
            and time.time() >= float(cached.get('retry_after') or 0)):
        flight = str(store.directory)
        with _lock:
            if flight not in _running:
                _running.add(flight)
                def refresh():
                    try:
                        from protocol import fetch
                        items = build(library, key, lambda url: fetch(url, timeout=4))
                        store.save({'created': time.time(), 'signature': signature, 'items': items})
                        if shared:
                            try: shared.recommendations(signature, items)
                            except Exception: pass
                        try:
                            import xbmcgui
                            xbmcgui.Window(10000).setProperty(
                                'strem4kodi.home.recommendations.revision', str(time.time_ns()))
                        except Exception:
                            pass
                    except Exception:
                        try:
                            store.save(dict(cached, retry_after=time.time() + 300))
                        except Exception:
                            pass
                    finally:
                        with _lock:
                            _running.discard(flight)
                try:
                    threading.Thread(target=refresh, daemon=True).start()
                except RuntimeError:
                    _running.discard(flight)
    return [{'label': 'You May Also Like', 'items': rows, 'failed': False}] if rows else []
