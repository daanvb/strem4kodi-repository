"""Local recent searches; no account credentials or remote upload."""
import json
from pathlib import Path
from setup_profile import atomic_write
from search_match import normalized


def _rows(profile):
    try:
        rows = json.loads((Path(profile) / 'search-history.json').read_text(encoding='utf-8'))
        return [s for s in rows if (isinstance(s, str) and s.strip()) or
                (isinstance(s, dict) and isinstance(s.get('name'), str) and s['name'].strip())][:20] if isinstance(rows, list) else []
    except Exception:
        return []


def recent(profile):
    return [row if isinstance(row, str) else row['name'] for row in _rows(profile)]


def recent_catalogues(profile):
    return {normalized(row['name']): row['meta'] for row in _rows(profile)
            if isinstance(row, dict) and isinstance(row.get('meta'), dict)
            and isinstance(row['meta'].get('_catalogue'), dict)}


def remember(profile, query, meta=None):
    value = str(query or '').strip()[:200]
    rows = _rows(profile)
    previous = next((r for r in rows if isinstance(r, dict) and normalized(r['name']) == normalized(value)), None)
    rows = [r for r in rows if normalized(r if isinstance(r, str) else r['name']) != normalized(value)]
    if value:
        entry = previous or value
        if isinstance(meta, dict) and isinstance(meta.get('_catalogue'), dict):
            entry = {'name': value, 'meta': meta}
        rows.insert(0, entry)
    atomic_write(Path(profile) / 'search-history.json', json.dumps(rows[:20], ensure_ascii=False).encode('utf-8'))


def clear(profile):
    atomic_write(Path(profile) / 'search-history.json', b'[]')


def suggestions(query, history, matches=()):
    key = normalized(query)
    rows = [r for r in history if not key or key in normalized(r)]
    rows += [str(r.get('name') or '') for r in matches if isinstance(r, dict) and r.get('name')]
    output, seen = [], set()
    for value in rows:
        if normalized(value) not in seen:
            output.append(value);seen.add(normalized(value))
    return output[:8]
