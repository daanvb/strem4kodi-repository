"""Bounded device-local autoplay penalties; no links or provider labels stored."""
import hashlib
import math
import threading
import time
from pathlib import Path

_lock = threading.RLock()
_profile = None
MAX_PROVIDERS = 32
DECAY_SECONDS = 1800


def configure(profile):
    global _profile
    _profile = Path(profile) / 'provider-health'


def identity(label):
    if not label or label in ('Stream', 'Unreported'):return ''
    return hashlib.sha256(str(label).casefold().encode('utf-8')).hexdigest()


def _read(now, snapshot=None):
    from account import Store
    try:data = (snapshot if snapshot is not None else Store(_profile).load()).get('providers', {}) if _profile else {}
    except Exception:return {}
    clean = {}
    for key, row in data.items() if isinstance(data, dict) else []:
        if not isinstance(key, str) or len(key) != 64 or not isinstance(row, dict):continue
        score, checked = row.get('score'), row.get('checked')
        if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in (score, checked)):continue
        score = max(0, min(6, score) - max(0, now - checked) / DECAY_SECONDS)
        if score > 0:clean[key] = {'score': score, 'checked': now}
    return dict(list(clean.items())[-MAX_PROVIDERS:])


def record(key, success=False, now=None):
    if not _profile or not key:return
    from account import Store, AccountConflict
    now = time.time() if now is None else now
    with _lock:
        for _ in range(3):
            store = Store(_profile)
            try:snapshot = store.load()
            except Exception:return
            rows = _read(now, snapshot)
            score = max(0, min(6, rows.get(key, {}).get('score', 0) + (-2 if success else 1)))
            rows.pop(key, None)
            if score:rows[key] = {'score': score, 'checked': now}
            rows = dict(list(rows.items())[-MAX_PROVIDERS:])
            try:
                snapshot['providers'] = rows
                store.save(snapshot)
                return
            except AccountConflict:continue
            except Exception:return


def rank(rows, now=None):
    """Stable soft ordering within an already eligible preference shortlist."""
    from lib.stream_presenter import stream_traits
    with _lock:health = _read(time.time() if now is None else now)
    return sorted(rows, key=lambda row: health.get(identity(stream_traits(row)['provider']), {}).get('score', 0) >= 1.5)


def penalized(row, now=None):
    from lib.stream_presenter import stream_traits
    with _lock:health = _read(time.time() if now is None else now)
    return health.get(identity(stream_traits(row)['provider']), {}).get('score', 0) >= 1.5


def summary(profile, now=None):
    global _profile
    with _lock:
        previous = _profile
        try:
            configure(profile)
            rows = _read(time.time() if now is None else now)
        finally:_profile = previous
    count = sum(row['score'] >= 1.5 for row in rows.values())
    return '{} provider(s) temporarily ranked lower'.format(count) if count else 'No provider penalties active'
