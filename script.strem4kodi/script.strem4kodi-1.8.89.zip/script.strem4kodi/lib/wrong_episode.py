"""Device-local, reversible reports for a specific episode release.

Only hashed source identities are retained. Reporting never changes provider
settings or removes the source from the manual picker.
"""
import hashlib
import json
import re
import time
from pathlib import Path

from account import Store
from lib.last_source import fingerprint, key as target_key

REPORT_LIMIT = 200


def _store(profile):
    return Store(Path(profile) / 'wrong-episodes')


def _filename(row, show=''):
    from lib.source_identity import filenames
    meta = row.get('meta') if isinstance(row.get('meta'), dict) else {}
    show = show or meta.get('tvshowtitle') or meta.get('name') or ''
    return next((name for name in filenames(row, {'name': show})
                 if re.search(r'(?i)\.(?:mkv|mp4|avi|m4v|webm|m2ts|ts)$', name)), '')


def _source(row, show=''):
    filename = re.sub(r'(?i)^(?:the|an|a)[ ._-]+', '', _filename(row, show))
    mark = fingerprint(dict(row, filename=filename))
    return mark if mark['release'] or mark['url'] else None


def _record_id(target, mark):
    stable = mark['release'] or mark['url']
    return hashlib.sha256(json.dumps([target, stable], separators=(',', ':')).encode()).hexdigest()


def _label(stream):
    meta = stream.get('meta') if isinstance(stream.get('meta'), dict) else {}
    show = str(meta.get('tvshowtitle') or meta.get('name') or 'Series').strip()[:70]
    try:
        episode = 'S{:02d}E{:02d}'.format(int(meta['season']), int(meta['episode']))
    except (KeyError, TypeError, ValueError):
        episode = 'Episode'
    name = str(meta.get('name') or '').strip()[:70]
    provider = str(stream.get('provider') or 'Unknown provider').strip()[:45]
    filename = _filename(stream)[:90]
    parts = [show, episode]
    if name and name != show:
        parts.append(name)
    parts.append(provider)
    if filename:
        parts.append(filename)
    return ' · '.join(parts)


def _record(stream, now=None):
    if stream.get('kind') != 'series' or not stream.get('id'):
        return None
    mark = _source(stream)
    if mark is None:
        return None
    now = time.time() if now is None else now
    target = target_key('series', stream['id'])
    return dict(id=_record_id(target, mark), target=target, **mark,
                label=_label(stream), updated=now)


def current(profile, player=None):
    """Identify the playing episode by its active Kodi item and exact URL."""
    try:
        if player is None:
            import xbmc
            player = xbmc.Player()
        if not player.isPlayingVideo():
            return None
        playing = player.getPlayingFile()
        from source_probe import error_video
        if not playing or error_video(playing):
            return None
        key = player.getPlayingItem().getProperty('StremioPlaybackKey')
        if not key:
            context = Store(Path(profile) / 'playback-context').load()
            age = time.time() - float(context.get('created') or 0)
            if not 0 <= age <= 120:
                return None
            key = context.get('key')
        if not key:
            return None
        from lib.playback_payload import load
        stream = (load(profile, key).get('urls') or {}).get(key)
        from lib.playback_recovery import owns_stream
        if not isinstance(stream, dict) or not owns_stream(player,stream,playing):
            return None
        return _record(stream)
    except (AttributeError, OSError, TypeError, ValueError, KeyError, RuntimeError):
        return None


def reports(profile):
    rows = _store(profile).load().get('reports') or []
    return [dict(row) for row in rows if isinstance(row, dict) and row.get('id')][:REPORT_LIMIT]


def add_current(profile, record_id, player=None):
    source = current(profile, player)
    if source is None or source['id'] != record_id:
        return False
    store = _store(profile)
    data = store.load()
    existing = [row for row in data.get('reports') or []
                if isinstance(row, dict) and row.get('id') != record_id]
    data['reports'] = [source] + existing[:REPORT_LIMIT-1]
    store.save(data)
    return True


def undo(profile, record_id):
    store = _store(profile)
    data = store.load()
    existing = data.get('reports') or []
    remaining = [row for row in existing
                 if isinstance(row, dict) and row.get('id') != record_id]
    if len(remaining) == len(existing):
        return False
    data['reports'] = remaining
    store.save(data)
    return True


def is_reported(profile, kind, identity, row):
    if kind != 'series' or not identity:
        return False
    mark = _source(row)
    if mark is None:
        return False
    target = target_key(kind, identity)
    for report in reports(profile):
        if report.get('target') == target and (
                mark['url'] and mark['url'] == report.get('url') or
                mark['release'] and mark['release'] == report.get('release')):
            return True
    return False


def exclude_reported(profile, kind, identity, rows, show=''):
    """Keep reported releases in the manual picker, out of automatic picks."""
    if kind != 'series' or not identity or not isinstance(profile, (str, Path)):
        return list(rows)
    target = target_key(kind, identity)
    blocked = [report for report in reports(profile) if report.get('target') == target]
    if not blocked:
        return list(rows)
    return [row for row in rows if not any(
        (mark['url'] and mark['url'] == report.get('url')) or
        (mark['release'] and mark['release'] == report.get('release'))
        for mark in [_source(row, show)] if mark for report in blocked)]
