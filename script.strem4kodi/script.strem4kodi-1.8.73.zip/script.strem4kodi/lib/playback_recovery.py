"""Session-only recovery for explicitly selected sources; no URL logging/storage."""
import hashlib
import threading
import time
import uuid

def digest(url):
    return hashlib.sha256(str(url).encode('utf-8')).hexdigest()

def playing_attempt(player):
    try:
        value=player.getPlayingItem().getProperty('Strem4KodiPlaybackAttempt')
        return value if isinstance(value,str) else ''
    except (AttributeError,RuntimeError):return ''


def stop_failed(player,event,clock=time.monotonic):
    """Serialise failure recovery with native player shutdown; Stop is async."""
    from lib.native_playback import busy
    if busy():
        # isPlayingVideo is false during resolver/decoder startup. That is not
        # permission to open another modal or dispatch another PlayMedia.
        event.setdefault('busy_since',clock())
        return 'blocked' if clock()-event['busy_since']>=15 else 'waiting'
    event.pop('busy_since',None)
    try:
        if not player.isPlayingVideo():return 'ready'
        current=player.getPlayingFile()
        from source_probe import error_video
        redirected_error=(event.get('reason')=='provider-error-video' and error_video(current))
        if (playing_attempt(player)!=event['attempt'] and digest(current)!=event['hash']
                and not redirected_error):
            return 'unrelated'
        if 'stop_requested' not in event:
            event['stop_requested']=clock()
            player.stop()
            return 'waiting'
        return 'blocked' if clock()-event['stop_requested']>=5 else 'waiting'
    except (AttributeError,RuntimeError):
        return 'blocked'


def opening_attempt(player,pending):
    """Identify a native player opening without marking AV/progress successful."""
    if not pending:return ''
    try:
        from lib.prerolls import phase
        intro=phase()
        if intro and intro.startswith('handoff:'):
            # Keep the neutral cover until AVStarted confirms the movie.
            # Kodi switches the playing item before its fullscreen window is
            # ready. Closing on that early callback exposes the title screen.
            # The cover's XML already hides it while fullscreen is visible.
            return ''
        if intro and not intro.startswith('handoff:'):
            # Keep the owned card through an audio pre-roll. Kodi briefly
            # leaves the fullscreen window while handing the intro to the
            # selected movie; closing here exposes the source picker beneath it.
            return ''
        attempt=playing_attempt(player)
        if attempt:return attempt if attempt==pending['attempt'] else ''
        return pending['attempt'] if digest(player.getPlayingFile())==pending['hash'] else ''
    except (AttributeError,RuntimeError,KeyError,TypeError):return ''

class RecoveryTracker:
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.lock=threading.RLock();self.pending=None;self.event=None
    def arm(self,url,identity,resume_ms,window,automatic=False):
        with self.lock:
            self.event=None
            self.pending={'hash':digest(url),'identity':identity,'resume':resume_ms,
                          'window':window,'created':self.clock(),'started':False,
                          'automatic':bool(automatic),'attempt':uuid.uuid4().hex}
            return self.pending['attempt']
    def poll_failure(self, profile):
        from pathlib import Path
        if not isinstance(profile, (str, Path)):return
        with self.lock:
            if not self.pending:return
            from account import Store
            try:row = Store(Path(profile)/'source-failure').load()
            except Exception:return
            if row.get('hash') == self.pending['hash'] and row.get('attempt') == self.pending['attempt']:
                self.event = dict(self.pending)
                self.pending = None
    def startup_timeout(self):
        with self.lock:
            if self.pending and not self.pending.get('preroll') and not self.pending['started'] and self.clock()-self.pending['created']>45:
                self.event=dict(self.pending)
                self.event['reason']='startup-timeout'
                self.pending=None
    def preroll(self, active):
        with self.lock:
            if self.pending:
                self.pending['preroll']=bool(active)
                if not active:self.pending['created']=self.clock()
    def started(self,url,attempt=''):
        with self.lock:
            if self.pending:
                if attempt and attempt!=self.pending['attempt']:return
                current=self.pending['attempt']
                # Kodi may report the redirected URL instead of the selected URL.
                # The resolver's attempt property identifies that same playback.
                if not attempt and digest(url)!=self.pending['hash']:
                    self.pending=None
                    return
                self.pending['started']=True
                self.pending.setdefault('started_at', self.clock())
                return current
    def snapshot(self):
        with self.lock:
            return dict(self.pending) if self.pending else None
    def loading_state(self):
        """Keep a failed attempt covered until its owner chooses the retry."""
        with self.lock:
            if self.pending:return dict(self.pending)
            return dict(self.event,failed=True) if self.event else None
    def position(self,url,seconds):
        with self.lock:
            if self.pending and digest(url)==self.pending['hash']:
                self.pending['resume']=max(0,int(seconds*1000))
    def failed(self, reason='playback-error'):
        with self.lock:
            if self.pending and (self.pending['started'] or self.clock()-self.pending['created']<120):
                self.event=dict(self.pending)
                self.event['reason']=reason if reason in {'provider-error-video','http-unavailable','startup-timeout','playback-stopped','playback-error'} else 'unknown'
            self.pending=None
    def stopped(self):
        with self.lock:self.pending=None
    def take(self):
        with self.lock:
            event=self.event;self.event=None;return event
    def clear(self):
        with self.lock:self.pending=None;self.event=None

def check_source(tracker, url, attempt, live=False, profile=None, redirect_only=False):
    """Check redirects in parallel with Kodi; only fail the same owned attempt."""
    with tracker.lock:
        if not tracker.pending or tracker.pending['attempt']!=attempt or tracker.pending['hash']!=digest(url):return
        tracker.pending['checking']=True
    def check():
        from source_probe import unavailable, redirect_failure
        probe=redirect_failure if redirect_only else unavailable
        failure=probe(url, live=live)
        with tracker.lock:
            if tracker.pending and tracker.pending['attempt']==attempt:
                from lib.runtime_trace import playback
                playback('redirect.failed' if failure else 'redirect.inconclusive',
                         reason=failure if failure else None)
                tracker.pending['checking']=False
                if failure:
                    if profile is not None:
                        from pathlib import Path
                        from account import Store
                        try:Store(Path(profile)/'source-failure').save({'hash':digest(url),'attempt':attempt,'reason':failure})
                        except Exception:pass
                    tracker.failed(failure)
    worker=threading.Thread(target=check,daemon=True)
    try:worker.start()
    except RuntimeError:
        with tracker.lock:
            if tracker.pending and tracker.pending['attempt']==attempt:tracker.pending['checking']=False

def player(tracker, profile=None, on_started=None, on_opened=None, on_intro=None):
    import xbmc
    class RecoveryPlayer(xbmc.Player):
        _preroll = False
        _preroll_error = False
        _active_hash = None
        def _opening_intro(self):
            from lib.prerolls import phase
            pending=tracker.snapshot();current=phase()
            if not pending or not current or current.startswith('handoff:'):return False
            try:
                item=self.getPlayingItem()
                if (item.getProperty('Strem4KodiPreRoll')!=current or
                        playing_attempt(self)!=pending['attempt']):return False
            except (AttributeError,RuntimeError):return False
            self._preroll=True
            tracker.preroll(True)
            if on_intro:on_intro(pending['attempt'])
            return True
        def onPlayBackStarted(self):
            # This callback precedes AVStarted and display/decoder readiness.
            # Yield the loading UI now; AVStarted still owns success/timings.
            if self._opening_intro():return
            attempt=opening_attempt(self,tracker.snapshot())
            if attempt and on_opened:on_opened(attempt)
        def onAVStarted(self):
            try:
                self._active_hash=digest(self.getPlayingFile())
                from lib.prerolls import phase, clear_phase
                current_phase=phase()
                if current_phase and not current_phase.startswith('handoff:'):
                    self._opening_intro()
                    return
                pending=tracker.snapshot()
                native_attempt=playing_attempt(self)
                if pending and native_attempt and native_attempt!=pending['attempt']:return
                self._preroll=False
                self._preroll_error=False
                tracker.preroll(False)
                if current_phase.startswith('handoff:'):clear_phase(current_phase)
                from source_probe import error_video
                if error_video(self.getPlayingFile()):
                    # Native player calls are deferred to the recovery tick;
                    # do not stop/reopen playback inside an AV callback. Kodi
                    # can lose the attempt property on an HTTP redirect, so a
                    # recognized provider slate is enough to fail the single
                    # pending app-owned attempt.
                    if pending and (native_attempt == pending['attempt'] or not native_attempt):
                        tracker.failed('provider-error-video')
                else:
                    status_video=False
                    if pending and pending.get('automatic'):
                        from source_probe import comet_episode_status_video
                        try:duration=self.getTotalTime()
                        except (AttributeError,RuntimeError,TypeError):duration=0
                        status_video=comet_episode_status_video(self.getPlayingFile(),duration,
                                                                pending.get('identity'),automatic=True)
                    if status_video:tracker.failed('provider-error-video')
                    else:
                        attempt=tracker.started(self.getPlayingFile(),native_attempt)
                        if attempt and on_started:on_started(attempt)
            except Exception:tracker.stopped()
        def onPlayBackError(self):
            pending=tracker.snapshot()
            attempt=playing_attempt(self)
            if pending and attempt and attempt!=pending['attempt']:return
            from lib.prerolls import phase
            if self._preroll or (phase() and not phase().startswith('handoff:')):
                self._preroll_error=True
                tracker.preroll(False)
            else:tracker.failed('playback-error')
        def onPlayBackStopped(self):
            from lib.prerolls import phase
            if phase() and (self._preroll_error or (self._preroll and phase().startswith('handoff:'))):
                self._preroll=False
                self._preroll_error=False
                tracker.preroll(False)
                return
            tracker.poll_failure(profile)
            self._finish_current()
        def _finish_current(self):
            pending=tracker.snapshot()
            # A lasting listener also sees the trailer/previous video's queued
            # Stop/End. That event must not clear a newly armed source attempt.
            if (pending and not pending['started'] and self._active_hash
                    and pending['hash']!=self._active_hash and not self._preroll):return
            tracker.stopped()
        def onPlayBackEnded(self):
            if self._preroll:
                self._preroll=False
                tracker.preroll(False)
            else:self._finish_current()
    native=RecoveryPlayer()
    try:
        if native.isPlayingVideo():native._active_hash=digest(native.getPlayingFile())
    except (AttributeError,RuntimeError):pass
    return native
