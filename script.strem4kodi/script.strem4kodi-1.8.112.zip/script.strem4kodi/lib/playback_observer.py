"""Kodi playback observer for Stremio watch-progress write-back."""
import time
import hashlib
import threading
import uuid
from collections import deque
import xbmc

from account import Store
from core.playback_progress import playback_context, sync_progress

KEY_PROPERTY = 'StremioPlaybackKey'
SOURCE_CONFIRM_MS = 20000
PROVIDER_RECOVERY_MS = 60000


def _account_store():
    from lib import backend as api
    return api.STORE


class ProgressPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        from lib.unpause_rewind import UnpauseRewind
        self._unpause_rewind = UnpauseRewind(ready=self._rewind_ready, trace=self._rewind_trace,
            resuming=lambda: not (self._resume_target_ms or self._resume_rewind_pending) and not xbmc.getCondVisibility('Player.Paused')
                and not xbmc.getCondVisibility('Player.Caching'))
        self._context = None
        self._key = None
        self._playing_file = None
        self._live_file = None
        self._live_key = None
        self._track_session = 0
        self._naturally_ended_session = None
        self._position_ms = 0
        self._duration_ms = 0
        self._last_position_ms = None
        self._last_clock = None
        self._watched_ms = 0
        self._source_played_ms = 0
        self._provider_recovered = False
        self._counting = True
        self._resume_target_ms = 0
        self._resume_rewind_pending = False
        self._resume_rewind_verified_at = None
        self._resume_attempts = 0
        self._resume_seek_at = None
        self._pending = []
        self._checkpoint_next = 0
        self._successful_source = None
        self._credits_watched = False
        self._diagnostic_ends = deque(maxlen=10)
        self._diagnostic_lock = threading.Lock()
        self._diagnostic_last_end = None
        self._live_recovery = None
        try:
            import xbmcgui
        except ImportError:
            pass  # Test hosts without Kodi's GUI cannot display a recovery card.
        else:
            from lib.live_recovery import LiveRecovery
            from lib.playback_loading import LoadingSession
            self._live_recovery = LiveRecovery(self, xbmc, xbmcgui.Window(10000),
                                               cover_factory=LoadingSession)

    @staticmethod
    def _rewind_ready():
        return (xbmc.getCondVisibility('Player.Paused') and
                not xbmc.getCondVisibility('Player.Caching'))

    @staticmethod
    def _rewind_trace(stage):
        from lib.runtime_trace import playback
        playback(stage, owned=True)

    def _stream_for_key(self, key):
        if not key:
            return None
        from lib.playback_payload import load
        cache = load(_account_store().directory, key)
        row = (cache.get('urls') or {}).get(key)
        return row if isinstance(row, dict) else None

    def _current_key(self):
        try:
            item = self.getPlayingItem()
            value = item.getProperty(KEY_PROPERTY)
            if value:
                return value
        except Exception:
            pass
        try:
            pending = Store(_account_store().directory / 'playback-context').load()
            if time.time() - float(pending.get('created') or 0) <= 120:
                return pending.get('key')
        except Exception:
            pass
        return None
    def _sample(self, force=False):
        if self._context is None:
            return
        try:
            if not force and not self.isPlayingVideo():
                return
            position = max(0, int(float(self.getTime()) * 1000))
            duration = max(0, int(float(self.getTotalTime()) * 1000))
            if force:
                # Some Kodi/Fire TV stop callbacks expose a cleared zero clock.
                # Keep our last sample instead of saving an unintended restart.
                if position==0 and self._position_ms>0:return
                if self._playing_file and self.getPlayingFile()!=self._playing_file:return
        except Exception:
            return
        now = time.monotonic()
        if self._last_position_ms is not None and self._last_clock is not None and self._counting:
            delta = position - self._last_position_ms
            wall_ms = max(0, int((now - self._last_clock) * 1000))
            # Count ordinary playback, never seek jumps or fast-forward as watched time.
            if 0 <= delta <= max(5000, wall_ms * 2 + 1500):
                self._watched_ms += delta
                self._source_played_ms += delta
        self._position_ms = position
        if duration:
            self._duration_ms = duration
        self._last_position_ms = position
        self._last_clock = now

    def _start_session(self, av_started=False):
        if not self.isPlayingVideo():
            return
        key = self._current_key()
        stream = self._stream_for_key(key)
        if stream is None:
            return
        try:
            current=self.getPlayingFile()
            from source_probe import error_video
            if error_video(current):return
            from lib.playback_recovery import owns_stream
            if not owns_stream(self,stream,current):return
        except Exception:return
        if stream.get('_live_sports') or stream.get('isLive') is True or stream.get('kind') in ('sports', 'sport', 'tv', 'channel', 'live'):
            if self._live_key == key and self._live_file == current:
                recovery = getattr(self, '_live_recovery', None)
                if recovery and av_started:self._start_live_recovery(recovery, key, stream, current, True)
                return
            if self._context is not None:
                self._finish(False)
            self._unpause_rewind.reset()
            self._track_session += 1
            self._clear_track_choices()
            self._live_key, self._live_file = key, current
            recovery = getattr(self, '_live_recovery', None)
            if recovery:self._start_live_recovery(recovery, key, stream, current, av_started)
            return
        recovery = getattr(self, '_live_recovery', None)
        if recovery:recovery.cancel()
        self._live_key = self._live_file = None
        meta = stream.get('meta') if isinstance(stream.get('meta'), dict) else {}
        context = playback_context(meta, stream.get('kind'), stream.get('id'))
        if context.get('kind') not in ('movie','series') or not context.get('meta_id') or not context.get('video_id'):
            return
        if key == self._key and self._context is not None:return
        self._unpause_rewind.reset()
        self._track_session += 1
        self._clear_track_choices()
        self._key, self._context = key, context
        self._playing_file = current
        self._successful_source = stream
        self._credits_watched = False
        self._checkpoint_next = time.monotonic()+30
        self._watched_ms = 0
        self._source_played_ms = 0
        self._provider_recovered = False
        self._last_position_ms = None
        self._last_clock = None
        self._counting = True
        self._position_ms = self._duration_ms = 0
        try:
            from continue_playback import resume_seconds
            self._resume_target_ms = int(resume_seconds(stream.get('resume_ms')) * 1000)
            self._resume_rewind_pending = int(resume_seconds(stream.get('_resume_original_ms')) * 1000) > self._resume_target_ms
        except Exception:
            self._resume_target_ms = 0
            self._resume_rewind_pending = False
        self._resume_rewind_verified_at = None
        self._resume_attempts = 0
        self._resume_seek_at = None
        self._sample()
    def _start_live_recovery(self, recovery, key, stream, current, ready):
        if not stream.get('_live_sports') and stream.get('kind') not in ('sport', 'sports'):
            recovery.cancel()
            return
        try:
            recovery.start(key, stream, stream.get('url') or current, self.getPlayingItem(), ready=ready)
            if recovery.session:recovery.session['current_url'] = current
        except (AttributeError, RuntimeError):recovery.cancel()

    @staticmethod
    def _clear_track_choices():
        try:
            import xbmcgui
            home = xbmcgui.Window(10000)
            home.clearProperty('strem4kodi.audio.manual')
            home.clearProperty('strem4kodi.subtitles.manual')
        except Exception:
            pass

    def _finish(self, ended=False):
        self._live_key = self._live_file = None
        if hasattr(self, "_unpause_rewind"):
            self._unpause_rewind.reset()
        self._clear_track_choices()
        if self._context is None:
            return
        # An error slate may retain the original URL behind a provider proxy.
        # Recovery's attempt-scoped verdict must not become watched progress.
        try:
            stream=self._stream_for_key(self._key) or {}
            failure=Store(_account_store().directory/'source-failure').load()
            rejected=bool(stream.get('_playback_attempt') and failure.get('attempt')==stream['_playback_attempt']
                          and failure.get('hash')==hashlib.sha256(str(stream.get('url','')).encode()).hexdigest())
        except Exception:rejected=False
        self._sample(force=True)
        from lib.credits_watched import consume
        self._credits_watched = self._credits_watched or consume(self._context, self._playing_file)
        # A queued-but-ignored Android resume must not replace the saved
        # several-minute position with the first seconds of a failed restart.
        resume_pending = self._resume_unconfirmed()
        if not rejected and not resume_pending:self._pending.append({
            'context': self._context,
            'position_ms': self._position_ms,
            'duration_ms': self._duration_ms,
            'watched_ms': self._watched_ms,
            'ended': bool(ended),
            'session': self._key,
            'checkpoint': False,
            'credits_watched': self._credits_watched,
        })
        self._context = None
        self._key = None
        self._playing_file = None
        self._live_file = None
        self._live_key = None
        self._successful_source = None
        self._source_played_ms = 0
        self._provider_recovered = False
        self._credits_watched = False
        self._last_position_ms = None
        self._last_clock = None
        self._watched_ms = 0
        self._resume_target_ms = 0
        self._resume_rewind_pending = False
        self._resume_rewind_verified_at = None
        self._resume_attempts = 0

    def _resume_unconfirmed(self):
        return bool(self._resume_rewind_pending or (self._resume_target_ms and
                    self._position_ms < max(1000, self._resume_target_ms - 3000)))

    def _apply_resume(self):
        target = self._resume_target_ms
        recap = self._resume_rewind_pending
        if not (target or recap) or self._context is None:
            return
        if recap:
            # Some native players reuse their old bookmark despite StartOffset.
            # Being *past* the requested recap is not success. Zero is also a
            # real target when the recap reaches the beginning of the file.
            if self._duration_ms <= 0 or not self.isPlayingVideo():return
            try:
                if xbmc.getCondVisibility('Player.Caching') is True:return
            except (AttributeError, RuntimeError):pass
            now = time.monotonic()
            observed = self._resume_rewind_verified_at
            if observed is not None:
                elapsed = max(0, now-observed[0])
                advance = self._position_ms-observed[1]
                # Normal advancement remains confirmation even if a slow
                # device misses a tick and leaves the initial target window.
                if 0 <= advance <= max(3000, elapsed*2000+1500):
                    if elapsed < 0.5:return
                    self._resume_target_ms = 0
                    self._resume_rewind_pending = False
                    self._resume_rewind_verified_at = None
                    return
                self._resume_rewind_verified_at = None
            if abs(self._position_ms-target) < 3000:
                self._resume_rewind_verified_at = (now,self._position_ms)
                # Observe two stable samples without delaying playback or
                # issuing another seek when Kodi already honoured the recap.
                return
            self._resume_rewind_verified_at = None
        # A successful seekTime return only queues a seek on Android. Confirm
        # the actual sampled position before dropping the saved resume target.
        if not recap and self._position_ms >= max(1000, target - 3000):
            self._resume_target_ms = 0
            return
        if self._duration_ms and target >= self._duration_ms:
            # Android can briefly expose the previous clip/error video's
            # duration. Do not discard saved progress from that first clock.
            # A genuinely obsolete resume may clear after ordinary advancing
            # playback confirms this source; seek jumps do not count.
            if self._source_played_ms >= SOURCE_CONFIRM_MS:
                self._resume_target_ms = 0
                self._resume_rewind_pending = False
            return
        if self._resume_attempts >= 5:
            return
        if self._duration_ms <= 0 or not self.isPlayingVideo():return
        try:
            if xbmc.getCondVisibility('Player.Caching') is True:return
        except (AttributeError, RuntimeError):pass
        now = time.monotonic()
        last = getattr(self, '_resume_seek_at', None)
        if last is not None and now-last < 2:return
        self._resume_attempts += 1
        self._resume_seek_at = now
        try:
            self.seekTime(target / 1000.0)
            # Never invent watched progress while the native player is still
            # opening/ignoring a seek. The next sample supplies the verdict.
            self._last_position_ms = None
            self._last_clock = None
        except Exception:
            pass

    def tick(self):
        recovery = getattr(self, '_live_recovery', None)
        if recovery:recovery.tick()
        if self._context is None:
            try:
                if self.isPlayingVideo():
                    self._start_session()
            except Exception:
                return
        else:
            rewind = getattr(self, '_unpause_rewind', None)
            if rewind is not None and self._counting and rewind.pending_resume is not None:
                from addon_state import get_addon
                from lib.native_playback import seek_relative
                rewind.retry_resume(self,get_addon(),self._key,self._playing_file,seek_relative)
            if rewind is not None and not self._counting and rewind.paused and not (self._resume_target_ms or self._resume_rewind_pending):
                from addon_state import get_addon
                if rewind.apply(self, get_addon(), self._key, self._playing_file):
                    self._last_position_ms = None
                    self._last_clock = None
            self._sample()
            # Never run the startup resume fallback against a paused recap.
            if self._counting:self._apply_resume()
            from lib.credits_watched import consume
            if not self._credits_watched and consume(self._context, self._playing_file):
                self._credits_watched = True
                self._checkpoint()
            # Opening a source is not success. Require real advancing playback;
            # seeks/resume offsets never count towards this confirmation gate.
            if self._successful_source is not None and self._source_played_ms >= SOURCE_CONFIRM_MS and not self._source_rejected():
                try:
                    if self.isPlayingVideo() and self.getPlayingFile() == self._playing_file:
                        from lib.last_source import remember
                        stream = self._successful_source
                        remember(_account_store().directory, stream.get('kind'), stream.get('id'), stream)
                        self._successful_source = None
                except Exception:
                    pass  # Storage failure must not interrupt playback/progress.
            if not self._provider_recovered and self._source_played_ms >= PROVIDER_RECOVERY_MS and not self._source_rejected():
                try:
                    if self.isPlayingVideo() and self.getPlayingFile() == self._playing_file:
                        from lib.provider_health import configure, identity, record
                        from lib.stream_presenter import stream_traits
                        stream = self._stream_for_key(self._key) or {}
                        configure(_account_store().directory)
                        record(identity(stream_traits(stream)['provider']), success=True)
                        self._provider_recovered = True
                except Exception:
                    pass
            if self._counting and time.monotonic()>=self._checkpoint_next:self._checkpoint()

    def _checkpoint(self):
        if self._context is None:return
        if self._resume_unconfirmed():return
        if self._source_rejected():return
        self._pending.append({'context':self._context,'position_ms':self._position_ms,
            'duration_ms':self._duration_ms,'watched_ms':self._watched_ms,'ended':False,
            'session':self._key,'checkpoint':True,'credits_watched':self._credits_watched})
        self._watched_ms=0
        self._checkpoint_next=time.monotonic()+30

    def _source_rejected(self, key=None):
        try:
            stream=self._stream_for_key(key or self._key) or {}
            failure=Store(_account_store().directory/'source-failure').load()
            return bool(stream.get('_playback_attempt') and failure.get('attempt')==stream['_playback_attempt']
                        and failure.get('hash')==hashlib.sha256(str(stream.get('url','')).encode()).hexdigest())
        except Exception:return False

    def pop_pending(self):
        if not self._pending:
            return None
        return self._pending.pop(0)

    def _report_end(self, outcome):
        # Native callbacks only enqueue fixed fields. Reading/compressing logs
        # or contacting GitHub here would delay the next playback callback.
        try:
            key = self._key or self._live_key
            if not key:return
            kind = 'sports' if self._live_key else (self._context or {}).get('kind')
            if kind not in ('movie', 'series', 'sports'):return
            with self._diagnostic_lock:
                if key == self._diagnostic_last_end:return
                self._diagnostic_ends.append(dict(id=uuid.uuid4().hex, outcome=outcome,
                                                 kind=kind, ended_at=int(time.time())))
                self._diagnostic_last_end = key
        except Exception:
            pass  # Optional evidence must never prevent final progress saving.

    def pop_diagnostic_ends(self):
        with self._diagnostic_lock:
            rows = list(self._diagnostic_ends)
            self._diagnostic_ends.clear()
        return rows

    def onAVStarted(self):
        try:
            import xbmcgui
            xbmcgui.Window(10000).clearProperty('strem4kodi.player.back')
        except Exception:
            pass
        self._start_session(av_started=True)

    def onPlayBackStopped(self):
        self._report_end('stopped')
        self._naturally_ended_session = None
        recovery = getattr(self, '_live_recovery', None)
        if recovery:recovery.ended('stopped')
        self._finish(False)

    def onPlayBackEnded(self):
        self._report_end('ended')
        self._naturally_ended_session = self._track_session if self._context else None
        recovery = getattr(self, '_live_recovery', None)
        if recovery:recovery.ended('ended')
        self._finish(True)

    def onPlayBackError(self):
        self._report_end('error')
        self._naturally_ended_session = None
        recovery = getattr(self, '_live_recovery', None)
        if recovery:recovery.ended('error')
        self._finish(False)
    def onPlayBackPaused(self):
        recovery = getattr(self, '_live_recovery', None)
        if recovery:recovery.paused = True
        rewind = getattr(self, '_unpause_rewind', None)
        if rewind is not None:
            try:
                rewind.pause(self._key if self._context else None, self._playing_file, self.getTime())
            except Exception:
                rewind.reset()
        self._sample()
        self._counting = False
        self._checkpoint()

    def onPlayBackResumed(self):
        recovery = getattr(self, '_live_recovery', None)
        if recovery:recovery.paused = False
        rewind = getattr(self, '_unpause_rewind', None)
        if rewind is not None:
            try:
                from addon_state import get_addon
                from lib.native_playback import seek_relative
                rewind.resume(self, get_addon(), self._key if self._context else None,
                              self._playing_file, self.getTime(), seek_relative)
            except Exception:
                rewind.reset()
        self._counting = True
        try:
            self._last_position_ms = max(0, int(float(self.getTime()) * 1000))
            self._last_clock = time.monotonic()
        except Exception:
            self._last_position_ms = None
            self._last_clock = None

    def onPlayBackSeek(self, time_ms, seek_offset):
        del seek_offset
        if hasattr(self, "_unpause_rewind"):
            self._unpause_rewind.seeked(max(0,int(time_ms or 0)))
        self._last_position_ms = max(0, int(time_ms or 0))
        self._last_clock = time.monotonic()

    def onPlayBackSpeedChanged(self, speed):
        self._sample()
        self._counting = int(speed) == 1
        self._last_clock = time.monotonic()


def flush_pending(player):
    pending=player.pop_pending()
    if pending is None:return False
    # A verdict can arrive after a checkpoint was queued on another callback.
    rejected=getattr(type(player),'_source_rejected',None)
    if rejected and rejected(player,pending.get('session')):return True
    try:
        from lib.progress_outbox import enqueue
        if not enqueue(_account_store(),pending):return False
    except Exception as error:
        # Keep it in memory until the profile can be written again.
        from lib.diagnostic_events import record
        record('progress.save', error)
        player._pending.insert(0,pending)
        return False
    if not pending.get('checkpoint'):
        from lib.runtime_trace import playback
        playback('progress.queued')
    return True
