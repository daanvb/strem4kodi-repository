"""Local ranking preferences: soft priorities, never hardware compatibility claims."""
from lib.stream_presenter import presentation, stream_traits, line

def preferences(addon):
    def choice(key,values):
        try:
            index=int(addon.getSetting(key) or '0')
            return values[index] if 0<=index<len(values) else values[0]
        except (ValueError,TypeError,IndexError):return values[0]
    return {'quality':choice('source_quality',('Any','4K','1080p','720p')),
            'maximum':choice('source_max_quality',('Any','4K','1080p','720p')),
            'dynamic':choice('source_dynamic',('Any','Dolby Vision','HDR10','FEL reported')),
            'provider':line(addon.getSetting('source_provider'),70),
            'audio':choice('source_audio',('Any','Atmos','TrueHD','Dolby Digital Plus','AAC')),
            'language':line(addon.getSetting('source_language'),40)}

def rank_rows(rows,prefs):
    def score(row):
        traits=stream_traits(row);view=presentation(row)
        score=0
        if prefs.get('provider') and traits['provider'].casefold()==prefs['provider'].casefold():score+=32
        language=view['audio'].partition(' | Language: ')[2]
        if prefs.get('language') and prefs['language'].casefold() in language.casefold():score+=16
        if prefs.get('quality') not in (None,'Any') and traits['quality']==prefs['quality']:score+=8
        if prefs.get('dynamic') not in (None,'Any') and prefs['dynamic'] in traits['dynamic']:score+=4
        if prefs.get('audio') not in (None,'Any') and prefs['audio'].casefold() in view['audio'].casefold():score+=2
        if row.get('_session_failed'):score-=128
        return score
    return sorted(rows,key=score,reverse=True)

def limit_quality(rows,maximum='Any'):
    resolutions={'4K':2160,'1080p':1080,'720p':720,'480p':480,'360p':360}
    ceiling=resolutions.get(maximum)
    if ceiling is None:return list(rows)
    return [row for row in rows if resolutions.get(presentation(row)['quality'],0)<=ceiling]

def load_filters(addon):
    if addon.getSetting('source_remember_filters')!='true':return ('All','All','All')
    provider=addon.getSetting('source_filter_provider') or 'All'
    codec=addon.getSetting('source_filter_codec') or 'All'
    dynamic=addon.getSetting('source_filter_dynamic') or 'All'
    if codec not in ('All','HEVC / H.265','H.264 / AVC','AV1'):codec='All'
    if dynamic not in ('All','Dolby Vision','HDR10','HDR','FEL reported'):dynamic='All'
    return provider,codec,dynamic

def save_filters(addon,provider,codec,dynamic):
    if addon.getSetting('source_remember_filters')=='true':
        for key,value in (('provider',provider),('codec',codec),('dynamic',dynamic)):
            addon.setSetting('source_filter_'+key,value)
