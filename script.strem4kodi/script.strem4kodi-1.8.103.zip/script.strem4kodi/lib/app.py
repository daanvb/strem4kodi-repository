from addon_state import get_addon
import xbmcgui
from lib.nimbus import HomeWindow, InfoWindow
from lib.theme import window as themed_window

ADDON = get_addon()
ADDON_PATH = ADDON.getAddonInfo('path')
SKIN = 'Main'
RES = '1080i'
SESSION_WINDOW_ID = 10000
APP_RUNNING = 'stremioforkodi.running'


def run(started=None):
    from lib.perf_trace import now, log
    started = now() if started is None else started
    from lib.launch_guard import LaunchGuard, mark_window, unmark_window
    guard = LaunchGuard()
    if not guard.acquire():
        return
    from lib.perf_report import begin_launch
    session = xbmcgui.Window(SESSION_WINDOW_ID)
    begin_launch(session.getProperty('strem4kodi.startup.seen') != 'true')
    session.setProperty('strem4kodi.startup.seen', 'true')
    confirmed_exit = False
    closing_window_id = None
    diagnostic_profile = None
    navigation_cover = None
    try:
        from lib.signin import signed_in, show_signin
        if not signed_in():
            from lib.device_setup_ui import first_run
            if not first_run():return
        from lib.device_setup_ui import activate_pending_skin
        activate_pending_skin()
        if not signed_in() and not show_signin():
            return
        import xbmcvfs
        from lib import backend
        from lib.ui_crash import begin, phase, finish
        diagnostic_profile = backend.STORE.directory
        begin(diagnostic_profile, guard.token)
        from lib.home_layout import build_layout
        from lib.appearance import options
        # Startup is stale-while-revalidate: never hold the UI behind catalog
        # network requests. HomeWindow refreshes account/catalog data in background.
        rows = backend.account_home(False)
        layout_started = now()
        filename, path, count = build_layout(
            ADDON_PATH,
            xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
            max(8, len(rows), backend.account_home_capacity()),
            options(ADDON)
        )
        log('startup.layout', layout_started, profile=xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), rows=count)
        browse_state = None
        search_result = None
        while True:
            phase(diagnostic_profile, 'home.allocate')
            window = HomeWindow(filename, path, SKIN, RES, account_rows=rows, row_count=count, browse_state=browse_state, search_result=search_result, launch_started=started)
            search_result = None
            mark_window(window, 'home')
            try:
                phase(diagnostic_profile, 'home.modal')
                window.doModal()
                phase(diagnostic_profile, 'home.return')
                reload_appearance = getattr(window, 'reload_appearance', False)
                browse_state = getattr(window, 'reload_browse_state', None)
                details_request = getattr(window, 'details_request', None)
                navigation_cover = window.__dict__.get('_navigation_cover')
                handoff_window_id = getattr(window, 'handoff_window_id', None)
                confirmed_exit = getattr(window, 'exit_requested', False) is True
                closing_window_id = getattr(window, 'exit_window_id', None)
            finally:
                unmark_window(window)
            handed_off = isinstance(details_request, dict)
            retired = True
            if handed_off and type(handoff_window_id) is int:
                import xbmc
                # Keep the Python/native window alive while Close is queued.
                # Deleting it first frees its ID for the next window; a delayed
                # Close can then target that newly allocated title instead.
                from lib.native_window import wait_retired
                retired = wait_retired(handoff_window_id, xbmc, xbmcgui)
                if not retired:
                    phase(diagnostic_profile, 'home.retire.timeout')
            del window
            if not retired:
                break
            while isinstance(details_request, dict):
                details_request = dict(details_request)
                search_origin = details_request.pop('search_origin', None)
                if navigation_cover is not None:
                    details_request['navigation_cover']=navigation_cover
                phase(diagnostic_profile, 'details.allocate')
                details = themed_window(InfoWindow, 'script-stremio-info.xml',
                                        ADDON_PATH, SKIN, RES, **details_request)
                mark_window(details, 'info')
                from lib.runtime_trace import navigation
                navigation(details, 'details.allocated')
                try:
                    phase(diagnostic_profile, 'details.modal')
                    details.doModal()
                    phase(diagnostic_profile, 'details.return')
                finally:
                    if (getattr(details, 'load_failed', False) is True
                            and isinstance(browse_state, dict)):
                        browse_state['return_status'] = 'Unable to open this title. Please try again.'
                    unmark_window(details)
                    if navigation_cover is not None:navigation_cover.finish()
                    import xbmc
                    from lib.native_window import wait_retired
                    details_retired = wait_retired(getattr(details, '_context_window_id', None), xbmc, xbmcgui)
                    if not details_retired:
                        phase(diagnostic_profile, 'details.retire.timeout')
                    del details
                details_request = None
                if not details_retired:
                    handed_off = False
                    reload_appearance = False
                    break
                if isinstance(search_origin, dict):
                    # The typing dialog is restored by the shell after details
                    # closes. No live Home window sits underneath either one.
                    from lib.search_box import show
                    phase(diagnostic_profile, 'search.modal')
                    query = show(backend.STORE.directory, backend.suggestions,
                                 state=search_origin,
                                 catalogue_searcher=backend.suggestion_collections)
                    phase(diagnostic_profile, 'search.return')
                    if isinstance(query, dict) and isinstance(query.get('_search_origin'), dict) and not query.get('_catalogue'):
                        details_request = dict(meta={k:v for k,v in query.items() if k != '_search_origin'},
                                               return_to_search=True, search_origin=query['_search_origin'])
                    elif query:
                        search_result = query
                    else:
                        browse_state = None
                if details_request is not None:
                    continue
            if handed_off:
                # Recreate the originating grid from its loaded rows/selection.
                # The details WindowXML is fully destroyed first, avoiding the
                # overlapping full-window lifetime that crashes some devices.
                continue
            if not reload_appearance:
                break
            filename, path, count = build_layout(
                ADDON_PATH, xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
                max(8, len(rows), backend.account_home_capacity()), options(ADDON))
    finally:
        if navigation_cover is not None:navigation_cover.finish()
        if diagnostic_profile is not None:
            import sys
            finish(diagnostic_profile, guard.token, sys.exc_info()[1])
        try:
            if confirmed_exit:
                # Exit returns to Kodi Home, rather than the addon launcher
                # underneath the modal. Keep the lease until navigation finishes.
                import xbmc
                # doModal can return before Kodi handles its queued native
                # previous-window message. Let that restore the launcher first.
                for _ in range(20):
                    if (xbmcgui.getCurrentWindowId() != closing_window_id
                            and not xbmc.getCondVisibility('System.HasVisibleModalDialog')):
                        break
                    xbmc.sleep(50)
                guard.defer_relaunch()
                xbmc.executebuiltin('ActivateWindow(Home)', True)
        finally:
            guard.release()
