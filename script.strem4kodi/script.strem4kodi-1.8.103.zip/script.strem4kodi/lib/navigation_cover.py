"""Keep the native Kodi launcher covered while retiring a full browse window."""
import weakref


class Cover:
    def __init__(self):
        self.window=None
        self.closed=False
        self.visible=False
        self.cancelled=False
        self.on_ready=None

    def show(self,title,on_ready,factory=None):
        self.on_ready=on_ready
        try:
            self.window=(factory or make_window)(self,title)
            self.window.show()  # Home.doModal continues pumping Python callbacks.
        except Exception:
            self.on_ready=None
            self.finish()
            raise

    def ready(self):
        if self.closed:return
        self.visible=True
        callback,self.on_ready=self.on_ready,None
        # Release the bound Home reference before the shell destroys its native
        # window. Retaining it would defeat the sole-full-window handoff.
        if callback:
            try:callback()
            except Exception:
                self.finish()
                raise

    def finish(self):
        if self.closed:return
        self.closed=True
        self.on_ready=None
        if self.window is not None:
            try:self.window.close()
            except RuntimeError:pass
            path=getattr(self.window,'_theme_layout_path',None)
            if path:
                try:path.unlink()
                except OSError:pass


def make_window(owner,title):
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window as themed_window
    reference=weakref.ref(owner)
    class Transition(xbmcgui.WindowXMLDialog):
        def onInit(self):
            current=reference()
            if current is None or current.closed:
                self.close()
                return
            current.ready()
        def onAction(self,action):
            current=reference()
            if current is not None and action.getId() in (10,92,216,247):
                current.cancelled=True
        def onClick(self,control):pass
    def initial(tree):
        tree.find('.//control[@id="302"]/label').text=str(title or '')[:160]
    return themed_window(Transition,'script-strem4kodi-transition.xml',
        get_addon().getAddonInfo('path'),'Main','1080i',unique_layout=True,layout_transform=initial)
