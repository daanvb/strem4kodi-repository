"""Reject explicit episode conflicts before ranking automatic candidates."""
import re
import unicodedata
from urllib.parse import unquote, urlsplit

EPISODE = re.compile(r'(?i)\bs(\d{1,3})[ ._-]*e(\d{1,3})(?!\d)|\b(\d{1,3})x(\d{1,3})(?!\d)')


def target(meta, identity):
    if meta.get('type') != 'series' or not identity:
        return None
    video = next((v for v in meta.get('videos') or [] if isinstance(v, dict) and v.get('id') == identity), {})
    try:
        return int(video['season']), int(video.get('episode', video.get('number')))
    except (KeyError, TypeError, ValueError):
        match = re.search(r':(\d+):(\d+)$', str(identity))
        return (int(match[1]), int(match[2])) if match else None


def words(value):
    text = unicodedata.normalize('NFKD', str(value)).encode('ascii', 'ignore').decode().casefold()
    return tuple(w for w in re.findall(r'[a-z0-9]+', text)
                 if w not in ('the', 'a', 'an') and not re.fullmatch(r'(19|20)\d{2}', w))


def filenames(row):
    """Independent provider filenames, plus a media filename in the URL path.

    Query strings and numeric pack indices are not episode evidence.
    """
    candidates=row.get('filename_candidates') or []
    if not isinstance(candidates,(list,tuple)):candidates=[]
    candidates=list(candidates)+[row.get('filename'),(row.get('card') or {}).get('filename')]
    try:
        linked=unquote(urlsplit(str(row.get('url') or '')).path).rsplit('/',1)[-1]
        if re.search(r'(?i)\.(mkv|mp4|avi|m4v|webm|ts)$',linked):candidates.append(linked)
    except ValueError:pass
    return list(dict.fromkeys(value.replace('\\','/').rsplit('/',1)[-1]
                             for value in candidates if isinstance(value,str) and value.strip()))


def status(row, meta, identity):
    expected = target(meta, identity)
    if expected is None:
        return 'unknown'
    verified = False
    for field in ('seriesId', 'imdbId'):
        supplied = str(row.get(field) or '')
        wanted = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
        if supplied.startswith('tt') and wanted.startswith('tt'):
            if supplied.split(':')[0] != wanted:
                return 'conflict'
    for field,number in zip(('season','episode'),expected):
        try:
            if row.get(field) is not None and int(row[field])!=number:return 'conflict'
        except (TypeError,ValueError):pass
    try:verified=(int(row['season']),int(row['episode']))==expected
    except (KeyError,TypeError,ValueError):pass
    evidence=[(value,True) for value in filenames(row)]
    evidence.extend((str(row.get(field) or ''),False) for field in ('title','description','detail'))
    for text,is_filename in evidence:
        marks = list(EPISODE.finditer(text))
        if not marks:continue
        numbers = {(int(m[1] or m[3]), int(m[2] or m[4])) for m in marks}
        # Multi-episode files are left for manual selection: their internal
        # timeline cannot safely be inferred from a release name.
        if numbers != {expected} or re.search(r'(?i)e\d+[ ._-]*e\d+|e\d+-\d+', text):
            return 'conflict'
        verified = True
        if is_filename and meta.get('name'):
            prefix = text[:marks[0].start()]
            actual, wanted = words(prefix), words(meta['name'])
            if actual and wanted and actual != wanted:
                return 'conflict'
    return 'match' if verified else 'unknown'


def eligible(rows, meta, identity, require_match=False):
    if target(meta, identity) is None:
        return list(rows)
    classified = [(row, status(row, meta, identity)) for row in rows]
    matches = [row for row, result in classified if result == 'match']
    # Unlabelled streams remain available to the manual picker. Automatic
    # playback needs positive episode evidence; guessing an unknown result can
    # start the wrong episode even when its source was returned for this ID.
    if matches:return matches
    return [] if require_match else [row for row, result in classified if result == 'unknown']
