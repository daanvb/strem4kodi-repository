"""Search with native Kodi edit input, phone paste and debounced suggestions."""
import threading
import time
import xbmc
import xbmcgui
from lib.ui_dialogs import InputWindow, BACK
from lib.theme import window as themed_window
from lib.search_history import recent, remember, clear
from lib.title_suggestions import entries, normalized
from search_match import relevance
from pathlib import Path


class SearchWindow(InputWindow):
    def __init__(self, *args, **kwargs):
        self.profile = kwargs.pop('profile')
        self.searcher = kwargs.pop('searcher')
        self.catalogue_searcher = kwargs.pop('catalogue_searcher', None)
        self.restore_state = kwargs.pop('state', None)
        self.closed = False
        self.query_generation = 0
        self.matches = []
        self.last_query = None
        self.recent_queries = recent(self.profile)
        self.suggestion_rows = []
        self.cache = {}
        self.catalogue_cache = {}
        self.catalogue_inflight = set()
        self.inflight = set()
        self.mailbox = []
        self.lock = threading.Lock()
        super().__init__(*args, title='Search movies and series', **kwargs)
        if isinstance(self.restore_state, dict):
            self.value = self.restore_state['query']
            self.last_query = self.value.strip()
            self.mode = self.restore_state['mode']
            self.cache = {key:list(rows) for key,rows in self.restore_state['cache'].items()}
            self.catalogue_cache = {key:list(rows) for key,rows in self.restore_state['catalogue_cache'].items()}
            self.recent_queries = list(self.restore_state['recent_queries'])

    def _display(self):
        self.getControl(301).setText(self.value)

    def onInit(self):
        self.setProperty('dialog_title', self.title)
        self._display(); self._render(self.restore_state['keyboard_position'] if isinstance(self.restore_state, dict) else 0)
        if isinstance(self.restore_state, dict):
            self._render_suggestion_rows(self.value, list(self.restore_state['rows']))
            if self.suggestion_rows:
                self.getControl(601).selectItem(min(max(0, self.restore_state['position']), len(self.suggestion_rows)-1))
            self.setFocusId(self.restore_state['focus'])
        else:
            self.render_suggestions(self.value, self.cached_matches(self.value))
            self.setFocusId(600)
        threading.Thread(target=self.watch, daemon=True).start()

    def render_suggestions(self, query, matches=()):
        rows = entries(query, self.recent_queries, matches)
        self._render_suggestion_rows(query, rows)

    def _render_suggestion_rows(self, query, rows):
        self.setProperty('suggestion_heading', 'Catalogues, movies and series' if query.strip() else 'Recent searches')
        self.setProperty('suggestion_empty', '' if rows else ('Type at least two letters to find a title.' if len(normalized(query))<2 else 'Keep typing, or select Search to see all results.'))
        with self.lock:previous_rows = list(self.suggestion_rows)
        if rows == previous_rows:
            return
        listing = self.getControl(601)
        selected = None
        try:
            position = listing.getSelectedPosition()
            if 0 <= position < len(previous_rows):
                selected = previous_rows[position]
        except (TypeError, AttributeError):
            pass
        with self.lock:self.suggestion_rows = rows
        listing.reset()
        items=[]
        for row in rows:
            item=xbmcgui.ListItem(label=row['name'])
            item.setProperty('subtitle',row['subtitle']);item.setProperty('kind',row['kind'])
            item.setArt({'thumb':row['poster']});items.append(item)
        listing.addItems(items)
        if selected in rows:
            listing.selectItem(rows.index(selected))

    def cached_matches(self, query):
        key = normalized(query)
        with self.lock:
            cache = {k:list(rows) for k,rows in self.cache.items()}
            catalogue_cache = {k:list(rows) for k,rows in self.catalogue_cache.items()}
        candidates = [k for k in cache if key and (key.startswith(k) or k.startswith(key))]
        base = cache.get(key, cache[max(candidates,key=len)] if candidates else [])
        # Responses often omit an already-discovered collection. Retain only
        # catalogues that still match this query, never unrelated old titles.
        retained=[];seen=set()
        collections = [r for k in candidates for r in cache[k] if r.get('_catalogue')]
        collections += [r for k,rows in catalogue_cache.items() if key and (key.startswith(k) or k.startswith(key)) for r in rows]
        for row in list(base)+collections:
            if row.get('_catalogue') and relevance(query,row.get('name','')) is None:continue
            identity=(row.get('type'),row.get('id'))
            if identity in seen:continue
            seen.add(identity);retained.append(row)
        return retained

    def watch(self):
        pending = None
        pending_catalogue = None
        changed = 0
        if isinstance(self.restore_state, dict) and len(normalized(self.value)) >= 2:
            with self.lock:cached = normalized(self.value) in self.cache
            if not cached:
                pending = self.value.strip();changed = time.monotonic()
            if self.catalogue_searcher:
                with self.lock:completed = normalized(self.value) in self.catalogue_cache
                if not completed:
                    pending_catalogue = self.value.strip();changed = time.monotonic()
        monitor = xbmc.Monitor()
        while not self.closed and not monitor.abortRequested():
            try:
                query = self.getControl(301).getText().strip()[:200]
                if query != self.last_query:
                    self.value = query;self.last_query = query
                    self.query_generation += 1;pending = query;changed = time.monotonic()
                    pending_catalogue = query if self.catalogue_searcher else None
                    self.render_suggestions(query, self.cached_matches(query))
                self.accept_results()
                if pending is not None and time.monotonic() - changed >= .25:
                    term = pending
                    if len(normalized(term)) < 2 or normalized(term) in self.cache:pending=None
                    elif self.queue_fetch(term,self.query_generation):pending=None
                if pending_catalogue is not None and time.monotonic() - changed >= .25:
                    term = pending_catalogue
                    with self.lock:completed = normalized(term) in self.catalogue_cache
                    if len(normalized(term)) < 2 or completed:pending_catalogue=None
                    elif self.queue_catalogues(term,self.query_generation):pending_catalogue=None
            except Exception:
                pass
            xbmc.sleep(50)

    def queue_fetch(self, term, generation):
        with self.lock:
            if self.closed or len(self.inflight)>=2:return False
            if any(normalized(active)==normalized(term) for active,_ in self.inflight):return False
            token=(term,generation);self.inflight.add(token)
        try:threading.Thread(target=self.fetch_suggestions,args=(term,generation),daemon=True).start()
        except RuntimeError:
            with self.lock:self.inflight.discard(token)
            return False
        return True

    def fetch_suggestions(self, term, generation):
        try:rows=self.searcher(term) or []
        except Exception:rows=[]
        with self.lock:
            self.inflight.discard((term,generation))
            if not self.closed:self.mailbox.append((term,generation,rows))

    def queue_catalogues(self, term, generation):
        with self.lock:
            # The collection request includes bounded parent-movie fallbacks;
            # keep only one running, independently of the fast title workers.
            if self.closed or not self.catalogue_searcher or self.catalogue_inflight:return False
            token=(term,generation);self.catalogue_inflight.add(token)
        try:threading.Thread(target=self.fetch_catalogues,args=(term,generation),daemon=True).start()
        except RuntimeError:
            with self.lock:self.catalogue_inflight.discard(token)
            return False
        return True

    def fetch_catalogues(self, term, generation):
        try:rows=self.catalogue_searcher(term) or []
        except Exception:rows=[]
        with self.lock:
            self.catalogue_inflight.discard((term,generation))
            if not self.closed:self.mailbox.append((term,generation,rows,'catalogues'))

    def accept_results(self):
        with self.lock:ready,self.mailbox=self.mailbox,[]
        refresh = False
        for response in ready:
            term,generation,rows = response[:3]
            catalogue_only = len(response)>3 and response[3]=='catalogues'
            if self.closed:return
            retained = [row for row in self.cached_matches(term) if row.get('_catalogue')]
            seen = {(row.get('type'),row.get('id')) for row in rows}
            rows = list(rows) + [row for row in retained if (row.get('type'),row.get('id')) not in seen]
            with self.lock:
                cache = self.catalogue_cache if catalogue_only else self.cache
                if len(cache)>=32:cache.pop(next(iter(cache)))
                cache[normalized(term)]=rows
            current = normalized(self.last_query)
            key = normalized(term)
            # A catalogue can arrive for an earlier prefix after the user has
            # already typed more. Redraw the current query from the merged
            # cache; exact-query title results still take precedence.
            if current and key and (current.startswith(key) or key.startswith(current)):
                refresh = refresh or key == current or any(
                    row.get('_catalogue') and relevance(self.last_query,row.get('name','')) is not None for row in rows)
        if refresh and not self.closed:
            self.render_suggestions(self.last_query,self.cached_matches(self.last_query))

    def onClick(self, cid):
        if cid == 302:
            keyboard = xbmc.Keyboard(self.getControl(301).getText(), 'Search movies and series')
            keyboard.doModal()
            if keyboard.isConfirmed():self.value = keyboard.getText()[:200];self._display()
            self.setFocusId(301)
        elif cid == 601:
            pos = self.getControl(601).getSelectedPosition()
            with self.lock:
                row = self.suggestion_rows[pos] if 0 <= pos < len(self.suggestion_rows) else None
            if row is not None:
                self.finish(row['query'], row.get('meta'))
        elif cid == 303:
            clear(self.profile);self.recent_queries=[];self.render_suggestions(self.value,self.cached_matches(self.value))
        elif cid == 204:
            query = self.getControl(301).getText()
            # Submit all results, including catalogues already discovered by
            # the independent collection lookup. Suggestions open directly.
            self.finish(query)
        elif cid == 301:
            self.value = self.getControl(301).getText()
        else:
            self.value = self.getControl(301).getText()
            super().onClick(cid)

    def finish(self, query, meta=None):
        query = str(query).strip()[:200]
        if meta:
            # A suggestion opens directly. Preserve the actual typing screen,
            # rather than replacing it with a new search for the chosen name.
            origin = {
                'query': self.getControl(301).getText()[:200],
                'position': self.getControl(601).getSelectedPosition(),
                'focus': self.getFocusId(),
                'mode': self.mode,
                'keyboard_position': self.getControl(600).getSelectedPosition()}
            with self.lock:
                origin.update(rows=list(self.suggestion_rows),
                              cache={key:list(rows) for key,rows in self.cache.items()},
                              catalogue_cache={key:list(rows) for key,rows in self.catalogue_cache.items()},
                              recent_queries=list(self.recent_queries))
            self.result = dict(meta, _search_origin=origin)
        else:
            # Carry catalogues already found while typing into the subsequent
            # full-results request. The full-search page has its own cache, so
            # without this handoff a list shown for "JU" vanishes when the
            # provider omits it for the submitted query "JUR".
            self.result = {'_search_query': query,
                           '_search_catalogues': [row for row in self.cached_matches(query)
                                                 if row.get('_catalogue')]}
        if query:
            try:remember(self.profile, query)
            except OSError:pass
        self.close()

    def close(self):
        self.closed = True;self.query_generation += 1
        super().close()


def show(profile, searcher, native=False, state=None, catalogue_searcher=None):
    root = str(Path(__file__).resolve().parents[1])
    default = ''
    if native:
        keyboard = xbmc.Keyboard('', 'Search movies and series')
        keyboard.doModal()
        if not keyboard.isConfirmed():return ''
        default = keyboard.getText()
    window = themed_window(SearchWindow, 'script-strem4kodi-search.xml', root, 'Main', '1080i', profile=profile, searcher=searcher, default=default, state=state, catalogue_searcher=catalogue_searcher)
    window.doModal()
    return window.result
