"""Vertical-only Discover grid with the same artwork size as Home."""
import xml.etree.ElementTree as ET
from lib.cinematic_cards import posters

ROW_IDS = (9500,)


def split(items, capacity=1):
    return [items] if items else []


def build(tree):
    controls = tree.getroot().find('controls')
    rows = tree.find('.//control[@id="2000"]')
    ET.SubElement(rows, 'visible').text = '!String.IsEqual(Window.Property(discover_grid),true)'
    listing = ET.SubElement(controls, 'control', type='panel', id='9500')
    for tag, value in {'left':50, 'top':660, 'width':1760, 'height':420,
                       'orientation':'vertical', 'scrolltime':180, 'pagecontrol':9564,
                       'onleft':'SetFocus(9500)', 'onright':9500,
                       'visible':'String.IsEqual(Window.Property(discover_grid),true)'}.items():
        ET.SubElement(listing, tag).text = str(value)
    # Numeric self navigation asks Kodi to wrap at the panel edge. Builtin
    # edge holds leave movement and scrolling inside the native container.
    ET.SubElement(listing, 'onup', condition='String.IsEqual(Window.Property(search_grid),true)').text = 'SetFocus(9500)'
    ET.SubElement(listing, 'onup', condition='!String.IsEqual(Window.Property(search_grid),true)').text = 'SetFocus(9200)'
    for tag in ('itemlayout', 'focusedlayout'):
        ET.SubElement(listing, tag, width='220', height='333')
    posters(listing)
    import copy
    # Search uses the same vertical panel, with room for title captions.
    # Its collections/catalogues precede movies and series in the item order.
    for tag in ('itemlayout', 'focusedlayout'):
        search_layout = copy.deepcopy(listing.find(tag))
        search_layout.set('height', '400')
        search_layout.set('condition', 'String.IsEqual(Window.Property(search_grid),true)')
        listing.find(tag).set('condition', '!String.IsEqual(Window.Property(search_grid),true)')
        listing.append(search_layout)
    for layout in (listing.find('itemlayout'), listing.find('focusedlayout')):
        for node in list(layout):
            if node.get('type') == 'label' and float(node.findtext('top', '0')) >= 320:
                layout.remove(node)
            elif node.find('left') is not None:
                node.find('left').text = str(int(node.findtext('left')) - 5)

    scrollbar=ET.SubElement(controls,'control',type='scrollbar',id='9564')
    for tag,value in {'left':1820,'top':660,'width':12,'height':400,
                      'orientation':'vertical','showonepage':'false','onleft':9500,
                      'onright':9500,'onup':9500,'ondown':9500,
                      'visible':'String.IsEqual(Window.Property(discover_grid),true)'}.items():
        ET.SubElement(scrollbar,tag).text=str(value)
    for tag,color in [('texturesliderbackground','FF303238'),('texturesliderbar','FFB6A4FF'),('texturesliderbarfocus','FFE1D8FF')]:
        ET.SubElement(scrollbar,tag,colordiffuse=color).text='special://home/addons/script.strem4kodi/resources/branding/white.png'
