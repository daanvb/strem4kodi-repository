"""Loopback-only, capability-protected live manifest refresh service.

Only built-in channel IDs are accepted. No caller-controlled upstream URL,
registration endpoint, credentials, logs or on-disk stream cache is exposed.
"""
import json
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit

from lib.live_tv_manifest import filter_dash
from lib.live_tv_provider import CHANNEL_IDS, read_https, resolve_channel
from lib.live_tv_commercial import LiveStream, license_response


class LiveServer:
    def __init__(self, resolve=resolve_channel, fetch=read_https, clock=time.monotonic):
        self.resolve, self.fetch, self.clock = resolve, fetch, clock
        self.token = secrets.token_hex(24)
        self.cache = {}
        self.closed = False
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def channel(self, extension):
                parts = urlsplit(self.path)
                prefix = '/' + owner.token + '/'
                if (parts.query or not parts.path.startswith(prefix)
                        or not parts.path.endswith(extension)):
                    return None
                channel = parts.path[len(prefix):-len(extension)]
                if channel not in CHANNEL_IDS or owner.closed:
                    return None
                return channel

            def respond(self, data, content_type):
                if owner.closed:
                    self.send_error(503)
                    return
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                try:
                    self.wfile.write(data)
                except OSError:
                    pass

            def do_GET(self):
                self.connection.settimeout(12)
                metadata = self.path.endswith('.json')
                channel = self.channel('.json' if metadata else '.mpd')
                if not channel:
                    self.send_error(404)
                    return
                try:
                    data = owner.manifest(channel)
                    if metadata:
                        stream = owner.cache[channel][1]
                        data = json.dumps({'widevine': bool(stream.license_url)}).encode('utf-8')
                except Exception:
                    self.send_error(502, 'HD live stream unavailable')
                    return
                self.respond(data, 'application/json' if metadata else 'application/dash+xml')

            def do_POST(self):
                channel = self.channel('.license')
                if not channel:
                    self.send_error(404)
                    return
                try:
                    length = int(self.headers.get('Content-Length', '0'))
                    if self.headers.get('Transfer-Encoding') or not 0 < length <= 1024 * 1024:
                        raise ValueError('size')
                    cached = owner.cache.get(channel)
                    if not cached:
                        raise ValueError('No prepared channel')
                    challenge = self.rfile.read(length)
                    if len(challenge) != length:
                        raise ValueError('Incomplete challenge')
                    data = license_response(cached[1], challenge)
                    self.respond(data, 'application/octet-stream')
                except Exception:
                    self.send_error(502, 'Live licence unavailable')

        class Server(HTTPServer):
            def get_request(self):
                connection, address = super().get_request()
                connection.settimeout(12)
                return connection, address

        self.http = Server(('127.0.0.1', 0), Handler)
        self.http.timeout = 0.25
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    @property
    def base_url(self):
        return 'http://127.0.0.1:{}/{}/'.format(self.http.server_port, self.token)

    def _run(self):
        try:
            while not self.closed:
                self.http.handle_request()
        finally:
            self.http.server_close()

    def manifest(self, channel):
        if self.closed or channel not in CHANNEL_IDS:
            raise ValueError('Live session unavailable')
        cached = self.cache.get(channel)
        if not cached or self.clock() - cached[0] >= 300:
            stream = self.resolve(channel)
            if isinstance(stream, str):
                stream = LiveStream(stream)
            cached = (self.clock(), stream)
            self.cache[channel] = cached
        try:
            data, final_url = self.fetch(cached[1].url)
            result = filter_dash(data, final_url, self.base_url + channel + '.mpd')
        except Exception:
            self.cache.pop(channel, None)
            raise
        if self.closed:
            raise ValueError('Live session ended')
        return result

    def close(self):
        self.closed = True
        self.cache.clear()
        self.thread.join(timeout=0.5)


class LiveService:
    """Start on demand; the Kodi service owns the server lifetime."""
    def __init__(self, window, player=None, clock=time.monotonic):
        self.window = window
        self.server = None
        self.player = player
        self.clock = clock
        self.started = 0
        self.playing = False
        self.window.clearProperty('s4k.live.endpoint')

    def tick(self):
        if self.window.getProperty('s4k.live.request') != 'true':
            if self.server and self.player:
                try:
                    active = (self.player.isPlayingVideo() and
                              self.player.getPlayingFile().startswith(self.server.base_url))
                except Exception:
                    active = False
                if active:
                    self.playing = True
                elif self.playing or self.clock() - self.started > 60:
                    self.close()
            return
        self.window.clearProperty('s4k.live.request')
        if self.server:
            self.server.close()
        self.window.clearProperty('s4k.live.endpoint')
        self.server = LiveServer()
        self.started = self.clock()
        self.playing = False
        self.window.setProperty('s4k.live.endpoint', self.server.base_url)

    def close(self):
        self.window.clearProperty('s4k.live.endpoint')
        self.window.clearProperty('s4k.live.request')
        if self.server:
            self.server.close()
            self.server = None
