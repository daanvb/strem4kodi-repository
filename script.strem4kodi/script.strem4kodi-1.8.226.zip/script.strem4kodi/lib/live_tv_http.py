"""Bounded broadcaster requests; never expose response bodies or signed URLs."""
import json
from urllib.parse import urlsplit
from urllib.request import Request, HTTPRedirectHandler, build_opener

from lib.live_tv_quality import HDUnavailable

UA = 'Mozilla/5.0 (X11; Linux x86_64; rv:131.0) Gecko/20100101 Firefox/131.0'


def secure_url(url):
    parsed = urlsplit(url)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username
            or parsed.password or any(c in url for c in '\r\n|')):
        raise HDUnavailable('Unsupported broadcaster address.')
    return url


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        # Do not forward account/authorisation headers to another origin.
        return None


def request(url, data=None, headers=None, limit=4 * 1024 * 1024):
    secure_url(url)
    values = {'User-Agent': UA, 'Accept-Encoding': 'identity'}
    values.update(headers or {})
    try:
        with build_opener(NoRedirect()).open(Request(url, data=data, headers=values), timeout=15) as response:
            result = response.read(limit + 1)
        if len(result) > limit:
            raise ValueError('size')
        return result
    except Exception:
        raise HDUnavailable('Broadcaster request failed. Check your region or sign in again.') from None


def json_request(url, payload=None, headers=None):
    values = dict(headers or {})
    data = None
    if payload is not None:
        data = json.dumps(payload).encode('utf-8')
        values['Content-Type'] = 'application/json'
    try:
        return json.loads(request(url, data, values))
    except HDUnavailable:
        raise
    except Exception:
        raise HDUnavailable('Invalid broadcaster response.') from None
