"""Read-only, device-local selection of supported hero output badges."""
import re
import threading
import time
from pathlib import Path
from lib.dolby_variants import FEL, TRUEHD_ATMOS

QUALITIES = ('4K', '1080p', '720p', '480p', '360p')
HEIGHTS = {'4K': 2160, '1080p': 1080, '720p': 720, '480p': 480, '360p': 360}
VIDEO = (FEL, 'Dolby Vision', 'HDR10+', 'HDR10', 'HDR')
AUDIO = (TRUEHD_ATMOS, 'TrueHD', 'DTS-HD MA', 'Dolby Digital Plus', 'DTS', 'Dolby Digital')
AUDIO_SETTINGS = {'TrueHD': 'truehd', 'DTS-HD MA': 'dtshd', 'Dolby Digital Plus': 'eac3',
                  'DTS': 'dts', 'Dolby Digital': 'ac3'}


def read_text(path):
    try:
        with Path(path).open(encoding='utf-8', errors='ignore') as stream:
            return stream.read(8192).replace('\x00', '').strip()
    except OSError:
        return ''


def resolution_height(text):
    dimensions = re.search(r'(?<!\d)(\d{3,4})\s*[x×]\s*(\d{3,4})(?!\d)', str(text), re.I)
    if dimensions:
        return int(dimensions[2])
    token = re.search(r'(?<!\d)(2160|1080|720|480|360)[pi](?!\d)', str(text), re.I)
    return int(token[1]) if token else 0


def capabilities(settings, hdr_types='', model='', audio_caps='', display_resolution='', driver_available=False):
    """Settings contains only Kodi's currently visible settings and enable state."""
    def value(key, default=None):
        row = settings.get(key) or {}
        return row.get('value', default) if row.get('enabled') is True else default
    hdr = {part.strip().casefold() for part in str(hdr_types).split(',') if part.strip()}
    videos = set()
    if 'winsystem.ishdrdisplay' not in settings or value('winsystem.ishdrdisplay') is True:
        videos.update(tag for tag in ('Dolby Vision', 'HDR10+', 'HDR10') if tag.casefold() in hdr)
        if 'HDR10' in videos:
            videos.add('HDR')
    allowed = value('videoplayer.allowedhdrformats')
    if 'videoplayer.allowedhdrformats' in settings:
        if not isinstance(allowed, list) or 0 not in allowed: videos.discard('Dolby Vision')
        if not isinstance(allowed, list) or 1 not in allowed: videos.discard('HDR10+')
    mode = value('coreelec.amlogic.dolbyvision.mode')
    dv_output = value('coreelec.amlogic.dolbyvision.vs10.dv')
    if 'coreelec.amlogic.dolbyvision.mode' in settings:
        if type(mode) is not int or mode not in (0, 1) or type(dv_output) is not int or dv_output not in (0, 1):
            videos.discard('Dolby Vision')
        # Only the user's known FEL-capable Ugoos AM6B+ profile is permitted.
        ugoos = re.search(r'\bugoos\b', model, re.I) and re.search(r'\bam6b(?:\s*\+|\s+plus\b)', model, re.I)
        if ugoos and driver_available is True and 'Dolby Vision' in videos:
            videos.add(FEL)
    # Explicit tone-mapping settings must not advertise their native HDR input.
    for key, tag, native_modes in (('hdr10', 'HDR10', (2, 5)), ('hdr10plus', 'HDR10+', (5,))):
        setting = 'coreelec.amlogic.dolbyvision.vs10.' + key
        if 'coreelec.amlogic.dolbyvision.mode' in settings and mode != 2 and value(setting) not in native_modes:
            videos.discard(tag)
            if tag == 'HDR10': videos.discard('HDR')
    audio = set()
    if value('audiooutput.passthrough') is True and value('videoplayer.usedisplayasclock') is not True:
        audio.update(tag for tag, stem in AUDIO_SETTINGS.items()
                     if value('audiooutput.' + stem + 'passthrough') is True)
    # TrueHD capability alone does not establish an Atmos-capable audio system.
    atmos = bool(re.search(r'(?i)\batmos\b', audio_caps)) and not re.search(
        r'(?i)(?:\b(?:no|not|without)\s+atmos\b|\batmos\s*[:=]\s*(?:0|no|false|off)\b|\batmos\s+(?:not supported|unsupported|disabled)\b)', audio_caps)
    if atmos and 'TrueHD' in audio:
        audio.add(TRUEHD_ATMOS)
    resolution = settings.get('videoscreen.resolution') or {}
    labels = [row.get('label', '') for row in resolution.get('options', []) if isinstance(row, dict)]
    # Current output is positive evidence, not a claim about a larger maximum.
    heights = [resolution_height(label) for label in labels + [display_resolution]]
    maximum = max(heights, default=0)
    order = ('HDR10+', FEL, 'Dolby Vision', 'HDR10', 'HDR') if value('coreelec.amlogic.dolbyvision.dual.priority') == 1 else VIDEO
    return {'video': videos, 'video_order': order, 'audio': audio, 'maximum': maximum or None}


def select(found, caps, maximum_setting='0', groups=None):
    tags = set(found)
    ceiling = caps.get('maximum')
    configured = {'1': 2160, '2': 1080, '3': 720}.get(maximum_setting)
    if ceiling is not None and configured is not None:
        ceiling = min(ceiling, configured)
    if groups:
        eligible, excluded = [], False
        for group in groups:
            heights = [HEIGHTS[tag] for tag in group if tag in HEIGHTS]
            if heights and ceiling is not None and max(heights) <= ceiling:
                eligible.append(group)
            else:
                excluded = True
        if not eligible:
            return []
        eligible_tags = {tag for group in eligible for tag in group}
        # A title-level playback observation cannot be assigned to a particular
        # source if some sources exceed this device's ceiling.
        tags = eligible_tags if excluded else tags.union(eligible_tags)
    elif any(tag in tags and (ceiling is None or HEIGHTS[tag] > ceiling) for tag in QUALITIES):
        # Old aggregate summaries cannot associate their HDR/audio with a lower
        # resolution. Show only resolutions explicitly known within the limit.
        tags.intersection_update(QUALITIES)
    if FEL in tags:
        tags.add('Dolby Vision')
    if TRUEHD_ATMOS in tags:
        tags.add('TrueHD')
    # Do not invent a lower-resolution source when only 4K is known.
    quality = next((tag for tag in QUALITIES if tag in tags and ceiling is not None and HEIGHTS[tag] <= ceiling), '')
    video = next((tag for tag in caps.get('video_order', VIDEO) if tag in tags and tag in caps.get('video', ())), '')
    audio = next((tag for tag in AUDIO if tag in tags and tag in caps.get('audio', ())), '')
    return [tag for tag in (quality, video, audio) if tag]


class SupportedOutput:
    def __init__(self, addon, rpc, label, availability, reader=read_text, clock=time.monotonic):
        self.addon, self.rpc, self.label, self.availability = addon, rpc, label, availability
        self.reader, self.clock = reader, clock
        self.lock = threading.Lock()
        self.next_refresh = 0
        self.cached = {'video': set(), 'audio': set(), 'maximum': None}

    def current(self):
        with self.lock:
            if self.clock() < self.next_refresh:
                return self.cached
            self.next_refresh = self.clock() + 5
            settings = {}
            player_settings_known = False
            for section, category in (('system', 'display'), ('system', 'audio'),
                                      ('system', 'coreelec'), ('player', 'videoplayer')):
                try:
                    result = self.rpc('Settings.GetSettings', {'level': 'expert',
                        'filter': {'section': section, 'category': category}})
                    rows = (result or {}).get('settings')
                    if not isinstance(rows, list):
                        continue
                    category_settings = {}
                    for row in rows:
                        if not isinstance(row, dict):
                            raise ValueError('Invalid native setting')
                        key = row.get('id', '')
                        if key in ('videoscreen.resolution', 'winsystem.ishdrdisplay',
                                   'videoplayer.allowedhdrformats', 'videoplayer.usedisplayasclock',
                                   'coreelec.amlogic.dolbyvision.mode', 'coreelec.amlogic.dolbyvision.vs10.dv',
                                   'coreelec.amlogic.dolbyvision.dual.priority',
                                   'coreelec.amlogic.dolbyvision.vs10.hdr10', 'coreelec.amlogic.dolbyvision.vs10.hdr10plus',
                                   'audiooutput.passthrough') or key in {
                                       'audiooutput.' + stem + 'passthrough' for stem in AUDIO_SETTINGS.values()}:
                            category_settings[key] = {field: row[field] for field in ('enabled', 'value', 'options') if field in row}
                    settings.update(category_settings)
                    if section == 'player':
                        player_settings_known = True
                except Exception:
                    continue  # Missing capability evidence never means supported.
            try:
                hdr, display = self.label('System.SupportedHDRTypes'), self.label('System.ScreenResolution')
            except Exception:
                hdr, display = '', ''
            model = self.reader('/proc/device-tree/model') or self.reader('/sys/firmware/devicetree/base/model')
            audio = self.reader('/sys/class/amhdmitx/amhdmitx0/aud_cap')
            try:
                int(self.reader('/sys/module/amdolby_vision/parameters/dolby_vision_flags'), 0)
                driver = True
            except (ValueError, TypeError):
                driver = False
            self.cached = capabilities(settings, hdr, model, audio, display, driver)
            if not player_settings_known:
                self.cached['video'] = set()
            return self.cached

    def __call__(self, meta, found):
        candidates = set(found)
        groups = None
        if hasattr(found, 'available_formats'):
            candidates.update(found.available_formats)
            groups = found.source_formats or None
        else:
            try:
                overview = dict(meta)
                if overview.get('type') == 'series': overview.pop('_focus_video_id', None)
                summary = self.availability(overview)
                if isinstance(summary, dict):
                    candidates.update(summary.get('available_formats') or [])
                    groups = summary.get('source_formats') or None
            except Exception:
                pass
        try:
            maximum = self.addon.getSetting('source_max_quality')
        except Exception:
            maximum = '0'
        return select(candidates, self.current(), maximum, groups)
