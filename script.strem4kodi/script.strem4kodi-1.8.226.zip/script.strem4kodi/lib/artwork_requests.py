"""Process-local artwork single-flight and a shared four-request budget.

No completed responses are retained here. Persistent caches own expiry and
invalidation; callers include their profile, provider and cache generation.
"""
import threading
from copy import deepcopy

_lock = threading.Lock()
_flights = {}
_slots = threading.BoundedSemaphore(4)


def resolve(key, work, cancelled):
    subscriber = object()
    with _lock:
        flight = _flights.get(key)
        owner = flight is None
        if owner:
            flight = {'done': threading.Event(), 'subscribers': {}, 'value': {}}
            _flights[key] = flight
        flight['subscribers'][subscriber] = cancelled

    def abandoned():
        with _lock:
            checks = list(flight['subscribers'].values())
        return not checks or all(check() for check in checks)

    try:
        if owner:
            acquired = False
            try:
                while not abandoned():
                    if _slots.acquire(timeout=.05):
                        acquired = True
                        if not abandoned():flight['value'] = work(abandoned)
                        break
            finally:
                if acquired:_slots.release()
                with _lock:
                    _flights.pop(key, None)
                    flight['done'].set()
        else:
            while not flight['done'].wait(.05):
                if cancelled():return {}
        return {} if cancelled() else deepcopy(flight['value'])
    finally:
        with _lock:
            flight['subscribers'].pop(subscriber, None)
