"""One active worker and one replaceable request; no UI calls on the worker."""
import threading


class LatestJob:
    def __init__(self, thread_factory=threading.Thread):
        self.lock = threading.Lock()
        self.thread_factory = thread_factory
        self.generation = 0
        self.request = self.result = None
        self.running = False

    def cancel(self):
        with self.lock:
            self.generation += 1
            self.request = self.result = None

    def submit(self, work, publish):
        with self.lock:
            self.generation += 1
            self.result = None
            self.request = (self.generation, work, publish)
            if self.running:return
            self.running = True
        try:self.thread_factory(target=self._run, daemon=True).start()
        except RuntimeError:
            with self.lock:
                self.running = False
                self.request = None
            raise

    def submit_progressive(self, work, publish):
        """Coalesce intermediate values in the same latest-only mailbox."""
        def run(alive):
            def emit(value):
                with self.lock:
                    if alive():self.result = (publish, value, False)
            return work(alive, emit)
        self.submit(run, publish)

    def _run(self):
        while True:
            with self.lock:
                job, self.request = self.request, None
                if job is None:
                    self.running = False
                    return
            generation, work, publish = job
            alive = lambda: self.generation == generation
            try:value, failed = work(alive), False
            except Exception:value, failed = None, True
            with self.lock:
                if alive():self.result = (publish, value, failed)

    def take(self):
        with self.lock:
            result, self.result = self.result, None
            return result
