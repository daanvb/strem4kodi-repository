"""Addon-owned full-screen settings UI for Strem4Kodi."""
from pathlib import Path
import textwrap

import xbmc
import xbmcgui
import xbmcvfs

from addon_state import get_addon
from account import Store
from lib.credits_sync import summary as credits_summary
from lib.saved_lists_sync import summary as lists_summary
from lib.format_sync import summary as formats_summary
from lib.theme import window as themed_window
from lib.ui_dialogs import dialog as themed_dialog

ADDON = get_addon()
PROFILE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")))
BACK = (10, 92, 216, 247)

THEMES = ("Purple", "Black", "Blue", "Green", "Gold")
FOCUS = ("Original", "Purple", "Blue", "Green", "Gold", "Theme")
START_DELAYS = ("Immediately", "1 second", "2 seconds", "3 seconds", "5 seconds")
TRAILER_QUALITY = ("1080p", "720p", "480p")
TRAILER_SCOPE = ("While browsing and on details pages", "While browsing only", "On details pages only")
TRAILER_DELAY = ("3 seconds", "5 seconds", "10 seconds", "15 seconds", "30 seconds", "1 second")
CATEGORIES = (
    ("API keys", "api"), ("Providers", "providers"), ("General", "general"), ("Account & Stremio", "account"), ("Playback", "playback"),
    ("Sources", "sources"), ("Auto Play", "autoplay"),
    ("Trailers", "trailers"), ("Skip & Up Next", "episodes"),
    ("Subtitles", "subtitles"), ("Appearance", "appearance"),
    ("Ratings", "ratings"), ("Cache", "cache"), ("Troubleshooting", "diagnostics"),
)
CATEGORY_HELP = {
    'api': 'Connect optional rating and metadata services.',
    'providers': 'Choose add-ons for catalogues, title details and streams.',
    'general': 'Language, region and startup preferences.',
    'account': 'Sign-in, saved lists and sharing between devices.',
    'playback': 'Player behaviour and audio/video output.',
    'sources': 'Stream quality, audio, language and provider preferences.',
    'autoplay': 'Automatic source selection for movies and series.',
    'trailers': 'Preview timing, quality and where trailers play.',
    'episodes': 'Intros, credits and next-episode behaviour.',
    'subtitles': 'Subtitle language, appearance and automatic selection.',
    'appearance': 'Theme, browsing layout and what appears on screen.',
    'ratings': 'Choose which scores appear for titles and episodes.',
    'cache': 'How long responses are kept and how to clear them.',
    'diagnostics': 'Playback tests, request status and performance details.',
}


def information_pages(text):
    """Fixed readable pages for long diagnostics, without scrolling text."""
    lines = []
    for paragraph in str(text or '').splitlines():
        lines.extend(textwrap.wrap(paragraph, width=92) or [''])
    return ['\n'.join(lines[i:i + 16]) for i in range(0, len(lines), 16)] or ['No further details.']


def help_preview(row):
    text = row.get('help', '')
    if row.get('kind') != 'info':return text
    if row.get('summary'):text = str(row['summary']) + '\n\n' + text
    lines = information_pages(text)[0].splitlines()
    return '\n'.join(lines[:4] + ['Press OK for full details.']) if len(lines) > 5 else text


def _enum(setting, label, values, help_text):
    return {"kind": "enum", "id": setting, "label": label, "values": values, "help": help_text}


def _bool(setting, label, help_text):
    return {"kind": "bool", "id": setting, "label": label, "help": help_text}


def _action(action, label, help_text, summary="Open"):
    return {"kind": "action", "action": action, "label": label, "help": help_text, "summary": summary}


def _secret(setting, label, help_text):
    return {"kind": "secret", "id": setting, "label": label, "help": help_text}


def _text(setting, label, help_text):
    if setting.startswith('auto_') and setting.rsplit('_', 1)[-1] in ('provider', 'language'):
        from lib.preference_choices import choices
        from addons_core import active_addons
        base = 'source_' + setting.rsplit('_', 1)[-1]
        labels, values, _ = choices(base, '', list(active_addons(Store(PROFILE).load())))
        from lib.source_preferences import preferences
        inherited = preferences(ADDON)[setting.rsplit('_',1)[-1]] or 'Any provider'
        labels = ['Source preferences · ' + inherited] + labels
        values = ['__inherit__'] + ['__any__' if v in ('', 'Any') else v for v in values]
        current = ADDON.getSetting(setting) or '__inherit__'
        if current not in values:values.append(current);labels.append(current)
        return _choice(setting, label, labels, values, values.index(current), help_text)
    if setting in ('source_provider', 'source_language', 'manifest'):
        from lib.preference_choices import choices
        from addons_core import active_addons
        labels, values, selected = choices(setting, ADDON.getSetting(setting).strip(), list(active_addons(Store(PROFILE).load())))
        return _choice(setting, label, labels, values, selected, help_text)
    return {"kind": "text", "id": setting, "label": label, "help": help_text}


def _info(label, summary, help_text):
    return {"kind": "info", "label": label, "summary": summary, "help": help_text}


def _choice(identity, label, labels, values, selected, help_text):
    return {
        "kind": "choice", "id": identity, "label": label,
        "labels": tuple(labels), "values": tuple(values), "selected": int(selected),
        "summary": str(labels[selected]) if labels and 0 <= selected < len(labels) else "Choose",
        "help": help_text,
    }


def _kodi(setting, label, help_text):
    return {"kind": "kodi", "id": setting, "label": label, "help": help_text}


def _kodi_definition(setting_id):
    try:
        from setup_profile import rpc
        settings = rpc("Settings.GetSettings", {"level": "expert"}).get("settings", [])
        return next((item for item in settings if item.get("id") == setting_id), None)
    except Exception:
        return None


def _kodi_options(definition):
    if not definition:
        return []
    try:
        from settings_ui import setting_options
        return setting_options(definition)
    except Exception:
        return []


def _kodi_rows():
    return [
        _kodi("subtitles.fontsize", "Subtitle text size", 'Set Kodi’s text-subtitle size for playback on this device. Image-based subtitles keep their original appearance.'),
        _kodi("subtitles.fontname", "Subtitle font", 'Choose Kodi’s font for text subtitles on this device. Image-based subtitles are unaffected.'),
        _kodi("subtitles.style", "Subtitle style", 'Choose normal, bold or italic text subtitles where supported. Applies to Kodi playback on this device.'),
        _kodi("subtitles.colorpick", "Subtitle color", 'Choose Kodi’s text-subtitle colour on this device. Embedded styles may take priority unless overridden below.'),
        _kodi("subtitles.align", "Subtitle position", 'Choose where Kodi places text subtitles vertically on this device.'),
        _kodi("subtitles.backgroundtype", "Background style", 'Choose whether Kodi draws a background behind text subtitles and which style it uses.'),
        _kodi("subtitles.bordercolorpick", "Border color", 'Choose the outline colour around Kodi’s text subtitles.'),
        _kodi("subtitles.bgcolorpick", "Background color", 'Choose the colour behind Kodi’s text subtitles when a background is enabled.'),
        _kodi("subtitles.shadowcolor", "Shadow color", 'Choose the shadow colour for Kodi’s text subtitles.'),
        _kodi("subtitles.overridestyles", "Override embedded styles", 'Choose whether Kodi replaces styles embedded in subtitle files with your settings above. Applies to Kodi playback on this device.'),
    ]


def _rows_for(category):
    if category == "general":
        from lib.settings import load_setup
        from lib.windows import LANGUAGES, REGIONS
        setup = load_setup()
        language = setup.get("language") or LANGUAGES[0]
        region = setup.get("region") or REGIONS[0]
        language_index = next((i for i, row in enumerate(LANGUAGES) if tuple(row) == tuple(language)), 0)
        region_index = next((i for i, row in enumerate(REGIONS) if tuple(row) == tuple(region)), 0)
        return [
            _bool("startup_autostart", "Launch when Kodi starts", 'Open Strem4Kodi automatically when Kodi starts. Startup delay below controls how long Kodi waits.'),
            _action('discover_opening', 'Discover opening list', 'Choose a movie or series list, Most Anticipated, or the last visited list. Applies when opening Discover from the sidebar and is saved on this device.'),
            _enum("startup_delay", "Startup delay", START_DELAYS, 'Wait this long after Kodi starts before opening Strem4Kodi. Applies only when Launch when Kodi starts is on.'),
            _choice("locale_language", "Language", [row[0] for row in LANGUAGES], LANGUAGES,
                    language_index, 'Choose the preferred language for Strem4Kodi metadata. This does not change Kodi’s interface language or the audio language of streams.'),
            _choice("locale_region", "Location / region", [row[0] for row in REGIONS], REGIONS,
                    region_index, 'Choose the region used for regional metadata and age-rating preferences. This does not change stream availability.'),
        ]
    if category == "account":
        token=Store(PROFILE).load().get("token")
        connected = bool(token)
        from lib.progress_outbox import summary
        sync_status=summary(PROFILE,token)
        rows = [
            _info("Account sync", sync_status, 'Watch progress uploads every 30 seconds and idle devices refresh every minute. Pending updates are queued watch-progress changes, not app updates. Use the same Stremio account on each device; this status refreshes automatically.'),
            _info("Progress upload status", Store(PROFILE/'progress-sync-status').load().get('error') or 'Ready', 'Shows the last watch-progress upload result. Failed changes remain queued and retry automatically. Sync account now requests another attempt.'),
            _info("Stremio account", "Connected" if connected else "Not connected",
                  'Shows whether this device is signed in. The account supplies your library, installed addons and shared watch progress.'),
        ]
        rows += ([
            _action("account_refresh", "Sync account now", 'Refresh your Stremio library and retry queued watch-progress uploads in the background. Library refresh runs when playback is idle; check Account sync for the result.', "Sync"),
            _action("account_disconnect", "Disconnect this device", 'Sign out on this device and remove its account-synced addons. Other devices remain signed in.', "Disconnect"),
        ] if connected else [
            _action("account_signin", "Connect Stremio account", 'Sign in using the QR code. Use the same Stremio account on every device to share your library and watch progress.', "Connect"),
        ])
        rows += [
            _bool("lists_github_enabled", "Sync favourites and watchlist tags", 'Share My Favourites and My Watchlist classifications through your private GitHub repository. Enable this and add the private GitHub sync token on each device using the same Stremio account. Saved titles and progress still sync through Stremio.'),
            _info("Saved lists sync", lists_summary(PROFILE, ADDON), 'Shows private GitHub tag sync status. Changes normally sync within a minute while Kodi is running. Each device needs this option enabled and access to the same private repository.'),
            _bool("formats_github_enabled", "Share format database between devices", 'Reuse technical format information on every device through your existing private GitHub sync repository. Uses the same private GitHub token. No stream links, credentials or watch progress are shared. Known formats are retained; opening a title can refresh them within the existing request budget.'),
            _info("Format database sync", formats_summary(PROFILE, ADDON), 'Local lookups need no network. Sharing requires the private GitHub sync token on each device. Updates run at startup and every five minutes.'),
            _bool("formats_slow_scan", "Slow background format discovery", 'Learn missing formats after three minutes of settled playback, then at most one title every three minutes across linked devices. Prioritises Watchlist / Up Next, recent browsing, then Popular / Trending. Uses one AIOStreams add-on; pauses outside playback, during buffering and near the end. Requires format sharing and a private GitHub token. Errors pause scans for 30 minutes; titles are tried at most daily. Other apps share your allowance.'),
            _bool("credits_github_enabled", "Sync smart credits between devices", 'Share learned credits timings and series overrides between your devices using the same private GitHub repository. Add a private GitHub sync token under API keys on each device. Stremio watch-progress sync is separate.'),
            _secret("credits_github_token", "Private GitHub sync token", 'Add a fine-grained GitHub token for the private strem4kodi-sync repository with Contents read/write access. Use the same repository on each device and enable the desired list/credits sync under Account & Stremio. Opens the Kodi keyboard for phone-app typing or pasting.'),
            _info("Smart credits sync", credits_summary(PROFILE, ADDON), 'Shows the status of learned credits and series-override sharing. Each device needs smart credits sync enabled and access to the same private GitHub repository. Watch progress uses Stremio separately.'),
            _action("addons", "Stremio addons", 'Manage the Stremio addons available to this account, including catalogue, stream and subtitle providers.', "Manage"),
            _text("manifest", "Fallback catalogue", 'Choose the fallback catalogue manifest for compatibility views. Account Home and Discover use enabled installed catalogues. Metadata, artwork and search preferences are under Providers.'),

        ]
        return rows
    if category == 'autoplay':
        rows = [_info('Automatic source selection', 'Separate content profiles', 'Choose settings separately for Movies, Series and Animated series. Animated movies use Movies. Use source preferences inherits the matching setting under Sources; each profile can be switched off independently.'),
                _enum('auto_source_attempts', 'Maximum automatic attempts', ('3 sources', '5 sources', '10 sources', '25 sources'), 'Try up to this many different eligible sources when automatic playback fails. Failed URLs are skipped during this session. If the attempts run out, open the source picker for manual selection.')]
        for scope, label in (('movie', 'Movies'), ('series', 'Series'), ('animation', 'Animated series')):
            for row in _category_rows('auto_' + scope):
                row['label'] = label + ' · ' + row['label']
                rows.append(row)
        return rows
    if category in ('auto_movie', 'auto_series', 'auto_animation'):
        return [
            _enum(category + '_mode', 'Source selection', ('Off — choose manually', 'Highlight best match', 'Auto play best match'), 'Off opens the source picker. Highlight best match selects a suggested source without starting it. Auto play starts the best eligible match, tries alternatives on failure, then offers manual selection. If no exact match exists, it uses the closest match within Maximum stream quality.'),
            _enum(category + '_quality', 'Preferred quality', ('Use source preferences', 'Any', '4K', '1080p', '720p'), 'Prefer this resolution for this content profile. Use source preferences inherits Sources; Any adds no resolution preference. The device’s Maximum stream quality still applies.'),
            _enum(category + '_dynamic', 'Preferred video format', ('Use source preferences', 'Any', 'Dolby Vision', 'HDR10', 'FEL reported'), 'Prefer sources reporting this format for this profile. Use source preferences inherits Sources; Any adds no format preference. Reported FEL is a claim, not a verified file check.'),
            _enum(category + '_audio', 'Preferred audio', ('Use source preferences', 'Any', 'Atmos', 'TrueHD', 'Dolby Digital Plus', 'AAC'), 'Prefer sources reporting this audio format for this profile. Use source preferences inherits Sources; Any adds no audio-format preference.'),
            _enum(category + '_sort', 'Source order', ('Use source preferences', 'Recommended', 'Provider order', 'Smallest first', 'Largest first'), 'Choose how matches for this profile are ordered. Use source preferences inherits Sources. If no exact match exists, autoplay uses the closest available match.'),
            _text(category + '_provider', 'Preferred provider', 'Prefer this installed provider for this profile. Use source preferences inherits Sources; Any provider removes the provider preference. Other providers can be used as a fallback.'),
            _text(category + '_language', 'Preferred audio language', 'Prefer streams reporting this audio language for this profile. Use source preferences inherits Sources; Any removes the language preference. Unknown languages can still be used.'),
        ]
    if category == "playback":
        return [
            _enum("coreelec_preset", "Reduce interface load", ("Normal quality", "Reduced load"), 'Reduce interface animations, trailer resolution and background work for devices that need it. Does not change video decoding or maximum stream quality. Reopen Strem4Kodi after changing.'),
            _enum("source_sort", "Source order", ("Recommended", "Provider order", "Smallest first", "Largest first"), 'Choose how the source list is ordered. Recommended ranks your preferences first; Provider order keeps the returned order. Size sorting puts sources without a reported size last.'),
            _bool("source_group_duplicates", "Group duplicate releases", 'Combine releases with the same filename and matching reported video and audio details. Select a grouped release to choose between its providers.'),
            _enum("source_quality", "Preferred stream quality", ("Any", "4K", "1080p", "720p"), 'Rank this resolution ahead of others. This is a preference: other resolutions remain available unless Maximum stream quality excludes them.'),
            _enum("source_max_quality", "Maximum stream quality", ("Any", "4K", "1080p", "720p"), 'Hide known resolutions above this limit on this device, including during autoplay. Sources with unknown resolution remain available. Choose 1080p for a Full HD screen.'),
            _enum("source_dynamic", "Preferred video format", ("Any", "Dolby Vision", "HDR10", "FEL reported"), 'Rank sources reporting this video format first. This does not verify compatibility or prove that a Profile 7 stream contains FEL.'),
            _text("source_provider", "Preferred source provider", 'Rank sources from this installed provider first. Other providers remain available. Autoplay profiles can inherit or override this preference.'),
            _enum("source_audio", "Preferred audio", ("Any", "Atmos", "TrueHD", "Dolby Digital Plus", "AAC"), 'Rank sources reporting this audio format first. This is a preference, not a filter; your device and audio equipment determine playback support.'),
            _text("source_language", "Preferred audio language", 'Rank streams reporting this audio language first. English is the default. Sources with other or unknown languages remain available.'),
            _bool("source_remember_filters", "Remember source filters", 'Keep your Source, Audio, Video and Quality filters between source-picker visits on this device. Clear filters restores all results within Maximum stream quality.'),
            _bool("fel_labels", "Show FEL source hints", 'Show filename claims and community disc hints for FEL. A disc hint does not confirm that the selected stream contains FEL. The public hints list downloads in the background without sending your viewing history.'),
            _bool("trailers_enabled", "Allow trailers", 'Allow manual trailers and automatic previews where a direct IMDb trailer is available. Turn this off to disable both.'),
            _enum("trailers_quality", "Trailer quality", TRAILER_QUALITY, 'Prefer this trailer resolution when available. Reduced interface load may lower it. This does not change movie or episode playback quality.'),
            _bool("trailers_auto", "Play trailers automatically", 'Start a trailer after focus stays on an eligible title for the selected delay. Requires Allow trailers. Continue Watching items are excluded.'),
            _enum("trailers_auto_scope", "Where to play trailers", TRAILER_SCOPE, 'Choose whether automatic previews run while browsing, on details pages, or both. Requires Allow trailers and Play trailers automatically.'),
            _enum("trailers_delay", "Wait before playing a trailer", TRAILER_DELAY, 'Keep the same title highlighted for this long before its automatic trailer starts. Moving to another item resets the wait.'),
            _bool("up_next_enabled", "Up Next floating card", 'Show a floating card for the next episode when credits begin or the fallback time is reached. Play Next uses that episode’s Auto Play profile.'),
            _bool("up_next_smart", "Estimate missing credits timing", 'Estimate typical credits length from at least three consistent episodes with IntroDB markers or manually marked credits starts. Use this estimate when an episode has no marker. Manual episode markers and series overrides take priority; smart credits sync shares samples and overrides between devices.'),
            _enum("up_next_lead", "Up Next fallback timing", ("60 seconds", "2 minutes", "3 minutes", "5 minutes"), 'Show Up Next this long before the end only when there is no IntroDB credits marker, series override or reliable learned timing. Short episodes may need a shorter fallback.'),
            _bool("introdb_enabled", "IntroDB skip buttons", 'Enable skip buttons using community timestamps from IntroDB. No API key is needed. Buttons appear only when that episode has a matching marker and its switch below is on.'),
            _bool("introdb_intro", "Show Skip Intro", 'Show Skip Intro during a marked opening sequence. Requires IntroDB skip buttons and an intro marker for the episode.'),
            _bool("introdb_recap", "Show Skip Recap", 'Show Skip Recap during a marked recap. Requires IntroDB skip buttons and a recap marker for the episode.'),
            _bool("introdb_outro", "Show Skip Outro", 'Show Skip Outro during marked closing credits. Requires IntroDB skip buttons and an outro marker for the episode.'),
            _bool("introdb_post_credits", "Show Skip Post-Credits", 'Show Skip Post-Credits during a marked post-credits section. Requires IntroDB skip buttons and a matching marker for the episode.'),
            _enum("playback_back_action", "Back during fullscreen playback", ("Kodi default", "Stop with one press", "Stop with two presses"), 'Choose how Back behaves during fullscreen video on this device. With two presses, press Back again within three seconds to stop and return to browsing. Applies to all Kodi fullscreen videos; player menus keep their normal Back behaviour.'),
            _bool("prerolls_enabled", "Movie audio pre-rolls", 'Play a short Dolby introduction before starting a movie from the beginning. Matches the chosen source’s reported audio. A random matching SDR clip is preferred. Press OK, then Skip pre-roll to start the movie. Back cancels playback. Clips stream from the public GitHub release; its file list refreshes hourly in the background. Episodes and resumes skip them.'),
            _enum("prerolls_dts", "DTS movie pre-roll", ("Play Dolby Digital pre-roll", "Skip pre-roll"), 'Choose what to do when the selected movie source reports DTS without a Dolby audio option. This controls the introduction only; it does not convert the movie’s DTS audio.'),
            _enum("scrub_commit", "Scrub seek confirmation", ("Seek on release", "Press OK to seek"), 'Choose how to jump to the time shown above the timeline. Seek on release: move with Left/Right, then let go to jump automatically. Press OK to seek: releasing keeps the preview without moving the video; press OK when ready. Back cancels a pending preview. Tap moves 10 seconds; holding gradually moves faster.'),
            _enum("playback_controls_hide", "Hide playback controls after", ("Kodi default", "5 seconds", "10 seconds", "15 seconds"), 'Hide Kodi’s control bar after this much inactivity during Strem4Kodi playback. Controls stay visible while paused, seeking or adjusting audio/subtitle settings. Kodi default leaves hiding to Kodi and your skin. Other Kodi videos are unaffected.'),
            _bool("chaptersdb_enabled", "ChaptersDB fallback", 'When embedded chapters are absent or their start times cannot be read, look up chapter lists on ChaptersDB from the player Settings menu. Choose the matching edition before seeking; chapter timings may differ between releases. Results are cached locally for 24 hours. No account key is sent.'),
        ]

    if category == "subtitles":
        common = [
            _bool("subtitles_default_off", "Start with subtitles off", 'Start Strem4Kodi videos without full subtitles, regardless of Kodi’s saved defaults. Automatic forced subtitles below can still enable matching forced tracks. Manual selections are respected. Turn off to retain Kodi’s subtitle defaults.'),
            _enum("forced_subtitles_mode", "Automatic forced subtitles", ("Off", "Embedded tracks only", "Embedded tracks, then matching addon download"), 'Use English forced subtitles for foreign dialogue when full subtitles are off. Prefer marked tracks in the video; downloads require an explicitly forced result with the exact release filename from your Stremio subtitle addons. Manual subtitle choices take priority.'),
            _enum("forced_subtitles_language", "Forced subtitle language", ("English", "Kodi preferred subtitle language"), 'English is the default. Kodi preferred subtitle language follows this device’s Kodi language setting. Forced-only or original uses the active audio language. No subtitles are selected when that language is unknown.'),
        ]
        return common + _kodi_rows()
    if category == "appearance":
        return [
            _action("player_skin", "Player appearance", "Strem4Kodi Player is installed alongside the app from our repository on Kodi 21 or later. Choose it under Kodi Interface > Skin to activate the matching playback bar and audio controls. This opens that page; you can switch back to your previous skin there too.", "Kodi skins"),
            _enum("ui_theme", "Theme", THEMES, 'Choose the colour theme for Strem4Kodi windows. Kodi’s own skin is unaffected.'),
            _enum("ui_focus_color", "Poster focus color", FOCUS, 'Choose the outline colour used to highlight posters and cards. Theme follows the selected Strem4Kodi theme.'),
            _bool("ui_animations", "Animations", 'Animate transitions in Strem4Kodi. Turn this off for a steadier interface or lower interface load.'),
            _bool("ui_dim_rows", "Dim rows with side menu", 'Darken the content rows while the side menu has focus, making navigation easier to see.'),
            _bool("ui_show_logo", "Title logos", 'Use a title’s graphic logo when available. A text title is used when no logo is supplied.'),
            _enum("episode_spoilers", "Episode spoiler protection", ("Off", "Blur unwatched episodes", "Blur unless provider artwork"), "Off uses the supplied artwork, including any provider blur. Blur unwatched episodes softens all unwatched thumbnails. Blur unless provider artwork keeps supplied thumbnails untouched and softens fallback artwork only. Watched episodes use the original supplied image."),
            _bool("ui_show_plot", "Descriptions", 'Show the highlighted title’s description on browsing and details pages.'),
            _bool("ui_show_rating", "Ratings", 'Show rating badges in the browsing hero and on details pages. Choose providers under Ratings; episode-card visibility has separate switches there.'),
            _action("catalogue_layout", "Catalogue thumbnails", 'Choose Posters or Wide thumbnails separately for each installed catalogue. Changes apply when you return to browsing.', "Choose"),
            _bool("ui_show_genres", "Genres", 'Show genres alongside the highlighted title’s year and runtime on browsing and details pages.'),
            _bool("ui_show_runtime", "Runtime", 'Show the supplied running time for the highlighted movie or series on browsing and details pages.'),
        ]
    if category == "ratings":
        rows = [
            _info("Rating visibility", "How ratings work", "Show Movie Rating covers movies and the overall series rating, and enables this provider. Show Episode Rating controls episode cards only; both must be on for episodes. The episode switch does not change movie or overall series ratings. Missing episode scores are omitted, never replaced with a series score."),
            _info("TMDB credits", "Photos and recommendations", "Cast photos, recommendations and TMDB episode ratings use TMDB. This product uses the TMDB API but is not endorsed or certified by TMDB. www.themoviedb.org"),
        ]
        for key, label in (("imdb", "IMDb"), ("tmdb", "TMDB"), ("trakt", "Trakt"),
                           ("tomatoes", "Rotten Tomatoes"), ("tomatoesaudience", "Popcornmeter"), ("metacritic", "Metacritic")):
            rows.append(_bool("rating_" + key, "Show Movie Rating - " + label,
                              "Show " + label + " ratings on movies and series, and allow them on episode cards. Turning this off also hides this provider on episodes. Scores appear only when supplied; additional title ratings may require the MDbList API key."))
            requirement = ("TMDB episode scores require your TMDB API key." if key == "tmdb" else
                           "The metadata provider must supply an actual episode score. MDbList title ratings cannot supply missing episode scores.")
            rows.append(_bool("episode_rating_" + key, "Show Episode Rating - " + label,
                              "Show " + label + " on episode cards when Show Movie Rating above is on. This does not change movie or series ratings. " + requirement))
        rows += [
            _bool("rating_mdblist", "Show Movie Rating - MDBList score", "Show the MDBList combined score on movies and series, and enable MDBList episode ratings. Requires your MDBList API key."),
            _bool("episode_rating_mdblist", "Show Episode Rating - MDBList", "Show MDBList's episode score when Show Movie Rating - MDBList score is on. Requires an API key from an MDBList Supporter account. Free accounts provide only an overall summary, which is never used as an episode rating. IMDb, TMDB and Rotten Tomatoes switches remain separate."),
            _bool("rating_letterboxd", "Show Movie Rating - Letterboxd", "Show Letterboxd ratings on movies and series when MDbList supplies them. Requires your MDbList API key; episode cards do not use this provider."),
        ]
        return rows

    if category == "cache":
        from lib.cache_policy import GROUPS, setting_id, parse_duration, parse_size, format_duration, format_size
        from lib.maintenance import PRESETS, SIZES
        rows = []
        duration_labels = [format_duration(parse_duration(value)) for value in PRESETS]
        for group, label, default in GROUPS:
            current = ADDON.getSetting(setting_id(group)) or default
            values = list(PRESETS)
            labels = list(duration_labels)
            if current not in values:
                try:
                    labels.append(format_duration(parse_duration(current)))
                    values.append(current)
                except ValueError:
                    current = default
            selected = values.index(current)
            rows.append(_choice("cache_ttl:" + group, label, labels, values, selected,
                                'Keep responses in this category for this long before fetching fresh data. Shorter times update more often; longer times reduce repeated requests.'))
        current_size = ADDON.getSetting("cache_max_mb") or "64"
        size_labels = [format_size(parse_size(value)) for value in SIZES]
        size_values = list(SIZES)
        if current_size not in size_values:
            try:
                size_labels.append(format_size(parse_size(current_size)))
                size_values.append(current_size)
            except ValueError:
                current_size = "64"
        size_selected = size_values.index(current_size)
        rows.append(_choice("cache_size", "Maximum response data", size_labels, size_values, size_selected,
                            'Limit disk space used by cached provider responses. Older entries are removed as needed. Does not limit Kodi’s artwork cache.'))
        rows += [
            _action("cache_clear_selected_custom", "Clear one cache category",
                    'Choose one category of cached responses to remove. New responses are fetched when needed. Sign-in, library and saved playback progress are kept.', "Choose"),
            _action("cache_clear_all_custom", "Clear all response caches",
                    'Remove cached catalogue, search, metadata and rating responses so they can be fetched again. Sign-in, library and saved playback progress are kept.', "Clear"),
        ]
        return rows
    return []


def _category_rows(category):
    """One home for each setting; saved setting IDs remain compatible."""
    if category == 'providers':
        from lib.provider_config import state as provider_state
        from provider_roles import choices, overlaps, preference, selected
        state = provider_state(PROFILE)
        rows = []
        definitions = (
            ('metadata', 'Title and episode details', 'Use this add-on first for descriptions, seasons and episode details. Other enabled metadata add-ons fill missing fields; Cinemeta is the final fallback.'),
            ('artwork', 'Posters and artwork', 'Use this add-on for posters across Home, Continue Watching, Up Next, Library, search and catalogues. Episode thumbnails also prefer this provider when supplied. Automatic uses AIOMetadata when enabled. Missing posters keep catalogue artwork.'),
            ('ratings', 'Metadata rating priority', 'Prefer ratings if this metadata add-on supplies them. Metadata support does not guarantee ratings or episode scores. TMDB and MDbList enrichment and rating visibility are controlled under Ratings and API keys.'),
            ('search', 'Movie and series search', 'Use this add-on first for both suggestions and full search. Other enabled search add-ons and Cinemeta fill full-search results. Suggestions fall back when the chosen provider returns no relevant titles. Automatic keeps fast IMDb suggestions.'),
            ('streams', 'Stream add-ons', 'Use all enabled stream add-ons, or restrict source requests to one add-on. Source filters still control which returned releases appear.'),
            ('subtitles', 'Subtitle add-ons', 'Use all enabled subtitle add-ons, or restrict downloaded subtitles to one add-on. Embedded subtitles stay available. Forced subtitle rules and language preferences still apply.'),
        )
        for role, label, help_text in definitions:
            labels, values, index = choices(state, role)
            if preference(state, role) and selected(state, role) is None:
                help_text += ' Your previous choice is disabled or uninstalled; the automatic fallback is active.'
            if len(values) == 1:
                rows.append(_info(label, 'No eligible installed add-ons', help_text +
                                  ' No enabled installed add-on advertises this capability in its saved manifest. Check Account & Stremio → Stremio addons.'))
            else:
                rows.append(_choice('provider_role:' + role, label, labels, values, index, help_text))
        rows.append(_action('artwork_refresh', 'Refresh artwork', 'Fetch preferred posters again for the current page. Catalogue lists, sign-in and watched progress are kept. Providers and Kodi may still cache unchanged image URLs.', 'Refresh'))
        for role, suppliers, primary in overlaps(state):
            rows.append(_info(role.title() + ' suppliers', suppliers,
                              suppliers + '. These add-ons advertise compatible resources. Metadata support alone does not prove that posters or ratings are included. Use the choice above to set priority or limit requests.'))
        return rows
    if category == 'diagnostics':
        from lib.troubleshooting import settings_rows
        return settings_rows(PROFILE)
    if category == 'api':
        return [_secret('tmdb_api_key', 'TMDB API key', 'Add your TMDB API key for cast photos, recommendations and TMDB episode ratings. Stored on this device. Opens the Kodi keyboard for phone-app typing or pasting.'),
                _secret('mdblist_api_key', 'MDbList API key', 'Add your MDbList API key for additional movie and series ratings, including Rotten Tomatoes and Metacritic. It does not supply episode scores for these cards. Opens the Kodi keyboard for phone-app typing or pasting.'),
                _secret('credits_github_token', 'Private GitHub sync token', 'Add a fine-grained GitHub token for the private strem4kodi-sync repository with Contents read/write access. Use the same repository on each device and enable the desired list/credits sync under Account & Stremio. Opens the Kodi keyboard for phone-app typing or pasting.')]
    if category in ('playback', 'sources', 'trailers', 'episodes'):
        groups = {'sources': ('source_', 'fel_'), 'trailers': ('trailers_',),
                  'episodes': ('up_next_', 'introdb_')}
        rows = _rows_for('playback')
        def group(row):
            identity = row.get('id', '')
            return next((key for key, prefixes in groups.items() if identity.startswith(prefixes)), 'playback')
        return [row for row in rows if group(row) == category]
    return [row for row in _rows_for(category) if row["kind"] != "secret"]


def rows_for(category):
    from lib.settings_dependencies import applicable
    rows = applicable(_category_rows(category), ADDON.getSetting)
    if category == 'subtitles':
        # One capability request per page, rather than querying for every row.
        from setup_profile import rpc
        try:
            definitions = rpc('Settings.GetSettings', {'level': 'expert'}).get('settings', [])
        except Exception:
            definitions = []
        supported = {row.get('id'): row for row in definitions if row.get('enabled', True)}
        missing = any(row['kind'] == 'kodi' and row['id'] not in supported for row in rows)
        rows = [dict(row, definition=supported[row['id']]) if row['kind'] == 'kodi' else row
                for row in rows if row['kind'] != 'kodi' or row['id'] in supported]
        if missing:
            rows.append(_info('Additional subtitle appearance controls', 'Unavailable on this device',
                              'Only controls supported by this Kodi build are shown. Your saved subtitle preferences are kept.'))
    for index, row in enumerate(rows):
        identity = row.get('id', '')
        parent = identity in ('startup_autostart', 'trailers_enabled', 'trailers_auto', 'introdb_enabled',
                              'up_next_enabled', 'prerolls_enabled', 'formats_github_enabled', 'rating_imdb', 'rating_tmdb',
                              'rating_trakt', 'rating_tomatoes', 'rating_tomatoesaudience', 'rating_metacritic', 'rating_mdblist')
        if parent or (identity.startswith('auto_') and identity.endswith('_mode')):
            row = row.copy()
            row['help'] = row.get('help', '') + ' Related options appear when enabled; hidden preferences are kept.'
            rows[index] = row
    return rows


def _index_value(setting, values):
    try:
        index = int(ADDON.getSetting(setting) or {"auto_source_attempts":"1", "forced_subtitles_mode":"2"}.get(setting, "0"))
    except (TypeError, ValueError):
        index = 0
    return values[index] if 0 <= index < len(values) else values[0]


def summary(row):
    kind = row["kind"]
    if kind == "bool":
        return "On" if ADDON.getSetting(row["id"]).lower() == "true" else "Off"
    if kind == "enum":
        return _index_value(row["id"], row["values"])
    if kind == "secret":
        return "Configured" if ADDON.getSetting(row["id"]).strip() else "Not set"
    if kind == "text":
        value = ADDON.getSetting(row["id"]).strip()
        if row["id"] == "manifest":
            return "Official Cinemeta" if "v3-cinemeta.strem.io" in value else ("Custom" if value else "Default")
        return value or "Not set"
    if kind == "choice":
        return row.get("summary", "Choose")
    if kind == "kodi":
        definition = row.get("definition") or _kodi_definition(row["id"])
        if not definition:
            return "Unavailable"
        value = definition.get("value")
        options = _kodi_options(definition)
        match = next((str(option.get("label")) for option in options
                      if option.get("value") == value), None)
        if match:
            return match
        if isinstance(value, bool):
            return "On" if value else "Off"
        return str(value)
    return row.get("summary", "")


def _set_bool(row):
    current = ADDON.getSetting(row["id"]).lower() == "true"
    ADDON.setSetting(row["id"], "false" if current else "true")


def _set_text(row):
    current = ADDON.getSetting(row["id"]).strip()
    value = themed_dialog().input(row["label"], defaultt=current, type=xbmcgui.INPUT_ALPHANUM)
    if not value.strip():
        return False
    if row["id"] == "manifest":
        from protocol import base_url
        try:
            base_url(value.strip())
        except Exception:
            themed_dialog().ok("Catalog manifest", "Use an HTTP(S) URL ending in /manifest.json.")
            return False
    ADDON.setSetting(row["id"], value.strip())
    return True


def run_action(action, owner=None):
    if action == 'fel7_test':
        from lib.player_tests import play_fel7
        play_fel7(ADDON,PROFILE,themed_dialog(),xbmc,xbmcgui,owner)
        return
    if action == 'artwork_refresh':
        from lib.provider_config import refresh_artwork
        refresh_artwork(PROFILE)
        if owner is not None:
            owner.providers_changed = True
        themed_dialog().notification('Artwork', 'Preferred posters will refresh when you return to browsing.')
        return
    if action == 'startup_benchmark':
        from lib.low_power_benchmark import run
        from lib.troubleshooting import benchmark_summary
        from lib.ui_dialogs import progress_bg
        progress = progress_bg()
        try:
            progress.create('Startup checks', 'Measuring cached browsing on this device…')
            result = run(PROFILE)
        finally:
            progress.close()
        themed_dialog().ok('Cached browsing checks', benchmark_summary(result))
        if owner is not None:
            owner.refresh_rows()
        return
    if action == 'player_skin':
        if owner is not None:
            owner.close()
        xbmc.executebuiltin('ActivateWindow(10032)')
        return
    if action == 'discover_opening' and owner is not None:
        from lib import backend as api
        from lib.discover_preferences import Preferences
        preferences = Preferences(PROFILE)
        labels, values = preferences.opening_options(api.discover_choices())
        opening = preferences.data.get('opening', {})
        selected = next((i for i, value in enumerate(values) if value['mode'] == opening.get('mode', 'last') and (value['mode'] != 'list' or (value['catalog']['kind'], value['catalog']['id']) == (opening.get('kind'), opening.get('id')))), 0)
        owner.open_command('discover_opening_choice', 'Discover opening list', labels, values,
                           'Choose what opens when you enter Discover. Saved on this device.', selected=selected)
        return
    if action == 'catalogue_layout' and owner is not None:
        from lib import backend as api
        rows = api.discover_choices()
        if not rows:
            themed_dialog().notification('Catalogue thumbnails', 'No installed catalogues are available.')
            return
        owner.open_command('catalogue_choose', 'Choose catalogue', [r['label'] + ' · ' + r['addon'] for r in rows], rows,
                           'Choose the catalogue whose thumbnail layout you want to change.')
        return
    if action == "account_signin":
        from lib.signin import show_signin
        show_signin()
    elif action == "account_refresh":
        xbmcgui.Window(10000).setProperty("strem4kodi.sync.manual", "true")
        xbmcgui.Window(10000).setProperty("strem4kodi.sync.request", "true")
        themed_dialog().notification("Strem4Kodi", "Retrying progress uploads now. Library refresh runs when playback is idle.")
    elif action == "account_disconnect" and owner is not None:
        owner.open_command(
            "account_disconnect", "Disconnect this device",
            ["Disconnect this device", "Cancel"], ["disconnect", "cancel"],
            "Removes this device login and account-synced addons. Your online Stremio account is unchanged."
        )
    elif action == "addons":
        if owner is not None:
            owner.request_page = "addons"
            owner.close()
    elif action == "cache_clear_selected_custom" and owner is not None:
        from lib.cache_policy import GROUPS
        labels = [label for _, label, _ in GROUPS] + ["Older entries", "Cancel"]
        values = [key for key, _, _ in GROUPS] + ["legacy", "cancel"]
        owner.open_command(
            "cache_clear_one", "Clear one cache category", labels, values,
            "Only the selected response cache is cleared. Login, library and playback data stay."
        )
    elif action == "cache_clear_all_custom" and owner is not None:
        owner.open_command(
            "cache_clear_all", "Clear all response caches",
            ["Clear all response caches", "Cancel"], ["clear", "cancel"],
            "Clears catalogs, search, metadata and ratings. Login, library and playback data stay."
        )


class SettingsWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.closed = False
        self.category_index = 0
        self.rows = []
        self.appearance_changed = False
        self.providers_changed = False
        self.discover_changed = False
        self.request_page = None
        self.subpage = None
        self.subpage_row = None
        self.subpage_options = []
        self.subpage_values = []
        self.return_position = 0
        self.feedback_kind = None
        self.feedback_category = None
        self.feedback_title = None
        self.feedback_description = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        categories = self.getControl(100)
        categories.reset()
        for label, key in CATEGORIES:
            item = xbmcgui.ListItem(label)
            item.setProperty("key", key)
            categories.addItem(item)
        categories.selectItem(self.category_index)
        self.load_category(self.category_index)
        self.setFocusId(100)
        import threading
        threading.Thread(target=self.watch_sync, daemon=True).start()

    def close(self):
        self.closed = True
        super().close()

    def watch_sync(self):
        try:
            monitor=xbmc.Monitor()
            while not self.closed and not monitor.waitForAbort(0.15):
                if not self.subpage and self.getFocusId()==100:self.preview_category()
                self.update_navigation()
                import time
                now=time.monotonic()
                if now-getattr(self,'_last_sync_refresh',0)<2:continue
                self._last_sync_refresh=now
                if self.subpage or CATEGORIES[self.category_index][1] != "account":continue
                rows=rows_for("account")
                if len(rows)!=len(self.rows):continue
                for index,row in enumerate(rows):
                    if row["kind"]=="info":
                        self.rows[index]=row
                        self.getControl(200).getListItem(index).setLabel2(summary(row))
                        self.getControl(200).getListItem(index).setProperty('help', help_preview(row))
        except Exception:
            return

    def preview_category(self):
        if self.subpage:return
        position=self.getControl(100).getSelectedPosition()
        if position!=self.category_index:self.load_category(position)

    def onFocus(self, control_id):
        if control_id == 100:
            if self.subpage:
                self.setFocusId(200)
            else:
                self.preview_category()

    def update_navigation(self):
        listing = self.getControl(200)
        total = len(self.subpage_options) if self.subpage else len(self.rows)
        position = max(0, listing.getSelectedPosition())
        state = (total, position, bool(self.subpage))
        if state == getattr(self, '_navigation_state', None):return
        self._navigation_state = state
        self.setProperty('settings_has_above', 'true' if total > 8 and position > 0 else '')
        self.setProperty('settings_has_below', 'true' if total > 8 and position < total - 1 else '')

    def layout(self, reading=False):
        self.getControl(200).setHeight(198 if reading else 528)
        self.getControl(302).setPosition(520, 420 if reading else 798)
        self.getControl(300).setPosition(550, 455 if reading else 830)
        self.getControl(300).setHeight(535 if reading else 170)
        self.getControl(306).setPosition(520, 435 if reading else 810)
        self.getControl(306).setHeight(565 if reading else 190)
        self.setProperty('settings_reading', 'true' if reading else '')

    def load_category(self, index):
        if not 0 <= index < len(CATEGORIES):
            return
        self.category_index = index
        label, key = CATEGORIES[index]
        self.setProperty('settings_category', key)
        self.getControl(307).setLabel(CATEGORY_HELP.get(key, 'Choose an option.') + ' Changes save immediately.')
        self.layout()
        self.getControl(301).setLabel(label)
        self.rows = rows_for(key)
        listing = self.getControl(200)
        listing.reset()
        for row in self.rows:
            item = xbmcgui.ListItem(row["label"], summary(row))
            item.setProperty("help", help_preview(row))
            item.setProperty("kind", row["kind"])
            listing.addItem(item)
        if self.rows:
            listing.selectItem(0)
        self.update_navigation()

    def refresh_rows(self):
        listing = self.getControl(200)
        position = max(0, listing.getSelectedPosition())
        self.load_category(self.category_index)
        if self.rows:
            listing.selectItem(min(position, len(self.rows) - 1))
            self.setFocusId(200)
        self.update_navigation()

    def open_subpage(self, row, labels, values=None, selected=0, help_text=None):
        self.layout()
        self.return_position = max(0, self.getControl(200).getSelectedPosition())
        self.subpage = "picker"
        self.subpage_row = row
        self.subpage_options = list(labels)
        self.subpage_values = list(values if values is not None else range(len(labels)))
        self.getControl(301).setLabel(row["label"])
        listing = self.getControl(200)
        listing.reset()
        for index, label in enumerate(self.subpage_options):
            item = xbmcgui.ListItem(str(label), "Selected" if index == selected else "")
            item.setProperty("help", help_text or row.get("help", ""))
            listing.addItem(item)
        if self.subpage_options:
            listing.selectItem(max(0, min(selected, len(self.subpage_options) - 1)))
        self.setFocusId(200)
        self.update_navigation()

    def close_subpage(self):
        self.subpage = None
        self.subpage_row = None
        self.subpage_options = []
        self.subpage_values = []
        self.load_category(self.category_index)
        if self.rows:
            self.getControl(200).selectItem(min(self.return_position, len(self.rows) - 1))
            self.setFocusId(200)
        self.update_navigation()

    def open_enum(self, row):
        try:
            current = int(ADDON.getSetting(row["id"]) or {"auto_source_attempts":"1", "forced_subtitles_mode":"2"}.get(row["id"], "0"))
        except (TypeError, ValueError):
            current = 0
        if not 0 <= current < len(row["values"]):
            current = 0
        self.open_subpage(row, row["values"], selected=current)

    def open_choice(self, row):
        self.open_subpage(row, row["labels"], values=row["values"],
                          selected=row.get("selected", 0))

    def open_command(self, identity, label, labels, values, help_text, selected=0):
        if identity == 'information':
            self.information_pages = information_pages(help_text)
            self.information_page = 0
            labels = ['Back'] + (['Previous page', 'Next page'] if len(self.information_pages) > 1 else [])
            values = ['cancel'] + ([-1, 1] if len(self.information_pages) > 1 else [])
            help_text = self.information_pages[0]
        row = {"kind": "command", "id": identity, "label": label, "help": help_text}
        self.open_subpage(row, labels, values=values, selected=selected, help_text=help_text)
        if identity == 'information':
            self.layout(reading=True)

    def open_feedback_type(self):
        self.open_command(
            "feedback_type", "Report a bug / request a feature",
            ["Bug report", "Feature request", "Report last error", "Cancel"],
            ["bug", "feature", "last", "cancel"],
            "Feedback is public on GitHub after the final addon-owned review screen. Never include credentials, links or personal details."
        )

    def open_last_error_custom(self):
        from lib.last_error import load_last_error
        from lib.error_report import show_report_dialog
        record = load_last_error()
        if record is None:
            themed_dialog().notification("Report last error", "No saved error is available.")
            return
        payload = record["payload"]
        summary = "{}: {}\nAddon {} | {}".format(
            payload.get("context", "Last error"), payload.get("errorType", "Error"),
            payload.get("addonVersion", "unknown"), payload.get("platform", "unknown")
        )
        show_report_dialog(payload, summary, replay=True)

    def finish_feedback(self, frequency):
        from lib.report_feedback import CATEGORIES, attach_feedback, report_labels
        from lib.error_report import build_payload, show_report_dialog
        payload = attach_feedback(build_payload("Manual report"), {
            "kind": self.feedback_kind,
            "category": self.feedback_category,
            "title": self.feedback_title,
            "description": self.feedback_description,
            "frequency": frequency,
        })
        labels = ", ".join(report_labels(payload, initial=True))
        kind = "Feature request" if self.feedback_kind == "feature" else "Bug report"
        show_report_dialog(payload, "{}\n{}\n\n{}".format(kind, self.feedback_title, labels))


    def open_secret(self, row):
        configured = bool(ADDON.getSetting(row["id"]).strip())
        labels = ["Replace key", "Remove key"] if configured else ["Add key"]
        self.open_subpage(row, labels, values=labels, selected=0,
                          help_text="API keys stay hidden. Use the Kodi keyboard or send text from your paired Kodi remote app.")

    def open_kodi(self, row):
        definition = _kodi_definition(row["id"])
        if not definition or not definition.get("enabled", True):
            themed_dialog().notification("Strem4Kodi", "This setting is unavailable on this device.")
            return
        value = definition.get("value")
        if isinstance(value, bool):
            from setup_profile import rpc
            rpc("Settings.SetSettingValue", {"setting": row["id"], "value": not value})
            self.refresh_rows()
            return
        options = _kodi_options(definition)
        if not options:
            themed_dialog().notification("Strem4Kodi", "No supported choices were reported for this setting.")
            return
        labels = [str(option.get("label")) for option in options]
        values = [option.get("value") for option in options]
        selected = next((i for i, option in enumerate(options) if option.get("value") == value), 0)
        self.open_subpage(row, labels, values=values, selected=selected)

    def execute_command(self, identity, value):
        if value in ("cancel", None):
            return
        if identity == 'discover_opening_choice':
            from lib.discover_preferences import Preferences
            Preferences(PROFILE).set_opening(value['mode'], value.get('catalog'))
            self.discover_changed = True
            themed_dialog().notification('Discover', 'Opening list saved')
            return
        if identity == 'catalogue_choose':
            self.open_command('catalogue_mode', 'Catalogue thumbnails', ['Posters','Wide thumbnails'],
                              [dict(catalog=value, layout='posters'), dict(catalog=value, layout='wide')],
                              'Saved for this catalogue on this device, on Home and Discover.')
            return
        if identity == 'catalogue_mode':
            from lib.catalogue_layout import save
            save(PROFILE, value['catalog'], value['layout'])
            themed_dialog().notification('Catalogue thumbnails', 'Saved: '+('Wide thumbnails' if value['layout']=='wide' else 'Posters'))
            self.appearance_changed = True
            return
        if identity == "account_disconnect" and value == "disconnect":
            state = Store(PROFILE).load()
            local = [item for item in state.get("addons", []) if item.get("account") is not True]
            disabled = set(state.get("disabledAddons", []))
            Store(PROFILE).save({
                "addons": local,
                "disabledAddons": sorted(disabled & {item.get("id") for item in local}),
            })
            for folder in ("streams", "playback", "subtitle-results"):
                Store(PROFILE / folder).forget()
            return
        if identity == "cache_clear_one":
            from lib.maintenance import _cache
            _cache().clear(str(value))
            return
        if identity == "cache_clear_all" and value == "clear":
            from lib.maintenance import _cache
            _cache().clear()
            return
        if identity == "feedback_type":
            if value == "last":
                self.open_last_error_custom()
                return
            if value in ("bug", "feature"):
                from lib.report_feedback import CATEGORIES
                self.feedback_kind = value
                self.open_command(
                    "feedback_category", "Feedback category",
                    [label for _, label in CATEGORIES] + ["Cancel"],
                    [key for key, _ in CATEGORIES] + ["cancel"],
                    "Choose the area that best matches this feedback."
                )
            return
        if identity == "feedback_category" and value != "cancel":
            from lib.report_feedback import feedback_text
            self.feedback_category = value
            title = themed_dialog().input(
                "Feature request title" if self.feedback_kind == "feature" else "Bug title"
            )
            if not title:
                return
            description = themed_dialog().input(
                "Describe the idea and why it helps" if self.feedback_kind == "feature"
                else "Steps to reproduce, expected result and what happens instead"
            )
            if not description:
                return
            try:
                self.feedback_title = feedback_text(title, 5, 100)
                self.feedback_description = feedback_text(description, 10, 1000)
            except ValueError:
                themed_dialog().notification("Feedback", "Check the title/description and remove links or credentials.")
                return
            if self.feedback_kind == "feature":
                self.finish_feedback("not-applicable")
            else:
                self.open_command(
                    "feedback_frequency", "How often does it happen?",
                    ["Every time", "Sometimes", "After restart", "Not retested", "Cancel"],
                    ["always", "sometimes", "after-restart", "not-retested", "cancel"],
                    "Choose how consistently the bug can be reproduced."
                )
            return
        if identity == "feedback_frequency" and value != "cancel":
            self.finish_feedback(str(value))
            return

    def apply_choice(self, row, value):
        identity = row.get("id", "")
        if identity.startswith('provider_role:'):
            from lib.provider_config import choose
            choose(PROFILE, identity.split(':', 1)[1], str(value))
            self.providers_changed = True
            return
        if identity in ('source_provider', 'source_language', 'manifest') or identity.startswith('auto_'):
            ADDON.setSetting(identity, str(value))
            return
        if identity in ("locale_language", "locale_region"):
            # This is an addon preference. Never switch Kodi's global language
            # while an addon-owned modal window is open: Kodi unloads/reloads the
            # skin and invalidates the active Strem4Kodi windows.
            from lib.settings import load_setup, save_setup
            setup = load_setup()
            setup["language" if identity == "locale_language" else "region"] = tuple(value)
            save_setup(setup)
            return
        if identity.startswith("cache_ttl:"):
            from lib.cache_policy import setting_id
            ADDON.setSetting(setting_id(identity.split(":", 1)[1]), str(value))
            from lib.maintenance import apply_settings
            apply_settings()
            return
        if identity == "cache_size":
            ADDON.setSetting("cache_max_mb", str(value))
            from lib.maintenance import apply_settings
            apply_settings()
            return

    def apply_subpage(self, index):
        if not self.subpage_row or not 0 <= index < len(self.subpage_values):
            return
        row = self.subpage_row
        value = self.subpage_values[index]
        if row["kind"] == "enum":
            ADDON.setSetting(row["id"], str(index))
            if row['id'] == 'playback_back_action':
                ADDON.setSetting('playback_back_migrated', 'true')
                from lib.playback_settings import apply
                apply()
            if row.get("id", "").startswith("ui_"):
                self.appearance_changed = True
            self.close_subpage()
            return
        if row["kind"] == "choice":
            self.apply_choice(row, value)
            self.close_subpage()
            return
        if row["kind"] == "command":
            identity = row.get("id", "")
            if identity == 'information' and value in (-1, 1):
                self.information_page = (self.information_page + value) % len(self.information_pages)
                for item in range(len(self.subpage_options)):
                    self.getControl(200).getListItem(item).setProperty('help', self.information_pages[self.information_page])
                return
            self.close_subpage()
            self.execute_command(identity, value)
            return
        if row["kind"] == "secret":
            action = str(value)
            if action == "Remove key":
                ADDON.setSetting(row["id"], "")
                self.close_subpage()
                return
            entered = themed_dialog().input(
                row["label"], type=xbmcgui.INPUT_ALPHANUM,
                option=xbmcgui.ALPHANUM_HIDE_INPUT
            )
            if entered.strip():
                ADDON.setSetting(row["id"], entered.strip())
            self.close_subpage()
            return
        if row["kind"] == "kodi":
            from setup_profile import rpc
            rpc("Settings.SetSettingValue", {"setting": row["id"], "value": value})
            self.close_subpage()
            return

    def onClick(self, control_id):
        if control_id == 100:
            if self.subpage:
                return
            position = self.getControl(100).getSelectedPosition()
            self.load_category(position)
            if self.rows:
                self.setFocusId(200)
            return
        if control_id != 200:
            return
        position = self.getControl(200).getSelectedPosition()
        if self.subpage:
            self.apply_subpage(position)
            return
        if not 0 <= position < len(self.rows):
            return
        row = self.rows[position]
        changed = False
        if row["kind"] == "info":
            detail = row.get('help', '')
            if row.get('summary'):detail = str(row['summary']) + '\n\n' + detail
            self.open_command('information', row['label'], ['Back'], ['cancel'], detail)
            return
        if row["kind"] == "bool":
            _set_bool(row)
            changed = True
        elif row["kind"] == "enum":
            self.open_enum(row)
            return
        elif row["kind"] == "choice":
            self.open_choice(row)
            return
        elif row["kind"] == "secret":
            self.open_secret(row)
            return
        elif row["kind"] == "kodi":
            self.open_kodi(row)
            return
        elif row["kind"] == "text":
            changed = _set_text(row)
        elif row["kind"] == "action":
            run_action(row["action"], self)
            # Opening a chooser must not immediately overwrite it with settings.
            if self.subpage:return
            changed = True
        if changed and row.get("id", "").startswith("ui_"):
            self.appearance_changed = True
        try:
            visible = self.isVisible()
        except Exception:
            visible = True
        if visible:
            self.refresh_rows()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in BACK:
            if self.subpage:
                self.close_subpage()
            elif self.getFocusId() == 200:
                self.setFocusId(100)
            else:
                self.close()
            return
        if self.subpage:
            if action_id == 1:
                self.close_subpage()
            return
        if action_id == 1 and self.getFocusId() == 200:
            self.setFocusId(100)
            return
        if action_id == 2 and self.getFocusId() == 100:
            position = self.getControl(100).getSelectedPosition()
            self.load_category(position)
            if self.rows:
                self.setFocusId(200)


def show():
    window = themed_window(
        SettingsWindow, "script-stremio-settings.xml",
        ADDON.getAddonInfo("path"), "Main", "1080i"
    )
    window.doModal()
    result = {
        "appearance_changed": window.appearance_changed,
        "providers_changed": window.providers_changed,
        "discover_changed": window.discover_changed,
        "request_page": window.request_page,
    }
    del window
    return result
