"""Episode air dates for UK display and source selection."""
from datetime import datetime, timezone
import re

from lib.sports_epg import uk_datetime

MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def air_date(row):
    value = row.get('released') or row.get('firstAired') or row.get('releaseInfo') or ''
    if not isinstance(value, str):
        return None, False
    value = value.strip()
    if not re.match(r'^\d{4}-\d{2}-\d{2}(?:$|T| )', value):
        return None, False
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is not None:
            parsed = uk_datetime(parsed.timestamp())
        return parsed, len(value) > 10
    except (ValueError, OverflowError, OSError):
        return None, False


def label(row):
    parsed, has_time = air_date(row)
    if parsed is None:
        value = row.get('released') or row.get('firstAired') or row.get('releaseInfo') or ''
        return value.strip() if isinstance(value, str) and re.fullmatch(r'\d{4}', value.strip()) else ''
    result = '{} {} {}'.format(parsed.day, MONTHS[parsed.month - 1], parsed.year)
    return '{} · {:02d}:{:02d} UK'.format(result, parsed.hour, parsed.minute) if has_time else result


def upcoming(row, now=None):
    parsed, has_time = air_date(row)
    if parsed is None:
        return False
    now = now or datetime.now(timezone.utc)
    uk_now = uk_datetime(now.timestamp())
    if not has_time:
        return parsed.date() > uk_now.date()
    return parsed.replace(tzinfo=None) > uk_now.replace(tzinfo=None)
