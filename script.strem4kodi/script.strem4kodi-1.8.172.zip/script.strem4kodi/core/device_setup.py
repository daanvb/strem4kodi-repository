"""HTTPS device pairing transport. No redirects, credentials in URLs or logs."""
import json
import re
import time
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError
from device_profile import MAX_BYTES, validate

DEFAULT_SERVER = 'https://setup.battleship.live'


class SetupError(RuntimeError):pass


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise SetupError('The setup server redirected the request')


class Client:
    def __init__(self, server=DEFAULT_SERVER, transport=None):
        parsed = urlsplit(server)
        if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password
                or parsed.query or parsed.fragment or parsed.path not in ('', '/')):
            raise SetupError('Use an HTTPS setup server address')
        self.server = server.rstrip('/')
        self.transport = transport or self.request

    def request(self, path, payload, secret=''):
        headers = {'Content-Type':'application/json', 'Accept':'application/json', 'User-Agent':'Strem4Kodi-Setup/1'}
        if secret:headers['Authorization'] = 'Bearer ' + secret
        request = Request(self.server + path, json.dumps(payload).encode(), headers, method='POST')
        try:
            try:response = build_opener(NoRedirect()).open(request, timeout=3)
            except HTTPError as error:
                if error.code != 409:raise
                response = error
            with response:
                raw = response.read(MAX_BYTES + 4097)
            if len(raw) > MAX_BYTES + 4096:raise ValueError()
            result = json.loads(raw)
            if isinstance(result, dict) and result.get('code') == 'profile_missing':
                raise SetupError('Copy the master profile from your Shield first')
            if not isinstance(result, dict) or result.get('error'):raise ValueError()
            return result
        except SetupError:raise
        except Exception:
            raise SetupError('Could not connect to the private setup server. Check its address or retry.') from None

    def start(self, label, purpose='enroll', stremio_link=''):
        result = self.transport('/v1/pairings', {'purpose':purpose, 'label':label[:80], 'stremio_link':stremio_link}, '')
        code, secret, expires = result.get('code'), result.get('secret'), result.get('expires')
        if (not isinstance(code, str) or not re.fullmatch('[A-F0-9]{8}', code)
                or not isinstance(secret, str) or not re.fullmatch('[A-Za-z0-9_-]{32,128}', secret)
                or type(expires) is not int or not time.time() < expires <= time.time() + 660
                or result.get('verification_url') != self.server + '/pair/' + code):
            raise SetupError('The setup server returned an invalid pairing request')
        return result

    def poll(self, pairing):
        result = self.transport('/v1/pairings/'+pairing['code']+'/poll', {}, pairing['secret'])
        if result.get('state') not in ('pending', 'approved', 'completed', 'denied'):
            raise SetupError('Invalid device pairing state')
        if 'profile' in result:result['profile'] = validate(result['profile'])
        return result

    def finish(self, pairing, profile=None):
        body = {'profile':validate(profile)} if profile is not None else {}
        result = self.transport('/v1/pairings/'+pairing['code']+'/finish', body, pairing['secret'])
        if result.get('state') != 'completed':raise SetupError('The setup server could not confirm completion')
