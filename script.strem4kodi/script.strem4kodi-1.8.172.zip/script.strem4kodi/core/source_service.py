"""Reported playback service only; never infer it from URLs or release names."""
import re
import unicodedata

_IDS = {'realdebrid': 'realdebrid', 'real-debrid': 'realdebrid',
        'real debrid': 'realdebrid', 'rd': 'realdebrid', 'torbox': 'torbox', 'tb': 'torbox'}
_TOKEN = r'(?:RD|TB|Real[- ]?Debrid|TorBox)'
_BRACKET = re.compile(r'\[\s*(' + _TOKEN + r')\s*[+⚡⏳]?\s*\]', re.I)
_SERVICE_FIELD = re.compile(r'(?:^|[|·])\s*(?:service|debrid)\s*:\s*('
                            + _TOKEN + r')\s*\+?\s*(?=$|[|·])', re.I)
_BRAND_FIELD = re.compile(r'(?:^|[|·])\s*(Real[- ]?Debrid|TorBox)\s*\+?\s*(?=$|[|·])', re.I)
_READY_FIELD = re.compile(r'(?:^|[|·])\s*Ready\s*\(\s*(' + _TOKEN
                          + r')\s*\)(?=$|\s|[|·])', re.I)
_FILE = re.compile(r'\.(?:mkv|mp4|avi|m2ts|ts)\b', re.I)
_URL = re.compile(r'(?:https?|plugin|magnet)://\S+', re.I)
_MARKUP = re.compile(r'<[^>]*>|\[/?(?:B|I|TAB|LIGHT|COLOR[^\]]*|UPPERCASE|LOWERCASE)\]', re.I)


def _canonical(value):
    return _IDS.get(value.strip().casefold(), '') if isinstance(value, str) else ''


def service_id(row):
    if not isinstance(row, dict):return ''
    # Normalized rows/cache entries carry only this allowlisted value, including
    # an empty value when explicit structured data was unknown or malformed.
    if 'service_id' in row:
        return _canonical(row['service_id'])
    data = row.get('streamData')
    if isinstance(data, dict) and 'service' in data:
        service = data['service']
        return _canonical(service.get('id')) if isinstance(service, dict) else ''
    reported = set()
    for key in ('name', 'title', 'description', 'detail', 'label'):
        value = row.get(key)
        if not isinstance(value, str):continue
        # The details dialog hides formatter icons/markup. Parse the same
        # visible evidence, retaining line boundaries and explicit words.
        value = re.sub(r'\[CR\]', '\n', value[:8192], flags=re.I)
        for line in value.splitlines():
            line = _URL.sub('', line)
            if _FILE.search(line):continue
            line = _MARKUP.sub('', line)
            line = ''.join(' ' if unicodedata.category(ch) in ('So', 'Cf') or ch == '\ufe0f'
                           else ch for ch in line)
            for pattern in (_BRACKET, _SERVICE_FIELD, _BRAND_FIELD, _READY_FIELD):
                reported.update(_canonical(match.group(1)) for match in pattern.finditer(line))
    # Contradictory label tags cannot identify the selected service reliably.
    return next(iter(reported)) if len(reported) == 1 else ''


def badge(row):
    return {'realdebrid': 'RD', 'torbox': 'TB'}.get(service_id(row), '')
