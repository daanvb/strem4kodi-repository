"""Kodi-language filtered Stremio subtitles; download only the selected file."""
from lib.ui_dialogs import dialog as themed_dialog
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import Request, urlopen
from protocol import fetch, resource_url
from sources import supports, direct_url
from setup_profile import atomic_write, get_setting

ALIASES = {'hr': 'hrv', 'croatian': 'hrv', 'scr': 'hrv', 'hrv': 'hrv',
           'sr': 'srp', 'serbian': 'srp', 'scc': 'srp', 'srp': 'srp',
           'bs': 'bos', 'bosnian': 'bos', 'bos': 'bos',
           'en': 'eng', 'english': 'eng', 'eng': 'eng'}


def language(value):
    value = str(value or '').strip().lower()
    if value in ALIASES:
        return ALIASES[value]
    try:
        import xbmc
        return xbmc.convertLanguage(value, xbmc.ISO_639_2).lower() or value
    except (ImportError, AttributeError):
        return value


def preferences():
    allowed = get_setting('subtitles.languages', [])
    if isinstance(allowed, str):
        allowed = allowed.split(',')
    return ([language(value) for value in allowed],
            language(get_setting('locale.subtitlelanguage', '')),
            bool(get_setting('subtitles.downloadfirst', False)))


def _subtitle_fps(entry):
    """Supplied frame rate only; adapted from upstream 9a69998."""
    value = next((entry[key] for key in ('fps', 'frameRate', 'framerate', 'frame_rate')
                  if entry.get(key) not in (None, '')), None)
    if isinstance(value, bool):
        return ''
    try:
        number = float(value)
    except (TypeError, ValueError):
        match = re.search(r'(?i)(\d{2}(?:\.\d{1,3})?)\s*fps\b',
                          str(entry.get('label') or entry.get('id') or ''))
        number = float(match[1]) if match else 0
    if not 10 <= number <= 120:
        return ''
    return ('{:.3f}'.format(number)).rstrip('0').rstrip('.')


def collect_subtitles(providers, kind, identity, allowed, preferred, inline=None, filename='', fetcher=fetch):
    def query(provider):
        name = ' '.join(str((provider.get('manifest') or {}).get('name') or 'Subtitle addon').split())[:80]
        try:
            extras = {'filename': filename} if filename else None
            response = fetcher(resource_url(provider['transportUrl'], 'subtitles', kind, identity, extras))
            return name, response.get('subtitles', [])
        except Exception:
            return name, []
    selected, seen = [], set()
    for provider in providers:
        url = provider.get('transportUrl')
        if url and url not in seen and supports(provider.get('manifest', {}), kind, identity, 'subtitles'):
            selected.append(provider)
            seen.add(url)
    # Adapted from upstream 9a69998 without supporter-tier/provider restrictions.
    # Copy responses so the provider label cannot modify cached or inline data.
    entries = [dict(entry, _provider=str(entry.get('provider') or 'Selected stream'))
               for entry in (inline if isinstance(inline, list) else []) if isinstance(entry, dict)]
    with ThreadPoolExecutor(max_workers=3) as pool:
        for provider_name, result in pool.map(query, selected):
            if isinstance(result, list):
                entries.extend(dict(entry, _provider=provider_name) for entry in result if isinstance(entry, dict))
    results, seen = [], set()
    for entry in entries:
        if not isinstance(entry, dict) or not direct_url(entry):
            continue
        lang = language(entry.get('lang'))
        if (allowed and lang not in allowed) or (lang, entry['url']) in seen:
            continue
        seen.add((lang, entry['url']))
        forced = (entry.get('forced') is True or entry.get('isForced') is True
                  or entry.get('isforced') is True
                  or bool(re.search(r'(?i)\bforced\b|\bforeign[ ._-]+(parts|dialogue)[ ._-]+only\b',
                                    str(entry.get('label') or entry.get('name') or entry.get('id') or ''))))
        provider = ' '.join(str(entry.get('_provider') or 'Subtitle addon').split())[:80]
        fps = _subtitle_fps(entry)
        name = ' '.join(str(entry.get('label') or entry.get('name') or entry.get('id') or 'Subtitle').split())[:160]
        parts = [lang, provider]
        if fps:
            parts.append(fps + ' FPS')
        if name and name.casefold() not in {part.casefold() for part in parts}:
            parts.append(name)
        results.append({'lang': lang, 'url': entry['url'], 'forced': forced,
                        'provider': provider, 'fps': fps,
                        'filename': str(entry.get('filename') or entry.get('fileName') or ''),
                        'label': ' | '.join(parts)})
    # Allowed languages are a set, NOT user-ranked fallback priorities.
    return sorted(results, key=lambda entry: (entry['lang'] != preferred, entry['lang']))



def download_original(entry, directory):
    with urlopen(Request(entry['url'], headers={'User-Agent': 'Strem4Kodi/1'}), timeout=10) as response:
        data = response.read(2 * 1024 * 1024 + 1)
    if len(data) > 2 * 1024 * 1024:
        raise ValueError('Subtitle too large')
    probe = data.decode('utf-8-sig', errors='replace').lstrip()
    if probe.startswith('WEBVTT'):
        extension = 'vtt'
    elif '[Script Info]' in probe[:2048]:
        extension = 'ass'
    elif '-->' in probe and not probe.lower().startswith(('<!doctype', '<html')):
        extension = 'srt'
    else:
        raise ValueError('Unsupported subtitle file')
    digest = hashlib.sha256(data).hexdigest()
    lang = entry['lang'] if entry['lang'].isalpha() else 'und'
    target = Path(directory) / '{}.{}.{}'.format(digest, lang, extension)
    atomic_write(target, data)
    return str(target)


def download(entry, directory):
    return download_original(entry, directory)


def remember_selection(profile, kind, identity, stream, listitem=None):
    from account import Store
    from lib.player_media_info import source_details
    try:
        media_info = source_details(stream)
    except Exception:
        media_info = {}  # Optional presentation must never prevent playback.
    from lib.stream_presenter import line
    hints = stream.get('behaviorHints') if isinstance(stream.get('behaviorHints'), dict) else {}
    filename = line(stream.get('filename') or hints.get('filename') or '', 500)
    try:
        playback_key = listitem.getProperty('StremioPlaybackKey') if listitem else ''
    except Exception:
        playback_key = ''
    Store(Path(profile) / 'playback').save({'created': time.time(), 'kind': kind, 'id': identity,
        'playback_key': playback_key,
        'isLive': stream.get('isLive') is True or stream.get('_live_sports') is True or kind in ('sport', 'sports', 'tv', 'channel', 'live'),
        'url_hash': hashlib.sha256(stream['url'].encode()).hexdigest(),
        'subtitles': stream.get('subtitles', []), 'filename': filename, 'media_info': media_info})


def _configured_providers(profile, providers):
    from lib.provider_config import state as provider_state
    from provider_roles import selected, ordered
    state = provider_state(profile)
    return ordered(state, 'subtitles') if selected(state, 'subtitles') else providers


def prepare_selected(profile, kind, identity, stream, providers, listitem):
    remember_selection(profile, kind, identity, stream, listitem)
    from addon_state import get_addon
    if get_addon().getSetting('subtitles_default_off') != 'false':
        return  # Do not preload full subtitles when only forced subtitles are wanted.
    allowed, preferred, auto = preferences()
    if not auto or not allowed or preferred in ('none', 'off'):
        return
    # Forced-only is managed after Kodi has exposed embedded tracks. Do not
    # attach an arbitrary full subtitle first and defeat forced-track selection.
    if preferred in ('forced_only', 'forced only'):
        return
    providers = _configured_providers(profile, providers)
    results = collect_subtitles(providers, kind, identity, allowed, preferred,
                                stream.get('subtitles'), stream.get('filename', ''))
    # No synchronization claim: if no file hash is available, provider order wins
    # within a language. Try at most two files so a bad source cannot stall forever.
    for entry in results[:2]:
        try:
            listitem.setSubtitles([download(entry, Path(profile) / 'subtitles')])
            return
        except Exception:
            continue


def manual_selection(profile, providers):
    providers = _configured_providers(profile, providers)
    import xbmc
    import xbmcgui
    from account import Store
    player = xbmc.Player()
    context = Store(Path(profile) / 'playback').load()
    def matches():
        try:
            return (player.isPlayingVideo() and time.time() - context.get('created', 0) < 86400
                    and hashlib.sha256(player.getPlayingFile().encode()).hexdigest() == context.get('url_hash'))
        except Exception:
            return False
    if not matches():
        themed_dialog().ok('Stremio subtitles', 'Start a video through Strem4Kodi first.')
        return
    allowed, preferred, _ = preferences()
    entries = collect_subtitles(providers, context['kind'], context['id'], allowed, preferred,
                                context.get('subtitles'), context.get('filename', ''))
    if not entries:
        themed_dialog().ok('Stremio subtitles', 'No subtitles found in the languages selected in Kodi Settings.')
        return
    index = themed_dialog().select('Stremio subtitles — Kodi languages', [entry['label'] for entry in entries])
    if index < 0 or index >= len(entries) or not matches():
        return
    path = download(entries[index], Path(profile) / 'subtitles')
    if matches():
        player.setSubtitles(path)
        player.showSubtitles(True)
