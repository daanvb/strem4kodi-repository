"""Read-only source aggregation; no account token is sent to providers."""
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from urllib.parse import urlsplit
import re
import time
from protocol import fetch, resource_url, failure_reason
from source_service import service_id


def request_failure(error):
    """Fixed categories only: provider exceptions can contain private URLs."""
    code = getattr(error, 'code', None)
    if isinstance(error, RateLimitError) or code == 429:
        return 'rate_limited', False
    if code in (401, 403):
        return 'denied', False
    if code in (408, 500, 502, 503, 504):
        headers = getattr(error, 'headers', None)
        # Do not retry ahead of a server's requested backoff, or keep the
        # interactive search waiting through an unbounded Retry-After period.
        return 'server_error', not (headers is not None and headers.get('Retry-After'))
    reason = failure_reason(error)
    if reason == 'Request timed out':
        return 'timed_out', True
    if reason == 'Connection to server failed':
        return 'connection_failed', True
    if isinstance(error, ValueError) or reason == 'Addon returned invalid JSON':
        return 'invalid_response', False
    return 'request_failed', False


class RateLimitError(ValueError):
    pass


def rate_limit_message(value):
    text = str(value or '').casefold()
    return any(term in text for term in ('rate limit', 'rate_limit', 'limit exceeded', 'too many requests'))


def supports(manifest, kind, identity, resource_name='stream'):
    if not isinstance(manifest, dict) or not isinstance(manifest.get('resources'), list):
        return False
    for resource in manifest.get('resources', []):
        spec = manifest if resource == resource_name else resource
        if not isinstance(spec, dict):
            continue
        if resource != resource_name and spec.get('name') != resource_name:
            continue
        types = spec.get('types', manifest.get('types', []))
        prefixes = spec.get('idPrefixes')
        if (isinstance(types, list) and all(isinstance(t, str) for t in types)
                and (prefixes is None or isinstance(prefixes, list) and all(isinstance(p, str) for p in prefixes))
                and kind in types and (prefixes is None or any(identity.startswith(p) for p in prefixes))):
            return True
    return False


def direct_url(stream):
    url = stream.get('url', '')
    if not isinstance(url, str) or '|' in url or any(ord(c) < 32 for c in url):
        return False
    parsed = urlsplit(url)
    hints = stream.get('behaviorHints') or {}
    # A playable direct URL remains valid even when a Stremio provider also
    # includes infoHash/externalUrl metadata. Some debrid providers do this
    # (for example Torrentio-style responses). Only reject URLs that Kodi
    # cannot safely play without extra proxy/header handling.
    return (parsed.scheme in ('http', 'https') and bool(parsed.netloc)
            and not parsed.username and not parsed.password
            and isinstance(hints, dict) and not hints.get('proxyHeaders'))


def embedded_sources(meta, identity):
    """Adapt upstream 0d24a03 using our existing AV-preserving stream parser."""
    video = next((v for v in meta.get('videos', []) if isinstance(v, dict)
                  and v.get('id') == identity), None)
    if not video or not isinstance(video.get('streams'), list):
        return None
    kind = meta.get('type') or 'movie'
    provider = {'transportUrl': 'https://embedded.invalid/manifest.json',
                'manifest': {'name': 'Stored video', 'types': [kind], 'resources': ['stream']}}
    return collect([provider], kind, identity,
                   fetcher=lambda url: {'streams': video['streams']})


def collect(providers, kind, identity, fetcher=None, timing=None, on_results=None, on_progress=None,
            observations=None, cancelled=None, recover=True):
    search_started = time.monotonic()
    live_event = kind in ('sports', 'sport', 'tv', 'channel', 'live')
    selected, seen = [], set()
    for provider in providers:
        if not isinstance(provider, dict):
            continue
        url = provider.get('transportUrl')
        if url and url not in seen and supports(provider.get('manifest', {}), kind, identity):
            seen.add(url)
            selected.append(provider)

    def stopped():
        return cancelled is not None and cancelled()

    def query(provider, attempt):
        started = time.monotonic()
        response_at = None
        def durations():
            ended = time.monotonic()
            total = max(0, int((ended - started) * 1000))
            request = total if response_at is None else max(0, min(total, int((response_at - started) * 1000)))
            return total, request, total - request
        name = provider.get('manifest', {}).get('name') or 'Addon'
        try:
            if stopped():
                return [], 0, 0, name, 0, False, 0, [], 'cancelled', False, 0, 0
            url = resource_url(provider['transportUrl'], 'stream', kind, identity)
            # Stream aggregators can need a cold lookup. Browsing and live HTTP
            # retain their original timeout; retry only transient VOD failures.
            result = (fetcher(url) if fetcher is not None else
                      fetch(url, timeout=15 if live_event or not recover or attempt > 1 else 30))
            response_at = time.monotonic()
            if result.get('error'):
                if rate_limit_message(result['error']):
                    raise RateLimitError()
                if re.search(r'\b(?:timeout|timed out)\b', str(result['error']), re.I):
                    raise TimeoutError()
                raise ValueError('Addon returned an error')
            streams = result.get('streams', [])
            if not isinstance(streams, list):
                raise ValueError('Invalid streams')
            if streams and all(isinstance(s, dict) and rate_limit_message(str(s.get('name') or '') + ' ' + str(s.get('title') or '')) for s in streams):
                raise RateLimitError()
            good, skipped, unavailable, countdowns = [], 0, 0, []
            for stream in streams:
                if not isinstance(stream, dict):
                    skipped += 1
                    continue
                report = ' '.join(str(stream.get(key) or '') for key in ('name', 'title', 'description'))
                for pattern in (() if not live_event else (
                        r'\b(?:the\s+)?stream\s+starts?\s+in\s+(\d{1,3})\s*(?:m|min|mins|minutes?)\b',
                        r'\bstarts?\s+in\s+(\d{1,3})\s*(?:m|min|mins|minutes?)\b',
                        r'\b(\d{1,3})\s*(?:m|min|mins|minutes?)\s+(?:until|till)\s+(?:the\s+)?stream\s+starts?\b')):
                    match = re.search(pattern, report, re.I)
                    if match:
                        value = int(match.group(1))
                        if 0 <= value <= 360:
                            countdowns.append(value)
                        break
                if live_event and re.search(r'\b(?:stream\s+)?(?:unavailable|offline)\b|\bstream\s+(?:has\s+)?ended\b', report, re.I):
                    unavailable += 1
                    skipped += 1
                    continue
                if not direct_url(stream):
                    skipped += 1
                    continue
                detail = stream.get('title') or stream.get('description') or stream.get('name') or 'Stream'
                hints = stream.get('behaviorHints') or {}
                # AIOStreams can retain its parsed filename independently of
                # formatted labels and standard behaviorHints.
                data=stream.get('streamData')
                data=data if isinstance(data,dict) else {}
                good.append({'url': stream['url'],
                             'label': '{} · {}'.format(name, detail),
                             'provider': name,
                             'service_id': service_id(stream),
                             'detail': detail,
                             'name': stream.get('name') or '',
                             'title': stream.get('title') or '',
                             'description': stream.get('description') or '',
                             'isLive': kind in ('sports','sport','tv','channel','live') or stream.get('isLive') is True,
                             'subtitles': stream.get('subtitles', []),
                             'videoSize': hints.get('videoSize', stream.get('videoSize')),
                             'quality': stream.get('quality') or hints.get('quality'),
                             'resolution': stream.get('resolution') or hints.get('resolution'),
                             'height': stream.get('height') or hints.get('height'),
                             'audio': stream.get('audio') or hints.get('audio'),
                             **{key: stream.get(key, hints.get(key)) for key in ('videoCodec','audioCodec','audioCodecs','audioTracks','audioStreams','channels','languages','hdr','bitDepth','frameRate','bitrate')},
                             'source': stream.get('source') or hints.get('source'),
                             'filename': hints.get('filename') or stream.get('filename') or data.get('filename') or '',
                             'filename_candidates': list(dict.fromkeys(value for value in
                                 (hints.get('filename'),stream.get('filename'),data.get('filename')) if isinstance(value,str) and value.strip())),
                             **{key: stream.get(key, hints.get(key)) for key in ('seriesId','imdbId','season','episode')},
                             'dvProfile': stream.get('dvProfile',hints.get('dvProfile')),
                             'dolbyVisionProfile':stream.get('dolbyVisionProfile',hints.get('dolbyVisionProfile')),
                             'enhancementLayer':stream.get('enhancementLayer',hints.get('enhancementLayer')),
                             'dvEnhancementLayer':stream.get('dvEnhancementLayer',hints.get('dvEnhancementLayer'))})
            total_ms, request_ms, parse_ms = durations()
            return good, skipped, 0, name, total_ms, False, unavailable, countdowns, '', False, request_ms, parse_ms
        except Exception as error:
            # Never expose configured URLs or provider exception messages.
            reason, transient = request_failure(error)
            total_ms, request_ms, parse_ms = durations()
            return [], 0, 1, name, total_ms, reason == 'rate_limited', 0, [], reason, transient, request_ms, parse_ms

    output, skipped, failed = [], 0, 0
    completed = {}
    retrying, reasons = set(), {}
    elapsed = [0] * len(selected)
    request_elapsed = [0] * len(selected)
    parse_elapsed = [0] * len(selected)
    limited_count = 0
    def progress():
        if on_progress is not None:
            try:
                on_progress({'total': len(selected), 'completed': len(completed),
                             'rows': len(output), 'failed': failed, 'rate_limited': limited_count,
                             'failure_reasons': dict(reasons),
                             'retrying': [str(selected[i].get('manifest', {}).get('name') or 'Add-on')[:80]
                                          for i in sorted(retrying)],
                             'pending': [str(p.get('manifest', {}).get('name') or 'Add-on')[:80]
                                         for i, p in enumerate(selected) if i not in completed]})
            except Exception:
                pass  # Optional UI feedback must not break playback.
    progress()
    # Keep successful providers available while another provider retries. Never
    # repeat a healthy result, rate limit, permission error or malformed reply.
    with ThreadPoolExecutor(max_workers=min(8, max(1, len(selected)))) as pool:
        futures = {pool.submit(query, provider, 1): (i, 1) for i, provider in enumerate(selected)}
        if observations is not None:observations['requests'] = len(selected)
        while futures:
            done, _ = wait(futures, return_when=FIRST_COMPLETED)
            if stopped():
                for future in futures:future.cancel()
                if observations is not None:observations['cancelled'] = True
                break
            for future in done:
                index, attempt = futures.pop(future)
                result = future.result()
                entries, ignored, errors, provider_name, elapsed_ms, rate_limited, unavailable, countdowns, reason, transient, request_ms, parse_ms = result
                elapsed[index] += elapsed_ms
                request_elapsed[index] += request_ms
                parse_elapsed[index] += parse_ms
                if errors and transient and attempt == 1 and recover and not live_event and not stopped():
                    retrying.add(index)
                    futures[pool.submit(query, selected[index], 2)] = (index, 2)
                    if observations is not None:observations['requests'] += 1
                    progress()
                    continue
                retrying.discard(index)
                completed[index] = result
                output.extend(entries)
                skipped += ignored
                failed += errors
                limited_count += int(rate_limited)
                if errors:reasons[reason] = reasons.get(reason, 0) + 1
                if observations is not None:
                    observations.setdefault('countdowns', []).extend(countdowns)
                    observations['unavailable_reports'] = observations.get('unavailable_reports', 0) + unavailable
                delivery_ms = None
                published_ms = None
                if entries and on_results is not None:
                    delivery_started = time.monotonic()
                    try:
                        on_results([row for i in sorted(completed) for row in completed[i][0]])
                        published_ms = max(0, int((time.monotonic() - search_started) * 1000))
                    except Exception:
                        pass
                    delivery_ms = max(0, int((time.monotonic() - delivery_started) * 1000))
                if timing is not None:
                    timing.append({'provider': str(provider_name)[:80], 'ms': max(0, elapsed[index]),
                                   'failed': bool(errors), 'rows': len(entries), 'rate_limited': rate_limited,
                                   'reason': reason, 'attempts': attempt,
                                   'request_ms': request_elapsed[index], 'parse_ms': parse_elapsed[index],
                                   'delivery_ms': delivery_ms, 'published_ms': published_ms})
                progress()
    output = [row for i in sorted(completed) for row in completed[i][0]]
    if observations is not None:
        observations['unavailable'] = bool(observations.get('unavailable_reports')) and not output
    return output, skipped, failed
