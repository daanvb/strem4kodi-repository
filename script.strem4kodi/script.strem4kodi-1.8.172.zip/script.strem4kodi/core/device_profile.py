"""Allowlisted, portable setup profiles. Never include account sessions or files."""
import hashlib
import json
import re
from pathlib import Path
import xml.etree.ElementTree as ET

VERSION = 1
MAX_BYTES = 65536
PREFIXES = ('ui_', 'rating_', 'episode_', 'trailers_', 'trailer_', 'unpause_',
            'autoplay_', 'manual_', 'source_', 'cache_', 'up_next_', 'sports_',
            'auto_movie_', 'auto_series_', 'auto_animation_', 'introdb_', 'forced_subtitles_')
EXACT = {'tmdb_api_key', 'mdblist_api_key', 'live_football_api_key', 'youtube_api_key', 'credits_github_token',
         'credits_github_enabled', 'lists_github_enabled', 'formats_github_enabled',
         'diagnostics_github_enabled', 'startup_autostart', 'startup_delay', 'device_setup_player_skin',
         'subtitles_default_off', 'playback_back_action', 'playback_controls_hide', 'scrub_commit',
         'chaptersdb_enabled', 'prerolls_enabled', 'auto_source_attempts', 'fel_labels',
         'resume_rewind_seconds'}
EXCLUDED = {'source_filter_provider', 'source_filter_quality', 'source_filter_audio',
            'source_remember_filters', 'source_max_quality', 'source_dynamic',
            'source_audio', 'ui_compact', 'ui_animations'}


def definitions():
    path = Path(__file__).resolve().parents[1] / 'resources/settings.xml'
    return {s.get('id'): s for s in ET.parse(path).iter('setting')
            if s.get('id') and s.get('type') in ('text', 'bool', 'enum')
            and s.get('id') not in EXCLUDED
            and not s.get('id').startswith('source_filter_')
            and (s.get('id') in EXACT or s.get('id').startswith(PREFIXES))}


def validate(profile):
    if not isinstance(profile, dict) or set(profile) - {'version', 'settings', 'providerPreferences'}:
        raise ValueError('Invalid setup profile')
    if type(profile.get('version')) is not int or profile['version'] != VERSION:
        raise ValueError('Unsupported setup profile version')
    settings = profile.get('settings')
    allowed = definitions()
    if not isinstance(settings, dict) or set(settings) - allowed.keys():
        raise ValueError('Unsupported setup setting')
    result = {}
    for key, value in settings.items():
        if not isinstance(value, str) or len(value) > 2048 or any(ord(c) < 32 for c in value):
            raise ValueError('Invalid setup value')
        spec = allowed[key]
        if spec.get('type') == 'bool' and value not in ('true', 'false'):
            raise ValueError('Invalid setup boolean')
        if spec.get('type') == 'enum':
            count = len((spec.get('values') or '').split('|'))
            if not value.isdigit() or not 0 <= int(value) < count:
                raise ValueError('Invalid setup choice')
        if key.startswith('cache_'):
            from lib.cache_policy import parse_duration, parse_size
            (parse_size if key == 'cache_max_mb' else parse_duration)(value)
        result[key] = value
    output = {'version': VERSION, 'settings': result}
    if 'providerPreferences' in profile:
        providers = profile['providerPreferences']
        roles = {'metadata','artwork','ratings','search','streams','subtitles'}
        if (not isinstance(providers, dict) or set(providers) - roles
                or any(not isinstance(v,str) or (v and not re.fullmatch('[a-f0-9]{64}',v)) for v in providers.values())):
            raise ValueError('Invalid provider preferences')
        output['providerPreferences'] = dict(providers)
    if len(json.dumps(output).encode()) > MAX_BYTES:
        raise ValueError('Setup profile is too large')
    return output


def export(get_setting):
    # Read only declared portable settings, never userdata/session files.
    settings = {}
    for key, spec in definitions().items():
        value = get_setting(key)
        if value == '':value = spec.get('default', '')
        settings[key] = value
    return validate({'version': VERSION, 'settings': settings})


def digest(profile):
    data = json.dumps(validate(profile), sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(data).hexdigest()


def apply(profile, addon, store, cancelled=lambda: False, provider_store=None):
    """Write a durable backup first; retry partial application without losing it."""
    profile = validate(profile)
    stamp = digest(profile)
    journal = store.load()
    provider_plan = profile.get('providerPreferences', {})
    if provider_plan and provider_store is None:raise RuntimeError('Provider preference storage is unavailable')
    if journal.get('revision') != stamp:
        journal = {'revision': stamp, 'before': {k: addon.getSetting(k) for k in profile['settings']},
                   'applied': dict(profile['settings']), 'completed': False}
        if provider_plan:
            journal['providers_before'] = provider_store.load().get('providerPreferences', {})
            journal['providers_applied'] = dict(provider_plan)
        store.save(journal)  # Failure here must precede any setting mutation.
    for key, value in profile['settings'].items():
        if cancelled():raise RuntimeError('Device setup cancelled')
        if addon.getSetting(key) != value:
            addon.setSetting(key, value)
            if addon.getSetting(key) != value:
                raise RuntimeError('A setup setting could not be saved')
        # The planned values were journalled before mutation. Actual settings
        # are the resume checkpoint, avoiding a disk write for every option.
    if provider_plan:
        if cancelled():raise RuntimeError('Device setup cancelled')
        data = provider_store.load()
        data['providerPreferences'] = dict(data.get('providerPreferences') or {}, **provider_plan)
        provider_store.save(data)
    journal['completed'] = True
    store.save(journal)
    return stamp


def restore(addon, store, provider_store=None):
    """Explicit undo; preserve preferences changed by the user after setup."""
    journal = store.load()
    allowed = definitions()
    restored = []
    for key, old in journal.get('before', {}).items():
        if key in allowed and isinstance(old, str) and addon.getSetting(key) == journal.get('applied', {}).get(key):
            addon.setSetting(key, old)
            if addon.getSetting(key) != old:
                raise RuntimeError('A previous setting could not be restored')
            restored.append(key)
    if provider_store is not None:
        data = provider_store.load()
        current = dict(data.get('providerPreferences') or {})
        before = journal.get('providers_before', {})
        for role, value in journal.get('providers_applied', {}).items():
            if current.get(role) == value:
                if role in before:current[role] = before[role]
                else:current.pop(role,None)
        data['providerPreferences'] = current
        provider_store.save(data)
    journal['restored'] = restored
    store.save(journal)
    return len(restored)
