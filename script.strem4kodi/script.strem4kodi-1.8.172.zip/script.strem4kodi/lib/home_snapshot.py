"""Fast Home snapshot for constrained Kodi devices.

Contains display rows only: never auth keys or configured addon transport URLs.
"""
import time
from account import Store, library_rows

MAX_ROWS = 16
CONTINUE = 'Continue Watching'
REMINDERS = "Don't Forget About Me"


def _key(row):
    return '|'.join(str(row.get(name) or '') for name in ('provider', 'kind', 'catalog_id'))


def _display_row(row):
    items = row.get('items') if isinstance(row, dict) else []
    if isinstance(row, dict) and row.get('label') == 'You May Also Like' and row.get('_recommendation_version') != 3:
        items = []  # Retire weak recommendations from old startup snapshots.
    clean = {
        'label': str((row or {}).get('label') or ''),
        'items': [dict(item) for item in items[:MAX_ROWS] if isinstance(item, dict) and item.get('id')],
        'failed': bool((row or {}).get('failed')),
    }
    key = str((row or {}).get('_key') or _key(row or {}))
    if key != '||':
        clean['_key'] = key
    if (row or {}).get('_recommendation_version') == 3:
        clean['_recommendation_version'] = 3
    return clean


def load(directory):
    try:
        state = Store(directory / 'home-snapshot').load()
        rows = state.get('rows')
        if not isinstance(rows, list):
            return []
        return [_display_row(row) for row in rows if isinstance(row, dict)]
    except Exception:
        return []


def active_rows(rows, addons):
    """Drop stale disabled catalogues, and restore live paging specs in memory only."""
    from lib.home_catalogs import descriptors
    specs = {_key(spec): spec for spec in descriptors(addons)}
    return [dict(specs.get(row.get('_key'), {}), **row) for row in rows
            if not row.get('_key') or row['_key'] in specs]


def save(directory, rows):
    previous = load(directory)
    by_key = {row.get('_key'): row for row in previous if row.get('_key')}
    clean = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        current = _display_row(row)
        old = by_key.get(current.get('_key'))
        if current['failed'] and not current['items'] and old and old.get('items'):
            current['items'] = old['items']
            current['failed'] = True
        clean.append(current)
    Store(directory / 'home-snapshot').save({'created': time.time(), 'rows': clean})
    return clean


def shell(directory, addons, library):
    """Return snapshot, or a network-free first-run skeleton."""
    cached = load(directory)
    if cached:
        return cached
    from lib.home_catalogs import descriptors
    rows = [dict(spec, items=[], failed=False) for spec in descriptors(addons)]
    return update_continue_rows(rows, library, directory)


def update_continue_rows(rows, library, directory=None):
    """Replace only Continue Watching using local account state and known artwork."""
    rows = [_display_row(row) for row in rows if isinstance(row, dict)]
    known = {}
    for row in rows:
        if row.get('label') == CONTINUE:
            continue
        for item in row.get('items', []):
            known[(item.get('type'), item.get('id'))] = item
    continuing = []
    saved_rows = library_rows(library, True)
    aged = []
    if directory is not None:
        import sqlite3
        from lib import continue_index
        try:
            continue_index.seed(directory, library)
            saved_rows, aged = continue_index.retained_rows(directory)
        except (sqlite3.Error, OSError):
            saved_rows = []
    for saved in saved_rows:
        item = dict(saved, id=saved.get('_id') or saved.get('id'))
        if directory is None:
            from lib.continue_index import watch_age
            age = watch_age(item)
            if age is not None and age >= 60 * 86400:
                continue
            if age is not None and age >= 30 * 86400:
                aged.append(dict(item, _continue_watching=True))
                continue
        full = known.get((item.get('type'), item.get('id')))
        if full:
            merged = dict(full)
            merged.update(item)
            item = merged
        continuing.append(item)
    from lib.home_upcoming import combine_reminders
    seasonal = [item for row in rows if row.get('label') == REMINDERS
                for item in row.get('items', []) if not item.get('_continue_watching')]
    forgotten = combine_reminders(seasonal, aged, continuing, library)
    rest = [row for row in rows if row.get('label') not in (CONTINUE, REMINDERS)]
    reminders = [{'label': REMINDERS, 'items': forgotten, 'failed': False}] if forgotten else []
    insert_at = next((i for i, row in enumerate(rest) if row.get('label') == 'You May Also Like'), len(rest))
    rest[insert_at:insert_at] = reminders
    return ([{'label': CONTINUE, 'items': continuing, 'failed': False}] if continuing else []) + rest


def update_continue(directory, library):
    rows = update_continue_rows(load(directory), library, directory)
    Store(directory / 'home-snapshot').save({'created': time.time(), 'rows': rows})
    return rows
