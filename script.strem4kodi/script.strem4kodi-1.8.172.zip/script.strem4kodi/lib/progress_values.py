"""Finite, non-negative progress values safe for native UI and SQLite."""
import math


def number(value, default=0):
    try:
        result = float(value)
        return result if math.isfinite(result) and 0 <= result <= 2**63 - 1 else default
    except (TypeError, ValueError, OverflowError):
        return default


def integer(value, default=0):
    return int(number(value, default))
