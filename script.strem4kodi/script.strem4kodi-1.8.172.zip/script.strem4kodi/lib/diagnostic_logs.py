"""Readable Kodi evidence reconstructed from fixed technical fields, never raw logs."""
import re
from functools import lru_cache
from pathlib import Path

READ_LIMIT = 256 * 1024
EXCERPT_LIMIT = 64
_HEADER = re.compile(
    r'^\s*(?P<time>(?:\d{4}-\d{2}-\d{2} )?\d{2}:\d{2}:\d{2}\.\d{3})'
    r'\s+T:(?P<thread>\d{1,12})\s+(?P<level>debug|info|notice|warning|error|fatal)\b'
    r'\s*(?:<[^>\r\n]{0,80}>:)?\s*(?P<message>.*)', re.I)
_GUI = re.compile(
    r'Non[- ]Existent Control(?:\s+\d{1,8})?'
    r'|Control(?:\s+(?:id\s*)?\d{1,8})? does not exist(?: in window(?:\s+\d{1,8})?)?'
    r'|Control(?:\s+(?:id\s*)?\d{1,8})? not found'
    r'|Window(?:\s+(?:id(?:\s+\d{1,8})?|\d{1,8}))? does not exist'
    r'|Unable to locate window with id \d{1,8}', re.I)
_EXCEPTION = re.compile(
    r'\b(MemoryError|RuntimeError|TypeError|ValueError|AttributeError|KeyError|OSError|'
    r'ImportError|ModuleNotFoundError|IndexError|WindowException):')
_FRAME = re.compile(r'File [\'"]([^\'"\r\n]{1,1024})[\'"], line (\d{1,7})')


@lru_cache(maxsize=1)
def _source_names():
    root = Path(__file__).resolve().parents[1]
    # A traceback may name other addons or user files; expose only this package's basenames.
    return {path.name for path in root.glob('*.py')} | {path.name for path in (root/'lib').glob('*.py')}


def _technical_message(text):
    """Allowlist evidence instead of trusting a best-effort credential scrubber."""
    gesture = re.fullmatch(r'Strem4Kodi REMOTE \| OK events=(\d{1,4}) duration_ms=(\d{1,5}) max_gap_ms=(\d{1,5}) context=([01])', text)
    if gesture and 1<=int(gesture[1])<=1000 and all(int(gesture[i])<=60000 for i in (2,3)):
        return 'remote_input','OK events={} duration_ms={} max_gap_ms={} context={}'.format(*gesture.groups())
    # Native CoreELEC/Kodi CEC select/enter events only. Keep the numeric hold
    # duration and timestamps, never typed keys, bus traffic or device names.
    cec = re.search(r'\bPushCecKeypress - received key\s+(?:0x)?(0?b|16)\s+duration\s+(\d{1,6})\b',text,re.I)
    if cec and int(cec[2]) <= 60000:
        return 'remote_input','CEC OK held_ms={}'.format(int(cec[2]))
    action = re.search(r'\b(?:HandleKey|OnKey):[^\r\n]{0,120}\bpressed,\s*'
                       r'(?:window\s+(\d{1,6}),\s*)?action is (Select|Enter|ContextMenu)\s*$',text,re.I)
    if action:
        name={'select':'Select','enter':'Enter','contextmenu':'ContextMenu'}[action[2].lower()]
        return 'remote_input','OK action={} window={}'.format(name,int(action[1]) if action[1] else 0)
    # Reconstruct audio evidence without exporting device names, URLs or raw
    # decoder messages. These correlate the one recap seek with native faults.
    audio_component = re.search(r'\b(CAESinkAUDIOTRACK|CAESinkALSA|CActiveAESink|CActiveAEStream|CDVDAudio|CVideoPlayerAudio)\b', text)
    if audio_component:
        if re.search(r'fail|error|underrun|discontinu|timeout|timed out|stalled',text,re.I):
            return 'audio_failure', audio_component[1] + ' audio failure/stall'
        if re.search(r'::Flush\b|::Initialize\b|::OpenSink\b',text):
            return 'audio_reset', audio_component[1] + ' audio flush/initialization'
    recap = re.search(r'Strem4Kodi RECOVERY \| ((?:rewind|next)\.[a-z]+) \|',text)
    if recap:
        from lib.runtime_trace import _STAGES
        if recap[1] in _STAGES:return ('up_next' if recap[1].startswith('next.') else 'unpause_rewind'),recap[1]
    blocked=re.search(r"Activate of window '(\d{1,6})' refused because there are active modal dialogs",text)
    if blocked:
        return 'window_activation_blocked','Window {} blocked by modal dialog'.format(int(blocked[1]))
    gui = _GUI.search(text)
    if gui:
        return 'gui_control_failure', gui.group(0)
    if 'Traceback (most recent call last)' in text:
        return 'python_traceback', 'Traceback (most recent call last)'
    frame = _FRAME.search(text)
    if frame:
        basename = frame.group(1).replace('\\', '/').rsplit('/', 1)[-1]
        filename = basename if basename in _source_names() else '[external file]'
        return 'python_frame', '{}:{}'.format(filename, int(frame.group(2)))
    error = _EXCEPTION.search(text)
    if error:
        return 'python_error', error.group(1) + ' (message omitted)'
    signal = re.search(r'\b(SIGSEGV|SIGABRT|SIGBUS)\b', text)
    if signal:
        return 'native_crash', signal.group(1)
    for expression, kind, message in (
            (r'\bfatal signal\s+\d{1,3}\b', 'native_crash', 'Fatal signal'),
            (r'\bsegmentation fault\b', 'native_crash', 'Segmentation fault'),
            (r'\bbad_alloc\b|\bout of memory\b|\blow memory\b', 'memory_failure', 'Memory allocation failure'),
            (r'(?:failed|unable) to load (?:texture|image)', 'texture_failure', 'Unable to load texture/image'),
            (r'(?:error|failed|unable).{0,60}(?:parsing xml|load skin|loading window)', 'ui_xml_failure', 'Unable to load XML/skin/window')):
        if re.search(expression, text, re.I):
            return kind, message
    nav = re.search(r'Strem4Kodi NAV \| ([a-z.]+) \| page=([a-z]+) \| action=(\d{1,5})'
                    r' \| focus=(\d{1,6}) \| search_return=([01]) \| preview=([01]) \| error=([A-Za-z-]+)', text)
    if nav:
        from lib.runtime_trace import _STAGES, _ERROR_TYPES
        stage, page, action, focus, search_return, preview, error = nav.groups()
        if (stage in _STAGES and page in {'home','search','discover','library','sports','addons','details'}
                and error in _ERROR_TYPES | {'-'}):
            return 'app_navigation', ('{} page={} action={} focus={} search_return={} preview={} error={}'
                                      .format(*nav.groups()))
    transition = re.search(r'\b(Window Init|Window Deinit|Activating window ID:)\s*\(?\s*(\d{1,6})\)?', text, re.I)
    if transition:
        return 'window_transition', '{} {}'.format(transition.group(1), int(transition.group(2)))
    search = re.fullmatch(r'Strem4Kodi SEARCH \| (search\.[a-z.]+) \| window=(\d{1,6})'
                         r' \| dialog=(\d{1,6}) \| rows=(\d{1,6})', text)
    if search:
        from lib.ui_crash import _STAGES
        if search[1] in _STAGES:
            return 'search_transition', '{} window={} dialog={} rows={}'.format(*search.groups())
    return None


def excerpts(text):
    lines = text.splitlines()
    entries = []
    for number, line in enumerate(lines, 1):
        # Never scan an unbounded payload masquerading as one log line.
        header = _HEADER.match(line[:4096])
        body = header.group('message') if header else line[:4096]
        technical = _technical_message(body)
        if header is None and technical is None:
            continue
        entry = {'line_in_tail': number, 'kind': technical[0] if technical else 'other',
                 'message': technical[1] if technical else '[message omitted]'}
        if header:
            entry.update(time=header.group('time'), thread=int(header.group('thread')),
                         level=header.group('level').lower())
        entries.append(entry)
    # Keep useful failures even when startup chatter follows them. Merge with
    # the final context in original order; at most 64 entries per log.
    failures = [row for row in entries if row['kind'] not in {'other','app_navigation','window_transition'}][-32:]
    errors = [row for row in entries if row.get('level') in {'error','fatal'}][-16:]
    tail = entries[-16:]
    selected = {row['line_in_tail']:row for row in failures + errors + tail}
    return {'entries': [selected[key] for key in sorted(selected)],
            'omitted_lines': len(lines) - len(selected)}


def read_tail(path):
    with Path(path).open('rb') as stream:
        stream.seek(0, 2)
        size = stream.tell()
        stream.seek(max(0, size - READ_LIMIT))
        raw = stream.read(READ_LIMIT)
    if size > READ_LIMIT:
        # The first line may start inside a URL or serialized configuration.
        raw = raw.partition(b'\n')[2]
    return raw.decode('utf-8', 'replace'), size > READ_LIMIT
