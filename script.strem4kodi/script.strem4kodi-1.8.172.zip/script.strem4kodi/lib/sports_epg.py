"""Sports kickoffs, UK clock conversion and the user-selected live window."""
from datetime import datetime, timedelta, timezone
import base64
import json
import math
import re
from urllib.parse import unquote, urlsplit
from lib.title_text import plain

SPAN = 3 * 60 * 60
STEP = 30 * 60
PAGE_ROWS = 7
LIVE_WINDOW = 180 * 60
LIVE_STATUS_GRACE = 15 * 60
MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def catalogue_role(value):
    """Recognise the provider lists with special live-guide semantics."""
    if isinstance(value, dict):
        role = str(value.get('_sports_role') or '').casefold()
        if role:
            return role
        value = value.get('label') or value.get('name') or ''
    text = re.sub(r'[^a-z0-9]+', ' ', str(value or '').casefold()).strip()
    if text in ('live channels', '24hr feeds', '24 hr feeds', '24 hour feeds'):
        return '24hr'
    if text == 'live now':
        return 'live-now'
    return ''


def annotate_rows(rows, catalog):
    """Attach guide behaviour without retaining provider configuration."""
    role = catalogue_role(catalog)
    if not role:
        return rows
    return [dict(row, _sports_role=role) if isinstance(row, dict) else row for row in rows]


def _competition_identity(row):
    if not isinstance(row, dict):
        return ''
    name = plain(row.get('_sports_competition'))
    if not name:
        return ''
    league_id = plain(row.get('_sports_competition_id'))
    if league_id:
        return 'id:' + league_id.casefold()
    country = plain(row.get('_sports_competition_country'))
    return 'name:' + name.casefold() + '\x1f' + country.casefold()


def competition_options(rows):
    """Return stable filter keys and unambiguous user-facing labels."""
    values = {}
    for row in rows:
        key = _competition_identity(row)
        if not key:
            continue
        values.setdefault(key, (plain(row.get('_sports_competition')),
                                plain(row.get('_sports_competition_country'))))
    name_counts = {}
    for name, _country in values.values():
        folded = name.casefold()
        name_counts[folded] = name_counts.get(folded, 0) + 1
    options = []
    for key, (name, country) in values.items():
        label = name
        if name_counts[name.casefold()] > 1:
            label += ' · ' + (country or 'Other')
        options.append({'key': key, 'label': label})
    return sorted(options, key=lambda option: option['label'].casefold())


def competitions(rows):
    """Return distinct user-facing competition labels."""
    return [option['label'] for option in competition_options(rows)]


def competition_rows(rows, competition=''):
    """Filter locally without changing provider rows or paging sentinels."""
    if not competition:
        return rows
    if competition.startswith(('id:', 'name:')):
        return [row for row in rows if _competition_identity(row) == competition]
    # Compatibility for rows/callers created before stable competition keys.
    return [row for row in rows if isinstance(row, dict)
            and plain(row.get('_sports_competition')) == competition]


def uk_datetime(stamp):
    """UK civil time, including BST, without depending on host timezone/tzdata.

    Modern UK transitions are at 01:00 UTC on the last Sundays of March/October.
    This also works on Kodi's Python 3.8 builds without zoneinfo.
    """
    utc = datetime.fromtimestamp(stamp, timezone.utc)
    transitions = []
    for month in (3, 10):
        last = datetime(utc.year, month, 31, 1, tzinfo=timezone.utc)
        transitions.append(last - timedelta(days=(last.weekday() + 1) % 7))
    summer = transitions[0] <= utc < transitions[1]
    return utc.astimezone(timezone(timedelta(hours=int(summer)), 'BST' if summer else 'GMT'))


def provider_timezone(catalog):
    """Read only the timezone option; never retain decoded provider configuration."""
    if not isinstance(catalog, dict):
        return ''
    defaults = catalog.get('defaults')
    defaults = defaults if isinstance(defaults, dict) else {}
    zone = catalog.get('timezone') or defaults.get('timezone')
    if isinstance(zone, str) and zone.strip():
        return zone.strip()[:80]
    if str(catalog.get('addon') or '').casefold() != 'sports streams':
        return ''
    try:
        url = catalog.get('url')
        parts = urlsplit(url if isinstance(url, str) else '').path.split('/')[:-1]
    except ValueError:
        return ''
    for part in reversed(parts):
        if not 4 <= len(part) <= 16384:
            continue
        try:
            data = json.loads(base64.urlsafe_b64decode(unquote(part) + '=' * (-len(unquote(part)) % 4)))
            if isinstance(data, dict) and isinstance(data.get('timezone'), str):
                return data['timezone'][:80]
        except (ValueError, UnicodeError):
            continue
    return ''


def release_start(value, zone=''):
    """Read Sports Streams' dated kickoff label; bare clock times are ambiguous."""
    match = re.fullmatch(r'(\d{1,2}) ([A-Za-z]{3}) (\d{4})\s*[·|,]\s*(\d{1,2}):(\d{2})(?:\s+(GMT|UTC|BST))?', plain(value))
    if not match:
        return None
    try:
        day, month, year, hour, minute, suffix = match.groups()
        date = datetime(int(year), MONTHS.index(month.title()) + 1, int(day), int(hour), int(minute))
        zone = (suffix or zone or 'Europe/London').strip()
        if zone.upper() in ('UTC', 'GMT', 'BST'):
            return date.replace(tzinfo=timezone(timedelta(hours=int(zone.upper() == 'BST')))).timestamp()
        if zone.casefold() in ('europe/london', 'uk'):
            # Test both offsets against the UK calendar. Reject nonexistent
            # spring-forward clock times, choosing the first autumn occurrence.
            base = date.replace(tzinfo=timezone.utc).timestamp()
            return next((stamp for stamp in (base - 3600, base)
                         if uk_datetime(stamp).replace(tzinfo=None) == date), None)
        from zoneinfo import ZoneInfo
        return date.replace(tzinfo=ZoneInfo(zone)).timestamp()
    except (ValueError, OverflowError, OSError, ImportError, KeyError):
        return None


def _valid_timestamp(stamp):
    try:
        if math.isfinite(stamp) and 0 < stamp < 253402300800 - LIVE_WINDOW - 3600:
            datetime.fromtimestamp(stamp, timezone.utc)  # Validate host range too.
            return stamp
    except (ValueError, OverflowError, OSError, TypeError):
        pass
    return None


def timestamp(value):
    """Only accept a full timestamp with an explicit timezone (or Unix time)."""
    try:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            stamp = float(value)
            if stamp > 100000000000:
                stamp /= 1000
            return _valid_timestamp(stamp)
        if not isinstance(value, str) or 'T' not in value:
            return None
        date = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
        return _valid_timestamp(date.timestamp()) if date.tzinfo is not None else None
    except (ValueError, TypeError, OverflowError, OSError):
        return None


def first_time(row, fields):
    for field in fields:
        value = timestamp(row.get(field))
        if value is not None:
            return value
    return None


def entry(row):
    role = str(row.get('_sports_role') or '').casefold()
    continuous = role == '24hr'
    start = first_time(row, ('_sports_source_start', 'startTime', 'start_time', 'start', 'released'))
    if start is None:
        # Display labels already use the provider's UK wall clock. Its config
        # can say GMT even during BST; applying that option adds an hour twice.
        # Explicit offsets in structured timestamps/label suffixes still win.
        start = release_start(row.get('releaseInfo'))
    if start is not None:
        start = _valid_timestamp(start)
    end = first_time(row, ('endTime', 'end_time', 'end'))
    if continuous:
        start = end = None
    if start is None or end is not None and end <= start:
        end = None
    release = plain(row.get('releaseInfo'))
    description = plain(row.get('description'))
    live = continuous or row.get('isLive') is True or bool(re.fullmatch(r'LIVE(?: NOW)?', release, re.I))
    live = live or any(line.strip().upper() == 'LIVE NOW' for line in description.splitlines())
    return dict(row=row, title=plain(row.get('name') or row.get('title')) or 'Sports stream',
                description=description, release=release, live=live, start=start, end=end,
                role=role, continuous=continuous,
                source_unavailable=row.get('_sports_source_unavailable') is True)


def entries(rows, now=None, role=''):
    """Retain supplier order while pruning ended entries from Live Now."""
    role = catalogue_role(role)
    values = [entry(dict(row, _sports_role=role) if role and not row.get('_sports_role') else row)
              for row in rows if isinstance(row, dict) and row.get('id')
              and not row.get('_discover_load_more') and not row.get('_discover_more')]
    if role != 'live-now' and not any(value['role'] == 'live-now' for value in values):
        return values
    now = datetime.now(timezone.utc).timestamp() if now is None else now
    return [value for value in values if value['continuous'] or
            not fixture_status(value) and status(value, now) != 'Ended' and not value['source_unavailable']]


def fixture_status(value):
    if value['continuous']:
        return ''
    state = (value.get('row') or {}).get('_sports_schedule_status')
    return {'postponed': 'Postponed', 'cancelled': 'Cancelled'}.get(state, '') if isinstance(state, str) else ''


def window_start(now):
    return math.floor(now / STEP) * STEP - STEP


def block(value, start, width=1500):
    """Clip a known interval or the three-hour estimated live window."""
    if value['start'] is None or value['source_unavailable'] or fixture_status(value):
        return None
    broadcast_start = first_time(value.get('row') or {}, ('_sports_broadcast_start',))
    left = max(start, min(value['start'], broadcast_start) if broadcast_start is not None else value['start'])
    right = min(start + SPAN, effective_end(value))
    if right <= left:
        return None
    return (left - start) / SPAN * width, (right - left) / SPAN * width


def marker(value, start, width=1500):
    kickoff = value['start']
    if kickoff is None or fixture_status(value) or not start <= kickoff <= start + SPAN:
        return None
    return min(width - 4, (kickoff - start) / SPAN * width)


def effective_end(value):
    if value['start'] is None or fixture_status(value):
        return None
    if value['end'] is not None:
        return value['end']
    estimated = value['start'] + LIVE_WINDOW
    row = value.get('row') or {}
    # A currently-live fixture may run beyond 180 minutes through stoppage,
    # extra time or penalties. Extend the estimate a little beyond the latest
    # schedule observation; each guide reload can move it forward until FT.
    if row.get('_sports_schedule_status') == 'live':
        checked = timestamp(row.get('_sports_schedule_checked'))
        if checked is not None:
            estimated = max(estimated, checked + LIVE_STATUS_GRACE)
    return estimated


def duration_label(value):
    end = effective_end(value)
    if end is None:
        return ''
    minutes = int((end - value['start']) / 60)
    return ('~' if value['end'] is None else '') + str(minutes) + ' min'


def status(value, now):
    if value['source_unavailable']:
        return 'Unavailable'
    exception = fixture_status(value)
    if exception:
        return exception
    if value['start'] is not None:
        if now < value['start']:
            return 'Upcoming'
        end = effective_end(value)
        if now < end:
            return 'Live'
        return 'Ended'
    return 'Live' if value['live'] else value['release'] or 'Available'


def local_time(stamp, date=False):
    try:
        return uk_datetime(stamp).strftime('%a %d %b · %H:%M %Z' if date else '%H:%M')
    except (ValueError, OverflowError, OSError, TypeError):
        return ''


def clock_label(value):
    exception = fixture_status(value)
    if exception:
        return exception
    if value['start'] is None:
        return 'Live stream' if value['live'] else value['release']
    times = local_time(value['start'])
    times += '–' + ('~' if value['end'] is None else '') + local_time(effective_end(value))
    return times


def caption(value, now):
    if value['start'] is None or fixture_status(value):
        return status(value, now)
    return clock_label(value) + ' · ' + duration_label(value) + ' · ' + status(value, now)


def source_countdown(rows, observations=None):
    """Return a strict provider countdown, ignoring generic durations."""
    minutes = []
    for value in (observations or {}).get('countdowns', []):
        if type(value) is int and 0 <= value <= 360:
            minutes.append(value)
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        text = ' '.join(str(row.get(key) or '') for key in ('name', 'title', 'description', 'detail', 'label'))
        for pattern in (
                r'\b(?:the\s+)?stream\s+starts?\s+in\s+(\d{1,3})\s*(?:m|min|mins|minutes?)\b',
                r'\bstarts?\s+in\s+(\d{1,3})\s*(?:m|min|mins|minutes?)\b',
                r'\b(\d{1,3})\s*(?:m|min|mins|minutes?)\s+(?:until|till)\s+(?:the\s+)?stream\s+starts?\b'):
            minutes.extend(int(match) for match in re.findall(pattern, text, re.I))
    return min((value for value in minutes if 0 <= value <= 360), default=None)


def update_from_sources(row, rows, observations=None, now=None):
    """Apply fresh source timing/status to the selected catalogue row in place."""
    if not isinstance(row, dict):
        return False
    now = datetime.now(timezone.utc).timestamp() if now is None else now
    changed = False
    countdown = source_countdown(rows, observations)
    if countdown is not None:
        start = math.floor(now / 60) * 60 + countdown * 60
        if row.get('_sports_source_start') != start:
            row['_sports_source_start'] = start
            changed = True
        if row.pop('_sports_source_unavailable', None) is not None:
            changed = True
    elif rows and row.pop('_sports_source_unavailable', None) is not None:
        # A later successful source search must be able to recover from a
        # provider's earlier explicit unavailable response.
        changed = True
    value = entry(row)
    unavailable = bool((observations or {}).get('unavailable'))
    end = effective_end(value)
    expired = end is not None and now >= end
    schedule_finished = row.get('_sports_schedule_status') == 'finished'
    untimed_live = value['start'] is None and value['live']
    if (unavailable and not value['continuous'] and
            (expired or schedule_finished or untimed_live or fixture_status(value))):
        if row.get('_sports_source_unavailable') is not True:
            row['_sports_source_unavailable'] = True
            changed = True
    return changed
