"""Small viewer-management flow using the existing themed Kodi controls."""
from pathlib import Path
import sqlite3
from account import Store,AccountError
from lib import viewer_profiles as profiles


def share(root, row):
    from lib.ui_dialogs import dialog
    ui=dialog();data=profiles.state(root);source=data.get('active')
    # Master remains accessible only through Settings management.
    targets=sorted((key for key,value in data.get('records',{}).items()
                    if key not in (source,profiles.MAIN) and not value['deleted']),
                   key=lambda key:data['records'][key]['name'].casefold())
    if not targets:
        ui.ok('Share Watch Progress','Create another viewer profile in Settings first.')
        return
    choice=ui.select('Share Watch Progress',[data['records'][key]['name'] for key in targets])
    if choice<0 or choice>=len(targets):return
    target=targets[choice];name=data['records'][target]['name']
    if not ui.yesno('Share Watch Progress','Copy this title’s current progress to '+name+
                    '? This replaces their progress for this title once. Future viewing stays separate.'):
        return
    try:
        profiles.share_progress(root,source,target,row.get('type'),str(row.get('id') or row.get('_id') or ''))
    except (AccountError,OSError,sqlite3.Error) as error:
        ui.ok('Share Watch Progress',str(error))
        return
    ui.notification('Watch progress','Copied to '+name)


def review_conflicts(root, ui=None, identity=None):
    """Review pending progress directly, retaining the existing conflict guards."""
    import xbmc
    from lib.ui_dialogs import dialog
    from lib.native_playback import busy
    from lib.viewer_sync import pending_conflicts, resolve_conflict, refresh_conflict
    from lib.credits_sync import SyncError
    ui = ui or dialog()
    if xbmc.Player().isPlaying() or busy():
        ui.ok('Progress conflicts', 'Stop playback and finish or cancel loading before reviewing progress.')
        return False
    data = profiles.state(root) or {}
    records = data.get('records', {})
    identities = [identity] if identity is not None else sorted(
        (key for key, row in records.items() if not row.get('deleted')),
        key=lambda key: records[key].get('name', '').casefold())
    entries = []
    for viewer in identities:
        if viewer not in records or records[viewer].get('deleted'):
            continue
        for key, pair in sorted(pending_conflicts(root, viewer).items()):
            title = pair['local'].get('name') or key
            label = title + ' · ' + key
            if identity is None:
                label = records[viewer].get('name', viewer) + ' · ' + label
            entries.append((viewer, key, label))
    if not entries:
        ui.ok('Progress conflicts', 'There are no pending progress conflicts to review.')
        return False
    selected = ui.select('Progress conflicts', [entry[2] for entry in entries])
    if selected < 0 or selected >= len(entries):
        return False
    viewer, key, _ = entries[selected]
    def description(row):
        state = row.get('state') or {}
        return '{} · {}s'.format(state.get('lastWatched') or 'Unknown date',
                                 round(float(state.get('timeOffset') or 0) / 1000))
    while True:
        pair = refresh_conflict(root, viewer, key)
        if pair is None:
            ui.ok('Progress conflicts', 'This conflict has already been resolved.')
            return False
        choices = ['Recorded playback: ' + description(pair['local']),
                   'Other saved progress: ' + description(pair['remote'])]
        if pair.get('current') is not None:
            choices.append('Current device progress: ' + description(pair['current']))
        decision = ui.select('Choose progress for ' + (pair['local'].get('name') or key), choices)
        if decision not in range(len(choices)):
            return False
        try:
            resolve_conflict(root, viewer, key, ('local', 'remote', 'current')[decision], expected=pair)
        except SyncError as error:
            if str(error) != 'Viewer progress changed; review the conflict again':
                raise
            ui.ok('Progress changed', 'The title changed while you were reviewing it. Choose again using the latest progress.')
            continue
        if viewer == data.get('active'):
            from lib.progress_signal import publish
            publish(dict(meta_id=pair['local']['_id'], video_id=''))
        ui.notification('Progress conflict', 'Progress choice saved')
        return True


def manage(root, switch_only=False, before_switch=None, ready_cover=None):
    import xbmc
    from lib.ui_dialogs import dialog
    from lib.credits_sync import SyncError
    ui=dialog(ready_cover=ready_cover)
    if not profiles.account_token(root):
        ui.ok('Viewer profiles','Connect your Stremio account first.')
        return False
    # Do not switch the data owner while the decoder or resolver is active.
    from lib.native_playback import busy
    if xbmc.Player().isPlaying() or busy():
        ui.ok('Viewer profiles','Stop playback and finish or cancel loading before changing profiles.')
        return False
    if not profiles.state(root):
        if switch_only:
            ui.ok('Switch profile','Set up viewer profiles in Settings first.')
            return False
        if not ui.yesno('Viewer profiles','Keep your current data as Master and enable separate viewers? With private saved-list sync enabled, viewer data also syncs between devices. Stremio login, providers and device settings stay shared.'):
            return False
        try:profiles.enable(root)
        except AccountError:
            ui.ok('Viewer profiles','Kodi could not save the profiles. Your existing data was kept.')
            return False
        changed=True
    else:changed=False
    master=profiles.state(root).get('records',{}).get(profiles.MAIN,{})
    if master.get('name')=='Main' and not master.get('deleted'):
        try:profiles.edit(root,'rename',profiles.MAIN,'Master')
        except ValueError:pass  # Preserve another viewer already named Master.
    while True:
        data=profiles.state(root);records=data['records'];active=data['active']
        live=sorted((key for key,row in records.items() if not row['deleted'] and
                     (not switch_only or key!=profiles.MAIN)),key=lambda k:records[k]['name'].casefold())
        if switch_only and not live:
            ui.ok('Switch profile','Create a viewer profile in Settings first.')
            return changed
        labels=[records[key]['name']+(' (current)' if key==active else '') for key in live]
        if not switch_only:labels.append('Add profile')
        choice=ui.select('Switch profile' if switch_only else 'Viewer profiles',labels,
                         preselect=live.index(active) if active in live else 0)
        if choice<0:return changed
        try:
            if choice==len(live):
                mode=ui.select('Create profile',['Start empty','Copy everything from Master'])
                if mode<0:continue
                name=ui.input('New profile name')
                if name.strip():profiles.edit(root,'create',name=name,copy_master=mode==1)
                continue
            identity=live[choice]
            if switch_only and identity == active:
                return changed
            options=['Switch to this profile','Rename profile','Delete profile']
            from lib.viewer_sync import pending_conflicts,resolve_conflict,refresh_conflict
            conflicts=pending_conflicts(root,identity)
            if conflicts:options.append('Review {} sync conflicts'.format(len(conflicts)))
            action=0 if switch_only else ui.select(records[identity]['name'],options,preselect=-1)
            if action==0:
                # An unsent final checkpoint must remain with the old viewer.
                from lib.progress_outbox import _worker
                pending=Store(profiles.directory(root)/'progress-outbox').load().get('rows') or []
                if pending or _worker is not None and _worker.is_alive():
                    ui.ok('Saving progress','Your last playback update is still being saved. Please try again in a moment.')
                    continue
                cover = before_switch() if identity != active and before_switch is not None else None
                if identity == active:
                    return changed
                try:
                    profiles.edit(root,'switch',identity)
                except Exception:
                    if cover is not None and hasattr(cover, 'finish'):
                        cover.finish()
                    raise
                return True
            if action==1:
                name=ui.input('Profile name',defaultt=records[identity]['name'])
                if name.strip():profiles.edit(root,'rename',identity,name)
            if action==2 and ui.yesno('Delete profile','Remove '+records[identity]['name']+' from all synced devices? Its local files are retained for recovery; other profiles are kept.'):
                profiles.edit(root,'delete',identity)
                if identity==active:return True
            if action==3 and conflicts:
                def description(row):
                    state=row.get('state') or {}
                    return '{} · {}s'.format(state.get('lastWatched') or 'Unknown date',
                                             round(float(state.get('timeOffset') or 0)/1000))
                while True:
                    conflicts=pending_conflicts(root,identity)
                    keys=sorted(conflicts)
                    if not keys:break
                    selected=ui.select('Progress conflicts',[(conflicts[key]['local'].get('name') or key)+' · '+key for key in keys])
                    if selected<0 or selected>=len(keys):break
                    key=keys[selected]
                    while True:
                        pair=refresh_conflict(root,identity,key)
                        if pair is None:
                            ui.ok('Progress conflicts','This conflict has already been resolved.')
                            break
                        choices=['Recorded playback: '+description(pair['local']),
                                 'Other saved progress: '+description(pair['remote'])]
                        if pair.get('current') is not None:
                            choices.append('Current device progress: '+description(pair['current']))
                        decision=ui.select('Choose progress for '+(pair['local'].get('name') or key),choices)
                        if decision not in range(len(choices)):break
                        try:
                            resolve_conflict(root,identity,key,('local','remote','current')[decision],expected=pair)
                        except SyncError as error:
                            if str(error)!='Viewer progress changed; review the conflict again':raise
                            ui.ok('Progress changed','The title changed while you were reviewing it. Choose again using the latest progress.')
                            continue
                        if identity==active:
                            from lib.progress_signal import publish
                            publish(dict(meta_id=pair['local']['_id'],video_id=''))
                        ui.notification('Progress conflict','Progress choice saved')
                        break
        except (ValueError,RuntimeError,OSError,sqlite3.Error,AccountError,SyncError) as error:
            ui.ok('Viewer profiles',str(error))
