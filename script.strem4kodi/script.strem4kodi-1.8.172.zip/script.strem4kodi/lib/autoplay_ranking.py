"""Lexicographic autoplay ordering after episode, language and ceiling checks."""
import re

from lib.source_preferences import reported_bitrate, reported_size
from lib.stream_presenter import presentation, stream_traits

VIDEO = ('P7 / FEL reported', 'Dolby Vision', 'HDR10+', 'HDR10', 'HDR', 'SDR', 'Unknown')
QUALITY = ('4K', '1080p', '720p', '480p', '360p', 'AUTO')
SOURCE = ('Remux', 'BluRay', 'WEB-DL', 'WEBRip', 'HDTV', 'Unknown')
PROVIDERS = ('AIOStreams', 'Usenet', 'Pengu')


def provider_group(label):
    """Match reported add-on names only; never infer a provider from its URL."""
    value = re.sub(r'[^a-z0-9]', '', str(label or '').casefold())
    if 'aiostreams' in value:return 'AIOStreams'
    if 'usenet' in value:return 'Usenet'
    if 'pengu' in value:return 'Pengu'
    return ''


def video_format(traits):
    values = traits['dynamic']
    if 'FEL reported' in values or 'Profile 7 reported' in values:return VIDEO[0]
    return next((v for v in VIDEO[1:-1] if v in values), 'Unknown')


def video_matches(traits, preferred):
    if preferred in ('FEL reported', VIDEO[0]):
        return video_format(traits) == VIDEO[0]
    if preferred == 'Dolby Vision':return video_format(traits) in (VIDEO[0], 'Dolby Vision')
    if preferred == 'HDR10':return any(v in traits['dynamic'] for v in ('HDR10+', 'HDR10'))
    return preferred in traits['dynamic']


def stage(value, order, preferred=None):
    """An explicit stage preference leads; all remaining values keep order."""
    index = order.index(value) if value in order else len(order)
    if preferred not in (None, '', 'Any', 'AUTO') and preferred in order:
        return (value != preferred, index)
    return (False, index)


def key(row, prefs):
    view = presentation(row)
    traits = stream_traits(row,view)
    video = video_format(traits)
    wanted_video = prefs.get('dynamic')
    if wanted_video == 'FEL reported':wanted_video = VIDEO[0]
    # A Dolby Vision preference includes reported P7/FEL; HDR10 includes
    # HDR10+. Keep the richer format first within that preferred family.
    video_key = (not video_matches(traits, wanted_video), VIDEO.index(video)) if wanted_video not in (None, '', 'Any') else stage(video, VIDEO)
    types = {value.casefold() for value in traits.get('source_types', [])}
    source = next((v for v in SOURCE[:-1] if v.casefold() in types), 'Unknown')
    wanted_source = prefs.get('source_type')
    source_key = (wanted_source.casefold() not in types, SOURCE.index(source)) if wanted_source in SOURCE[:-1] else stage(source, SOURCE)
    audio = view['audio'].partition(' | Language: ')[0].casefold()
    if 'atmos' in audio:audio_rank = 0
    elif 'truehd' in audio:audio_rank = 1
    elif 'dolby digital plus' in audio:audio_rank = 2
    elif 'dolby digital' in audio:audio_rank = 3
    elif 'dts' in audio:audio_rank = 4
    else:audio_rank = 5
    provider = provider_group(traits['provider'])
    return (video_key, stage(traits['quality'], QUALITY, prefs.get('quality')),
            source_key, audio_rank,
            -reported_bitrate(row,view), -reported_size(row,view),
            PROVIDERS.index(provider) if provider in PROVIDERS else len(PROVIDERS))


def rank(rows, prefs):
    return sorted(rows, key=lambda row: key(row, prefs))
