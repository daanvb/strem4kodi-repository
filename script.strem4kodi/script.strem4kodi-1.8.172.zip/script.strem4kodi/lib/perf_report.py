"""Explicit, privacy-safe Home performance report.

Only allowlisted PERF stage durations/counts plus broad environment versions are
submitted. kodi.log, URLs, account data, titles, keys and device IDs are never read.
"""
import hashlib
import json
import math
import re
import statistics
import time
import threading
from pathlib import Path

from account import Store, AccountError
from lib.error_report import _environment, send_report

STAGES = (
    'startup.layout', 'startup.visible',
    'home.cached', 'home.cached.total', 'ui.home.initial',
    'home.refresh.account.local', 'home.refresh.catalogs', 'home.refresh.library.local',
    'ui.home.full', 'ui.home.incremental', 'ui.home.background.total', 'home.refresh.total',
    'benchmark.cached_home', 'benchmark.snapshot_load', 'benchmark.continue_index',
    'benchmark.account_load', 'benchmark.stream_cache',
)
MAX_MS = 30 * 60 * 1000
MAX_COUNT = 10000
_launch_kind = None
_lock = threading.RLock()


def begin_launch(first_in_session):
    global _launch_kind
    _launch_kind = 'first' if first_in_session else 'repeat'


def startup_measurements(profile):
    launches = _store(profile).load().get('launches') or []
    result = {}
    for kind in ('first', 'repeat'):
        samples = [r['ms'] for r in launches if isinstance(r, dict) and r.get('kind') == kind
                   and isinstance(r.get('ms'), int)]
        if samples:
            result[kind] = int(statistics.median(samples))
    return result


def startup_summary(profile):
    measurements = startup_measurements(profile)
    parts = ['{}: {} ms'.format(label, measurements[kind])
             for kind, label in (('first', 'First launch'), ('repeat', 'Repeat'))
             if kind in measurements]
    return ' · '.join(parts) if parts else 'Open Home to record startup'


def _store(profile):
    return Store(Path(profile) / 'performance')


def record(profile, stage, elapsed=None, **counts):
    with _lock:
        _record(profile, stage, elapsed, **counts)


def _record(profile, stage, elapsed=None, **counts):
    global _launch_kind
    if stage not in STAGES:
        return
    row = {}
    if elapsed is not None:
        row['ms'] = max(0, min(MAX_MS, int(elapsed)))
    for key in ('rows', 'items'):
        if key in counts:
            row[key] = max(0, min(MAX_COUNT, int(counts[key])))
    state = _store(profile).load()
    if stage == 'startup.visible' and elapsed is not None and _launch_kind:
        launches = state.get('launches') if isinstance(state.get('launches'), list) else []
        state['launches'] = (launches + [{'kind': _launch_kind, 'ms': row['ms'], 'at': time.time()}])[-12:]
        _launch_kind = None
    timings = state.get('timings') if isinstance(state.get('timings'), dict) else {}
    timings[stage] = row
    state['timings'] = timings
    _store(profile).save(state)


def _stream_provider_rows(rows):
    """Fixed provider families and bounded numeric measurements only."""
    safe = []
    def number(value, maximum):
        if (isinstance(value, bool) or not isinstance(value, (int, float))
                or isinstance(value, float) and not math.isfinite(value)):return None
        return max(0, min(maximum, int(value)))
    for row in rows[:40] if isinstance(rows, list) else []:
        if not isinstance(row, dict):continue
        label = re.sub(r'[^a-z0-9]', '', str(row.get('provider') or '').lower()[:160])
        family = next((name for key, name in (('aiostreams', 'AIOStreams'),
                       ('usenetultimate', 'Usenet Ultimate'), ('penguplay', 'PenguPlay'))
                       if label.startswith(key)), 'Other add-on')
        item = {
            'provider': family,
            'ms': number(row.get('ms'), MAX_MS) or 0,
            'failed': bool(row.get('failed')),
            'rows': number(row.get('rows'), MAX_COUNT) or 0,
        }
        for key in ('request_ms', 'parse_ms', 'delivery_ms', 'published_ms', 'attempts'):
            value = number(row.get(key), 2 if key == 'attempts' else MAX_MS)
            if value is not None:item[key] = value
        safe.append(item)
    return safe


def record_stream_providers(profile, rows):
    """Save once on the existing search worker; never start/upload anything."""
    with _lock:
        state = _store(profile).load()
        state['streamProviders'] = _stream_provider_rows(rows)
        _store(profile).save(state)


def stream_providers(profile):
    """Read only this profile's bounded search snapshot, without Home/playback."""
    with _lock:
        try:
            return _stream_provider_rows(_store(profile).load().get('streamProviders'))
        except (AccountError, OSError):
            return []  # Optional measurements cannot prevent opening settings.


def load(profile):
    state = _store(profile).load()
    timings = state.get('timings')
    if not isinstance(timings, dict):
        return {}
    return {stage: dict(timings[stage]) for stage in STAGES
            if stage in timings and isinstance(timings[stage], dict)}



def set_couch_pass(profile, value):
    state = _store(profile).load()
    timings = state.get('timings') if isinstance(state.get('timings'), dict) else {}
    state.update(timings=timings, validation={'couchPass': bool(value)})
    _store(profile).save(state)


def load_validation(profile):
    state = _store(profile).load()
    value = state.get('validation')
    return {'couchPass': bool(value.get('couchPass'))} if isinstance(value, dict) else {}

def build_payload(profile, environment=None, source_only=False):
    timings = {} if source_only else load(profile)
    provider_rows = stream_providers(profile)
    if not timings and not provider_rows:
        return None
    env = dict(environment or _environment())
    if not env.get('hardwareClass'):
        from lib.hardware_class import current
        env['hardwareClass'] = current(env.get('platform'))
    report = {
        'reportVersion': 1,
        'context': 'Source search performance' if source_only else 'Home performance',
        'errorType': 'PerformanceReport',
        'addonVersion': str(env.get('addonVersion') or 'unknown')[:40],
        'kodiVersion': str(env.get('kodiVersion') or 'unknown')[:80],
        'platform': str(env.get('platform') or 'unknown')[:40],
        'pythonVersion': str(env.get('pythonVersion') or 'unknown')[:40],
        'hardwareClass': str(env.get('hardwareClass') or 'Other')[:40],
        'stack': [],
        'performance': timings,
    }
    if provider_rows:
        report['streamProviders'] = provider_rows
    validation = {} if source_only else load_validation(profile)
    if validation:
        report['validation'] = validation
    identity = dict(report)
    identity['performance'] = {k: sorted(v) for k, v in timings.items()}
    report['fingerprint'] = hashlib.sha256(
        json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()
    ).hexdigest()[:12]
    return report


def send(profile):
    payload = build_payload(profile)
    return bool(payload and send_report(payload))
