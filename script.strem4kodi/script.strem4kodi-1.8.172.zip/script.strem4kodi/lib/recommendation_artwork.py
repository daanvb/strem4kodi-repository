"""Reuse configured poster artwork on title-detail recommendation cards."""
import threading
from lib.catalogue_identity import identity, ARTWORK_FIELDS


def cached(rows, api):
    from lib.catalog_poster import configured
    try:
        resolver = configured(api.STORE.load())
        rows = resolver.cached([{'items': rows}])[0]['items']
        return rows, resolver
    except Exception:
        return rows, None


def start(window, rows, resolver):
    if resolver is None or not resolver.providers or not rows:
        return
    token = object()
    window._similar_artwork_token = token
    def current():
        return (not window.closed and window.section == 'Similar' and window.cards is rows
                and window._similar_artwork_token is token)
    def work():
        try:
            for batch in resolver.refresh([{'items': rows}], cancelled=lambda: not current()):
                with window._row_update_lock:
                    if not current():return
                    art = {identity(row): row for row in batch[0]['items'] if row.get('_poster_preferred')}
                    for position, row in enumerate(rows):
                        fresh = art.get(identity(row))
                        if not fresh:continue
                        changed = any(fresh.get(field) and fresh[field] != row.get(field)
                                      for field in ('poster', 'landscape', 'logo'))
                        row.update({field: fresh[field] for field in ARTWORK_FIELDS if field in fresh})
                        if changed:
                            window.getControl(503).getListItem(position).setArt({
                                'poster': row['poster'], 'thumb': row.get('landscape') or row['poster']})
        except Exception:
            pass  # Optional artwork cannot interrupt navigation.
    try:threading.Thread(target=work, daemon=True).start()
    except RuntimeError:pass
