"""Isolate service tasks; log bounded technical failures without private values."""
import time


class ServiceGuard:
    def __init__(self, logger, clock=time.monotonic, profile=None):
        self.logger=logger
        self.profile=profile
        self.clock=clock
        self.reported={}

    def run(self, name, callback, *args):
        try:
            return callback(*args)
        except Exception as error:
            now=self.clock()
            if now>=self.reported.get(name,0):
                self.reported[name]=now+60
                try:
                    from lib.diagnostic_events import record
                    record('service', error, self.profile)
                except Exception:pass
                # Static task names and error classes only; never exception text.
                kind=type(error).__name__
                if kind not in ('RuntimeError','ValueError','TypeError','AttributeError',
                                'OSError','KeyError','ImportError'):kind='Exception'
                try:self.logger('S4K service: {} failed ({}); will retry.'.format(name,kind))
                except Exception:pass
            return None
