"""Pre-roll lifecycle: end/skip/error starts movie; Stop/Back cancels it."""
import time
from urllib.parse import urlencode
from lib.prerolls import PROPERTY, select

STALL_SECONDS = 10


class ProgressWatch:
    def __init__(self, now):
        self.progress_at = now
        self.position = None

    def stalled(self, now, position, paused=False):
        if paused:
            self.progress_at = now
            return False
        if position is not None and (self.position is None or abs(position-self.position) >= .1):
            self.position = position
            self.progress_at = now
        return now-self.progress_at >= STALL_SECONDS


class Outcome:
    def __init__(self):
        self.started = False
        self.native_finished = False
        self.result = ''
    def finish(self, result):
        # A user's cancellation wins; a skip's Stop callback must not cancel.
        if not self.result:self.result = result
    def action(self, action, visible):
        if action in (10,13,92,216,247):
            self.finish('cancel')
        elif action == 14:
            self.finish('skip')
        elif action == 7 and visible:
            self.finish('skip')
        return visible or action == 7


def skip_window(outcome, gui, addon):
    from lib.theme import window as themed_window
    class SkipWindow(gui.WindowXMLDialog):
        visible = False
        def onInit(self):self.setProperty('skip_visible','false')
        def onAction(self, action):
            self.visible = outcome.action(action.getId(),self.visible)
            if outcome.result:return
            if self.visible:
                self.setProperty('skip_visible','true')
                self.setFocusId(201)
        def onClick(self, control_id):
            if control_id == 201:
                if self.visible:outcome.finish('skip')
                else:
                    self.visible = True
                    self.setProperty('skip_visible','true')
                    self.setFocusId(201)
    return themed_window(SkipWindow,'script-strem4kodi-preroll.xml',addon.getAddonInfo('path'),'Main','1080i')


def play_intro(asset, addon, key, attempt, kodi, gui, window, monitor, cancelled,
               clock=time.monotonic, factory=skip_window):
    outcome = Outcome()
    def owns(player):
        try:
            if player.getPlayingItem().getProperty('Strem4KodiPreRoll') == key:return True
        except Exception:pass
        try:return player.getPlayingFile() == asset['url']
        except Exception:return False
    class IntroPlayer(kodi.Player):
        def onAVStarted(self):
            if outcome.result:return
            if owns(self):outcome.started = True
            else:outcome.finish('cancel')
        def onPlayBackEnded(self):
            if outcome.started:
                outcome.native_finished = True
                outcome.finish('ended')
        def onPlayBackError(self):outcome.finish('error')
        def onPlayBackStopped(self):
            if outcome.started or owns(self):
                outcome.native_finished = True
                outcome.finish('cancel')
    player = IntroPlayer()
    overlay = None
    started = clock()
    progress = None
    try:
        item = gui.ListItem(label='Audio pre-roll',path=asset['url'])
        item.setProperty('Strem4KodiPreRoll',key)
        item.setProperty('Strem4KodiPlaybackAttempt',attempt)
        item.setProperty('IsPlayable','true')
        if cancelled(attempt) or monitor.abortRequested() or window.getProperty(PROPERTY) != key:
            outcome.finish('cancel')
            return outcome.result
        player.play(asset['url'],item)
        from lib.runtime_trace import playback
        playback('intro.start')
        while not outcome.result:
            if cancelled(attempt) or monitor.abortRequested() or window.getProperty(PROPERTY) != key:
                outcome.finish('cancel')
                break
            if outcome.started and overlay is None:
                progress = ProgressWatch(clock())
                playback('intro.ready')
                overlay = factory(outcome,gui,addon)
                overlay.show()
            elapsed = clock()-started
            if (not outcome.started and elapsed >= STALL_SECONDS) or elapsed > 600:
                outcome.finish('error')
                break
            if progress is not None:
                try:position = float(player.getTime())
                except (AttributeError, RuntimeError, TypeError, ValueError):position = None
                try:paused = kodi.getCondVisibility('Player.Paused') is True
                except (AttributeError, RuntimeError):paused = False
                if progress.stalled(clock(), position, paused):
                    playback('intro.stall',reason='caching-stall')
                    outcome.finish('error')
                    break
            monitor.waitForAbort(0.1)
    except Exception:
        outcome.finish('error')
    finally:
        # Publish the handoff before removing Skip or stopping a failed intro.
        # The loading dialog can restore its card on the very next GUI frame.
        if window.getProperty(PROPERTY) == key and outcome.result in ('ended','skip','error'):
            window.setProperty(PROPERTY,'handoff:'+key)
        from lib.runtime_trace import playback
        playback('intro.' + (outcome.result if outcome.result in ('ended','skip','error','cancel') else 'error'))
        if overlay is not None:
            try:overlay.close()
            except Exception:pass
        # Only stop our pre-roll. Never interrupt another playback request.
        if window.getProperty(PROPERTY) in (key,'handoff:'+key) and outcome.result != 'ended':
            try:
                # PlayMedia replaces a skipped intro directly. Explicit Stop
                # first returns Kodi to its GUI/display mode before the movie.
                if outcome.result != 'skip' and not outcome.native_finished and owns(player):player.stop()
            except Exception:pass
    return outcome.result


def run(key, kodi=None, gui=None, addon=None, store=None, intro=play_intro):
    if kodi is None:import xbmc as kodi
    if gui is None:import xbmcgui as gui
    if addon is None:
        from addon_state import get_addon
        addon=get_addon()
    if store is None:
        import xbmcvfs
        from account import Store
        store=Store(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
    from account import Store
    from lib.playback_loading import cancelled
    window=gui.Window(10000)
    if window.getProperty(PROPERTY) != key:return
    proceed=False
    valid=False
    attempt=''
    try:
        from lib.playback_payload import load
        cache=load(store.directory,key)
        stream=(cache.get('urls') or {}).get(key) or {}
        if not isinstance(stream,dict) or not stream.get('url'):return
        attempt=stream.get('_playback_attempt','')
        if cancelled(attempt) or time.time()-float(cache.get('created') or 0)>3600:return
        valid=True
        asset=select(stream.get('meta') or {},stream,stream.get('resume_ms'),addon)
        monitor=kodi.Monitor()
        if cancelled(attempt) or monitor.abortRequested() or window.getProperty(PROPERTY) != key:return
        result=intro(asset,addon,key,attempt,kodi,gui,window,monitor,cancelled) if asset else 'ended'
        proceed=result in ('ended','skip','error') and not cancelled(attempt) and not monitor.abortRequested()
    except Exception:
        proceed=valid and not cancelled(attempt)
    finally:
        # A newer request owns the player now; this script must not launch over it.
        if window.getProperty(PROPERTY) not in (key,'handoff:'+key):proceed=False
        elif proceed:window.setProperty(PROPERTY,'handoff:'+key)
        else:window.clearProperty(PROPERTY)
    if proceed:
        url='plugin://script.strem4kodi/?'+urlencode({'action':'play','key':key})
        if cancelled(attempt) or window.getProperty(PROPERTY) != 'handoff:'+key:
            if window.getProperty(PROPERTY) == 'handoff:'+key:window.clearProperty(PROPERTY)
            return
        kodi.executebuiltin('PlayMedia('+url+')')
