"""Companion pause button: suppress its repeat burst, use native PlayPause."""
import hashlib
import json
import time

PROPERTY = 'strem4kodi.player.pause_press'
QUIET_SECONDS = .75


def run(kodi, window, rpc, clock=time.monotonic):
    player = kodi.Player()
    if not player.isPlayingVideo() or not kodi.getCondVisibility('Player.PauseEnabled'):
        return
    identity = hashlib.sha256(player.getPlayingFile().encode()).hexdigest()
    # Capture the desired state before reading the shared marker. If two
    # scripts both observe an old marker, both captured the pre-command state.
    play = bool(kodi.getCondVisibility('Player.Paused') or
                kodi.getCondVisibility('Player.Forwarding | Player.Rewinding'))
    now = clock()
    try:previous = json.loads(window.getProperty(PROPERTY))
    except (ValueError, TypeError):previous = {}
    try:elapsed = now-float(previous.get('time', -1000)) if isinstance(previous, dict) else 1000
    except (ValueError, TypeError, OverflowError):elapsed = 1000
    window.setProperty(PROPERTY, json.dumps({'identity':identity, 'time':now}))
    if isinstance(previous, dict) and previous.get('identity') == identity and 0 <= elapsed < QUIET_SECONDS:
        return
    # Explicit desired state is safe if two script instances query the same
    # native state before it changes. Seeking remains the observer's job.
    rpc('Player.PlayPause', {'playerid':1, 'play':play})
