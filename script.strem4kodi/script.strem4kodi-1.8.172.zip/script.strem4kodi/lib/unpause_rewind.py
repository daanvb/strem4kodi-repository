"""Prepare a recap while paused; dispatch one native scrub immediately on Play."""
import math
import time
import threading

PAUSE_SECONDS = (5, 10, 15, 30, 60, 120, 300)
REWIND_SECONDS = (3, 5, 7, 10, 12, 15, 20, 30)


def choice(addon, key, values, default):
    try:
        index = int(addon.getSetting(key))
        return values[index] if 0 <= index < len(values) else default
    except (TypeError, ValueError):
        return default


class UnpauseRewind:
    def __init__(self, clock=time.monotonic, ready=lambda: False, trace=lambda stage: None,
                 resuming=lambda: False):
        self.lock = threading.RLock()
        self.clock = clock
        # True only while the native player is paused and not buffering.
        self.ready = ready
        self.resuming = resuming
        self.trace = trace
        self.reset()

    def reset(self):
        with self.lock:
            self.paused = None
            self.attempted = False
            self.prepared = False
            self.pending_resume = None

    def event(self, stage):
        try:self.trace(stage)
        except Exception:pass

    def _reset_if(self, paused):
        with self.lock:
            if self.paused is paused:self.reset()

    def pause(self, session, filename, position):
        recorded = False
        with self.lock:
            if self.pending_resume is not None:self.reset()
            if not session or not filename or not math.isfinite(position):
                self.reset()
                return
            if self.paused and self.paused[:2] != (session, filename):self.reset()
            # A duplicate callback must not restart the timer or repeat our seek.
            if self.paused is None:
                self.paused = (session, filename, max(0, position), self.clock())
                recorded = True
        if recorded:self.event('rewind.pause')

    def resume(self, player, addon, session, filename, position, seek):
        paused = self.paused
        try:
            if self.pending_resume is not None and self.clock()>self.pending_resume:
                self._reset_if(paused);self.event('rewind.skipped');return False
            target = self.target(addon, session, filename, position)
            if (target is None or not player.isPlayingVideo()
                    or player.getPlayingFile() != filename or self.paused is not paused):
                self._reset_if(paused)
                return False
            ready=self.resuming()
            if self.paused is not paused:
                self._reset_if(paused);return False
            if not ready:
                # Kodi's resume callback can precede the Paused/Caching flag
                # update. Keep this one intent briefly; never seek a paused
                # passthrough decoder or add a delay on the normal path.
                with self.lock:
                    if self.paused is not paused:return False
                    if self.pending_resume is None:self.pending_resume=self.clock()+2
                return False
            # Consume BEFORE the native call: its seek/resume callbacks can
            # re-enter Python. Never seek while paused or retry on later ticks.
            with self.lock:
                if self.paused is not paused or self.attempted:return False
                self.reset()
            seconds = int(round(target-position))
            if not seconds:return False
            seek(seconds)
            self.event('rewind.seek')
            return True
        except Exception:
            self._reset_if(paused)
            self.event('rewind.error')
            return False
        finally:
            # Diagnostic persistence must not delay the native recap scrub.
            if paused:self.event('rewind.resume')

    def retry_resume(self, player, addon, session, filename, seek):
        if self.pending_resume is None:return False
        if self.clock()>self.pending_resume:
            self.reset();self.event('rewind.skipped');return False
        try:return self.resume(player,addon,session,filename,float(player.getTime()),seek)
        except Exception:
            self.reset();self.event('rewind.error');return False

    def target(self, addon, session, filename, position):
        paused = self.paused
        if paused is None or self.attempted:return None
        if (paused[:2] != (session, filename) or not math.isfinite(position)
                or abs(position-paused[2]) > 2):return None
        if addon.getSetting('unpause_rewind_enabled') != 'true':return None
        if self.clock()-paused[3] < choice(addon,'unpause_rewind_pause',PAUSE_SECONDS,30):return None
        return max(0,paused[2]-choice(addon,'unpause_rewind_seconds',REWIND_SECONDS,10))

    def seeked(self, time_ms):
        """A user's scrub cancels the recap for this pause."""
        del time_ms
        with self.lock:
            paused = self.paused
            if paused:
            # Keep the active pause disarmed through duplicate pause callbacks.
                self.attempted = True
                self.prepared = False
        if paused:self.event('rewind.skipped')

    def apply(self, player, addon, session, filename):
        paused = self.paused
        if paused is None or self.attempted:return False
        if paused[:2] != (session, filename):
            self.reset()
            return False
        if addon.getSetting('unpause_rewind_enabled') != 'true':
            self.attempted = True
            return False
        if self.clock()-paused[3] < choice(addon,'unpause_rewind_pause',PAUSE_SECONDS,30):return False
        try:
            if not player.isPlayingVideo() or player.getPlayingFile() != filename:
                self.reset()
                return False
            if not self.ready():return False
            position = float(player.getTime())
            if not math.isfinite(position) or abs(position-paused[2]) > 2:
                self.attempted = True
                self.event('rewind.skipped')
                return False
            target = self.target(addon,session,filename,position)
            if target is None:return False
            # Recheck after querying the native player: a resume callback may
            # have arrived while this tick was preparing the request.
            if not self.ready() or self.paused is not paused:return False
            if abs(position-target) < .25:return False
            with self.lock:
                if self.paused is not paused or self.prepared:return False
                self.prepared = True
            # Seeking a paused passthrough decoder can leave stale audio in its
            # queue. Record readiness only; resume performs a normal relative
            # scrub as playback becomes active, without a settling timer.
            self.event('rewind.prepared')
            return True
        except Exception:
            self.attempted = True
            self.prepared = False
            self.event('rewind.error')
            return False
