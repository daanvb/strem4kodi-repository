"""Episode air dates for display and source selection."""
from datetime import datetime, timezone
import re

from lib.sports_epg import uk_datetime

MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def air_date(row):
    # Generic episode `released` timestamps often encode a date with an
    # arbitrary clock value. Only an explicit schedule start is an airtime.
    scheduled = row.get('_broadcast_start') or row.get('startTime') or row.get('start_time')
    if isinstance(scheduled, str):
        try:
            parsed = datetime.fromisoformat(scheduled.strip().replace('Z', '+00:00'))
            if parsed.tzinfo is not None:
                return uk_datetime(parsed.timestamp()), True
        except (ValueError, OverflowError, OSError):
            pass
    value = row.get('released') or row.get('firstAired') or row.get('releaseInfo') or ''
    if not isinstance(value, str):
        return None, False
    value = value.strip()
    if not re.match(r'^\d{4}-\d{2}-\d{2}(?:$|T| )', value):
        return None, False
    try:
        return datetime.fromisoformat(value[:10]), False
    except (ValueError, OverflowError, OSError):
        return None, False


def label(row):
    parsed, has_time = air_date(row)
    if parsed is None:
        value = row.get('released') or row.get('firstAired') or row.get('releaseInfo') or ''
        return value.strip() if isinstance(value, str) and re.fullmatch(r'\d{4}', value.strip()) else ''
    result = '{} {} {}'.format(parsed.day, MONTHS[parsed.month - 1], parsed.year)
    return '{} · {:02d}:{:02d} UK'.format(result, parsed.hour, parsed.minute) if has_time else result


def card_labels(row, now=None):
    """Keep aired dates below the card; show upcoming schedules on artwork."""
    date = label(row)
    if upcoming(row, now):
        parsed, has_time = air_date(row)
        if has_time:
            return '', 'Airs {} {} · {:02d}:{:02d} UK'.format(
                parsed.day, MONTHS[parsed.month - 1], parsed.hour, parsed.minute)
        return '', 'Airs ' + date if date else ''
    return date.split(' · ', 1)[0], ''


def upcoming(row, now=None):
    parsed, has_time = air_date(row)
    if parsed is None:
        return False
    now = now or datetime.now(timezone.utc)
    uk_now = uk_datetime(now.timestamp())
    if not has_time:
        return parsed.date() > uk_now.date()
    return parsed.replace(tzinfo=None) > uk_now.replace(tzinfo=None)


def release_today_without_time(row, now=None):
    parsed, has_time = air_date(row)
    if parsed is None or has_time:
        return False
    now = now or datetime.now(timezone.utc)
    return parsed.date() == uk_datetime(now.timestamp()).date()
