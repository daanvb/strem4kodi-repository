"""Fast IMDb title autocomplete with a Cinemeta fallback."""
from concurrent.futures import ThreadPoolExecutor
import re
from search_match import normalized, relevance, search_artwork, searchable_title, title_relevance, query_variants, title_identity
from urllib.parse import quote
from protocol import fetch, resource_url

HOME = 'https://v3-cinemeta.strem.io/manifest.json'


def ranked(query, rows, limit=40, allow_pending_artwork=False):
    output, seen = [], set()
    for row in rows:
        candidate = row
        if allow_pending_artwork and isinstance(row, dict) and row.get('_artwork_pending') is True:
            deferred = row.get('_fallback_artwork')
            if isinstance(deferred, dict):
                # The configured artwork resolver deliberately hides old art.
                # Validate the original image without restoring it for display.
                candidate = dict(row, **{field: deferred[field] for field in
                                       ('poster', 'background', 'landscape') if field in deferred})
        if not searchable_title(candidate):continue
        score = title_relevance(query,row)
        key = title_identity(row)
        if score is None or not row.get('id') or key in seen:continue
        seen.add(key);output.append((score,len(output),dict(row,poster=search_artwork(row))))
    return [row for _,_,row in sorted(output,key=lambda r:r[:2])][:limit]


def imdb_titles(payload):
    types = {'movie':'movie','tvMovie':'movie','tvSeries':'series','tvMiniSeries':'series'}
    rows=[]
    for row in payload.get('d',[]) if isinstance(payload,dict) else []:
        if not isinstance(row,dict) or row.get('qid') not in types:continue
        if not re.fullmatch(r'tt[0-9]+',str(row.get('id',''))):continue
        image=row.get('i') if isinstance(row.get('i'),dict) else {}
        rows.append({'id':row['id'],'type':types[row['qid']],'name':row.get('l') or '',
                     'year':row.get('y') or '', 'poster':image.get('imageUrl') or ''})
    return rows


def lookup(query, fetcher=None, imdb_fetcher=None):
    term = normalized(str(query or '')[:200])
    if len(term) < 2:return []
    imdb_fetcher = imdb_fetcher or (lambda url:fetch(url,timeout=2))
    def imdb_request(variant):
        try:
            url = ('https://v3.sg.media-imdb.com/suggestion/'
                   + quote(variant[0].lower(), safe='') + '/'
                   + quote(variant, safe='') + '.json')
            return imdb_titles(imdb_fetcher(url))
        except Exception:
            return []
    # IMDb is punctuation-sensitive even though our ranking is not. Search
    # the possessive form too: a nonempty 'bobs' response can omit Bob's Burgers.
    with ThreadPoolExecutor(max_workers=3) as pool:
        batches = list(pool.map(imdb_request, query_variants(query)))
    rows = ranked(term, [row for batch in batches for row in batch])
    if rows:
        return rows
    fetcher = fetcher or (lambda url:fetch(url,timeout=3))
    def request(kind):
        try:
            data = fetcher(resource_url(HOME,'catalog',kind,'top',{'search':term}))
            return [dict(row,type=kind) for row in data.get('metas',[])[:40] if isinstance(row,dict) and row.get('type',kind)==kind]
        except Exception:return []
    with ThreadPoolExecutor(max_workers=2) as pool:
        batches = list(pool.map(request,('movie','series')))
    return ranked(term,[row for batch in batches for row in batch])


def entries(query, history, matches=()):
    key = normalized(query)
    rows = [{'query':r['name'],'name':r['name'],
             'subtitle':('Exact match · ' if title_relevance(query,r)==0 else '') + ('Movie' if r['type']=='movie' else 'Series') + (' · '+str(r.get('year') or r.get('releaseInfo') or '')[:14] if r.get('year') or r.get('releaseInfo') else ''),
             'poster':r.get('poster') or '', 'kind':'title', 'exact':title_relevance(query,r)==0,
             'meta':dict(r)} for r in ranked(query,matches,allow_pending_artwork=True)] if key else []
    collections = [r for r in matches if r.get('type') == 'collection' and r.get('_catalogue')
                   and key and relevance(query,r.get('name','')) is not None]
    collections.sort(key=lambda r:relevance(query,r.get('name','')))
    collection_rows = [{'query': r['name'], 'name': r['name'], 'subtitle': 'Collection · Release order' if r['_catalogue'].get('_tmdb_collection') else 'Genre · Popular titles' if r['_catalogue'].get('_genre') else 'Public list · MDBList' if r['_catalogue'].get('_mdblist') else 'Catalogue · Supplied order',
                        'poster': r.get('poster') or '', 'kind': 'catalogue', 'exact': False, 'meta': dict(r)}
                       for r in collections]
    rows = collection_rows + rows
    seen = {normalized(row['query']) for row in rows}
    for value in history:
        if isinstance(value,str) and (not key or relevance(query,value) is not None) and normalized(value) not in seen:
            rows.append({'query':value,'name':value,'subtitle':'','poster':'','kind':'recent'})
            seen.add(normalized(value))
    return rows[:60]
