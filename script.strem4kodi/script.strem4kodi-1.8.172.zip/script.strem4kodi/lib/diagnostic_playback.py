"""Ten self-contained, redacted playback reports per private diagnostic client."""
import base64
import gzip
import hashlib
import io
import json
import os
import re
import tempfile
import zlib
from pathlib import Path

KEEP = 10
PACKED_LIMIT = 1024 * 1024 - 1
RAW_LIMIT = 2 * 1024 * 1024
SOURCES = ('kodi.log', 'kodi.old.log', 'android-crash')


def event(value):
    if not isinstance(value, dict):raise ValueError('Invalid playback report event')
    if not re.fullmatch(r'[0-9a-f]{32}', str(value.get('id', ''))):raise ValueError('Invalid playback report identity')
    if value.get('outcome') not in ('ended', 'stopped', 'error'):raise ValueError('Invalid playback outcome')
    if value.get('kind') not in ('movie', 'series', 'sports'):raise ValueError('Invalid playback kind')
    ended = value.get('ended_at')
    if type(ended) is not int or not 0 < ended < 2100000000:raise ValueError('Invalid playback timestamp')
    return {key:value[key] for key in ('id', 'outcome', 'kind', 'ended_at')}


def _unpack(data):
    if len(data) > PACKED_LIMIT:raise ValueError('Playback report too large')
    with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
        raw = stream.read(RAW_LIMIT + 1)
    if len(raw) > RAW_LIMIT:raise ValueError('Playback report expands beyond limit')
    result = json.loads(raw)
    event(result.get('playback'))
    if type(result.get('sequence')) is not int or result['sequence'] < 1:raise ValueError('Invalid playback sequence')
    return result


def _write(path, data):
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix='.playback-')
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):os.unlink(temporary)


def entries(profile):
    """Recover an interrupted slot replacement; all calls hold upload_guard."""
    from account import Store, AccountError
    root = Path(profile) / 'diagnostic-export' / 'playback'
    try:state = Store(root).load()
    except AccountError:state = {}
    reports = state.get('reports')
    known = {row.get('file'):row for row in reports if isinstance(row, dict)} if isinstance(reports,list) else {}
    rows = []
    for number in range(KEEP):
        name = '{}.json.gz'.format(number)
        path = root / name
        try:
            if path.is_symlink() or path.stat().st_size > PACKED_LIMIT:continue
            data = path.read_bytes()
            sha = hashlib.sha256(data).hexdigest()
            prior = known.get(name, {})
            if prior.get('sha256') == sha and type(prior.get('sequence')) is int:
                row = dict(event(prior), sequence=prior['sequence'], file=name, sha256=sha,
                           bytes=len(data), uploaded=prior.get('uploaded') is True)
            else:
                bundle = _unpack(data)
                row = dict(event(bundle['playback']), sequence=bundle['sequence'],
                           file=name, sha256=sha, bytes=len(data))
            rows.append(row)
        except (OSError, ValueError, EOFError, TypeError, KeyError, zlib.error):continue
    rows.sort(key=lambda row:row['sequence'])
    return rows[-KEEP:]


def _store(profile, rows):
    from account import Store, AccountError
    store = Store(Path(profile) / 'diagnostic-export' / 'playback')
    try:index = store.load().get('index_sha256')
    except AccountError:index = None
    store.save({'reports':rows[-KEEP:], 'index_sha256':index})


def _manifest(rows):
    return json.dumps({'version':1, 'reports':[
        {key:value for key,value in row.items() if key!='uploaded'} for row in rows
    ]}, sort_keys=True, separators=(',', ':')).encode()


def save(profile, report, attachments, completed):
    """Persist once per owned playback, independently of periodic log slots."""
    completed = event(completed)
    rows = entries(profile)
    if any(row['id'] == completed['id'] for row in rows):return
    # Pick the newest available capture for each source. Periodic slots may
    # rotate freely after these redacted texts are copied into this bundle.
    selected = {}
    from lib.diagnostic_archive import TEXT_LIMIT
    for descriptor, data in attachments:
        source = descriptor.get('source')
        if source not in SOURCES:continue
        if hashlib.sha256(data).hexdigest() != descriptor.get('sha256'):raise ValueError('Log checksum mismatch')
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
            text = stream.read(TEXT_LIMIT + 128)
        if len(text) > TEXT_LIMIT + 64:raise ValueError('Log expands beyond limit')
        selected[source] = {'text':text.decode('utf-8', 'replace'),
                            'captured':descriptor.get('captured'),
                            'input_truncated':descriptor.get('input_truncated', False)}
    sequence = max((row['sequence'] for row in rows), default=0) + 1
    bundle = dict(version=1, sequence=sequence, playback=completed, report=report, logs=selected)
    raw = json.dumps(bundle, sort_keys=True, separators=(',', ':')).encode()
    if len(raw) > RAW_LIMIT:raise ValueError('Playback report too large')
    packed = gzip.compress(raw, mtime=0)
    if len(packed) > PACKED_LIMIT:raise ValueError('Playback report too large')
    used = {row['file'] for row in rows}
    name = next((str(i)+'.json.gz' for i in range(KEEP) if str(i)+'.json.gz' not in used), rows[0]['file'] if rows else '0.json.gz')
    root = Path(profile) / 'diagnostic-export' / 'playback'
    root.mkdir(parents=True, exist_ok=True)
    _write(root/name, packed)
    rows = [row for row in rows if row['file'] != name]
    rows.append(dict(completed, sequence=sequence, file=name, sha256=hashlib.sha256(packed).hexdigest(), bytes=len(packed)))
    _store(profile, rows)


def pending(profile):
    from account import Store, AccountError
    rows = entries(profile)
    if not rows:return False
    try:prior = Store(Path(profile) / 'diagnostic-export' / 'playback').load().get('index_sha256')
    except AccountError:prior = None
    return (any(not row.get('uploaded') for row in rows) or
            prior != hashlib.sha256(_manifest(rows)).hexdigest())


def upload(profile, token, identity, transport=None, still_current=lambda:True):
    from lib.credits_sync import request, SyncError
    transport = transport or request
    if not re.fullmatch(r'[0-9a-f]{32}', str(identity)):raise ValueError('Invalid diagnostic client')
    rows = entries(profile)
    if not rows:return True
    if not still_current():return False
    if transport(token).get('private') is not True:raise SyncError('Playback reports require a private repository')
    root = Path(profile) / 'diagnostic-export' / 'playback'
    prefix = '/contents/diagnostic-playback/' + identity + '/'
    for row in rows:
        if row.get('uploaded'):continue
        if not still_current():return False
        data = (root/row['file']).read_bytes()
        if hashlib.sha256(data).hexdigest() != row['sha256']:raise ValueError('Playback report changed')
        path = prefix + row['file']
        prior = transport(token, path)
        if not still_current():return False
        if not prior or base64.b64decode(prior.get('content', '')) != data:
            payload = dict(message='Update private playback diagnostic report', content=base64.b64encode(data).decode())
            if prior:payload['sha'] = prior['sha']
            transport(token, path, payload)
            verified = transport(token, path)
            if not verified or base64.b64decode(verified.get('content', '')) != data:
                raise SyncError('Playback report upload could not be verified')
        row['uploaded'] = True
        _store(profile, rows)
    # A small manifest makes the last ten reports discoverable and checksummed.
    if not still_current():return False
    raw = _manifest(rows)
    path = prefix + 'index.json'
    prior = transport(token, path)
    if not still_current():return False
    if not prior or base64.b64decode(prior.get('content', '')) != raw:
        payload = dict(message='Update private playback diagnostic index', content=base64.b64encode(raw).decode())
        if prior:payload['sha'] = prior['sha']
        transport(token, path, payload)
        verified = transport(token, path)
        if not verified or base64.b64decode(verified.get('content', '')) != raw:
            raise SyncError('Playback index upload could not be verified')
    from account import Store
    Store(root).save(dict(reports=rows, index_sha256=hashlib.sha256(raw).hexdigest()))
    return True
