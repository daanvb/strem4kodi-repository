"""Observe Kodi's native startup wait without closing or hiding its dialogs."""


def seek_relative(seconds):
    """Use Kodi's ordinary scrub path so video and passthrough audio flush together."""
    import json
    import xbmc
    result = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc':'2.0','id':1,'method':'Player.Seek',
        'params':{'playerid':1,'value':{'seconds':int(seconds)}}})))
    if not isinstance(result,dict) or 'error' in result or 'result' not in result:
        raise RuntimeError('Native recap seek unavailable')


def busy():
    try:
        import xbmc
        # Artwork can be hidden by the skin while the native modal is active.
        return xbmc.getCondVisibility(
            'Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)') is True
    except (ImportError, AttributeError, RuntimeError):
        return False
