"""Prepare sparse account entries before displaying their hero."""
from concurrent.futures import ThreadPoolExecutor


def prepare(rows, catalogs, fetch_details=None):
    known = {(r.get('type'), r.get('id')): r
             for catalog in catalogs for r in catalog.get('items', [])
             if r.get('background') and r.get('description')}

    def enrich(row):
        result = dict(row)
        full = known.get((row.get('type'), row.get('id')))
        if full is None:
            if fetch_details is None:
                return result
            try:
                full = fetch_details(row)
            except Exception:
                return result
        # Keep playback state and identity from the account entry.
        for field in ('name', 'background', 'logo', 'description', 'tagline', 'year', 'releaseInfo',
                      'imdbRating', 'runtime', 'genres', 'released', 'certification', 'mpaa', 'certificate_gb', 'certificate_country',
                      'imdb_id', 'imdbId', '_imdbId', 'ids', 'external_ids', 'externalIds',
                      'quality', 'resolution', 'height', 'audio', 'audioCodec', 'hdr', 'bitDepth',
                      'availableFormats', 'videoFormats', 'audioFormats',
                      'cast', 'castPeople', 'director', 'directorPeople'):
            if full.get(field):
                result[field] = full[field]
        return result

    # Home's ready path only merges local snapshots; threads add startup work
    # and can fail under resource pressure without doing any network lookup.
    if fetch_details is None:
        return [enrich(row) for row in rows]
    with ThreadPoolExecutor(max_workers=8) as pool:
        return list(pool.map(enrich, rows))
