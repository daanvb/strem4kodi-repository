"""Match provider language fields, including common English flag labels.

Only pass the dedicated language field: GB in a file size is not a language.
These are provider labels, not proof of the file's actual audio tracks.
"""
import re


def matches_language(reported, preferred):
    wanted = str(preferred or '').strip().casefold()
    tokens = set(re.findall(r'[a-z]+', str(reported or '').casefold()))
    # Stream cards decode flag emoji to country codes; structured language
    # lists may already contain those codes. Retain them in the display.
    flags = re.findall(r'[\U0001F1E6-\U0001F1FF]{2}', str(reported or ''))
    tokens.update(''.join(chr(ord(c)-0x1F1E6+ord('a')) for c in flag) for flag in flags)
    aliases = {'english', 'eng', 'en', 'gb', 'gbr', 'uk', 'us', 'usa'} if wanted in ('english', 'eng', 'en') else {wanted}
    return bool(wanted and tokens & aliases)
