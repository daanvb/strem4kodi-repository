"""Bound full in-memory hero metadata during long browsing sessions."""
from collections import OrderedDict
import threading


class HeroMemory(OrderedDict):
    def __init__(self, limit=64):
        super().__init__()
        self.limit=limit
        self.lock=threading.RLock()

    def __setitem__(self, key, value):
        with self.lock:
            super().__setitem__(key,value)
            self.move_to_end(key)
            while len(self)>self.limit:self.popitem(last=False)

    def get(self, key, default=None):
        with self.lock:
            value=super().get(key,default)
            if key in self:self.move_to_end(key)
            return value

    def clear(self):
        with self.lock:super().clear()
