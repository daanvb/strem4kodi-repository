"""Kodi texture-cache transforms for cinematic background artwork."""
from urllib.parse import quote, unquote


def blurred_background(artwork, width=64, height=36):
    """Return a soft, cacheable Kodi texture URL for a full-screen backdrop.

    Kodi has no live backdrop-blur shader for skin image controls. Resizing the
    source into a small bilinear texture and letting the skin scale it to screen
    size produces a soft background using Kodi's normal texture cache. Keep the
    source URL intact inside Kodi's image:// wrapper; do not fetch it in Python.
    """
    artwork = str(artwork or '').strip()
    if not artwork:
        return ''
    if artwork.startswith('image://'):
        artwork = unquote(artwork[len('image://'):].split('/', 1)[0])
    if not artwork.startswith(('http://', 'https://', 'special://', 'file://')):
        return artwork
    try:
        width = max(16, min(256, int(width)))
        height = max(9, min(144, int(height)))
    except (TypeError, ValueError):
        width, height = 64, 36
    return ('image://' + quote(artwork, safe='') + '/transform?width=' + str(width)
            + '&height=' + str(height) + '&scaling_algorithm=bilinear')
