"""Finite episode runtime and progress values shared by initial and refreshed cards."""
import math
import re


def minutes(value):
    if value is None or isinstance(value, bool):
        return 0
    text = str(value).strip()
    iso = re.fullmatch(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?', text, re.I)
    clock = re.fullmatch(r'(\d{1,2}):(\d{2}):(\d{2})', text)
    units = re.fullmatch(r'(?:(\d+)\s*h(?:ours?)?)?\s*(?:(\d+)\s*m(?:in(?:ute)?s?)?)?', text, re.I)
    try:
        if iso and any(iso.groups()):
            result = int(iso[1] or 0) * 60 + int(iso[2] or 0) + float(iso[3] or 0) / 60
        elif clock and int(clock[2]) < 60 and int(clock[3]) < 60:
            result = int(clock[1]) * 60 + int(clock[2]) + int(clock[3]) / 60
        elif units and any(units.groups()):
            result = int(units[1] or 0) * 60 + int(units[2] or 0)
        else:
            result = float(text)
            result = result / 60000 if result > 10000 else result / 60 if result > 300 else result
        return max(1, int(round(result))) if math.isfinite(result) and 0 < result <= 1440 else 0
    except (ValueError, TypeError, OverflowError):
        return 0


def progress(video_id, state, runtime=None, watched=False):
    if not video_id or not isinstance(state, dict) or str(video_id) != str(state.get('video_id') or ''):
        return 0, 0, 0
    # Watched history remains set when rewatching an episode. A new, explicitly
    # unfinished session must retain its own progress despite that history bit.
    if watched and str(state.get('flaggedWatched',1)).lower() not in ('0','false'):
        return 0, 0, 0
    try:
        offset = float(state.get('timeOffset') or 0) / 1000
        duration = float(state.get('duration') or 0) / 1000
        if not math.isfinite(offset) or not math.isfinite(duration):
            return 0, 0, 0
        if not duration:
            duration = minutes(runtime) * 60
        if offset < 1 or not 0 < offset < duration or duration > 86400:
            return 0, 0, 0
        return max(1, min(99, int(round(offset * 100 / duration)))), offset, duration
    except (TypeError, ValueError, OverflowError):
        return 0, 0, 0


def runtime_text(value, video_id=None, state=None):
    from lib.hero_tags import measured_episode_seconds
    measured = measured_episode_seconds(video_id, state)
    count = max(1, int(round(measured / 60))) if measured else minutes(value)
    if not count:return ''
    hours, remaining = divmod(count, 60)
    return '{}h {}m'.format(hours, remaining) if hours and remaining else '{}h'.format(hours) if hours else '{}m'.format(remaining)


def apply_progress(item, video_id, state, runtime=None, watched=False):
    percent, offset, duration = progress(video_id, state, runtime, watched)
    item.setProperty('WatchedProgress', str(percent))
    item.setProperty('episode_progress_label', '{}%'.format(percent) if percent else '')
    try:
        item.getVideoInfoTag().setResumePoint(offset, duration)
    except (AttributeError, RuntimeError):
        pass


def title_lines(title, max_width=390):
    """Use two Kodi labels and scroll overflow in the second line."""
    from lib.text_metrics import width
    words = title.split()
    first = []
    while words and (not first or width(' '.join(first + [words[0]]), 24) * 1.15 <= max_width):
        first.append(words.pop(0))
    return ' '.join(first), ' '.join(words)
