"""Persistent conservative budget for automatic title-opening source checks."""
import sqlite3
import time
from pathlib import Path
from contextlib import closing


def claim(profile, cost=1, now=None):
    now = time.time() if now is None else now
    try:
        directory = Path(profile) / 'cache'
        directory.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(directory / 'format-budget.sqlite', timeout=2)) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS budget (id INTEGER PRIMARY KEY, next_check REAL)')
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT next_check FROM budget WHERE id=1').fetchone()
            if row and now < row[0]:
                return False
            # Count every addon in the fan-out, plus one minute reserved for playback.
            deadline = now + 60 * (max(1, int(cost)) + 1)
            db.execute('INSERT OR REPLACE INTO budget VALUES (1, ?)', (deadline,))
        return True
    except (OSError, ValueError, TypeError, sqlite3.Error):
        return False  # Optional checks fail closed, never spend unchecked quota.


def cooldown(profile, now=None):
    now = time.time() if now is None else now
    try:
        with closing(sqlite3.connect(Path(profile) / 'cache' / 'format-budget.sqlite', timeout=2)) as db, db:
            db.execute('UPDATE budget SET next_check=MAX(next_check, ?) WHERE id=1', (now + 15 * 60,))
    except (OSError, TypeError, sqlite3.Error):
        pass
