"""Optional MDbList ratings, independent of the active Kodi skin."""
import re
import hashlib
from urllib.parse import urlencode

SOURCES = [('imdb', 'IMDb'), ('tmdb', 'TMDb'), ('trakt', 'Trakt'),
           ('tomatoes', 'Rotten Tomatoes'), ('metacritic', 'Metacritic'),
           ('letterboxd', 'Letterboxd'), ('tomatoesaudience', 'Popcornmeter'),
           ('metacriticuser', 'Metacritic User'), ('myanimelist', 'MyAnimeList'), ('mdblist', 'MDbList')]


def episode_scores(payload, season, rows):
    """Map only the returned episode matrix; never use aggregate averages."""
    matrix = payload.get('episode_ratings')
    if not isinstance(matrix, dict) or not isinstance(matrix.get('seasons'), list):
        return rows
    scores = {}
    for block in matrix['seasons']:
        if not isinstance(block, dict) or block.get('season_number') != season:
            continue
        for episode in block.get('episodes') or []:
            if not isinstance(episode, dict):
                continue
            number, rating = episode.get('episode_number'), episode.get('rating')
            if not isinstance(number, int) or isinstance(number, bool) or isinstance(rating, bool):
                continue
            try:
                score = float(rating)
            except (ValueError, TypeError):
                continue
            if 0 < score <= 100:
                scores[number] = score
    return [dict(row, mdblistRating=scores[row.get('episode', row.get('number'))])
            if row.get('season', season) == season and row.get('episode', row.get('number')) in scores
            else dict(row) for row in rows]


def enrich_episodes(meta, season, rows):
    from addon_state import get_addon
    from protocol import fetch
    from lib.cache_policy import read_policy, open_cache
    addon = get_addon()
    key = addon.getSetting('mdblist_api_key').strip()
    identity = str(meta.get('imdb_id') or meta.get('id') or '')
    if (not key or meta.get('type') != 'series' or not re.fullmatch(r'tt\d+', identity)
            or addon.getSetting('rating_mdblist') != 'true'
            or addon.getSetting('episode_rating_mdblist') != 'true'):
        return rows
    try:
        policy = read_policy(addon.getSetting)
        cache = open_cache('ratings', policy)
        cache_key = 'mdblist-episodes-v1:' + hashlib.sha256(key.encode()).hexdigest() + ':' + identity
        try:
            payload = cache.get(cache_key) if cache else None
        except Exception:
            payload = None
        if payload is None:
            url = 'https://api.mdblist.com/imdb/show/{}/?{}'.format(identity,
                urlencode({'apikey': key, 'append_to_response': 'episode_ratings'}))
            payload = fetch(url, timeout=8)
            if not isinstance(payload, dict) or payload.get('error') or payload.get('imdb_id', identity) != identity:
                return rows
            if isinstance(payload.get('episode_ratings'), dict) and cache:
                try:
                    cache.put(cache_key, payload, policy['ratings'])
                except Exception:
                    pass
        return episode_scores(payload, season, rows)
    except Exception:
        # Keep existing episode ratings; never log an API-key-bearing URL.
        return rows


def rating_text(payload, source):
    name, label = SOURCES[source] if 0 <= source < len(SOURCES) else SOURCES[0]
    for rating in payload.get('ratings') or []:
        if rating.get('source') == name and rating.get('value') is not None:
            return '{} {}'.format(label, rating['value'])
    return ''


def selected_text(payload, get_setting):
    return '  ·  '.join(text for index, (name, _) in enumerate(SOURCES)
                       if get_setting('rating_' + name) == 'true'
                       for text in [rating_text(payload, index)] if text)


def enabled():
    from addon_state import get_addon
    return bool(get_addon().getSetting('mdblist_api_key').strip())


def enrich(row):
    from addon_state import get_addon
    import xbmcvfs
    from pathlib import Path
    from protocol import fetch
    from lib.cache_policy import read_policy, open_cache
    addon = get_addon()
    key = addon.getSetting('mdblist_api_key').strip()
    identity = str(row.get('imdb_id') or row.get('id') or '')
    if not key or not re.fullmatch(r'tt\d+', identity) or row.get('type') not in ('movie', 'series'):
        return row
    kind = 'show' if row['type'] == 'series' else 'movie'
    url = 'https://api.mdblist.com/imdb/{}/{}/?{}'.format(kind, identity, urlencode({'apikey': key}))
    try:
        policy = read_policy(addon.getSetting)
        cache = open_cache('ratings', policy)
        payload = None
        if cache is not None:
            try:
                payload = cache.get(url)
            except Exception:
                pass
        if payload is None:
            payload = fetch(url, timeout=8)
            if cache is not None and payload.get('ratings'):
                try:
                    cache.put(url, payload, policy['ratings'])
                except Exception:
                    pass
        text = selected_text(payload, addon.getSetting)
        result = dict(row, rating_text=text, rating_badges=badges(payload, addon.getSetting))
        if payload.get('certification'):
            result['certification'] = payload['certification']
        if payload.get('released'):
            result['released'] = payload['released']
        return result
    except Exception:
        # Never log request URLs or exception text containing the API key.
        return row


def badges(payload, get_setting):
    """Provider score scales and rating icons."""
    result = []
    icons = {'imdb':'imdb','tmdb':'tmdb','trakt':'trakt','letterboxd':'letterboxd',
             'metacritic':'metacritic','metacriticuser':'metacritic','myanimelist':''}
    for name, label in SOURCES:
        if get_setting('rating_' + name) != 'true':
            continue
        entry = ({'value': payload.get('score')} if name == 'mdblist' else
                 next((r for r in payload.get('ratings', []) if r.get('source') == name), {}))
        try:
            value = float(entry['value'])
        except (KeyError, TypeError, ValueError):
            continue
        icon = icons.get(name, 'mdblist')
        if name in ('tmdb', 'trakt'): value /= 10
        if name == 'letterboxd': value *= 2
        text = '{:g}'.format(value) if name in ('tomatoes','tomatoesaudience','metacritic','mdblist') else '{:.1f}'.format(value)
        if name in ('tomatoes','tomatoesaudience','metacritic','mdblist'):
            text += '%'
        if name == 'tomatoes': icon = 'rtfresh' if value >= 60 else 'rtrotten'
        if name == 'tomatoesaudience': icon = 'popcorn' if value >= 60 else 'popcorn_spilt'
        result.append({'source':name,'value':text,'icon':icon+'.png' if icon else '', 'label':'MAL' if name == 'myanimelist' else ''})
    return result
