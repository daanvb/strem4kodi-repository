"""Native poster facts from loaded catalogues and local source observations only."""
from datetime import date
import re
from urllib.parse import urlsplit

from lib.catalogue_identity import aliases


NOTABLE_DIRECTORS = {
    'steven spielberg': 'Spielberg Movie',
    'christopher nolan': 'Nolan Movie',
    'martin scorsese': 'Scorsese Movie',
    'quentin tarantino': 'Tarantino Movie',
    'james cameron': 'Cameron Movie',
    'ridley scott': 'Ridley Scott Movie',
    'david fincher': 'Fincher Movie',
    'denis villeneuve': 'Villeneuve Movie',
    'greta gerwig': 'Gerwig Movie',
    'wes anderson': 'Wes Anderson Movie',
    'jordan peele': 'Jordan Peele Movie',
    'sofia coppola': 'Coppola Movie',
}


def _words(value):
    """Flatten provider metadata for conservative, explicit label matching."""
    if isinstance(value, dict):
        return ' '.join(str(part) for key, item in value.items()
                        for part in (key, _words(item)) if part not in ('', None))
    if isinstance(value, (list, tuple, set)):
        return ' '.join(_words(item) for item in value)
    return str(value or '')


def award_label(value):
    text = re.sub(r'\s+', ' ', _words(value)).strip().casefold()
    if not text:
        return ''
    # A nomination alone is never promoted to a winner sash.
    won = r'(?:\bwon\b|\bwinner\b|\bwins?\b)'
    for label, prize in (
            ('Oscar Winner', r'(?:oscars?|academy awards?)'),
            ('Emmy Winner', r'(?:primetime )?emmys?'),
            ('Globe Winner', r'(?:golden globes?|globes?)'),
            ('Cannes Winner', r'(?:cannes|palme d.?or)')):
        if re.search(won + r'.{0,45}' + prize + '|' + prize + r'.{0,45}' + won, text):
            return label
    return ''


def editorial_label(row):
    if row.get('type') != 'movie':
        return ''
    names = list(row.get('director') or []) if isinstance(row.get('director'), list) else []
    for person in row.get('directorPeople') or []:
        if isinstance(person, dict) and person.get('name'):
            names.append(person['name'])
    for name in names:
        label = NOTABLE_DIRECTORS.get(str(name).strip().casefold())
        if label:
            return label
    return ''


def status_label(row):
    if row.get('type') != 'series':
        return ''
    status = re.sub(r'[^a-z]+', ' ', str(row.get('status') or '').casefold()).strip()
    if re.search(r'\bnew season\b', status) or row.get('newSeason') is True:
        return 'New Season'
    if status in ('returning', 'returning series'):
        return 'Returning'
    if status in ('airing', 'currently airing'):
        return 'Airing'
    if status == 'in production':
        return 'In Production'
    if status == 'ended':
        return 'Ended'
    if status in ('canceled', 'cancelled'):
        return 'Cancelled'
    return ''


def trending_catalog(catalog):
    """Recognize chart metadata, including provider IDs such as tmdb_trending."""
    if catalog.get('_genre') or catalog.get('_genre_label'):
        return False
    for field in ('label', 'name', 'catalog_id', 'id', '_id', 'category'):
        text = re.sub(r'[^a-z0-9]+', ' ', str(catalog.get(field) or '').lower())
        if re.search(r'\btrending\b', text):
            return True
    return False


def catalogue_sash(catalog):
    """Return a verified sash carried by an explicitly named curated list."""
    if catalog.get('_genre') or catalog.get('_genre_label'):
        return ('', '')
    text = re.sub(r'[^a-z0-9]+', ' ', ' '.join(str(catalog.get(field) or '')
                  for field in ('label', 'name', 'catalog_id', 'id', '_id', 'category')).casefold()).strip()
    if not text:
        return ('', '')
    if re.search(r'\bwinners?\b', text):
        for label, pattern in (
                ('Oscar Winner', r'\b(?:oscar|academy award)s?\b'),
                ('Emmy Winner', r'\b(?:primetime )?emmys?\b'),
                ('Globe Winner', r'\b(?:golden )?globes?\b'),
                ('Cannes Winner', r'\b(?:cannes|palme d or)\b')):
            if re.search(pattern, text):
                return ('award', label)
    for name, label in NOTABLE_DIRECTORS.items():
        if re.search(r'\b' + re.escape(name) + r'\b', text):
            return ('editorial', label)
    for label, pattern in (
            ('New Season', r'\bnew seasons?\b'),
            ('Returning', r'\breturning(?: series| shows?)?\b'),
            ('Airing', r'\b(?:currently )?airing\b'),
            ('In Production', r'\bin production\b')):
        if re.search(pattern, text):
            return ('status', label)
    return ('', '')


def context_catalog(catalog):
    return trending_catalog(catalog) or bool(catalogue_sash(catalog)[0])


def annotate(catalogs, context=()):
    """Recompute membership; retained row flags must not manufacture a chart."""
    catalogs = list(catalogs)
    try:
        context = list(context)
    except TypeError:
        context = []
    trending = set()
    ranks = {}
    contexts = {}
    sources = catalogs + context
    # Overview grids retain their actual source charts after flattening rows.
    sources += [source for catalog in list(sources)
                for source in catalog.get('_poster_tag_context', [])]
    for catalog in sources:
        if '_poster_tag_context' not in catalog and trending_catalog(catalog):
            for position, row in enumerate(catalog.get('items', []), 1):
                keys = aliases(row)
                trending.update(keys)
                for key in keys:
                    ranks[key] = min(position, ranks.get(key, position))
        if '_poster_tag_context' not in catalog:
            kind, label = catalogue_sash(catalog)
            if kind:
                priority = {'award': 0, 'editorial': 2, 'status': 3}[kind]
                for row in catalog.get('items', []):
                    for key in aliases(row):
                        if key not in contexts or priority < contexts[key][0]:
                            contexts[key] = (priority, kind, label)
    annotated = []
    for catalog in catalogs:
        items = []
        for row in catalog.get('items', []):
            fresh = dict(row)
            fresh.pop('_poster_trending', None)
            fresh.pop('_poster_rank', None)
            fresh.pop('_poster_context_kind', None)
            fresh.pop('_poster_context_label', None)
            matches = aliases(row) & trending
            if matches:
                fresh['_poster_trending'] = True
                fresh['_poster_rank'] = min(ranks[key] for key in matches if key in ranks)
            explicit = [contexts[key] for key in aliases(row) if key in contexts]
            if explicit:
                _, fresh['_poster_context_kind'], fresh['_poster_context_label'] = min(explicit)
            items.append(fresh)
        annotated.append(dict(catalog, items=items))
    return annotated


SETTINGS = (('Trending tags', 'ui_poster_trending_tags'),)


def properties(row, summary_reader=None, today=None, get_setting=None):
    values = {'poster_trend': '', 'poster_trending_label': '', 'poster_new_label': '',
              'poster_sash_rank': '', 'poster_sash_award': '', 'poster_sash_editorial': '',
              'poster_sash_status': '', 'poster_sash_trend': ''}
    if row.get('type') not in ('movie', 'series') or row.get('_catalogue'):
        return values
    try:
        host = (urlsplit(str(row.get('poster') or '')).hostname or '').lower()
    except ValueError:
        host = ''
    # These posters already have provider-controlled tags baked into their pixels.
    if host == 'btttr.cc' or host.endswith('.btttr.cc'):
        return values
    trending_enabled = not get_setting or get_setting('ui_poster_trending_tags') != 'false'
    labels = ['Trending'] if row.get('_poster_trending') and trending_enabled else []
    released = str(row.get('released') or '')
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}(?:T.*)?', released):
        try:
            age = ((today or date.today()) - date.fromisoformat(released[:10])).days
            if 0 <= age <= 30 and trending_enabled:
                labels.append('New')
        except ValueError:
            pass
    values['poster_trend'] = ' · '.join(labels)
    values['poster_trending_label'] = 'Trending' if 'Trending' in labels else ''
    values['poster_new_label'] = 'New' if 'New' in labels else ''
    if trending_enabled:
        try:
            rank = int(row.get('_poster_rank') or 0)
        except (TypeError, ValueError):
            rank = 0
        candidates = (
            ('poster_sash_award', award_label(row.get('awards')) or
             (row.get('_poster_context_label') if row.get('_poster_context_kind') == 'award' else '')),
            ('poster_sash_rank', '#{}'.format(rank) if 0 < rank <= 999 else ''),
            ('poster_sash_editorial', editorial_label(row) or
             (row.get('_poster_context_label') if row.get('_poster_context_kind') == 'editorial' else '')),
            ('poster_sash_status', status_label(row) or
             (row.get('_poster_context_label') if row.get('_poster_context_kind') == 'status' else '')),
            ('poster_sash_trend', 'Trending' if row.get('_poster_trending') else
             'New' if 'New' in labels else ''),
        )
        for field, label in candidates:
            if label:
                # Cached catalogue context may predate the title-case labels.
                values[field] = str(label).title()
                break
    return values


def append(layout):
    """Top-aligned facts, clear of the watched mark and progress bar."""
    import xml.etree.ElementTree as ET
    # One priority sash is visible at a time. Categories keep distinct colours
    # while sharing geometry, so combinations can never overlap.
    for field, colour in (
            ('poster_sash_award', 'E6C78A22'),
            ('poster_sash_rank', 'E6D84B78'),
            ('poster_sash_editorial', 'E6298D8F'),
            ('poster_sash_status', 'E63F6FBF'),
            ('poster_sash_trend', 'E65E3FBF')):
        visible = '!String.IsEmpty(ListItem.Property(%s))' % field
        background = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=19, top=12, width=192, height=28,
                               texture='special://home/addons/script.strem4kodi/resources/branding/white.png',
                               colordiffuse=colour, visible=visible).items():
            ET.SubElement(background, key).text = str(value)
        label = ET.SubElement(layout, 'control', type='label')
        for key, value in dict(left=23, top=12, width=184, height=28,
                               label='$INFO[ListItem.Property(%s)]' % field,
                               font='font_flag', textcolor='FFFFFFFF',
                               align='center', aligny='center', visible=visible).items():
            ET.SubElement(label, key).text = str(value)
