"""Per-device, per-content source selection; never bypass the quality ceiling."""
from lib.source_preferences import preferences, limit_quality
from lib.stream_presenter import stream_traits, presentation, filter_rows
import re

PROFILES = ('movie', 'series', 'animation')
FIELDS = {'quality': ('Any', '4K', '1080p', '720p'),
          'dynamic': ('Any', 'Dolby Vision', 'HDR10', 'P7 / FEL reported'),
          'source_type': ('Any', 'Remux', 'BluRay', 'WEB-DL', 'WEBRip', 'HDTV')}



def profile(meta):
    genres = meta.get('genres') or []
    if isinstance(genres, str):genres = [genres]
    if meta.get('type') == 'series' and any(str(g).casefold() == 'animation' for g in genres):return 'animation'
    return 'series' if meta.get('type') == 'series' else 'movie'


def configured(addon, meta):
    scope = profile(meta)
    prefs = preferences(addon)
    # Autoplay has a fixed hierarchy; manual picker ordering stays independent.
    prefs.update(sort='highest_bitrate', audio='Any', provider='')
    prefs['priority']='fast' if addon.getSetting('auto_'+scope+'_priority')=='1' else 'quality'
    for field, values in FIELDS.items():
        try:index = int(addon.getSetting('auto_' + scope + '_' + field) or '0') - 1
        except (ValueError, TypeError):index = -1
        if 0 <= index < len(values):prefs[field] = values[index]
    for field in ('language',):
        value = addon.getSetting('auto_' + scope + '_' + field)
        if value and value != '__inherit__':prefs[field] = '' if value == '__any__' else value
    try:mode = int(addon.getSetting('auto_' + scope + '_mode') or '0')
    except (ValueError, TypeError):mode = 0
    return mode if mode in (0, 1, 2) else 0, prefs


def matches(row, prefs):
    traits = stream_traits(row)
    if prefs.get('provider') and traits['provider'].casefold() != prefs['provider'].casefold():return False
    if prefs.get('quality') not in (None, 'Any') and traits['quality'] != prefs['quality']:return False
    from lib.autoplay_ranking import video_matches
    if prefs.get('dynamic') not in (None, 'Any') and not video_matches(traits,prefs['dynamic']):return False
    source_type=prefs.get('source_type')
    if source_type not in (None, '', 'Any') and source_type.casefold() not in {v.casefold() for v in traits.get('source_types',[])}:return False
    audio = presentation(row)['audio']
    if prefs.get('audio') not in (None, 'Any') and prefs['audio'].casefold() not in audio.casefold():return False
    language = prefs.get('language', '').casefold()
    if language and language != 'any':
        aliases = {'english', 'eng', 'en'} if language in ('english', 'eng', 'en') else {language}
        if not aliases & set(re.findall(r'[a-z]+', audio.partition(' | Language: ')[2].casefold())):return False
    return True


def eligible_candidates(rows,prefs,meta,filters,identity,profile):
    """Shared safety gates for speed, quality, arrivals and complete searches."""
    if profile:
        from lib.wrong_episode import exclude_reported
        rows = exclude_reported(profile, meta.get('type'), identity, rows, meta.get('name', ''))
    from lib.source_identity import eligible as matching_episode
    from source_probe import unsupported_disc
    rows = matching_episode([r for r in rows if not unsupported_disc(r.get('url',''),r)],
                            meta, identity, require_match=True)
    eligible = [r for r in filter_rows(limit_quality(rows, prefs['maximum']), *filters)
                if r.get('url') and not r.get('_session_failed')]
    from lib.source_identity import target, title_verified
    if target(meta, identity) is not None:
        titled = [r for r in eligible if title_verified(r, meta, identity)]
        if titled:
            eligible = titled
    if prefs.get('language') and prefs['language'].casefold()!='any':
        language_prefs={'language':prefs['language']}
        possible=[r for r in eligible if matches(r,language_prefs) or
                  presentation(r)['audio'].partition(' | Language: ')[2].strip().casefold()
                  in ('','unknown','und','unk','unreported','multi','multilingual')]
        if possible:eligible=possible
    return eligible


def select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None, identity=None, profile=None):
    mode, prefs = configured(addon, meta)
    if mode == 0:return mode, None, False
    eligible=eligible_candidates(rows,prefs,meta,filters,identity,profile)
    from lib.last_source import match, load, recent_success
    from lib.autoplay_ranking import rank, key
    from lib.provider_health import rank as health_rank, penalized
    ranked = list(eligible) if prefs['priority']=='fast' else rank(eligible, prefs)
    if mode == 2:ranked = health_rank(ranked)
    selected = (ranked or [None])[0]
    if prefs['priority']=='fast':
        if remembered is None and profile and eligible:
            remembered=load(profile,meta.get('type'),identity)
        if not recent_success(remembered):remembered=None
    previous = match(eligible, remembered)
    # Best quality reuses success only for a complete technical tie. Fastest
    # start may reuse any eligible, healthy release without a quality wait.
    if (selected is not None and previous is not None and
            (prefs['priority']=='fast' or key(previous,prefs)==key(selected,prefs)) and
            (mode != 2 or not penalized(previous))):
        selected = previous
    return mode, selected, bool(selected and prefs['priority']!='fast' and not matches(selected,prefs))


def early_select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None, identity=None, profile=None):
    """Fast priority may start early; quality priority needs the full search."""
    mode,prefs=configured(addon,meta)
    if mode!=2 or prefs['priority']!='fast':return None
    eligible=eligible_candidates(rows,prefs,meta,filters,identity,profile)
    from lib.source_identity import target,comparable_title,title_verified
    if target(meta,identity) is not None and comparable_title(meta,identity):
        # Do not take a number-only file while a verifiable title can arrive.
        eligible=[row for row in eligible if title_verified(row,meta,identity)]
    if prefs.get('language') and prefs['language'].casefold()!='any':
        # Unlike a completed search, a partial foreign-only batch is not
        # evidence that English/unknown alternatives are unavailable.
        eligible=[row for row in eligible if matches(row,{'language':prefs['language']}) or
                  presentation(row)['audio'].partition(' | Language: ')[2].strip().casefold()
                  in ('','unknown','und','unk','unreported','multi','multilingual')]
    from lib.provider_health import penalized
    eligible=[row for row in eligible if not penalized(row)]
    from lib.last_source import match, load, recent_success
    if remembered is None and profile and eligible:
        remembered=load(profile,meta.get('type'),identity)
    return (match(eligible,remembered) if recent_success(remembered) else None) or (eligible or [None])[0]


def selection_details(row, addon, meta, identity):
    """Explain observed autoplay rules, without claiming provider truth."""
    from lib.source_identity import status, target, title_verified
    _, prefs = configured(addon, meta)
    details = (['Fastest start: eligible success within 36 hours or first suitable source; no quality wait']
               if prefs['priority']=='fast' else
               ['Best available quality: video format > resolution > source type > audio > bitrate > file size > provider'])
    if target(meta, identity) is not None:
        verdict = status(row, meta, identity)
        details.append(('Filename title matches the requested episode' if title_verified(row, meta, identity)
                        else 'Episode number matches; filename title is unconfirmed') if verdict == 'match'
                       else 'Episode identity not confirmed by source labels')
    traits=stream_traits(row)
    details.append('Reported quality: ' + traits['quality'])
    if traits.get('source_types'):details.append('Reported source type: ' + ' / '.join(traits['source_types']))
    bitrate=(row.get('card') or {}).get('bitrate')
    if not bitrate:
        from core.stream_ui import stream_card
        bitrate=stream_card(row).get('bitrate')
    if bitrate:details.append('Reported bitrate: ' + str(bitrate))
    if prefs['priority']!='fast':details.append('Source preferences matched' if matches(row, prefs) else 'Closest available match to source preferences')
    return details
