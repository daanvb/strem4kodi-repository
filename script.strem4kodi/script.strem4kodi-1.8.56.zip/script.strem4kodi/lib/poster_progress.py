"""Aligned watch-progress track and fill for generated artwork cards."""
import xml.etree.ElementTree as ET

BASE = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/progress-local/'
VISIBLE = 'Integer.IsGreater(ListItem.Property(WatchedProgress),0) + Integer.IsLess(ListItem.Property(WatchedProgress),100)'


def append(parent, left, top, width, height=4):
    geometry = dict(left=left, top=top, width=width, height=height, visible=VISIBLE)
    track = ET.SubElement(parent, 'control', type='image')
    fill = ET.SubElement(parent, 'control', type='progress')
    for node, description in ((track, 'Watch progress track'), (fill, 'Watch progress fill')):
        ET.SubElement(node, 'description').text = description
        for name, value in geometry.items():
            ET.SubElement(node, name).text = str(value)
    ET.SubElement(track, 'texture', colordiffuse='FF42365C', border='0').text = BASE + 'capsule.png'
    for name, value in dict(info='ListItem.PercentPlayed', colordiffuse='FFB5A4E8',
                            texturebg=BASE+'transparent.png', overlaytexture=BASE+'transparent.png',
                            midtexture=BASE+'capsule.png', lefttexture='', righttexture='', reveal='false').items():
        ET.SubElement(fill, name).text = value
    fill.find('midtexture').set('border', '0')
