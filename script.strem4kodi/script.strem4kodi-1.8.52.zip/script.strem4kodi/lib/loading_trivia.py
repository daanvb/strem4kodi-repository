"""Local, exact-title facts; no network work on the playback path."""
from collections import OrderedDict
from functools import lru_cache
import json
from pathlib import Path
import random
import re
import threading
from lib.stream_presenter import line

_previous = OrderedDict()
_lock = threading.Lock()


@lru_cache(maxsize=1)
def catalogue():
    try:
        rows = json.loads((Path(__file__).resolve().parents[1] / 'resources/trivia.json').read_text(encoding='utf-8'))
        return rows if isinstance(rows, dict) else {}
    except (OSError, ValueError):return {}


def identity(meta):
    kind = meta.get('type')
    imdb = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
    if kind not in ('movie', 'series') or not re.fullmatch(r'tt\d+', imdb):return ''
    return kind + ':' + imdb


def facts(meta):
    rows = catalogue().get(identity(meta), [])
    curated = [line(row['text'], 190) for row in rows
               if isinstance(row, dict) and isinstance(row.get('text'), str) and row.get('source')]
    if curated:return 'Did you know?', list(dict.fromkeys(curated))
    # These are labelled title details, rather than behind-the-scenes trivia.
    rows = []
    original = line(meta.get('original_title') or '', 100)
    if original and original.casefold() != line(meta.get('name') or '', 100).casefold():
        rows.append('Original title: ' + original)
    for field, prefix in [('creators', 'Created by '), ('director', 'Directed by '), ('cast', 'Featuring ')]:
        values = meta.get(field) or []
        if isinstance(values, str):values = [values]
        if not isinstance(values, list):continue
        for value in values[:4]:
            name = line((value.get('name') if isinstance(value, dict) else value) or '', 100)
            if name:rows.append(prefix + name + '.')
    return 'About this title', list(dict.fromkeys(rows))


def choose(meta):
    """Avoid consecutive repeats during this app session, with bounded history."""
    label, rows = facts(meta)
    if not rows:return {}
    key = identity(meta) or (str(meta.get('type')), str(meta.get('id')))
    with _lock:
        previous = _previous.pop(key, '')
        selected = random.choice([row for row in rows if row != previous] or rows)
        _previous[key] = selected
        while len(_previous) > 512:_previous.popitem(last=False)
    return {'trivia_label': label, 'trivia': selected}
