"""Attempt-bound playback loading screen; never stores stream URLs."""
import json
import threading
import time
from lib.stream_presenter import line

CANCEL_KEY='strem4kodi.playback.cancelled'

def cancelled(attempt):
    if not attempt:return False
    import xbmcgui
    try:return attempt in json.loads(xbmcgui.Window(10000).getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):return False

def signal_cancel(attempt):
    if not attempt:return
    import xbmcgui
    window=xbmcgui.Window(10000)
    try:rows=json.loads(window.getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):rows=[]
    if not isinstance(rows,list):rows=[]
    window.setProperty(CANCEL_KEY,json.dumps((rows+[attempt])[-16:]))

def _make_window(title,detail,on_cancel,art=None):
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window as themed_window
    class LoadingWindow(xbmcgui.WindowXMLDialog):
        initialized=False
        dismissed=False
        def update(self,title,detail='',art=None):
            self.content=(title,detail,dict(art or {}))
            if not self.initialized:return
            # Modeless dialog Window.Property can resolve against the underlying
            # media window. Address this dialog's own controls for every field.
            title,detail,art=self.content
            self.getControl(301).setLabel(art.get('stage') or 'Starting playback')
            self.getControl(302).setText(title)
            self.getControl(303).setText(art.get('hint') or 'Opening your selected source')
            self.getControl(304).setText(detail)
            for cid,name in ((305,'poster'),(307,'background')):
                self.getControl(cid).setImage(art.get(name) or '')
                self.getControl(cid).setVisible(bool(art.get(name)))
            self.getControl(306).setVisible(not bool(art.get('poster')))
            self.getControl(310).setVisible(bool(art.get('trivia')))
            self.getControl(311).setLabel(art.get('trivia_label') or '')
            self.getControl(312).setText(art.get('trivia') or '')
        def hint(self,text):
            title,detail,art=self.content
            art['hint']=text
            self.content=(title,detail,art)
            if self.initialized:self.getControl(303).setText(text)
        def onInit(self):
            if self.dismissed:
                self.close()
                return
            self.initialized=True
            self.update(*self.content)
            self.setFocusId(201)
        def onAction(self,action):
            if action.getId() in (10,13,92,216,247):on_cancel()
        def onClick(self,control_id):
            if control_id==201:on_cancel()
    window=themed_window(LoadingWindow,'script-strem4kodi-loading.xml',
                         get_addon().getAddonInfo('path'),'Main','1080i')
    window.update(title,detail,art)
    return window

class LoadingSession:
    def __init__(self,on_cancel,factory=_make_window,state=None,ready=None,clock=time.monotonic):
        self.on_cancel=on_cancel;self.factory=factory
        self.lock=threading.RLock();self.attempt='';self.window=None
        self.state=state;self.ready=ready;self.clock=clock
        self.created=0;self.elapsed=-1;self.wake=threading.Event()
    def begin(self,attempt,title,detail='',art=None):
        with self.lock:
            self.finish()
            self.attempt=attempt
            self.created=self.clock();self.elapsed=-1;self.wake=threading.Event()
            try:
                arguments = (line(title,110),line(detail,140),lambda:self._cancel_window(window))
                self.window=self.factory(*arguments,art) if art else self.factory(*arguments)
                window=self.window
                self.window.show()
                if self.state is not None:
                    threading.Thread(target=self._watch,args=(attempt,self.wake),daemon=True).start()
            except Exception:
                self.finish(attempt)
    def wait(self):
        """Pump Kodi input on the calling UI thread, never under the session lock."""
        with self.lock:window=self.window
        if window is not None:
            window.doModal()
    def _cancel_window(self,window):
        with self.lock:
            if window is not self.window:return
            attempt=self.attempt
        self.cancel(attempt)
    def advance(self,attempt,title,detail='',art=None,on_cancel=None,state=None,ready=None):
        """Transfer search to playback without closing or allocating a dialog."""
        with self.lock:
            if self.window is None:return False
            self.wake.set()
            self.attempt=attempt
            self.on_cancel=on_cancel or self.on_cancel
            self.state,self.ready=state,ready
            self.created=self.clock();self.elapsed=-1;self.wake=threading.Event()
            self.window.update(line(title,110),line(detail,140),art)
            if state is not None:
                threading.Thread(target=self._watch,args=(attempt,self.wake),daemon=True).start()
            return True
    def hint(self,text):
        with self.lock:
            if self.window:self.window.hint(text)
    def _watch(self,attempt,wake):
        """Keep overlay cleanup independent of the media-details refresh thread."""
        while not wake.wait(.2):
            try:
                pending=self.state()
                ready=bool(self.ready and self.ready())
                self.check(attempt,pending,ready)
            except Exception:
                # Even unavailable player/state queries cannot strand the dialog.
                self.check(attempt,{'attempt':attempt,'started':False})
    def check(self,attempt,pending,ready=False):
        with self.lock:
            if self.attempt!=attempt:return
            if ready or self.clock()-self.created>=50:
                self.finish(attempt)
            else:
                elapsed = int(max(0, self.clock() - self.created))
                if self.window and elapsed != self.elapsed:
                    self.elapsed = elapsed
                    try:
                        self.window.hint('This source is taking longer. You can cancel and choose another.' if elapsed >= 15 else 'Opening your selected source')
                    except Exception:
                        pass
                self.observe(pending)
    def cancel(self,attempt):
        with self.lock:
            if self.attempt!=attempt:return
            signal_cancel(attempt)
            self.finish(attempt)
        # Parent cancellation may acquire its search lock; do not hold the
        # dialog lock while calling it (search results close this dialog too).
        self.on_cancel()
    def observe(self,pending):
        with self.lock:
            if self.attempt and (not pending or pending.get('attempt')!=self.attempt or pending.get('started')):
                self.finish(self.attempt)
    def finish(self,attempt=None):
        with self.lock:
            if attempt is not None and self.attempt!=attempt:return
            window=self.window;self.window=None;self.attempt=''
            self.wake.set()
            if window:
                window.dismissed=True
                try:window.close()
                except Exception:pass
