"""Readable local status, using fixed fields rather than raw logs."""
import time


def age(timestamp):
    if not isinstance(timestamp, (int, float)) or timestamp <= 0:
        return 'Not recorded'
    minutes = max(0, int((time.time() - timestamp) / 60))
    return 'Just now' if minutes == 0 else '{} min ago'.format(minutes)


def info(label, value, help_text):
    return {'kind': 'info', 'label': label, 'summary': value, 'help': help_text}


def benchmark_summary(result):
    labels = {'benchmark.cached_home': 'Cached Home', 'benchmark.snapshot_load': 'Catalogue snapshot',
              'benchmark.continue_index': 'Continue Watching', 'benchmark.account_load': 'Account data',
              'benchmark.stream_cache': 'Source cache'}
    return '\n'.join('{}: {} ms'.format(labels.get(stage, stage), ms)
                     for stage, ms in result['metrics'].items()) + '\n\nLocal cached browsing only; network refresh and video loading are separate.'


def player_rows(kodi, gui):
    skin = kodi.getSkinDir()
    playing = bool(kodi.Player().isPlayingVideo())
    owned = gui.Window(10000).getProperty('strem4kodi.player.active') == 'true'
    return [info('Player appearance', 'Strem4Kodi' if skin == 'skin.strem4kodi' else 'Kodi skin',
                 'The companion skin supplies the customised player. Current skin: ' + skin),
            info('Playback controls', 'Active' if playing and owned else ('Other playback' if playing else 'Idle'),
                 'Only videos started by Strem4Kodi use its player controls. Live TV retains the Kodi controls. '
                 'Optional manual checks: during a video, open Audio, Subtitles and Settings, then use Back to close each menu. '
                 'Try seeking, pausing and resuming, and check that controls hide and the scrub handle sits on the progress line. '
                 'These are visual checks for you; the app does not record completion.')]


def request_status(request):
    if request.get('status') != 'failed':
        return {'refreshed': 'Updated', 'cached': 'Cached'}.get(request.get('status'), 'Unknown')
    reason = request.get('reason')
    if reason == 'Request timed out':
        return 'Timed out'
    if reason == 'HTTP 429':
        return 'Rate limited'
    if reason in ('HTTP 401', 'HTTP 403'):
        return 'Access denied'
    if isinstance(reason, str) and len(reason) == 8 and reason.startswith('HTTP 5') and reason[5:].isdigit():
        return 'Server error'
    return 'Failed'


def request_details(request):
    """Explain observed failures without inventing a root cause or exposing URLs."""
    resource = request.get('resource')
    operation = {'stream': 'stream search', 'meta': 'title-details lookup', 'catalog': 'catalogue lookup',
                 'subtitles': 'subtitle lookup', 'manifest': 'add-on connection check'}.get(resource, 'request')
    label = request.get('provider') or 'Add-on'
    elapsed = request.get('ms')
    seconds = '{:.1f} seconds'.format(elapsed / 1000) if isinstance(elapsed, (int, float)) and 0 <= elapsed <= 1800000 else 'an unrecorded duration'
    status = request_status(request)
    reason = request.get('reason')
    if request.get('status') == 'failed':
        action = 'timed out' if status == 'Timed out' else 'failed'
        headline = '{} {} {} after {}.'.format(label, operation, action, seconds)
        causes = {
            'Request timed out': 'The request did not finish before a network operation timed out. The provider, a service it depends on, or the connection may have been slow. This record cannot identify which. A timeout alone does not confirm a rate limit.',
            'HTTP 429': 'The server explicitly reported too many requests (HTTP 429). It did not report the allowance or reset time in this saved record.',
            'HTTP 401': 'The server rejected authentication (HTTP 401). Check the saved configuration for this add-on.',
            'HTTP 403': 'The server refused access (HTTP 403). Account permissions, provider policy or a limit may be involved; this code alone does not identify which.',
            'HTTP 404': 'The requested endpoint was not found (HTTP 404). The add-on configuration may be outdated or the endpoint may have changed.',
            'Server address could not be resolved': 'The server name could not be resolved. A DNS problem, connection problem or outdated server address may be involved.',
            'Server certificate could not be verified': 'The secure server certificate could not be verified. Check the device date/time and the provider service.',
            'Secure connection failed': 'The secure connection could not be established. This record cannot identify the underlying connection or server problem.',
            'Connection to server failed': 'The connection failed before the request completed. The server may be unreachable, unavailable or blocked by the network.',
            'Addon returned invalid JSON': 'The server replied, but its reply was not readable add-on data. A provider or upstream service may have returned an error page.',
            'Addon response is too large': 'The response exceeded the app response-size limit.',
            'Addon returned an invalid response': 'The server replied with data that did not match the expected add-on response format.',
            'Addon returned an error': 'The add-on reported an error. This record contains no further verified explanation.',
        }
        explanation = causes.get(reason)
        if explanation is None:
            explanation = ('The server returned {}. This is a server-side error; this record does not identify the underlying cause.'.format(reason)
                           if status == 'Server error' else 'The request failed without a more specific recorded cause.')
        impact = {'stream': 'This attempt could not provide fresh sources or format logos. Other enabled add-ons may still supply results; cached logos are kept.',
                  'meta': 'This attempt could not refresh title details or artwork. Cached details and other metadata providers may still be used.',
                  'catalog': 'This attempt could not refresh this catalogue. Cached items may remain visible.',
                  'subtitles': 'This attempt could not refresh subtitle results from this add-on. Embedded subtitles and other providers may still be available.',
                  'manifest': 'This attempt could not refresh the add-on capabilities.'}.get(resource, 'Only this recorded request is marked as failed.')
        if status == 'Rate limited':
            next_step = 'Wait before trying this provider again. Avoid repeated searches; other devices and apps may share the same allowance.'
        elif status == 'Access denied' or reason == 'HTTP 404':
            next_step = 'Check this add-on configuration and account access. Update its installed configuration if it has changed.'
        else:
            next_step = 'Try another enabled add-on, or retry once later. If it keeps happening, check the provider service and your connection. Repeated retries can use provider allowance.'
        details = headline + '\n\nWhat happened: ' + explanation + '\n\nEffect: ' + impact + '\n\nWhat to try: ' + next_step
    else:
        details = '{} {}: {}. Time spent: {}.'.format(label, operation, status, seconds)
        details += ('\n\nCached means saved data was reused without a new network request.' if status == 'Cached' else
                    '\n\nUpdated means a response arrived; it does not guarantee matching results were found.')
    details += '\n\nLast attempt: ' + age(request.get('checked')) + '.'
    details += '\nLast recorded successful network response: ' + age(request.get('refreshed')) + '.'
    timeout = request.get('timeout')
    if isinstance(timeout, (int, float)) and 0 < timeout <= 1800:
        details += '\nNetwork timeout setting: {:g} seconds.'.format(timeout)
    details += '\n\nThis is the latest request summary for this add-on and operation, not a live health test. Title names, private configuration links and search text are not recorded. No extra request is made by viewing this page.'
    return details


def settings_rows(profile):
    from lib.perf_report import load, startup_measurements
    from lib.provider_diagnostics import rows as requests
    timings = load(profile)
    launches = startup_measurements(profile)
    help_text = 'Time from opening Strem4Kodi until Home is visible; excludes Kodi boot. Values are medians of recent launches. Sign-in and prompts can add time. '
    rows = [{'kind':'action','action':'fel7_test','label':'Play FEL7 test video','summary':'Play test',
             'help':'Play the FEL7 diagnostic clip and follow its on-screen instructions. A Dolby Vision or Profile 7 label alone does not confirm that the enhancement layer is decoded. This test does not affect watched status. Uses a test attachment from the GitHub release when available, otherwise the original V4 MKV pattern linked by Kodi’s samples page.'},
            info('First launch after Kodi starts', '{:.2f} seconds'.format(launches['first'] / 1000)
                 if 'first' in launches else 'Not recorded',
                 help_text + 'Restart Kodi and open Strem4Kodi to record this measurement.'),
            info('Repeat app launch', '{:.2f} seconds'.format(launches['repeat'] / 1000)
                 if 'repeat' in launches else 'Not recorded',
                 help_text + 'Close and reopen Strem4Kodi without restarting Kodi.'),
            info('Background Home refresh', '{:.2f} seconds'.format(timings['ui.home.background.total']['ms'] / 1000)
                 if timings.get('ui.home.background.total', {}).get('ms') is not None else 'Not recorded',
                 'Provider catalogue refresh runs after Home is usable. This duration is separate from startup.'),
            {'kind': 'action', 'action': 'startup_benchmark', 'label': 'Measure cached browsing',
             'summary': 'Run checks', 'help': 'Measure local Home, snapshots and caches on this device. Makes no network requests and does not upload results.'}]
    from lib.availability_scan import snapshot, describe
    scan = snapshot(profile)
    rows.append(info('Logo loading', '{} of {} checked'.format(scan.get('checked',0),scan.get('total',0)) if scan else 'Not recorded',
                     describe(scan) + '\n\nLocal scan status only; not included in uploaded reports. Source addon timings are listed below.'))
    try:
        import xbmc
        import xbmcgui
        rows.extend(player_rows(xbmc, xbmcgui))
    except (ImportError, AttributeError):
        pass
    history = requests(profile)
    for request in history:
        row = info(request.get('provider', 'Add-on') + ' \u00b7 ' + request.get('resource', 'Request'),
                   request_status(request), request_details(request))
        row['health'] = 'error' if request.get('status') == 'failed' else 'ok' if request.get('status') in ('refreshed', 'cached') else ''
        rows.append(row)
    if not history:
        rows.append(info('Provider requests', 'No requests recorded', 'Browse, search or choose a source, then return here for request status.'))
    return rows
