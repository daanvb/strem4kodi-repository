"""Recognise a raw CEC/IR OK burst without native repeated selections."""
import threading
import time

RELEASE_GAP = .32
HOLD_SECONDS = .65


class SelectBurst:
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.first = self.last = None
        self.focus = None

    def cancel(self):
        self.first = self.last = self.focus = None

    def press(self, focus):
        now = self.clock()
        if self.first is None or focus != self.focus:
            self.first, self.focus = now, focus
        self.last = now

    def released(self):
        if self.last is None or self.clock() - self.last < RELEASE_GAP:
            return None
        result = (self.focus, self.last - self.first >= HOLD_SECONDS)
        self.cancel()
        return result


def _focus(window):
    cid = window.getFocusId()
    try: position = window.getControl(cid).getSelectedPosition()
    except (AttributeError, RuntimeError): position = None
    return cid, position


class RemoteSelect:
    def __init__(self, window):
        self.window = window
        self.burst = SelectBurst()
        self.lock = threading.Lock()
        self.running = False

    def cancel(self):
        with self.lock:self.burst.cancel()

    def press(self):
        focus = _focus(self.window)
        with self.lock:
            self.burst.press(focus)
            if self.running:return
            self.running = True
        threading.Thread(target=self.watch, daemon=True).start()

    def watch(self):
        import xbmc
        import xbmcgui
        from lib.hero_preview import NO_DIALOG
        try:
            while True:
                time.sleep(.04)
                with self.lock:
                    if self.burst.first is None:
                        self.running = False
                        return
                    result = self.burst.released()
                    if result is None:continue
                    self.running = False
                focus, held = result
                owner = getattr(self.window, '_context_window_id', None)
                if (getattr(self.window, 'closed', False) is True or
                        xbmcgui.getCurrentWindowId() != owner or
                        xbmcgui.getCurrentWindowDialogId() not in (*NO_DIALOG, owner) or
                        _focus(self.window) != focus):return
                # Dispatch only after release: repeats cannot immediately
                # choose the first item of the newly opened context menu.
                # SendClick omits ACTION_SELECT_ITEM and Kodi ignores that
                # message on list containers. A real Select action supports
                # both poster lists and buttons through their native handlers.
                command = 'Action({},{})'.format('ContextMenu' if held else 'Select', owner)
                xbmc.executebuiltin(command)
                return
        except (AttributeError, RuntimeError):
            with self.lock:
                self.burst.cancel()
                self.running = False


def handle(window, action):
    guard = getattr(window, '_remote_select', None)
    try: selected = action.getId() == 58 and action.getButtonCode() == 11
    except (AttributeError, RuntimeError): selected = False
    if not selected:
        if isinstance(guard, RemoteSelect):guard.cancel()
        return False
    if not isinstance(guard, RemoteSelect):
        guard = window._remote_select = RemoteSelect(window)
    guard.press()
    return True
