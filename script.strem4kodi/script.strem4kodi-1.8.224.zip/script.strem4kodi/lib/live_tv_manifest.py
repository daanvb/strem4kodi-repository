"""Keep only HD/UHD video representations in a DASH manifest.

Run on every manifest refresh, not just the first request. Audio, subtitles,
timelines and ContentProtection remain intact. No DRM keys are handled here.
"""
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlsplit

from lib.live_tv_quality import HDUnavailable, Rendition, is_hd

NS = 'urn:mpeg:dash:schema:mpd:2011'
TAG = '{' + NS + '}'
MAX_BYTES = 4 * 1024 * 1024


def _integer(value):
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def filter_dash(data, source_url):
    """Return a self-contained manifest whose video ladder contains only HD.

    Fail closed for ambiguous adaptation sets, external updates, or periods
    without HD. This intentionally rejects SD adverts as well as SD programmes.
    """
    if len(data) > MAX_BYTES:
        raise HDUnavailable('Live manifest exceeds the supported size.')
    raw = data.encode('utf-8') if isinstance(data, str) else data
    if b'\x00' in raw or b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise HDUnavailable('Unsupported live manifest declarations.')
    parsed = urlsplit(source_url)
    if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password:
        raise HDUnavailable('A secure manifest source is required.')
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise HDUnavailable('Invalid live manifest.') from None
    if root.tag != TAG + 'MPD':
        raise HDUnavailable('Expected a DASH live manifest.')
    # External locations could let subsequent refreshes bypass this filter.
    for node in root.iter():
        if node.tag in (TAG + 'Location', TAG + 'PatchLocation'):
            raise HDUnavailable('External manifest updates are unsupported.')
        if any(key.startswith('{http://www.w3.org/1999/xlink}') for key in node.attrib):
            raise HDUnavailable('External manifest fragments are unsupported.')
    periods = root.findall(TAG + 'Period')
    if not periods:
        raise HDUnavailable('The live manifest has no programmes.')
    for period in periods:
        video_count = 0
        for adaptation in list(period.findall(TAG + 'AdaptationSet')):
            reps = adaptation.findall(TAG + 'Representation')
            kind = adaptation.get('contentType') or adaptation.get('mimeType', '').split('/')[0]
            if not kind:
                kinds = {r.get('mimeType', '').split('/')[0] for r in reps}
                kind = next(iter(kinds)) if len(kinds) == 1 else ''
            if kind in ('audio', 'text', 'application'):
                continue
            if kind != 'video' or not reps:
                raise HDUnavailable('Cannot verify video resolution.')
            for rep in reps:
                width = _integer(rep.get('width', adaptation.get('width')))
                height = _integer(rep.get('height', adaptation.get('height')))
                if not is_hd(Rendition(rep.get('id', ''), width, height)):
                    adaptation.remove(rep)
                else:
                    video_count += 1
            if not adaptation.findall(TAG + 'Representation'):
                period.remove(adaptation)
        if not video_count:
            raise HDUnavailable('HD is unavailable in this part of the live broadcast.')
    # A local manifest endpoint must not make relative segments point to localhost.
    bases = root.findall(TAG + 'BaseURL')
    if bases:
        for base in bases:
            base.text = urljoin(source_url, base.text or '')
    else:
        base = ET.Element(TAG + 'BaseURL')
        base.text = urljoin(source_url, '.')
        root.insert(0, base)
    # Kodi 21's DASH parser uses literal child("MPD") / children("Period")
    # lookups. ElementTree's generated ns0: prefixes are valid XML but cannot
    # be consumed by that parser. Use the DASH default namespace locally;
    # avoid modifying ElementTree's process-wide namespace registry.
    for node in root.iter():
        if node.tag.startswith(TAG):
            node.tag = node.tag[len(TAG):]
    root.set('xmlns', NS)
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)
