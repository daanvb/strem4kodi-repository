"""BBC live DASH adapter; network results and URLs never enter diagnostics."""
import json
from urllib.parse import urlsplit
from urllib.request import Request, HTTPRedirectHandler, build_opener

from lib.live_tv_manifest import MAX_BYTES
from lib.live_tv_quality import HDUnavailable

CHANNELS = (
    ('bbc_one_hd', 'BBC One'), ('bbc_two_hd', 'BBC Two'),
    ('bbc_three_hd', 'BBC Three'), ('bbc_four_hd', 'BBC Four'),
    ('cbbc_hd', 'CBBC'), ('cbeebies_hd', 'CBeebies'),
    ('bbc_news24', 'BBC News'), ('bbc_scotland', 'BBC Scotland'),
)
CHANNEL_IDS = frozenset(identity for identity, _ in CHANNELS)


class SecureRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        target = urlsplit(newurl)
        if target.scheme != 'https' or target.username or target.password:
            raise HDUnavailable('Insecure broadcaster redirect.')
        return super().redirect_request(request, fp, code, msg, headers, newurl)


def read_https(url, limit=MAX_BYTES):
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise HDUnavailable('Unsupported broadcaster address.')
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Accept-Encoding': 'identity'})
    try:
        with build_opener(SecureRedirect()).open(request, timeout=10) as response:
            final = response.geturl()
            if urlsplit(final).scheme != 'https':
                raise HDUnavailable('Insecure broadcaster redirect.')
            data = response.read(limit + 1)
            if len(data) > limit:
                raise HDUnavailable('Broadcaster response is too large.')
            return data, final
    except HDUnavailable:
        raise
    except Exception:
        raise HDUnavailable('The broadcaster is unavailable. Please try again.') from None


def resolve_bbc(channel, fetch=read_https):
    if channel not in CHANNEL_IDS:
        raise HDUnavailable('Unknown live channel.')
    url = ('https://open.live.bbc.co.uk/mediaselector/6/select/version/2.0/'
           'mediaset/pc/vpid/' + channel + '/format/json')
    try:
        data, _ = fetch(url)
        payload = json.loads(data)
        for media in payload.get('media', []):
            if not str(media.get('kind', '')).startswith('video'):
                continue
            for connection in media.get('connection', []):
                candidate = connection.get('href', '')
                if (connection.get('transferFormat') == 'dash'
                        and urlsplit(candidate).scheme == 'https'):
                    return candidate
    except HDUnavailable:
        raise
    except Exception:
        raise HDUnavailable('The broadcaster returned an invalid response.') from None
    raise HDUnavailable('No compatible live stream is available in your region.')
