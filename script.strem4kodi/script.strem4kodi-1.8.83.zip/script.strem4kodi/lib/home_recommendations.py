"""Local Home suggestions with bounded, single-flight background TMDB refresh."""
import hashlib
import re
import threading
import time
from datetime import date
from pathlib import Path

_lock = threading.Lock()
_running = set()


def completed(row):
    """A playback timestamp alone also covers checkpoints and marking unwatched."""
    state = row.get('state') or {}
    if not state.get('lastWatched'):
        return False
    try:
        offset = max(0, float(state.get('timeOffset') or 0))
        duration = max(0, float(state.get('duration') or 0))
    except (TypeError, ValueError):
        return False
    if duration and offset >= duration * .90:
        return True
    if offset > 1:
        return False
    if state.get('flaggedWatched'):
        return True
    # Completed episodes advance to the next aired episode at a 1ms sentinel
    # and clear flaggedWatched on that next episode.
    return row.get('type') == 'series' and offset == 1 and bool(state.get('timesWatched'))


def identities(row):
    kind = row.get('type')
    return {(kind, str(row.get(field))) for field in ('id', '_id', 'imdb_id', 'moviedb_id')
            if row.get(field)}


def recent(library):
    rows = [dict(row, id=row.get('id') or row.get('_id')) for row in library
            if row.get('type') in ('movie', 'series') and completed(row)]
    rows.sort(key=lambda row: str(row['state']['lastWatched']), reverse=True)
    seen, result = set(), []
    for row in rows:
        keys = identities(row)
        if keys and not keys & seen:
            seen.update(keys)
            result.append(row)
    return result[:5]


def build(library, key, fetcher):
    """At most five seeds, four discovery calls per seed and ten ID lookups."""
    from tmdb_metadata import identity, request, photo
    watched = set().union(*(identities(row) for row in library if completed(row)))
    candidate_groups, preferred = [], []
    had_error = False
    id_budget = 10
    today = date.today().isoformat()
    for seed in recent(library):
        try:
            resolved = identity(seed, key, fetcher)
            if not resolved:
                continue
            kind, tid = resolved
            watched.add((seed['type'], tid))
            sequel = None
            if kind == 'movie':
                details = request(key, 'movie/' + tid, fetcher)
                collection = details.get('belongs_to_collection') or {}
                cid = str(collection.get('id') or '')
                if re.fullmatch(r'[1-9]\d*', cid):
                    parts = request(key, 'collection/' + cid, fetcher).get('parts') or []
                    parts = sorted((r for r in parts if isinstance(r, dict)),
                                   key=lambda r: str(r.get('release_date') or '9999'))
                    after = False
                    for row in parts:
                        if str(row.get('id')) == tid:
                            after = True
                            continue
                        if (after and row.get('release_date') and row['release_date'] <= today
                                and ('movie', str(row.get('id'))) not in watched):
                            if id_budget <= 0:
                                break
                            id_budget -= 1
                            imdb = request(key, 'movie/' + str(row.get('id')) + '/external_ids', fetcher).get('imdb_id')
                            if re.fullmatch(r'tt\d+', str(imdb or '')) and ('movie', imdb) not in watched:
                                sequel = (kind, dict(row, _imdb=imdb))
                                break
            if sequel:
                preferred.append(sequel)
            else:
                rows = request(key, kind + '/' + tid + '/similar', fetcher).get('results') or []
                candidate_groups.append([(kind, row) for row in rows[:10] if isinstance(row, dict)])
        except Exception:
            had_error = True
            continue
    candidates = []
    for index in range(10):
        candidates.extend(group[index] for group in candidate_groups if index < len(group))
    result, seen = [], set(watched)
    # Converting at most ten candidates bounds external-ID requests even when
    # the supplier returns invalid IDs or already-watched IMDb identities.
    for kind, row in preferred + candidates:
        if len(result) >= 10:
            break
        tid = str(row.get('id') or '')
        media = 'movie' if kind == 'movie' else 'series'
        released = str(row.get('release_date') or row.get('first_air_date') or '')
        if (not re.fullmatch(r'[1-9]\d*', tid) or row.get('adult') or
                not released or released > today or (media, tid) in seen):
            continue
        try:
            imdb = row.get('_imdb')
            if not imdb:
                if id_budget <= 0:
                    continue
                id_budget -= 1
                imdb = request(key, kind + '/' + tid + '/external_ids', fetcher).get('imdb_id')
            if not re.fullmatch(r'tt\d+', str(imdb or '')) or (media, imdb) in seen:
                continue
            seen.update(((media, tid), (media, imdb)))
            result.append(dict(id=imdb, imdb_id=imdb, moviedb_id=tid, type=media,
                               name=row.get('title') or row.get('name') or '',
                               poster=photo(row.get('poster_path')), released=released,
                               year=released[:4], description=row.get('overview') or ''))
        except Exception:
            had_error = True
            continue
    if not result and had_error:
        raise RuntimeError('Recommendation lookup failed; keep the previous cache')
    return result


def sections(directory, state):
    """Return persisted cards immediately; never perform HTTP on the Home thread."""
    from account import Store
    from addon_state import get_addon
    library = state.get('library') or []
    key = get_addon().getSetting('tmdb_api_key').strip()
    if not key or not recent(library):
        return []
    namespace = hashlib.sha256((str(state.get('token') or '') + key).encode()).hexdigest()
    signature = hashlib.sha256(repr([(row.get('type'), row.get('id'), row['state'].get('lastWatched'))
                                     for row in recent(library)]).encode()).hexdigest()
    store = Store(Path(directory) / ('home-recommendations-' + namespace))
    try:
        cached = store.load()
    except Exception:
        cached = {}
    watched = set().union(*(identities(row) for row in library if completed(row)))
    rows = [row for row in cached.get('items', []) if isinstance(row, dict)
            and not identities(row) & watched][:10]
    if ((cached.get('signature') != signature or time.time() - float(cached.get('created') or 0) >= 3600)
            and time.time() >= float(cached.get('retry_after') or 0)):
        flight = str(store.directory)
        with _lock:
            if flight not in _running:
                _running.add(flight)
                def refresh():
                    try:
                        from protocol import fetch
                        items = build(library, key, lambda url: fetch(url, timeout=4))
                        store.save({'created': time.time(), 'signature': signature, 'items': items})
                        try:
                            import xbmcgui
                            xbmcgui.Window(10000).setProperty(
                                'strem4kodi.home.recommendations.revision', str(time.time_ns()))
                        except Exception:
                            pass
                    except Exception:
                        try:
                            store.save(dict(cached, retry_after=time.time() + 300))
                        except Exception:
                            pass
                    finally:
                        with _lock:
                            _running.discard(flight)
                try:
                    threading.Thread(target=refresh, daemon=True).start()
                except RuntimeError:
                    _running.discard(flight)
    return [{'label': 'You May Also Like', 'items': rows, 'failed': False}] if rows else []
