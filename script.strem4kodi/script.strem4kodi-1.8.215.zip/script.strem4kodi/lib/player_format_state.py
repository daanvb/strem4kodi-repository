"""Keep explicit format detections through incomplete same-stream refreshes."""
import re
from lib.player_format_logos import logo


class FormatHistory:
    def __init__(self):
        self.previous = None

    def apply(self, data):
        previous = self.previous or {}
        evidence = data.get('format_evidence') or {}
        before = previous.get('format_evidence') or {}
        icons = dict(data['icons'])
        old_icons = previous.get('icons') or {}
        same_session = (data.get('file') == previous.get('file')
                        and evidence.get('key') == before.get('key'))
        if same_session:
            video = evidence.get('video')
            detail = evidence.get('detail', '')
            layer = evidence.get('layer', '')
            # Missing layer detail is not a new MEL/profile/output verdict.
            if (video is not None and video == before.get('video')
                    and old_icons.get('hdr') == logo('dolby_vision_fel')
                    and icons.get('hdr') == logo('dolby_vision')
                    and layer in ('', 'unknown')
                    and (not detail or detail.lower() == 'unknown'
                         or re.fullmatch(r'\s*7(?:\.6)?(?:\s*EL)?\s*', detail, re.I))
                    and evidence.get('source') in ('', '3')
                    and evidence.get('mode') in ('', 'Dolby Vision')):
                icons['hdr'] = old_icons['hdr']
            audio = evidence.get('audio')
            if (audio is not None and audio == before.get('audio')
                    and old_icons.get('audio') == logo('truehd_atmos')
                    and icons.get('audio') == logo('truehd')
                    and evidence.get('active_audio') in ('', 'truehd', 'atmos', 'truehd_atmos')):
                icons['audio'] = old_icons['audio']
                icons['audio_base'] = ''
        result = dict(data, icons=icons)
        self.previous = result
        return result
