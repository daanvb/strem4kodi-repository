"""Addon-owned hero stream panel; Back restores the original cards and focus."""
import threading
import time
import xbmcgui
from lib.ui_dialogs import dialog as themed_dialog
from lib import backend as api
from lib.stream_presenter import presentation, target_label, playback_meta, filter_rows, provider_choices

LIST, CLOSE, RETRY, PROVIDER_FILTER, CODEC_FILTER, HDR_FILTER = 7100, 7101, 7103, 7104, 7105, 7106
SORT, CLEAR_FILTERS, QUALITY_FILTER = 7107, 7108, 7109
BACK = (10, 92, 216, 247)


class InlineStreams:
    def init_streams(self):
        self._streams_lock = threading.RLock()
        self._streams_failed = set()
        self._streams_recovery_player = None
        from lib.playback_recovery import RecoveryTracker
        self._streams_recovery = RecoveryTracker()
        # Construct on the long-lived media-window thread. A player created by
        # an early-selection Timer loses its callback pump when that timer exits.
        from lib.playback_recovery import player
        self._streams_recovery_player=player(self._streams_recovery, api.STORE.directory,
            on_started=self._stream_started)
        self._streams_recovery_event = None
        self._streams_worker = None
        self._streams_request = None
        self._streams_search_progress = None
        self._streams_early_timer = None
        self._streams_search_started = 0
        self._streams_search_elapsed = -1
        self._streams_generation = 0
        self._streams_dead = False
        self._streams_open = False
        self._streams_rows = []
        self._streams_visible = []
        self._streams_positions = {}
        self._streams_launching = False
        self._streams_loading_screen = None
        self._streams_search_screen = None
        self._streams_search_token = ''
        self._streams_playback_generation = None
        self._streams_loading_art = None
        self._streams_resume_grace = None
        self._streams_prefetch_identity = None
        self._streams_prefetched = set()
        self._streams_prefetch_timer = None
        self._streams_format_status = {}
        self._streams_provider_filter = 'All'
        self._streams_codec_filter = 'All'
        self._streams_dynamic_filter = 'All'
        from addon_state import get_addon
        from lib.source_preferences import load_filters
        self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter = load_filters(get_addon())
        self._streams_codec_filter = 'All'
        addon = get_addon()
        remember = addon.getSetting('source_remember_filters') == 'true'
        self._streams_audio_filter = (addon.getSetting('source_filter_audio') or 'All') if remember else 'All'
        self._streams_quality_filter = (addon.getSetting('source_filter_quality') or 'All') if remember else 'All'
        self._sync_stream_filter_labels()

    def prefetch_streams(self, identity):
        """Explicit title-open check; reuse fresh sources and check each target once."""
        if not identity or self._streams_dead:return
        from lib.loading_trivia import prefetch as prefetch_trivia
        prefetch_trivia(self.meta)
        self._streams_prefetch_identity = identity
        self.setProperty('format_check_status', self._streams_format_status.get(identity, ''))
        if identity in self._streams_prefetched:return
        from addon_state import get_addon
        from lib.coreelec import enabled
        import xbmc
        if self._streams_prefetch_timer:
            self._streams_prefetch_timer.cancel()
            self._streams_prefetch_timer = None
        cached_state=api.stream_cache_state(self.meta,identity)
        cached=api.cached_source_rows(self.meta,identity) if cached_state else None
        if cached and cached[0]:
            self.section_cache['streams:'+identity]=cached
            from lib.available_formats import apply
            apply(self, cached[0])
        # Badge freshness is independent of short-lived playback URLs.
        summary = api.availability_summary(dict(self.meta, _focus_video_id=identity))
        if isinstance(summary, dict) and summary.get('target') == identity and summary.get('formats') and not summary.get('stale'):
            from lib.available_formats import properties
            for key, value in properties(summary['formats']).items():self.setProperty(key, value)
            self._streams_prefetched.add(identity)
            self._set_format_status(identity, '')
            return
        # Fresh cache needs no provider fan-out. Stale/missing cache refreshes once
        # in the background while the user can already open the cached rows.
        if cached_state and not cached_state[4]:
            self._streams_prefetched.add(identity)
            self._set_format_status(identity, '')
            return
        from lib.format_preload import background_allowed
        if enabled(get_addon()) and not background_allowed(xbmc.Player(), self.getProperty('hero_trailer'), getattr(self, 'preview_url', None)):
            return
        from lib.format_budget import claim, cooldown, retry_after
        if not claim(api.STORE.directory, len(api.providers('streams'))):
            self._set_format_status(identity, 'Waiting to refresh')
            delay = retry_after(api.STORE.directory)
            if delay is not None:
                def retry():
                    if not self._streams_dead and self.play_target == identity and not self._streams_open:
                        self.prefetch_streams(identity)
                self._streams_prefetch_timer = threading.Timer(delay, retry)
                self._streams_prefetch_timer.daemon = True
                self._streams_prefetch_timer.start()
            return
        self._streams_prefetched.add(identity)
        self._set_format_status(identity, 'Checking formats…')
        from lib.available_formats import formats, merge_formats, properties
        retained = formats(cached[0]) if cached and cached[0] else (
            summary.get('formats', []) if isinstance(summary, dict) and summary.get('target') == identity else [])
        def arriving(rows):
            if not self._streams_dead and self.play_target == identity and not self._streams_open:
                for key, value in properties(merge_formats(retained, formats(rows))).items():self.setProperty(key, value)
        outcome = []
        def refresh():
            try:
                result=api.source_rows(self.meta,identity,on_formats=arriving,on_status=outcome.append)
                limited = 'rate_limited' in outcome
                if limited or result is None or (result[2] and not result[0]):
                    cooldown(api.STORE.directory)
                self._set_format_status(identity, 'Provider rate limit' if limited else
                    'Some providers unavailable' if result and result[0] and result[2] else
                    'Provider unavailable' if result is None or result[2] else
                    '' if result[0] else 'No format information')
                if not self._streams_dead and result is not None:
                    if result[0]:self.section_cache['streams:'+identity]=result
                    if result[0] and self.play_target == identity and not self._streams_open:
                        found = merge_formats(retained, formats(result[0])) if result[2] else formats(result[0])
                        for key, value in properties(found).items():self.setProperty(key, value)
            except Exception:
                cooldown(api.STORE.directory)
                self._set_format_status(identity, 'Provider unavailable')
        try:threading.Thread(target=refresh,daemon=True).start()
        except RuntimeError:pass

    def refresh_format_status(self):
        # Database/other-client updates can populate logos without completing
        # this window's deferred source check. Reconcile the display locally.
        identity = self._streams_prefetch_identity
        if (not self._streams_dead and identity == getattr(self, 'play_target', None)
                and self._streams_format_status.get(identity) == 'Waiting to refresh'
                and any(self.getProperty('available_format_' + str(i)) for i in range(4))):
            self._set_format_status(identity, '')

    def _set_format_status(self, identity, text):
        if (text == 'Waiting to refresh' and identity == self._streams_prefetch_identity
                and any(self.getProperty('available_format_' + str(i)) for i in range(4))):
            text = ''
        self._streams_format_status[identity] = text
        if not self._streams_dead and self._streams_prefetch_identity == identity:
            self.setProperty('format_check_status', text)

    def choose_source(self, identity, resume_ms=0, allow_auto=True, continue_auto=False):
        if (self._streams_dead or self._streams_open or
                (self._streams_loading_screen and ((self._streams_loading_screen.attempt and not continue_auto)
                    or not self._streams_loading_screen.cancel_done.is_set()))):
            return
        self.cancel_trailer()
        self._streams_previous_preview = self.preview_suspended
        self.preview_suspended = True
        self._streams_origin = self.getFocusId()
        self._streams_card_position = self.getControl(self.active_list).getSelectedPosition()
        self._streams_identity, self._streams_resume = identity, resume_ms
        self._streams_allow_auto = allow_auto
        self._streams_auto_chain = False
        self._streams_loading_art = None
        self._streams_resume_grace = None
        if not continue_auto:
            self._streams_auto_attempts = 0
            self._streams_owner_window = xbmcgui.getCurrentWindowId()
        self._streams_rows, self._streams_visible = [], []
        self._streams_rendered = []
        self._streams_open = True
        self.clearProperty('menu')
        self.menu_mode = None
        self.setProperty('streams_target', target_label(self.meta, identity))
        import uuid
        from lib import playback_timing
        self._streams_search_token = 'search:' + uuid.uuid4().hex
        playback_timing.begin(self._streams_search_token)
        from addon_state import get_addon
        from lib.auto_source import configured
        if allow_auto and configured(get_addon(), self.meta)[0] == 2:
            from lib.playback_loading import LoadingSession
            from lib.loading_trivia import choose as loading_fact
            self._streams_loading_art = dict(loading_fact(self.meta),
                poster=self.meta.get('poster') or '',
                background=self.getProperty('fanart') or self.meta.get('background') or '')
            self.setProperty('streams_auto_loading', 'true')
            generation = self._streams_generation + 1
            art=dict(self._streams_loading_art,stage='Finding your stream',
                     hint='Trying another source' if continue_auto else 'Checking your enabled add-ons')
            previous=self._streams_loading_screen if continue_auto else None
            if previous and previous.advance(self._streams_search_token,target_label(self.meta,identity),
                    art=art,on_cancel=lambda:self._cancel_stream_search(generation)):
                self._streams_search_screen=previous
                self._streams_loading_screen=None
            else:
                self._streams_search_screen = LoadingSession(lambda:self._cancel_stream_search(generation))
                self._streams_search_screen.begin(self._streams_search_token,target_label(self.meta, identity),art=art)
            self._streams_search_screen.load_trivia(dict(self.meta))
        self.setProperty('streams_open', 'true')
        self._queue_streams()

    def _finish_stream_search(self):
        if self._streams_search_screen:
            self._streams_search_screen.finish()
            self._streams_search_screen = None
        self.clearProperty('streams_auto_loading')

    def _cancel_stream_search(self, generation):
        loading=None
        with self._streams_lock:
            if generation != self._streams_generation:
                # A click during the search/playback handover still cancels
                # that attempt, but a stale callback cannot cancel a retry.
                if (generation == self._streams_playback_generation and self._streams_loading_screen
                        and self._streams_loading_screen.attempt):
                    loading=self._streams_loading_screen
            else:
                self._streams_allow_auto = False
                self._streams_auto_chain = False
                self.close_streams()
                self.report('Playback cancelled.')
        if loading:loading.cancel(loading.attempt)

    def _queue_streams(self, refresh=False):
        with self._streams_lock:
            self._cancel_early_stream()
            self._streams_generation += 1
            generation, identity = self._streams_generation, self._streams_identity
            self.clearProperty('streams_ready')
            self.setProperty('streams_loading', 'true')
            self.setProperty('streams_message', 'Finding available sources…')
            self.setProperty('streams_count', '')
            self._streams_search_started = time.monotonic()
            self._streams_search_elapsed = -1
            self._streams_search_progress = None
            self.setProperty('streams_search_status', 'Searching your enabled add-ons')
            self.setProperty('streams_search_detail', 'Sources appear as each add-on replies')
            if not self.getProperty('streams_auto_loading'):self.setFocusId(CLOSE)
            if not refresh and 'streams:' + identity in self.section_cache:
                self.setProperty('streams_search_status', 'Saved sources · ready to choose')
                self.clearProperty('streams_search_detail')
                self._show_stream_result(generation, self.section_cache['streams:' + identity])
                return
            if not refresh:
                cached = api.stream_cache_state(self.meta, identity)
                if isinstance(cached, (tuple, list)) and len(cached) >= 5 and not cached[4]:
                    result = api.cached_source_rows(self.meta, identity)
                    if isinstance(result, (tuple, list)) and len(result) == 3 and result[0]:
                        self.section_cache['streams:' + identity] = result
                        self.setProperty('streams_search_status', 'Saved sources · ready to choose')
                        self.clearProperty('streams_search_detail')
                        self._show_stream_result(generation, result)
                        return
            self._streams_request = (generation, identity)
            if self._streams_worker is not None:
                return
            try:
                self._streams_worker = threading.Thread(target=self._load_streams, daemon=True)
                self._streams_worker.start()
            except RuntimeError:
                self._streams_worker = None
                self._streams_request = None
                self._show_stream_result(generation, None)

    def _load_streams(self):
        while True:
            with self._streams_lock:
                job, self._streams_request = self._streams_request, None
                if self._streams_dead or job is None:
                    self._streams_worker = None
                    return
            generation, identity = job
            try:
                result = api.source_rows(self.meta, identity,
                    on_formats=lambda rows: self._stream_arrival(generation, rows),
                    on_progress=lambda status: self._stream_progress(generation, status))
                if not isinstance(result, (tuple, list)) or len(result) != 3:
                    result = None
            except Exception:
                result = None  # Never log provider URLs or raw exceptions.
            with self._streams_lock:
                if not self._streams_dead and result is not None and result[0]:
                    self.section_cache['streams:' + identity] = result
                if not self._streams_dead and self._streams_open and generation == self._streams_generation:
                    try:
                        self._show_stream_result(generation, result)
                    except (RuntimeError, ValueError, TypeError):
                        self.clearProperty('streams_loading')
                        self._finish_stream_search()
                        self.setProperty('streams_message', 'Could not show sources. Select Refresh to retry.')
                        self.setFocusId(RETRY)

    def _stream_arrival(self, generation, rows):
        with self._streams_lock:
            if rows:
                self._show_stream_result(generation, (rows, 0, 0), partial=True)

    def _stream_progress(self, generation, status):
        with self._streams_lock:
            if self._streams_dead or not self._streams_open or generation != self._streams_generation:
                return
            self._streams_search_progress = dict(status)
            if not self._streams_rows:
                from lib.source_loading import properties
                self.setProperty('streams_message', properties(status)['streams_search_detail'] or 'Finding available sources.')
            self._streams_search_elapsed = -1
            self._update_search_progress()

    def _update_search_progress(self):
        if self._streams_search_progress is None:
            return
        from lib.source_loading import properties
        elapsed = int(max(0, time.monotonic() - self._streams_search_started))
        if elapsed == self._streams_search_elapsed:
            return
        self._streams_search_elapsed = elapsed
        for key, value in properties(self._streams_search_progress, elapsed).items():
            self.setProperty(key, value)
        if self._streams_search_screen:
            self._streams_search_screen.hint(
                'Some add-ons are taking longer. You can cancel and try again.' if elapsed >= 15
                else 'Checking your enabled add-ons')

    def _show_stream_result(self, generation, result, partial=False):
        if self._streams_dead or not self._streams_open or generation != self._streams_generation:
            return
        had_rows = bool(self._streams_rows)
        incomplete = result is None and had_rows
        if incomplete:
            result = (self._streams_rows, 0, 1)
            self._streams_allow_auto = False
        if not partial:
            self._cancel_early_stream()
            self.clearProperty('streams_loading')
            if result is None or incomplete:
                self.setProperty('streams_search_status', 'Search incomplete')
            elif self.getProperty('streams_search_status').startswith('Searching'):
                self.setProperty('streams_search_status', 'Search complete')
        from lib.playback_recovery import digest
        self._streams_rows = [dict(row) for row in (result[0] if result else []) if isinstance(row, dict)]
        for row in self._streams_rows:
            row['_session_failed'] = row.get('_session_failed', False) or digest(row.get('url','')) in self._streams_failed
        automatic_loading = bool(self.getProperty('streams_auto_loading'))
        if not automatic_loading:
            from lib.available_formats import apply
            apply(self, self._streams_rows)
            self.refresh_format_status()
        if not self._streams_rows:
            self._finish_stream_search()
            self.clearProperty('streams_ready')
            message = 'Unable to load sources. Select Refresh to try again.' if result is None else (
                'No supported sources. {} unsupported · {} providers unavailable.'.format(result[1], result[2]))
            self.setProperty('streams_message', message)
            self.setFocusId(RETRY)
            return
        automatic_loading = bool(self.getProperty('streams_auto_loading'))
        if not automatic_loading:self._render_streams(restore=True)
        if not had_rows and not automatic_loading:
            self.setFocusId(LIST if self._streams_visible else CLOSE)
        if partial:
            self._schedule_early_stream(generation)
            return
        if incomplete:
            self.setProperty('streams_message', 'Search stopped early. Available sources are kept; Refresh to retry.')
        elif self._streams_search_progress and self._streams_search_progress.get('failed') and not self.getProperty('streams_message'):
            self.setProperty('streams_message', self.getProperty('streams_search_detail'))
        if getattr(self, '_streams_allow_auto', False):
            self._streams_allow_auto = False
            from addon_state import get_addon
            from lib.auto_source import select
            from lib.last_source import load as successful_source
            remembered = successful_source(api.STORE.directory, self.meta.get('type'), self._streams_identity) if self._streams_resume > 0 else None
            mode, selected, fallback = select(self._streams_rows, get_addon(), self.meta,
                (self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter, self._streams_audio_filter, self._streams_quality_filter), remembered=remembered, identity=self._streams_identity)
            if selected is not None:
                if fallback:self.setProperty('streams_message', 'Using the closest available match to your preferences.')
                if mode == 2:
                    self._streams_auto_chain = True
                    self._play_stream_row(selected)
                    return
                elif mode == 1:
                    for index, row in enumerate(self._streams_visible):
                        if selected in (row.get('_alternatives') or [row]):
                            self.getControl(LIST).selectItem(index)
                            break
            elif mode==2:
                self._manual_source_only=True
                self.refresh_primary_action()
        if automatic_loading:
            self._finish_stream_search()
            self._render_streams(restore=True)
            self.setFocusId(LIST if self._streams_visible else CLOSE)

    def _cancel_early_stream(self):
        timer = self._streams_early_timer
        self._streams_early_timer = None
        if timer:
            timer.cancel()

    def _early_stream_match(self, resume_fallback=False):
        from addon_state import get_addon
        from lib.auto_source import early_select
        from lib.last_source import load as successful_source
        remembered = successful_source(api.STORE.directory, self.meta.get('type'), self._streams_identity) if self._streams_resume > 0 else None
        return early_select(self._streams_rows, get_addon(), self.meta,
            (self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter,
             self._streams_audio_filter, self._streams_quality_filter), remembered=None if resume_fallback else remembered, identity=self._streams_identity)

    def _schedule_early_stream(self, generation):
        if not getattr(self, '_streams_allow_auto', False):return
        selected=self._early_stream_match()
        delay=0.0
        if selected is None:
            if not self._streams_resume or self._early_stream_match(resume_fallback=True) is None:return
            # Start the grace only when an exact alternative is available, not
            # at search launch. Further arrivals do not restart the deadline.
            if self._streams_resume_grace is None:self._streams_resume_grace=time.monotonic()+2.0
            delay=max(0.0,self._streams_resume_grace-time.monotonic())
        if self._streams_early_timer is not None:
            if delay>0:return
            self._cancel_early_stream()  # The working release arrived: start now.
        def settle():
            with self._streams_lock:
                if self._streams_early_timer is not timer:return
                self._streams_early_timer = None
                if (self._streams_dead or not self._streams_open or generation != self._streams_generation
                        or not self._streams_allow_auto):return
                selected = self._early_stream_match()
                if (selected is None and self._streams_resume_grace is not None
                        and time.monotonic()>=self._streams_resume_grace):
                    selected=self._early_stream_match(resume_fallback=True)
                if selected is not None:
                    self._streams_allow_auto = False
                    self._streams_auto_chain = True
                    self._play_stream_row(selected)
        # Dispatch playback off the provider callback, without an artificial delay.
        timer = threading.Timer(delay, settle)
        timer.daemon = True
        self._streams_early_timer = timer
        try:timer.start()
        except RuntimeError:self._streams_early_timer = None

    def _render_streams(self, restore=False):
        from addon_state import get_addon
        from lib.source_preferences import preferences, rank_rows, limit_quality
        prefs = preferences(get_addon())
        ranked = rank_rows(limit_quality(self._streams_rows, prefs['maximum']), prefs)
        self._streams_visible = filter_rows(ranked, self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter, self._streams_audio_filter, self._streams_quality_filter)
        from lib.source_groups import group_rows
        total = len(self._streams_visible)
        if get_addon().getSetting('source_group_duplicates') != 'false':
            self._streams_visible = group_rows(self._streams_visible)
        control = self.getControl(LIST)
        selected_url = getattr(self, '_streams_selected_url', '')
        old_position = control.getSelectedPosition()
        previous = getattr(self, '_streams_rendered', [])
        if restore and 0 <= old_position < len(previous):
            selected_url = previous[old_position].get('url', '')
        control.reset()
        for row in self._streams_visible:
            view = presentation(row)
            alternatives = row.get('_alternatives') or [row]
            suffix = ' | {} options'.format(len(alternatives)) if len(alternatives)>1 else ''
            entry = xbmcgui.ListItem(('Failed to play | ' if row.get('_session_failed') else '') + view['title'] + suffix)
            entry.setProperty('stream_detail', view['detail'])
            entry.setProperty('stream_audio', view['audio'])
            from core.stream_ui import stream_card
            from lib.stream_presenter import line
            entry.setProperty('stream_release',line(stream_card(row).get('filename'),180))
            control.addItem(entry)
        key = self._streams_identity
        pos = self._streams_positions.get(key, 0) if restore else 0
        if restore and selected_url:
            pos = next((i for i, row in enumerate(self._streams_visible)
                        if any(source.get('url') == selected_url for source in (row.get('_alternatives') or [row]))), pos)
        control.selectItem(max(0, min(pos, len(self._streams_visible) - 1)))
        self._streams_rendered = list(self._streams_visible)
        self.setProperty('streams_count', '{} releases / {} sources'.format(len(self._streams_visible), total))
        self.setProperty('streams_ready', 'true' if self._streams_visible else '')
        from lib.stream_presenter import stream_traits
        p7_unknown=any('Profile 7 reported' in stream_traits(r)['dynamic'] and 'P7 FEL reported' not in stream_traits(r)['dynamic'] for r in ranked)
        fel_empty=self._streams_dynamic_filter in ('FEL reported','P7 FEL reported') and p7_unknown
        self.setProperty('streams_message', ('Profile 7 sources are available, but their FEL layer is unreported. Choose Video: Profile 7 to include them.' if fel_empty else 'No sources explicitly report FEL. A Dolby Vision or REMUX label alone does not confirm the enhancement layer.') if not self._streams_visible and self._streams_dynamic_filter in ('FEL reported','P7 FEL reported') else '' if self._streams_visible else 'No sources match your filters or maximum quality. Clear filters or adjust Maximum stream quality in Sources settings.')

    def _sync_stream_filter_labels(self):
        from addon_state import get_addon
        orders=('Recommended','Provider order','Smallest first','Largest first')
        try:index=int(get_addon().getSetting('source_sort') or '0')
        except (ValueError,TypeError):index=0
        self.setProperty('streams_sort', 'Sort: '+orders[index if 0<=index<len(orders) else 0])
        self.setProperty('streams_provider_filter', 'Source: '+self._streams_provider_filter)
        audio_labels={'Dolby Digital Plus':'DD+','Dolby Digital':'DD','DTS-HD MA':'DTS-HD'}
        self.setProperty('streams_codec_filter', 'Audio: '+audio_labels.get(self._streams_audio_filter,self._streams_audio_filter))
        self.setProperty('streams_quality_filter', 'Quality: '+('Unknown' if self._streams_quality_filter=='AUTO' else self._streams_quality_filter))
        video_labels={'P7 FEL reported':'P7 FEL','FEL reported':'FEL','Profile 7 reported':'Profile 7'}
        self.setProperty('streams_hdr_filter', 'Video: '+video_labels.get(self._streams_dynamic_filter,self._streams_dynamic_filter))

    def _pick_stream_filter(self, kind):
        if kind=='provider':
            values=provider_choices(self._streams_rows); current=self._streams_provider_filter; heading='Source / provider'
        elif kind=='codec':
            values=['All','Atmos','TrueHD','Dolby Digital Plus','Dolby Digital','DTS-HD MA','DTS-X','AAC','FLAC','Stereo','Mono']; current=self._streams_audio_filter; heading='Audio'
        elif kind=='quality':
            from lib.stream_presenter import quality_choices
            values=quality_choices(self._streams_rows); current=self._streams_quality_filter; heading='Quality'
        else:
            values=['All','Dolby Vision','HDR10','HDR','P7 FEL reported','Profile 7 reported','FEL reported']; current=self._streams_dynamic_filter; heading='Video format - FEL requires an explicit layer report'
        selected=themed_dialog().select(heading,values,preselect=(values.index(current) if current in values else 0))
        if selected<0:return
        if kind=='provider': self._streams_provider_filter=values[selected]
        elif kind=='codec': self._streams_audio_filter=values[selected]
        elif kind=='quality': self._streams_quality_filter=values[selected]
        else: self._streams_dynamic_filter=values[selected]
        from addon_state import get_addon
        from lib.source_preferences import save_filters
        save_filters(get_addon(), self._streams_provider_filter, self._streams_codec_filter, self._streams_dynamic_filter)
        if get_addon().getSetting('source_remember_filters')=='true':
            get_addon().setSetting('source_filter_audio', self._streams_audio_filter)
            get_addon().setSetting('source_filter_quality', self._streams_quality_filter)
        self._sync_stream_filter_labels(); self._render_streams()

    def set_stream_filters(self, provider='All', codec='All', dynamic='All'):
        self._streams_provider_filter = provider or 'All'
        self._streams_codec_filter = codec or 'All'
        self._streams_dynamic_filter = dynamic or 'All'
        self._streams_audio_filter = 'All'
        self._streams_quality_filter = 'All'
        if self._streams_open:
            self._render_streams()

    def _remember_stream_position(self):
        if self._streams_visible:
            self._streams_positions[self._streams_identity] = self.getControl(LIST).getSelectedPosition()

    def close_streams(self):
        with self._streams_lock:
            if not self._streams_open:
                return
            self._remember_stream_position()
            self._cancel_early_stream()
            self._streams_generation += 1
            self._streams_request = None
            self._streams_open = False
            self._finish_stream_search()
            self.clearProperty('streams_open')
            self.clearProperty('streams_loading')
            self._streams_search_progress = None
            self.preview_suspended = self._streams_previous_preview
            listing = self.getControl(self.active_list)
            if listing.getSelectedPosition() != self._streams_card_position:
                listing.selectItem(max(0, self._streams_card_position))
            # Queue focus after Kodi evaluates the restored cards' visibility.
            import xbmc
            if self._streams_loading_screen and self._streams_loading_screen.window:
                self.setFocusId(self._streams_origin)
            else:xbmc.executebuiltin('SetFocus({})'.format(self._streams_origin))

    def streams_focus(self, cid):
        if self.getProperty('streams_auto_loading'):return
        if self._streams_open and cid not in (LIST, CLOSE, RETRY, PROVIDER_FILTER, CODEC_FILTER, HDR_FILTER, SORT, CLEAR_FILTERS, QUALITY_FILTER):
            self.setFocusId(LIST if self.getProperty('streams_ready') else CLOSE)

    def streams_action(self, action):
        loading=self._streams_search_screen or self._streams_loading_screen
        if loading and loading.attempt:
            if action.getId() in BACK:loading.cancel(loading.attempt)
            return True
        if not self._streams_open:
            return False
        if action.getId() in BACK:
            self.close_streams()
            if getattr(self, 'sports_source_only', False) is True:
                self.close()
        return True  # Do not dispatch panel actions to the hidden episode UI.

    def streams_click(self, cid):
        if self._streams_loading_screen and self._streams_loading_screen.attempt:return True
        if self.getProperty('streams_auto_loading'):return True
        if not self._streams_open:
            return False
        if cid == CLOSE:
            self.close_streams()
            if getattr(self, 'sports_source_only', False) is True:
                self.close()
        elif cid == RETRY and not self.getProperty('streams_loading'):
            self._queue_streams(refresh=True)
        elif cid == PROVIDER_FILTER:
            self._pick_stream_filter('provider')
        elif cid == CODEC_FILTER:
            self._pick_stream_filter('codec')
        elif cid == QUALITY_FILTER:
            self._pick_stream_filter('quality')
        elif cid == HDR_FILTER:
            self._pick_stream_filter('hdr')
        elif cid == SORT:
            from addon_state import get_addon
            addon=get_addon();values=['Recommended','Provider order','Smallest first','Largest first']
            try:current=int(addon.getSetting('source_sort') or '0')
            except (ValueError,TypeError):current=0
            selected=themed_dialog().select('Source order',values,preselect=max(0,min(3,current)))
            if selected>=0:
                addon.setSetting('source_sort',str(selected));self._sync_stream_filter_labels();self._render_streams()
        elif cid == CLEAR_FILTERS:
            from addon_state import get_addon
            from lib.source_preferences import save_filters
            self.set_stream_filters();save_filters(get_addon(),'All','All','All');self._sync_stream_filter_labels()
            if get_addon().getSetting('source_remember_filters')=='true':
                get_addon().setSetting('source_filter_audio','All')
                get_addon().setSetting('source_filter_quality','All')
        elif cid == LIST:
            self._play_selected_stream()
        return True

    def _play_selected_stream(self):
        if self._streams_launching or not self.getProperty('streams_ready'):
            return
        index = self.getControl(LIST).getSelectedPosition()
        if not 0 <= index < len(self._streams_visible):
            return
        row=self._streams_visible[index]
        alternatives=row.get('_alternatives') or [row]
        row=alternatives[0]
        if len(alternatives)>1:
            labels=[('Failed | ' if r.get('_session_failed') else '')+presentation(r)['title'] for r in alternatives]
            selected=themed_dialog().select('Choose source for this release',labels,preselect=next((i for i,r in enumerate(alternatives) if not r.get('_session_failed')),0))
            if selected<0:return
            row=alternatives[selected]
        self._streams_auto_chain = False
        self._play_stream_row(row)

    def _stream_opened(self,token):
        if token and self._streams_loading_screen:
            self._streams_loading_screen.finish(token)

    def _intro_opened(self,token):
        if token and self._streams_loading_screen:
            self._streams_loading_screen.cover(token)

    def _stream_started(self,token):
        if not token:return
        if self._streams_loading_screen:
            self._streams_loading_screen.finish(token)
        from lib.playback_timing import mark
        mark(token,'playing')
        from lib.player_back import PROPERTY,STOPPING_PROPERTY
        session=xbmcgui.Window(10000)
        session.clearProperty(PROPERTY);session.clearProperty(STOPPING_PROPERTY)

    def _play_stream_row(self, row):
        if self._streams_launching or self._streams_dead or not self._streams_open:return
        from lib.playback_loading import cancelled
        if self._streams_search_token and cancelled(self._streams_search_token):return
        self._streams_launching = True
        from lib.diagnostic_export import record_source
        record_source(api.STORE.directory, self._streams_identity, row)
        try:
            from lib.playback_recovery import player
            if self._streams_recovery_player is None:
                self._streams_recovery_player=player(self._streams_recovery, api.STORE.directory,
                    on_started=self._stream_started,on_opened=self._stream_opened,on_intro=self._intro_opened)
            attempt = self._streams_recovery.arm(row.get('url',''),self._streams_identity,self._streams_resume,getattr(self,'_streams_owner_window',xbmcgui.getCurrentWindowId()))
            from lib.playback_timing import transfer
            transfer(self._streams_search_token,attempt)
            self._streams_playback_generation = self._streams_generation
            from lib.playback_loading import LoadingSession,video_running
            def video_ready():
                import xbmc
                native=self._streams_recovery_player
                pending=self._streams_recovery.snapshot()
                return bool(pending and pending.get('attempt')==attempt and video_running(native,pending,
                    fullscreen=xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)')))
            from lib.loading_trivia import choose as loading_fact
            art=self._streams_loading_art or dict(loading_fact(self.meta), poster=self.meta.get('poster') or '',
                         background=self.getProperty('fanart') or self.meta.get('background') or '')
            search=self._streams_search_screen
            if search and search.advance(attempt,target_label(self.meta,self._streams_identity),
                    presentation(row)['title'],art=art,on_cancel=lambda:self._cancel_video_loading(attempt),
                    state=self._stream_loading_state,ready=video_ready):
                self._streams_loading_screen=search
                self._streams_search_screen=None
            elif search:
                # Cancel may win after selection checked its search token.
                # Never replace a cancelled card with a fresh playback attempt.
                self._streams_recovery.clear()
                if not cancelled(self._streams_search_token):
                    self._finish_stream_search()
                    self._streams_allow_auto=False
                    self._streams_auto_chain=False
                    self._render_streams(restore=True)
                    self.setProperty('streams_message','Could not open the loading screen. Choose a source or retry.')
                    self.setFocusId(LIST if self._streams_visible else CLOSE)
                return
            if self._streams_loading_screen is not search or self._streams_loading_screen is None:
                if self._streams_loading_screen:self._streams_loading_screen.finish()
                self._streams_loading_screen=LoadingSession(lambda:self._cancel_video_loading(attempt),
                    state=self._stream_loading_state,ready=video_ready)
            if self._streams_loading_screen is not search:
                self._streams_loading_screen.begin(attempt,target_label(self.meta,self._streams_identity),
                    presentation(row)['title'],art=art)
                self._streams_loading_screen.load_trivia(dict(self.meta))
            self._finish_stream_search()
            if getattr(self, '_streams_auto_chain', False):self._streams_auto_attempts += 1
            episode = next((card for card in getattr(self, 'cards', [])
                            if card.get('id') == self._streams_identity), None)
            meta = playback_meta(self.meta, self._streams_identity, episode)
            from lib.playback_timing import mark
            mark(attempt,'handoff_ready')
            identity,resume=self._streams_identity,self._streams_resume
            automatic=getattr(self,'_streams_auto_chain',False)
            def dispatch():
                try:
                    # Check redirects under the existing card, before an error
                    # slate can enter fullscreen. Never probe a live session.
                    if automatic:
                        from source_probe import unavailable, unsupported_disc
                        live=bool(row.get('isLive') or meta.get('type')=='tv' or '.m3u8' in row.get('url',''))
                        failure=unsupported_disc(row.get('url',''),row) or unavailable(row.get('url',''),live=live)
                        pending=self._streams_recovery.snapshot()
                        if not pending or pending['attempt']!=attempt or cancelled(attempt):return
                        if failure:
                            self._streams_recovery.failed()
                            return
                    pending=self._streams_recovery.snapshot()
                    if pending and pending['attempt']==attempt and not cancelled(attempt):
                        details = []
                        if automatic:
                            try:
                                from addon_state import get_addon
                                from lib.auto_source import selection_details
                                details = selection_details(row,get_addon(),meta,identity)
                            except Exception:pass
                        api.play(meta, identity, dict(row, _playback_attempt=attempt,
                            _automatic_selection=automatic, _selection_details=details), resume)
                except Exception:
                    if not automatic:raise
                    pending=self._streams_recovery.snapshot()
                    if pending and pending['attempt']==attempt:self._streams_recovery.failed()
            if automatic:threading.Thread(target=dispatch,daemon=True).start()
            else:dispatch()
            self.close_streams()
        except Exception:
            self._finish_stream_search()
            if self._streams_loading_screen:self._streams_loading_screen.finish()
            from lib.playback_recovery import digest
            if getattr(self, '_streams_auto_chain', False):self._streams_recovery.failed()
            else:self._streams_recovery.clear()
            row['_session_failed'] = True
            self._streams_failed.add(digest(row.get('url','')))
            for source in self._streams_rows:
                if digest(source.get('url','')) in self._streams_failed:source['_session_failed']=True
            self._render_streams()
            self.setProperty('streams_message', 'Playback could not start. Select another source or Refresh.')
            self.setFocusId(LIST if self._streams_visible else CLOSE)
        finally:
            self._streams_launching = False

    def _cancel_video_loading(self, attempt):
        import xbmc
        from lib.playback_recovery import digest, playing_attempt
        with self._streams_lock:
            pending = self._streams_recovery.snapshot()
            if not pending or pending['attempt'] != attempt:
                return
            self._streams_allow_auto=False
            self._streams_auto_chain=False
            self._streams_recovery.clear()
            self._streams_recovery_event=None
            self.close_streams()
        player = xbmc.Player()
        try:
            if (not player.isPlayingVideo() or playing_attempt(player) == attempt
                    or digest(player.getPlayingFile()) == pending['hash']):
                player.stop()
        except (AttributeError, RuntimeError):
            pass
        self.report('Playback cancelled.')

    def _stream_loading_state(self):
        state=self._streams_recovery.loading_state()
        return state or (dict(self._streams_recovery_event,failed=True) if self._streams_recovery_event else None)

    def recover_stream_tick(self):
        if self._streams_open and self.getProperty('streams_loading'):
            self._update_search_progress()
        if self._streams_dead or self._streams_recovery_player is None:return
        import xbmc
        player=self._streams_recovery_player
        self._streams_recovery.poll_failure(api.STORE.directory)
        pending=self._streams_recovery.snapshot()
        if pending and not pending['started']:
            try:
                if player.isPlayingVideo() and player.getTime()>0.5:
                    from lib.playback_recovery import playing_attempt
                    token=self._streams_recovery.started(player.getPlayingFile(),playing_attempt(player))
                    if token:self._stream_started(token)
            except Exception:pass
        self._streams_recovery.startup_timeout()
        with self._streams_recovery.lock:
            pending=dict(self._streams_recovery.pending) if self._streams_recovery.pending else None
        if self._streams_loading_screen:self._streams_loading_screen.observe(self._stream_loading_state())
        event=self._streams_recovery_event or self._streams_recovery.take()
        if event:
            from lib.playback_recovery import stop_failed
            self._streams_recovery_event=event
            state=stop_failed(player,event)
            if state=='waiting':return
            if state in ('blocked','unrelated'):
                self._streams_recovery_event=None
                self._streams_recovery.clear()
                self._streams_auto_chain=False
                if self._streams_loading_screen:self._streams_loading_screen.finish()
                if state=='blocked':self.report('Kodi is still busy with the failed stream. Automatic retries have stopped.')
                return
        if not event and player.isPlayingVideo():
            try:self._streams_recovery.position(player.getPlayingFile(),player.getTime())
            except Exception:pass
            return
        if not event:return
        from lib.playback_loading import signal_cancel
        signal_cancel(event.get('attempt'))
        self._streams_recovery_event=event
        current=xbmcgui.getCurrentWindowId()
        if current not in (event['window'],12005,12006):return
        self._streams_failed.add(event['hash'])
        if current!=event['window']:xbmc.executebuiltin('ActivateWindow({})'.format(event['window']))
        self._streams_recovery.clear()
        from addon_state import get_addon
        try:limit=(3,5,10,25)[int(get_addon().getSetting('auto_source_attempts') or '1')]
        except (ValueError,IndexError):limit=5
        was_auto=getattr(self,'_streams_auto_chain',False)
        retry_auto=was_auto and getattr(self,'_streams_auto_attempts',0)<limit
        if not retry_auto and self._streams_loading_screen:self._streams_loading_screen.finish()
        if self._streams_open:
            if self._streams_identity!=event['identity']:return
            from lib.playback_recovery import digest
            for row in self._streams_rows:
                if digest(row.get('url','')) in self._streams_failed:row['_session_failed']=True
            self._streams_resume=event['resume'];self._render_streams(restore=True)
            if retry_auto:
                self.close_streams()
                self.choose_source(event['identity'],resume_ms=event['resume'],allow_auto=True,continue_auto=True)
        else:self.choose_source(event['identity'],resume_ms=event['resume'],allow_auto=retry_auto,continue_auto=True)
        self._streams_recovery_event=None
        if retry_auto and not self._streams_open:return
        if was_auto and not retry_auto:
            self._manual_source_only=True
            self.refresh_primary_action()
        from lib.diagnostic_export import report_reference
        self.setProperty('streams_message','That source failed. Choose another source or Refresh. '+report_reference(api.STORE.directory))

    def stop_streams(self):
        with self._streams_lock:
            self._streams_dead = True
            self._cancel_early_stream()
            self._finish_stream_search()
            if self._streams_loading_screen:self._streams_loading_screen.finish()
            self._streams_recovery.clear()
            if self._streams_prefetch_timer:
                self._streams_prefetch_timer.cancel()
                self._streams_prefetch_timer = None
            self._streams_open = False
            self._streams_generation += 1
            self._streams_request = None
