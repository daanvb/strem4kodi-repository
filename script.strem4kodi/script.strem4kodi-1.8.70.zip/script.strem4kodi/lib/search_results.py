"""Group full-page search results without changing supplier title ranking."""


def ordered(rows):
    def group(row):
        catalog = row.get('_catalogue') or {}
        if row.get('type') == 'collection' or catalog:
            return (0 if catalog.get('_tmdb_collection') else
                    1 if catalog.get('_genre') else
                    2 if catalog.get('_mdblist') else 3)
        return 4 if row.get('type') == 'movie' else 5 if row.get('type') == 'series' else 6
    return sorted(rows, key=group)
