"""Small, private-URL-free chart snapshots shared by every browsing page."""
import hashlib
import json
import time
from pathlib import Path

from account import Store
from lib.poster_tags import context_catalog, trending_catalog

TTL = 6 * 3600


def scope(addons):
    descriptors = [(a.get('transportUrl'), (a.get('manifest') or {}).get('catalogs'))
                   for a in addons if isinstance(a, dict)]
    return hashlib.sha256(json.dumps(descriptors, sort_keys=True).encode()).hexdigest()


def cached_context(api, catalogs=()):
    """Optional facts must never prevent a browse page from rendering."""
    try:
        addons = api.providers()
        remember(api.STORE.directory, addons, catalogs)
        return load(api.STORE.directory, addons)
    except Exception:
        return []


def load(profile, addons, now=None):
    try:
        state = Store(Path(profile) / 'poster-context').load()
        now = time.time() if now is None else now
        created = float(state.get('created', 0))
    except (OSError, TypeError, ValueError):
        return []
    if state.get('scope') != scope(addons):
        return []
    rows = state.get('rows')
    result = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict) or not isinstance(row.get('items'), list):
            continue
        try:
            if 0 <= now - float(row.get('updated', created)) < TTL:
                result.append(row)
        except (TypeError, ValueError):
            pass
    return result


def refresh(profile, addons, fetch_items, now=None, cancelled=lambda: False):
    """Idle maintenance only: at most one configured trending list per media type."""
    now = time.time() if now is None else now
    if cancelled():
        return
    from lib.browse import discover_catalogs
    specs = discover_catalogs(addons)
    selected = []
    for kind in ('movie', 'series'):
        selected.extend(next(([s] for s in specs if s.get('kind') == kind and trending_catalog(s)), []))
    rows = load(profile, addons, now)
    known = {(r.get('label'), r.get('id')) for r in rows}
    changed = False
    for spec in selected:
        if (spec.get('label'), spec.get('id')) in known:
            continue
        if cancelled():
            return
        try:
            items = fetch_items(spec)
        except Exception:
            continue
        # Store identity/explicit tag facts only. Configured URLs, names of
        # titles, artwork, and tokens never enter the snapshot.
        safe = [{k: item[k] for k in ('id', 'type', 'imdb_id', 'imdbId', 'moviedb_id',
                                     'tmdb_id', 'tvdb_id') if k in item}
                for item in items[:100] if isinstance(item, dict) and item.get('id')]
        if safe:
            rows.append({'label': spec['label'], 'id': spec['id'], 'items': safe, 'updated': now})
            changed = True
    if changed and not cancelled():
        Store(Path(profile) / 'poster-context').save({'created': now, 'scope': scope(addons), 'rows': rows})


def remember(profile, addons, catalogs):
    """Retain charts already loaded in Discover without another network request."""
    sources = list(catalogs)
    sources += [s for c in catalogs for s in c.get('_poster_tag_context', [])]
    fresh = [c for c in sources if context_catalog(c)]
    if not fresh:
        return
    previous = load(profile, addons)
    rows = {(c.get('label'), c.get('id')): c for c in previous}
    for catalog in fresh:
        rows[(catalog.get('label'), catalog.get('id'))] = {
            'label': catalog.get('label'), 'id': catalog.get('id'),
            'updated': time.time(),
            'items': [{k: r[k] for k in ('id', 'type', 'imdb_id', 'imdbId', 'moviedb_id',
                                       'tmdb_id', 'tvdb_id') if k in r}
                      for r in catalog.get('items', [])[:100] if isinstance(r, dict) and r.get('id')]}
    Store(Path(profile) / 'poster-context').save({'created': time.time(), 'scope': scope(addons),
                                               'rows': list(rows.values())[-8:]})
