"""Persistent, bounded UI evidence. An unfinished session is not proof of a crash."""
import hashlib
import re
import threading
import time
from functools import lru_cache
from pathlib import Path

from account import Store

_LOCK = threading.RLock()
_STAGES = {'ui.start', 'ui.closed', 'ui.error', 'home.allocate', 'home.modal',
           'home.return', 'details.queued', 'details.allocate', 'details.modal',
           'details.return', 'search.select', 'search.closed', 'search.modal',
           'search.return', 'details.init', 'details.metadata', 'details.cards',
           'details.ready', 'details.failed', 'browse.select', 'browse.back', 'details.back', 'catalogue.open'}
_PAGES = {'home', 'search', 'discover', 'library', 'sports', 'addons', 'details'}
_ERRORS = {'MemoryError', 'TypeError', 'ValueError', 'RuntimeError', 'AttributeError',
           'KeyError', 'OSError', 'UnknownError'}


def _store(profile):
    return Store(Path(profile) / 'diagnostic-ui-session')


def _safe(row):
    result = {}
    for key in ('started', 'updated', 'ended', 'focus', 'window', 'dialog', 'items', 'rows'):
        value = row.get(key)
        if type(value) is int and 0 <= value <= (2000000000 if key in ('started','updated','ended') else 100000):
            result[key] = value
    if row.get('stage') in _STAGES:
        result['stage'] = row['stage']
    if row.get('last_stage') in _STAGES:
        result['last_stage'] = row['last_stage']
    if row.get('page') in _PAGES:
        result['page'] = row['page']
    if row.get('error_type') in _ERRORS:
        result['error_type'] = row['error_type']
    for key in ('finished', 'preview', 'search_return'):
        if type(row.get(key)) is bool:
            result[key] = row[key]
    return result


def begin(profile, token):
    if not isinstance(token, str) or not re.fullmatch(r'[0-9a-f]{32}', token):
        return
    try:
        with _LOCK:
            store = _store(profile)
            state = store.load()
            previous = state.get('current')
            previous = _safe(previous) if isinstance(previous, dict) else {}
            now = int(time.time())
            store.save({'previous': previous, 'current': {'token':token, 'started':now,
                        'updated':now, 'stage':'ui.start', 'finished':False}})
    except Exception:
        pass


def phase(profile, stage, **fields):
    if stage not in _STAGES:
        return
    try:
        with _LOCK:
            store = _store(profile)
            state = store.load()
            current = state.get('current')
            if not isinstance(current, dict) or current.get('finished') is True:
                return
            current.update(_safe(dict(fields, stage=stage, updated=int(time.time()))))
            store.save(state)
    except Exception:
        pass


def finish(profile, token, error=None):
    try:
        with _LOCK:
            store = _store(profile)
            state = store.load()
            current = state.get('current')
            if not isinstance(current, dict) or current.get('token') != token:
                return
            name = type(error).__name__ if error is not None else ''
            current['last_stage'] = current.get('stage')
            current.update(finished=True, ended=int(time.time()),
                           stage='ui.error' if error is not None else 'ui.closed')
            if name:
                current['error_type'] = name if name in _ERRORS else 'UnknownError'
            store.save(state)
    except Exception:
        pass


@lru_cache(maxsize=1)
def fingerprints():
    result = {}
    for name in ('app', 'nimbus', 'search_box', 'poster_tags', 'ui_crash'):
        try:
            result[name] = hashlib.sha256(Path(__file__).with_name(name+'.py').read_bytes()).hexdigest()[:16]
        except OSError:
            pass
    return result


def snapshot(profile, live_token=None):
    """A changed/absent Kodi lease identifies an interrupted prior app session."""
    try:
        state = _store(profile).load()
        if live_token is None:
            try:
                import xbmcgui
                from lib.launch_guard import TOKEN
                live_token = xbmcgui.Window(10000).getProperty(TOKEN)
            except Exception:
                live_token = ''
        result = {'code':fingerprints()}
        previous = state.get('previous')
        current = state.get('current')
        if isinstance(previous, dict) and previous:
            result['previous'] = _safe(previous)
        if isinstance(current, dict) and current:
            result['current'] = _safe(current)
            result['current']['lease_active'] = bool(current.get('token') and current.get('token') == live_token)
            result['current']['interrupted'] = bool(current.get('finished') is False and not result['current']['lease_active'])
        return result
    except Exception:
        return {'code':fingerprints()}


def posters(profile, page, catalogs, get_setting=None):
    """Record why tags appear/disappear using counts only, not viewing data."""
    try:
        current = _store(profile).load().get('current')
        if not isinstance(current, dict) or current.get('finished') is True:
            return
        from lib.poster_tags import properties
        page = 'search' if str(page).startswith('Search:') else str(page).lower()
        if page not in _PAGES:
            return
        counts = {key:0 for key in ('items','awards','status','director','chart','tagged',
                                    'award_tag','status_tag','rank_tag','editorial_tag','trend_tag')}
        for catalog in catalogs:
            for row in catalog.get('items', [])[:500]:
                if row.get('type') not in ('movie','series'):
                    continue
                counts['items'] += 1
                for field in ('awards','status','director'):
                    counts[field] += int(bool(row.get(field)))
                counts['chart'] += int(bool(row.get('_poster_trending')))
                values = properties(row, get_setting=get_setting)
                for field in ('award','status','rank','editorial','trend'):
                    counts[field+'_tag'] += int(bool(values.get('poster_sash_'+field)))
                counts['tagged'] += int(any(values.get('poster_sash_'+f) for f in ('award','status','rank','editorial','trend')))
        Store(Path(profile)/'diagnostic-posters').save({'page':page, 'time':int(time.time()), 'counts':counts})
    except Exception:
        pass


def poster_snapshot(profile):
    try:
        data = Store(Path(profile)/'diagnostic-posters').load()
        if data.get('page') not in _PAGES or not isinstance(data.get('counts'), dict):
            return {}
        allowed = {'items','awards','status','director','chart','tagged','award_tag',
                   'status_tag','rank_tag','editorial_tag','trend_tag'}
        return {'page':data['page'], 'counts':{k:v for k,v in data['counts'].items()
                if k in allowed and type(v) is int and 0 <= v <= 100000}}
    except Exception:
        return {}
