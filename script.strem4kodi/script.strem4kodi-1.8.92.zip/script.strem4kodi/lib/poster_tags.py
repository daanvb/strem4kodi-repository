"""Native poster facts from loaded catalogues and local source observations only."""
from datetime import date
import re
from urllib.parse import urlsplit

from lib.catalogue_identity import aliases


# Persisted verification from older rules must be re-established from source lists.
CONTEXT_VERSION = 2


NOTABLE_DIRECTORS = {
    'steven spielberg': 'Spielberg Movie',
    'christopher nolan': 'Nolan Movie',
    'martin scorsese': 'Scorsese Movie',
    'quentin tarantino': 'Tarantino Movie',
    'james cameron': 'Cameron Movie',
    'ridley scott': 'Ridley Scott Movie',
    'david fincher': 'Fincher Movie',
    'denis villeneuve': 'Villeneuve Movie',
    'greta gerwig': 'Gerwig Movie',
    'wes anderson': 'Wes Anderson Movie',
    'jordan peele': 'Jordan Peele Movie',
    'sofia coppola': 'Coppola Movie',
}


def award_label(value):
    """Require a positive win in the same award record or sentence.

    Provider dictionaries often contain all award families, including zero
    wins. Flattening them turns ``Emmys: wins 0, Oscars: wins 2`` into a false
    Emmy winner, and can pair nominations with an unrelated prize's win.
    """
    if isinstance(value, (list, tuple)):
        for item in value:
            label = award_label(item)
            if label:
                return label
        return ''
    if isinstance(value, dict):
        prize = value.get('award') or value.get('name') or value.get('prize')
        if prize:
            wins = value.get('wins', value.get('win', value.get('won')))
            try:
                positive = not isinstance(wins, bool) and float(wins) > 0
            except (TypeError, ValueError):
                positive = False
            return award_label('Won {} {}'.format(wins, prize)) if positive else ''
        for prize, record in value.items():
            if isinstance(record, dict):
                label = award_label(dict(record, award=prize))
                if label:
                    return label
        return ''
    if not isinstance(value, str):
        return ''
    text = re.sub(r'\s+', ' ', value).strip().casefold()
    if not text:
        return ''
    # A nomination alone is never promoted to a winner sash.
    for label, prize in (
            ('Oscar Winner', r'(?:oscars?|academy awards?)'),
            ('Emmy Winner', r'(?:primetime )?emmys?'),
            ('Globe Winner', r'(?:golden globes?|globes?)'),
            ('Cannes Winner', r'(?:cannes|palme d.?or)')):
        for statement in re.split(r'[.;\n]|\b(?:but|and|plus)\b', text):
            if re.search(r'\b(?:catalogue|catalog|account|lists?|nominees?|nominations?|nominated)\b', statement):
                continue
            if re.search(r'\b(?:not|never|no|zero)\b|\b0\s+(?:wins?|'+prize+r')\b', statement):
                continue
            if re.search(r'\bwon\s+(?:[1-9]\d*\s+)?'+prize+r'\b|\b'+prize+r'\s+(?:award\s+)?winners?\b|\b(?:winner\s+(?:of\s+)?)'+prize+r'\b', statement):
                return label
    return ''


def editorial_label(row):
    if row.get('type') != 'movie':
        return ''
    director = row.get('director')
    names = [director] if isinstance(director, str) else list(director) if isinstance(director, (list, tuple)) else []
    people = row.get('directorPeople')
    for person in people if isinstance(people, (list, tuple)) else []:
        if isinstance(person, dict) and person.get('name'):
            names.append(person['name'])
    for name in names:
        label = NOTABLE_DIRECTORS.get(str(name).strip().casefold())
        if label:
            return label
    return ''


def status_label(row):
    if row.get('type') != 'series':
        return ''
    status = re.sub(r'[^a-z]+', ' ', str(row.get('status') or '').casefold()).strip()
    if re.search(r'\bnew season\b', status) or row.get('newSeason') is True:
        return 'New Season'
    if status in ('returning', 'returning series'):
        return 'Returning'
    if status in ('airing', 'currently airing'):
        return 'Airing'
    if status == 'in production':
        return 'In Production'
    # Completed/cancelled are common catalogue defaults, not timely news.
    # Keep these facts in details instead of crowding every older TV poster.
    return ''


def trending_catalog(catalog):
    """Recognize chart metadata, including provider IDs such as tmdb_trending."""
    if catalog.get('_genre') or catalog.get('_genre_label'):
        return False
    for field in ('label', 'name', 'catalog_id', 'id', '_id', 'category'):
        text = re.sub(r'[^a-z0-9]+', ' ', str(catalog.get(field) or '').lower())
        if re.search(r'\btrending\b', text):
            return True
    return False


def catalogue_sash(catalog):
    """Return a verified sash carried by an explicitly named curated list."""
    if catalog.get('_genre') or catalog.get('_genre_label'):
        return ('', '')
    # A display name must identify the actual curated list on its own. IDs,
    # account categories and another field must never complete an award claim.
    text = re.sub(r'[^a-z0-9]+', ' ', str(catalog.get('label') or catalog.get('name') or '').casefold()).strip()
    if not text:
        return ('', '')
    if not re.search(r'\b(?:nominees?|nominations?|nominated)\b', text) and re.search(r'\bwinners?\b', text):
        matches = [label for label, pattern in (
                ('Oscar Winner', r'\b(?:oscar|academy award)s?\b'),
                ('Emmy Winner', r'\b(?:primetime )?emmys?\b'),
                ('Globe Winner', r'\b(?:golden )?globes?\b'),
                ('Cannes Winner', r'\b(?:cannes|palme d or)\b'))
                   if re.search(pattern, text)]
        # A combined awards list cannot identify which prize each title won.
        if len(matches) == 1:
            return ('award', matches[0])
        if matches:
            return ('', '')
    for name, label in NOTABLE_DIRECTORS.items():
        if re.search(r'\b' + re.escape(name) + r'\b', text):
            return ('editorial', label)
    for label, pattern in (
            ('New Season', r'\bnew seasons?\b'),
            ('Returning', r'\breturning(?: series| shows?)?\b'),
            ('Airing', r'\b(?:currently )?airing\b'),
            ('In Production', r'\bin production\b')):
        if re.search(pattern, text):
            return ('status', label)
    return ('', '')


def context_catalog(catalog):
    return trending_catalog(catalog) or bool(catalogue_sash(catalog)[0])


def annotate(catalogs, context=()):
    """Recompute membership; retained row flags must not manufacture a chart."""
    catalogs = list(catalogs)
    try:
        context = list(context)
    except TypeError:
        context = []
    trending = set()
    ranks = {}
    contexts = {}
    sources = catalogs + context
    # Overview grids retain their actual source charts after flattening rows.
    sources += [source for catalog in list(sources)
                for source in catalog.get('_poster_tag_context', [])]
    for catalog in sources:
        if '_poster_tag_context' not in catalog and trending_catalog(catalog):
            for position, row in enumerate(catalog.get('items', []), 1):
                keys = aliases(row)
                trending.update(keys)
                for key in keys:
                    ranks[key] = min(position, ranks.get(key, position))
        if '_poster_tag_context' not in catalog:
            kind, label = catalogue_sash(catalog)
            if kind:
                priority = {'status': 0, 'editorial': 1, 'award': 2}[kind]
                for row in catalog.get('items', []):
                    for key in aliases(row):
                        if key not in contexts or priority < contexts[key][0]:
                            contexts[key] = (priority, kind, label)
    annotated = []
    for catalog in catalogs:
        items = []
        for row in catalog.get('items', []):
            fresh = dict(row)
            fresh.pop('_poster_trending', None)
            fresh.pop('_poster_rank', None)
            fresh.pop('_poster_context_kind', None)
            fresh.pop('_poster_context_label', None)
            fresh.pop('_poster_context_verified', None)
            fresh.pop('_poster_context_version', None)
            matches = aliases(row) & trending
            if matches:
                fresh['_poster_trending'] = True
                fresh['_poster_rank'] = min(ranks[key] for key in matches if key in ranks)
            explicit = [contexts[key] for key in aliases(row) if key in contexts]
            if explicit:
                _, fresh['_poster_context_kind'], fresh['_poster_context_label'] = min(explicit)
                fresh['_poster_context_verified'] = True
                fresh['_poster_context_version'] = CONTEXT_VERSION
            items.append(fresh)
        annotated.append(dict(catalog, items=items))
    return annotated


SETTINGS = (('Trending tags', 'ui_poster_trending_tags'),)


def properties(row, summary_reader=None, today=None, get_setting=None):
    values = {'poster_trend': '', 'poster_trending_label': '', 'poster_new_label': '',
              'poster_sash_rank': '', 'poster_sash_award': '', 'poster_sash_editorial': '',
              'poster_sash_status': '', 'poster_sash_trend': ''}
    if row.get('type') not in ('movie', 'series') or row.get('_catalogue'):
        return values
    try:
        host = (urlsplit(str(row.get('poster') or '')).hostname or '').lower()
    except ValueError:
        host = ''
    # These posters already have provider-controlled tags baked into their pixels.
    provider = re.sub(r'\W+', '', str(row.get('_poster_provider') or '')).casefold()
    if (host == 'btttr.cc' or host.endswith('.btttr.cc')) and 'aiometadata' not in provider:
        return values
    trending_enabled = not get_setting or get_setting('ui_poster_trending_tags') != 'false'
    labels = ['Trending'] if row.get('_poster_trending') and trending_enabled else []
    released = str(row.get('released') or '')
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}(?:T.*)?', released):
        try:
            age = ((today or date.today()) - date.fromisoformat(released[:10])).days
            if 0 <= age <= 30 and trending_enabled:
                labels.append('New')
        except ValueError:
            pass
    values['poster_trend'] = ' · '.join(labels)
    values['poster_trending_label'] = 'Trending' if 'Trending' in labels else ''
    values['poster_new_label'] = 'New' if 'New' in labels else ''
    if trending_enabled:
        try:
            rank = int(row.get('_poster_rank') or 0)
        except (TypeError, ValueError):
            rank = 0
        candidates = (
            ('poster_sash_rank', '#{}'.format(rank) if 0 < rank <= 999 else ''),
            ('poster_sash_status', status_label(row) or
             (row.get('_poster_context_label') if row.get('_poster_context_verified') is True and row.get('_poster_context_version') == CONTEXT_VERSION and row.get('_poster_context_kind') == 'status' else '')),
            ('poster_sash_editorial', editorial_label(row) or
             (row.get('_poster_context_label') if row.get('_poster_context_verified') is True and row.get('_poster_context_version') == CONTEXT_VERSION and row.get('_poster_context_kind') == 'editorial' else '')),
            ('poster_sash_trend', 'Trending' if row.get('_poster_trending') else
             'New' if 'New' in labels else ''),
            ('poster_sash_award', award_label(row.get('awards')) or
             (row.get('_poster_context_label') if row.get('_poster_context_verified') is True and row.get('_poster_context_version') == CONTEXT_VERSION and row.get('_poster_context_kind') == 'award' else '')),
        )
        for field, label in candidates:
            if label:
                # Cached catalogue context may predate the title-case labels.
                values[field] = str(label).title()
                break
    return values


def append(layout):
    """Top-aligned facts, clear of the watched mark and progress bar."""
    import xml.etree.ElementTree as ET
    # One priority sash is visible at a time. Categories keep distinct colours
    # while sharing geometry, so combinations can never overlap.
    # Native fixed geometry is supported on older Android Kodi versions. Each
    # category fits its longest supported label with 4px padding per side; do
    # not allocate dozens of conditional controls for every poster.
    for field, colour, width in (
            ('poster_sash_award', 'E6C78A22', 140),
            ('poster_sash_rank', 'E6D84B78', 58),
            ('poster_sash_editorial', 'E6298D8F', 192),
            ('poster_sash_status', 'E63F6FBF', 126),
            ('poster_sash_trend', 'E65E3FBF', 88)):
        visible = '!String.IsEmpty(ListItem.Property(%s))' % field
        background = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=12 + (206 - width) // 2, top=12, width=width, height=28,
                               texture='special://home/addons/script.strem4kodi/resources/skins/Main/media/browse-local/tag-rounded.png',
                               colordiffuse=colour, visible=visible).items():
            ET.SubElement(background, key).text = str(value)
        background.find('texture').set('border', '8,8,8,8')
        label = ET.SubElement(layout, 'control', type='label')
        for key, value in dict(left=16 + (206 - width) // 2, top=12, width=width - 8, height=28,
                               label='$INFO[ListItem.Property(%s)]' % field,
                               font='font_flag', textcolor='FFFFFFFF',
                               align='center', aligny='center', visible=visible).items():
            ET.SubElement(label, key).text = str(value)
