"""Native poster facts from loaded catalogues and local source observations only."""
from datetime import date
import re
from urllib.parse import urlsplit

from lib.catalogue_identity import aliases


NOTABLE_DIRECTORS = {
    'steven spielberg': 'SPIELBERG MOVIE',
    'christopher nolan': 'NOLAN MOVIE',
    'martin scorsese': 'SCORSESE MOVIE',
    'quentin tarantino': 'TARANTINO MOVIE',
    'james cameron': 'CAMERON MOVIE',
    'ridley scott': 'RIDLEY SCOTT MOVIE',
    'david fincher': 'FINCHER MOVIE',
    'denis villeneuve': 'VILLENEUVE MOVIE',
    'greta gerwig': 'GERWIG MOVIE',
    'wes anderson': 'WES ANDERSON MOVIE',
    'jordan peele': 'JORDAN PEELE MOVIE',
    'sofia coppola': 'COPPOLA MOVIE',
}


def _words(value):
    """Flatten provider metadata for conservative, explicit label matching."""
    if isinstance(value, dict):
        return ' '.join(str(part) for key, item in value.items()
                        for part in (key, _words(item)) if part not in ('', None))
    if isinstance(value, (list, tuple, set)):
        return ' '.join(_words(item) for item in value)
    return str(value or '')


def award_label(value):
    text = re.sub(r'\s+', ' ', _words(value)).strip().casefold()
    if not text:
        return ''
    # A nomination alone is never promoted to a winner sash.
    won = r'(?:\bwon\b|\bwinner\b|\bwins?\b)'
    for label, prize in (
            ('OSCAR WINNER', r'(?:oscars?|academy awards?)'),
            ('EMMY WINNER', r'(?:primetime )?emmys?'),
            ('GLOBE WINNER', r'(?:golden globes?|globes?)'),
            ('CANNES WINNER', r'(?:cannes|palme d.?or)')):
        if re.search(won + r'.{0,45}' + prize + '|' + prize + r'.{0,45}' + won, text):
            return label
    return ''


def editorial_label(row):
    if row.get('type') != 'movie':
        return ''
    names = list(row.get('director') or []) if isinstance(row.get('director'), list) else []
    for person in row.get('directorPeople') or []:
        if isinstance(person, dict) and person.get('name'):
            names.append(person['name'])
    for name in names:
        label = NOTABLE_DIRECTORS.get(str(name).strip().casefold())
        if label:
            return label
    return ''


def status_label(row):
    if row.get('type') != 'series':
        return ''
    status = re.sub(r'[^a-z]+', ' ', str(row.get('status') or '').casefold()).strip()
    if re.search(r'\bnew season\b', status) or row.get('newSeason') is True:
        return 'NEW SEASON'
    if status in ('returning', 'returning series'):
        return 'RETURNING'
    if status in ('airing', 'currently airing'):
        return 'AIRING'
    if status == 'in production':
        return 'IN PRODUCTION'
    if status == 'ended':
        return 'ENDED'
    if status in ('canceled', 'cancelled'):
        return 'CANCELLED'
    return ''


def trending_catalog(catalog):
    """Recognize chart metadata, including provider IDs such as tmdb_trending."""
    if catalog.get('_genre') or catalog.get('_genre_label'):
        return False
    for field in ('label', 'name', 'catalog_id', 'id', '_id', 'category'):
        text = re.sub(r'[^a-z0-9]+', ' ', str(catalog.get(field) or '').lower())
        if re.search(r'\btrending\b', text):
            return True
    return False


def catalogue_sash(catalog):
    """Return a verified sash carried by an explicitly named curated list."""
    if catalog.get('_genre') or catalog.get('_genre_label'):
        return ('', '')
    text = re.sub(r'[^a-z0-9]+', ' ', ' '.join(str(catalog.get(field) or '')
                  for field in ('label', 'name', 'catalog_id', 'id', '_id', 'category')).casefold()).strip()
    if not text:
        return ('', '')
    if re.search(r'\bwinners?\b', text):
        for label, pattern in (
                ('OSCAR WINNER', r'\b(?:oscar|academy award)s?\b'),
                ('EMMY WINNER', r'\b(?:primetime )?emmys?\b'),
                ('GLOBE WINNER', r'\b(?:golden )?globes?\b'),
                ('CANNES WINNER', r'\b(?:cannes|palme d or)\b')):
            if re.search(pattern, text):
                return ('award', label)
    for name, label in NOTABLE_DIRECTORS.items():
        if re.search(r'\b' + re.escape(name) + r'\b', text):
            return ('editorial', label)
    for label, pattern in (
            ('NEW SEASON', r'\bnew seasons?\b'),
            ('RETURNING', r'\breturning(?: series| shows?)?\b'),
            ('AIRING', r'\b(?:currently )?airing\b'),
            ('IN PRODUCTION', r'\bin production\b')):
        if re.search(pattern, text):
            return ('status', label)
    return ('', '')


def context_catalog(catalog):
    return trending_catalog(catalog) or bool(catalogue_sash(catalog)[0])


def annotate(catalogs, context=()):
    """Recompute membership; retained row flags must not manufacture a chart."""
    catalogs = list(catalogs)
    try:
        context = list(context)
    except TypeError:
        context = []
    trending = set()
    ranks = {}
    contexts = {}
    sources = catalogs + context
    # Overview grids retain their actual source charts after flattening rows.
    sources += [source for catalog in list(sources)
                for source in catalog.get('_poster_tag_context', [])]
    for catalog in sources:
        if '_poster_tag_context' not in catalog and trending_catalog(catalog):
            for position, row in enumerate(catalog.get('items', []), 1):
                keys = aliases(row)
                trending.update(keys)
                for key in keys:
                    ranks[key] = min(position, ranks.get(key, position))
        if '_poster_tag_context' not in catalog:
            kind, label = catalogue_sash(catalog)
            if kind:
                priority = {'award': 0, 'editorial': 2, 'status': 3}[kind]
                for row in catalog.get('items', []):
                    for key in aliases(row):
                        if key not in contexts or priority < contexts[key][0]:
                            contexts[key] = (priority, kind, label)
    annotated = []
    for catalog in catalogs:
        items = []
        for row in catalog.get('items', []):
            fresh = dict(row)
            fresh.pop('_poster_trending', None)
            fresh.pop('_poster_rank', None)
            fresh.pop('_poster_context_kind', None)
            fresh.pop('_poster_context_label', None)
            matches = aliases(row) & trending
            if matches:
                fresh['_poster_trending'] = True
                fresh['_poster_rank'] = min(ranks[key] for key in matches if key in ranks)
            explicit = [contexts[key] for key in aliases(row) if key in contexts]
            if explicit:
                _, fresh['_poster_context_kind'], fresh['_poster_context_label'] = min(explicit)
            items.append(fresh)
        annotated.append(dict(catalog, items=items))
    return annotated


SETTINGS = (('Trending tags', 'ui_poster_trending_tags'),
            ('Quality tags', 'ui_poster_quality_tags'))


def properties(row, summary_reader=None, today=None, get_setting=None):
    values = {'poster_trend': '', 'poster_trending_label': '', 'poster_new_label': '',
              'poster_sash_rank': '', 'poster_sash_award': '', 'poster_sash_editorial': '',
              'poster_sash_status': '', 'poster_sash_trend': '', 'poster_quality': ''}
    values.update({'poster_quality_' + str(i): '' for i in range(3)})
    if row.get('type') not in ('movie', 'series') or row.get('_catalogue'):
        return values
    try:
        host = (urlsplit(str(row.get('poster') or '')).hostname or '').lower()
    except ValueError:
        host = ''
    # These posters already have provider-controlled tags baked into their pixels.
    if host == 'btttr.cc' or host.endswith('.btttr.cc'):
        return values
    trending_enabled = not get_setting or get_setting('ui_poster_trending_tags') != 'false'
    quality_enabled = not get_setting or get_setting('ui_poster_quality_tags') != 'false'
    labels = ['Trending'] if row.get('_poster_trending') and trending_enabled else []
    released = str(row.get('released') or '')
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}(?:T.*)?', released):
        try:
            age = ((today or date.today()) - date.fromisoformat(released[:10])).days
            if 0 <= age <= 30 and trending_enabled:
                labels.append('New')
        except ValueError:
            pass
    values['poster_trend'] = ' · '.join(labels)
    values['poster_trending_label'] = 'Trending' if 'Trending' in labels else ''
    values['poster_new_label'] = 'New' if 'New' in labels else ''
    if trending_enabled:
        try:
            rank = int(row.get('_poster_rank') or 0)
        except (TypeError, ValueError):
            rank = 0
        candidates = (
            ('poster_sash_award', award_label(row.get('awards')) or
             (row.get('_poster_context_label') if row.get('_poster_context_kind') == 'award' else '')),
            ('poster_sash_rank', '#{}'.format(rank) if 0 < rank <= 999 else ''),
            ('poster_sash_editorial', editorial_label(row) or
             (row.get('_poster_context_label') if row.get('_poster_context_kind') == 'editorial' else '')),
            ('poster_sash_status', status_label(row) or
             (row.get('_poster_context_label') if row.get('_poster_context_kind') == 'status' else '')),
            ('poster_sash_trend', 'TRENDING' if row.get('_poster_trending') else
             'NEW' if 'New' in labels else ''),
        )
        for field, label in candidates:
            if label:
                values[field] = label
                break
    from lib.available_formats import catalogue_formats
    found = catalogue_formats(row)
    if summary_reader:
        try:
            summary = summary_reader(row)
            # Local availability summaries are source observations. Shared disc
            # hints are intentionally excluded: they do not prove a usable source.
            if isinstance(summary, dict) and summary.get('origin', 'sources') == 'sources':
                found = list(summary.get('formats') or []) or found
        except Exception:
            pass
    values['poster_quality'] = ' · '.join(tag for tag in ('4K', 'Dolby Vision', 'Atmos') if tag in found and quality_enabled)
    for index, tag in enumerate(('4K', 'Dolby Vision', 'Atmos')):
        values['poster_quality_' + str(index)] = tag if tag in found and quality_enabled else ''
    return values


def append(layout):
    """Compact corner badges, clear of the watched mark and progress bar."""
    import xml.etree.ElementTree as ET
    # One priority sash is visible at a time. Categories keep distinct colours
    # while sharing geometry, so combinations can never overlap.
    for field, colour in (
            ('poster_sash_award', 'E6C78A22'),
            ('poster_sash_rank', 'E6D84B78'),
            ('poster_sash_editorial', 'E6298D8F'),
            ('poster_sash_status', 'E63F6FBF'),
            ('poster_sash_trend', 'E65E3FBF')):
        visible = '!String.IsEmpty(ListItem.Property(%s))' % field
        background = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=19, top=20, width=126, height=22,
                               texture='special://home/addons/script.strem4kodi/resources/branding/white.png',
                               colordiffuse=colour, visible=visible).items():
            ET.SubElement(background, key).text = str(value)
        label = ET.SubElement(layout, 'control', type='label')
        for key, value in dict(left=23, top=20, width=118, height=22,
                               label='$INFO[ListItem.Property(%s)]' % field,
                               font='font_flag', textcolor='FFFFFFFF',
                               align='center', aligny='center', visible=visible).items():
            ET.SubElement(label, key).text = str(value)
    from lib.available_formats import ASSETS
    # A bottom-right vertical stack keeps the central artwork readable.
    for index, (tag, width) in enumerate((('4K', 27), ('Dolby Vision', 61), ('Atmos', 43))):
        left, top = 211-width, 283-index*23
        visible = '!String.IsEmpty(ListItem.Property(poster_quality_%d))' % index
        image = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=left, top=top, width=width, height=20,
                               texture='special://home/addons/script.strem4kodi/resources/branding/white.png',
                               colordiffuse='DD15171C', visible=visible).items():
            ET.SubElement(image, key).text = str(value)
        image = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=left+3, top=top+3, width=width-6, height=14,
                               # Poster badges use the higher-resolution player
                               # masters. The hero copies are tuned for much
                               # larger controls and become visibly soft here.
                               texture='special://home/addons/script.strem4kodi/resources/skins/Main/media/formats/display/player/'+ASSETS[tag]+'.png',
                               aspectratio='keep', visible=visible).items():
            ET.SubElement(image, key).text = str(value)
