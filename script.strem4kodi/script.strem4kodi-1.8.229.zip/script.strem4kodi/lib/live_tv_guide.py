"""Remote-operated Live TV timeline. Only the owner loop paints native controls."""
import queue
import threading
import time

import xbmcgui

from lib import live_tv_epg as epg
from lib.live_tv_provider import CHANNELS
from lib.sports_epg import local_time
from lib.theme import window as themed_window

WHITE = 'special://home/addons/script.strem4kodi/resources/branding/white.png'
TRANSPARENT = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/progress-local/transparent.png'
ROWS = 7


class LiveGuide(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.events = queue.Queue()
        self.closed = False
        self.ready = False
        self.row = 0
        self.cursor = time.time()
        self.start = int(self.cursor // epg.STEP) * epg.STEP
        self.minimum = self.start
        self.maximum = self.start + 24 * 3600
        self.data = {}
        self.status = 'Loading programme schedules…'
        self.dynamic = []
        self.buttons = []
        self.dirty = True
        self.minute = -1
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.buttons = [xbmcgui.ControlButton(50, 230 + i * 76, 1810, 66, '',
            focusTexture=TRANSPARENT, noFocusTexture=TRANSPARENT, focusedColor='00FFFFFF',
            textColor='00FFFFFF') for i in range(ROWS)]
        self.addControls(self.buttons)
        for button in self.buttons:
            button.setNavigation(button, button, button, button)
        self.setFocus(self.buttons[0])
        self.ready = True

    def onAction(self, action):
        identity = action.getId()
        if identity in (9, 10, 92):
            self.events.put(('close', None))
        elif identity in (1, 2, 3, 4, 5, 6):
            self.events.put(('move', identity))
        elif identity == 117:
            self.events.put(('setup', None))

    def onClick(self, control):
        if control == 101:
            self.events.put(('now', None))
        elif control == 102:
            self.events.put(('setup', None))
        elif control == 103:
            self.events.put(('close', None))
        else:
            for offset, button in enumerate(self.buttons):
                if button.getId() == control:
                    self.events.put(('play', self.row // ROWS * ROWS + offset))

    def selected(self):
        channel = CHANNELS[self.row][0]
        return next(p for p in epg.cells(self.data.get(channel, []), self.start)
                    if p['start'] <= self.cursor < p['end'])

    def move(self, direction):
        focus = self.getFocusId()
        if focus in (101, 102, 103):
            if direction == 4:
                self.setFocus(self.buttons[self.row % ROWS])
            # Toolbar left/right is handled by the XML's native navigation.
            return
        if direction == 3 and self.row == 0:
            self.setFocusId(101)
            return
        if direction in (3, 4, 5, 6):
            self.row = max(0, min(len(CHANNELS) - 1, self.row + {3: -1, 4: 1, 5: -ROWS, 6: ROWS}[direction]))
        else:
            item = self.selected()
            self.cursor = item['end'] if direction == 2 else item['start'] - 1
            self.cursor = max(self.minimum, min(self.maximum + epg.SPAN - 1, self.cursor))
            if self.cursor < self.start:
                self.start = max(self.minimum, self.start - epg.SPAN)
            elif self.cursor >= self.start + epg.SPAN:
                self.start = min(self.maximum, self.start + epg.SPAN)
        self.dirty = True

    def render(self):
        if self.dynamic:
            self.removeControls(self.dynamic)
        self.dynamic = []

        def label(x, y, width, height, text, color='FFE5E5E7', font='Strem4Kodi21'):
            self.dynamic.append(xbmcgui.ControlLabel(x, y, width, height, text, font=font, textColor=color))

        def block(x, y, width, height, color):
            self.dynamic.append(xbmcgui.ControlImage(int(x), y, max(1, int(width)), height, WHITE, colorDiffuse=color))

        now = time.time()
        self.setProperty('live_date', local_time(self.start, date=True))
        self.setProperty('live_status', self.status)
        page = self.row // ROWS * ROWS
        for tick in range(6):
            label(360 + tick * 250, 186, 240, 32, local_time(self.start + tick * epg.STEP))
        for offset, button in enumerate(self.buttons):
            index = page + offset
            button.setVisible(index < len(CHANNELS))
            if index >= len(CHANNELS):
                continue
            channel, name = CHANNELS[index]
            y = 230 + offset * 76
            block(50, y, 304, 66, 'FF30343E' if index == self.row else 'FF191C24')
            label(64, y + 16, 280, 40, name)
            for programme in epg.cells(self.data.get(channel, []), self.start):
                x = 360 + (programme['start'] - self.start) / epg.SPAN * 1500
                width = (programme['end'] - programme['start']) / epg.SPAN * 1500
                selected = index == self.row and programme['start'] <= self.cursor < programme['end']
                block(x, y, width - 3, 66, 'FFE5E5E7' if selected else 'FF30343E')
                if width > 35:
                    label(int(x) + 9, y + 16, int(width) - 20, 40, programme['title'],
                          'FF15161D' if selected else 'FFE5E5E7')
        if self.start <= now < self.start + epg.SPAN:
            block(360 + (now - self.start) / epg.SPAN * 1500, 222, 3, 540, 'FF47D7AC')
        item = self.selected()
        label(50, 790, 1810, 42, CHANNELS[self.row][1] + ' · ' + item['title'], font='Strem4Kodi24Bold')
        times = '' if item.get('gap') else local_time(item['original_start']) + '–' + local_time(item['original_end']) + ' · '
        label(50, 838, 1810, 32, times + 'OK: watch channel live · Left/right: programmes · Up/down: channels')
        box = xbmcgui.ControlTextBox(50, 882, 1810, 96, font='Strem4Kodi21', textColor='FFADACB5')
        self.dynamic.append(box)
        self.addControls(self.dynamic)
        box.setText(item['description'] or 'Programme information unavailable. You can still watch this channel live.')
        if self.getFocusId() not in (101, 102, 103):
            self.setFocus(self.buttons[self.row % ROWS])
        self.minute = int(now // 60)
        self.dirty = False


def show(kodi, gui, addon_module):
    from lib.live_tv_playback import setup
    from lib.ui_dialogs import dialog
    path = addon_module.Addon('script.strem4kodi').getAddonInfo('path')
    guide = themed_window(LiveGuide, 'script-stremio-live-guide.xml', path, 'Main', '1080i')
    cancelled = threading.Event()
    results = queue.Queue()

    def load():
        try:
            results.put(epg.load(cancelled=cancelled.is_set))
        except Exception:
            results.put({})

    worker = threading.Thread(target=load, name='s4k-live-guide', daemon=True)
    monitor = kodi.Monitor()
    refresh_at = time.monotonic() + 900
    play_channel = None
    try:
        guide.show()
        worker.start()
        while not guide.closed and not monitor.waitForAbort(0.1):
            if not guide.ready:
                continue
            try:
                result = results.get_nowait()
                guide.data = result or {}
                count = sum(bool(v) for v in guide.data.values())
                guide.status = '{} of {} schedules · UK time · London/national listings'.format(count, len(CHANNELS))
                guide.dirty = True
            except queue.Empty:
                pass
            if time.monotonic() >= refresh_at and not worker.is_alive():
                worker = threading.Thread(target=load, name='s4k-live-guide', daemon=True)
                worker.start()
                refresh_at = time.monotonic() + 900
            while not guide.events.empty() and not guide.closed:
                action, value = guide.events.get_nowait()
                if action == 'close':
                    guide.closed = True
                elif action == 'move':
                    guide.move(value)
                elif action == 'now':
                    guide.cursor = time.time()
                    guide.start = guide.minimum = int(guide.cursor // epg.STEP) * epg.STEP
                    guide.maximum = guide.start + 86400
                    guide.dirty = True
                    guide.setFocus(guide.buttons[guide.row % ROWS])
                elif action == 'setup':
                    setup(gui, addon_module)
                elif action == 'play' and 0 <= value < len(CHANNELS):
                    guide.row = value
                    guide.dirty = True
                    item = guide.selected()
                    now = time.time()
                    current = item.get('gap') or item['original_start'] <= now < item['original_end']
                    if current or dialog().yesno('Watch live', 'This programme is not currently on air. Watch {} live instead?'.format(CHANNELS[value][1])):
                        play_channel = CHANNELS[value][0]
                        guide.closed = True
            if not guide.closed and (guide.dirty or guide.minute != int(time.time() // 60)):
                guide.render()
    finally:
        cancelled.set()
        guide.closed = True
        guide.close()
    if play_channel is not None and not monitor.abortRequested():
        kodi.executebuiltin('PlayMedia(plugin://script.strem4kodi/?action=play_live&channel=' + play_channel + ')')
