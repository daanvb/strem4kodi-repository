"""User-requested, bounded HLS inspection. Never fetch video segments."""
import re
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

LIMIT=65536

def inspect(row, opener=urlopen):
    url=str(row.get('url') or '')
    try:parsed=urlsplit(url)
    except ValueError:return {}, 'Invalid source address.'
    if parsed.scheme not in ('http','https') or not parsed.path.lower().endswith('.m3u8'):
        return {}, 'Inspection supports HLS manifests. File streams use provider-reported details.'
    try:
        response=opener(Request(url,headers={'Range':'bytes=0-65535'}),timeout=5)
        try:data=response.read(LIMIT+1)
        finally:response.close()
        if len(data)>LIMIT:return {}, 'Manifest too large to inspect.'
        text=data.decode('utf-8-sig')
        if not text.lstrip().startswith('#EXTM3U'):return {}, 'This source did not return an HLS manifest.'
        variants=[]
        for line in text.splitlines():
            if not line.startswith('#EXT-X-STREAM-INF:'):continue
            fields=dict(re.findall(r'([A-Z-]+)=("[^"]*"|[^,]*)',line))
            fields={k:v.strip('"') for k,v in fields.items()}
            dimensions=fields.get('RESOLUTION','').split('x')
            height=int(dimensions[1]) if len(dimensions)==2 and dimensions[1].isdigit() else 0
            variants.append((height,fields))
        if not variants:return {}, 'No audio/video details in this manifest. Provider details are kept.'
        height,fields=max(variants,key=lambda item:item[0])
        codecs=fields.get('CODECS','').lower()
        video='H.265' if any(v in codecs for v in ('hvc1','hev1','dvh1','dvhe')) else 'H.264' if 'avc1' in codecs else 'AV1' if 'av01' in codecs else ''
        audio='Dolby Digital Plus' if 'ec-3' in codecs else 'Dolby Digital' if 'ac-3' in codecs else 'AAC' if 'mp4a' in codecs else ''
        result={k:v for k,v in {'height':height,'resolution':fields.get('RESOLUTION'),'videoCodec':video,'audioCodec':audio,'hdr':'Dolby Vision' if 'dvhe' in codecs or 'dvh1' in codecs else '', 'frameRate':fields.get('FRAME-RATE'),'bitrate':fields.get('AVERAGE-BANDWIDTH') or fields.get('BANDWIDTH')}.items() if v}
        return result, 'Highest advertised HLS variant inspected; playback can use a different variant.'
    except Exception:return {}, 'Could not inspect this source. Provider details are kept.'
