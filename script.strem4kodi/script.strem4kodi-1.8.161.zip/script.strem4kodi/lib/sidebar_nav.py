"""Single source of truth for sidebar order, icons and existing actions."""
from account import AccountError
MEDIA = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/navigation-local/'
ICONS = MEDIA.replace('navigation-local/', 'icons-refined/navigation-v2/')
# Remix Icon outlines are rendered by Kodi's font engine at display size.
GLYPHS = {'profile-avatar': 0xf256, 'search': 0xf0d1, 'home': 0xee2b,
          'discover-v2': 0xebbe, 'sports': 0xed8f, 'favourite': 0xee0f,
          'watch-later': 0xeae5, 'settings': 0xf0e6, 'exit': 0xf126}
SIDEBAR_FOCUS = '[Control.HasFocus(9000) | Control.HasFocus(209) | Control.HasFocus(210)]'
ENTRIES = (
    ('Profile', 210, 'profile-avatar'),
    ('Search', 201, 'search'),
    ('Home', 202, 'home'),
    ('Discover', 203, 'discover-v2'),
    ('Sports', 207, 'sports'),
    ('Favourites', 208, 'favourite'),
    ('Watch Later', 204, 'watch-later'),
    ('Settings', 206, 'settings'),
)


def profile_name(profile_root=None):
    name='Profile'
    try:
        from lib.viewer_profiles import state
        if profile_root is None:
            import xbmcvfs
            from addon_state import get_addon
            profile_root=xbmcvfs.translatePath(get_addon().getAddonInfo('profile'))
        data=state(profile_root)
        name=data.get('records',{}).get(data.get('active'),{}).get('name','Profile')
    except (ImportError,OSError,RuntimeError,TypeError,ValueError,AccountError):
        pass
    return name


def menu_items(gui, profile_root=None):
    name = profile_name(profile_root)
    rows = []
    for label, action, icon in ENTRIES:
        item = gui.ListItem(name if action==210 else label)
        item.setArt({'icon': ICONS + icon + '.png'})
        item.setProperty('sidebar_glyph', chr(GLYPHS[icon]))
        item.setProperty('sidebar_action', str(action))
        if action == 210:
            item.setProperty('sidebar_separator_after', 'true')
        rows.append(item)
    return rows


def primary_menu_items(gui, profile_root=None):
    """The Home drawer keeps the active viewer as a separate header control."""
    return menu_items(gui, profile_root)[1:]


def menu_action(index):
    return ENTRIES[index][1] if type(index) is int and 0 <= index < len(ENTRIES) else 202


def primary_menu_action(index):
    """Map Home drawer rows after the standalone profile header."""
    return menu_action(index + 1) if type(index) is int and not isinstance(index, bool) and index >= 0 else 202


def home_index():
    return next(i - 1 for i, entry in enumerate(ENTRIES) if entry[1] == 202)


def footer_control():
    """Bottom-anchored exit, outside the centred navigation list."""
    import xml.etree.ElementTree as ET
    group = ET.Element('control', type='group')
    for tag, value in dict(left='12', bottom='192', width='276', height='64').items():
        ET.SubElement(group, tag).text = value
    separator = ET.SubElement(group, 'control', type='image')
    for tag, value in dict(left='16', top='0', width='244', height='1', texture=MEDIA.replace('navigation-local/', 'colors/white.png')).items():
        ET.SubElement(separator, tag).text = value
    separator.find('texture').set('colordiffuse', 'FF343434')
    button = ET.SubElement(group, 'control', type='button', id='209')
    for tag, value in dict(left='0', top='6', width='276', height='52', label='Exit app',
                           font='font27', textcolor='FFAAAAAA', focusedcolor='FF0F1017',
                           align='left', aligny='center', textoffsetx='64',
                           texturefocus=MEDIA.replace('navigation-local/', 'controls/local-pill-h54-v1.png'), texturenofocus='', onup='9000', ondown='9000',
                           onleft='209', onright='400').items():
        ET.SubElement(button, tag).text = value
    button.find('texturefocus').set('border','27,0,27,0')
    button.find('texturefocus').set('colordiffuse','E6FFFFFF')
    button.find('texturefocus').set('theme-colour','fixed')
    marker = ET.SubElement(group, 'control', type='image')
    for tag, value in dict(left='2', top='25', width='4', height='34', visible='false',
                           texture=MEDIA.replace('navigation-local/', 'colors/white.png')).items():
        ET.SubElement(marker, tag).text = value
    marker.find('texture').set('colordiffuse','FF0F1017')
    for focused in (False, True):
        icon = ET.SubElement(group, 'control', type='image')
        for tag, value in dict(left='14', top='14', width='36', height='36',
                               visible=('' if focused else '!') + 'Control.HasFocus(209)',
                               texture=MEDIA + 'icon-disc.png').items():
            ET.SubElement(icon, tag).text = value
        icon.find('texture').set('colordiffuse','FFF5F4F6' if focused else 'FF5B6068')
        icon = ET.SubElement(group, 'control', type='image')
        for tag, value in dict(left='18', top='18', width='28', height='28', aspectratio='keep',
                               visible=('' if focused else '!') + 'Control.HasFocus(209)',
                               texture=ICONS + 'exit.png').items():
            ET.SubElement(icon, tag).text = value
        icon.find('texture').set('colordiffuse', 'FF0F1017' if focused else 'FFE5E5E7')
    return group
