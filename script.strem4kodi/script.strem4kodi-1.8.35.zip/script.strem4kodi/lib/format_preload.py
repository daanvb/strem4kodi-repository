"""Debounced, single-flight availability checks for the focused browsing title."""
import threading
from weakref import WeakValueDictionary

_SOURCE_LOCKS = WeakValueDictionary()
_LOCK_GUARD = threading.Lock()


def source_lock(kind, target):
    with _LOCK_GUARD:
        key = (kind, target)
        lock = _SOURCE_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _SOURCE_LOCKS[key] = lock
        return lock


def background_allowed(player, trailer_flag='', preview_url=None):
    """An owned hero preview must not be mistaken for full playback."""
    if not player.isPlayingVideo() or trailer_flag:
        return True
    try:
        return bool(preview_url and player.getPlayingFile() == preview_url)
    except RuntimeError:
        return False


def lookup(meta, api, current=lambda: True):
    if not current():
        return None
    meta = dict(meta)
    if meta.get('type') not in ('movie', 'series') or meta.get('_catalogue'):
        return None
    original = dict(meta)
    summary = api.availability_summary(meta)
    if isinstance(summary, dict) and summary.get('target') and not summary.get('stale'):
        meta['_focus_video_id'] = summary['target']
        return meta
    target = meta.get('id') if meta['type'] == 'movie' else meta.get('_focus_video_id')
    if not target:
        saved = api.saved(meta)
        if not meta.get('videos'):
            meta.update(api.metadata(meta))
        video, _ = api.next_series_episode(meta.get('videos', []), meta['id'], saved)
        if video:
            target = video['id']
    if not target or (meta['type'] == 'series' and target == meta['id']):
        return None
    if not current():
        return None
    # Page warming and focused lookups share source requests, then recheck the
    # cache after waiting. Do not fan out twice for the same movie/episode.
    with source_lock(meta['type'], target):
        if not current():
            return None
        cached = api.stream_cache_state(meta, target)
        if not cached or cached[4]:
            if isinstance(summary, dict) and summary.get('scope'):
                meta['_availability_scope'] = summary['scope']
            result = api.source_rows(meta, target)
            rows = result[0] if isinstance(result, tuple) else []
        else:
            rows = cached[0]
        api.remember_availability(original, target, rows,
            summary.get('scope') if isinstance(summary, dict) else None)
    meta['_focus_video_id'] = target
    return meta


def page_candidates(rows):
    """Interleave loaded rows so a long first row cannot starve later rows."""
    groups = list(rows.values())
    seen, result = set(), []
    for index in range(max((len(group) for group in groups), default=0)):
        for group in groups:
            if index >= len(group):
                continue
            row = group[index]
            context = (row.get('type'), row.get('id'), row.get('_focus_video_id'))
            if context in seen or row.get('type') not in ('movie', 'series') or row.get('_catalogue'):
                continue
            seen.add(context)
            result.append((context, dict(row)))
    return result


class Preloader:
    def __init__(self, delay=0.15):
        self.delay = delay
        self.lock = threading.Lock()
        self.timer = None
        self.pending = None
        self.loading = False
        self.closed = False
        self.revision = 0

    def request(self, work):
        with self.lock:
            if self.closed:
                return
            self.pending = work
            self.revision += 1
            if self.timer:
                self.timer.cancel()
            if not self.loading:
                self._schedule()

    def _schedule(self):
        self.timer = threading.Timer(self.delay, self._run, args=(self.revision,))
        self.timer.daemon = True
        self.timer.start()

    def _run(self, revision):
        with self.lock:
            if self.closed or self.loading or not self.pending or revision != self.revision:
                return
            work, self.pending = self.pending, None
            self.loading = True
        try:
            work()
        except Exception:
            pass  # Optional artwork metadata must never interrupt browsing.
        finally:
            with self.lock:
                self.loading = False
                if self.pending and not self.closed:
                    self._schedule()

    def close(self):
        with self.lock:
            self.closed = True
            self.pending = None
            if self.timer:
                self.timer.cancel()
