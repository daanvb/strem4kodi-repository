"""Remote-friendly channel/event guide over the already-loaded sports catalogue."""
import time
import xbmcgui

from lib import sports_epg as epg
from lib.theme import PALETTES, index, window as themed_window
from addon_state import get_addon

WHITE = 'special://home/addons/script.strem4kodi/resources/branding/white.png'
TRANSPARENT = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/progress-local/transparent.png'


class SportsGuide(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        rows = kwargs.pop('rows')
        self.entries = epg.entries(rows)
        self.more_row = next((row for row in rows if isinstance(row, dict) and row.get('_discover_load_more')), None)
        self.heading = epg.plain(kwargs.pop('heading'))
        self.selected = min(max(0, kwargs.pop('position', 0)), max(0, len(self.entries) - 1))
        self.start = epg.window_start(time.time())
        self.result = None
        self.dynamic = []
        self.cells = {}
        self.palette = PALETTES[index(get_addon())]
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('guide_heading', 'Sports guide · ' + self.heading)
        self.setProperty('guide_more', 'true' if self.more_row is not None else '')
        self.render()

    def label(self, x, y, width, height, text, color='FFE5E5E7', font='Strem4Kodi21'):
        control = xbmcgui.ControlLabel(x, y, width, height, text, font=font, textColor=color)
        self.dynamic.append(control)
        return control

    def render(self, toolbar=None):
        # Move focus onto a permanent control before removing the previous page.
        self.setFocusId(101)
        if self.dynamic:
            self.removeControls(self.dynamic)
        self.dynamic = []
        self.cells = {}
        now = time.time()
        self.setProperty('guide_date', epg.local_time(self.start, date=True))
        page = self.selected // epg.PAGE_ROWS * epg.PAGE_ROWS
        self.setProperty('guide_count', '{}–{} of {} loaded listings · Times shown in device timezone'.format(
            page + 1 if self.entries else 0, min(page + epg.PAGE_ROWS, len(self.entries)), len(self.entries)))
        for tick in range(7):
            x = 360 + tick * 250
            # Last tick is right-aligned inside the screen boundary.
            self.label(min(x, 1760), 204, 100, 36, epg.local_time(self.start + tick * epg.STEP))
        for offset, value in enumerate(self.entries[page:page + epg.PAGE_ROWS]):
            position = page + offset
            y = 250 + offset * 82
            self.label(50, y + 4, 285, 35, value['title'])
            self.label(50, y + 40, 285, 28, epg.status(value, now),
                       'FF83CEA1' if epg.status(value, now) == 'Live' else 'FFADACB5')
            geometry = epg.block(value, self.start)
            if geometry is None:
                x, width = 0, 1500
                text = 'Outside this time window · ' + epg.caption(value, now)
            else:
                x, width = geometry
                text = epg.caption(value, now)
            # Very short programmes retain their true geometry. A separate
            # row-sized focus target preserves remote/mouse selection.
            background = xbmcgui.ControlImage(360 + int(x), y, max(1, int(width)), 70,
                                               WHITE, colorDiffuse=self.palette[2])
            self.dynamic.append(background)
            button = xbmcgui.ControlButton(360, y, 1500, 70, text,
                focusTexture=WHITE, noFocusTexture=TRANSPARENT, textOffsetX=18,
                font='Strem4Kodi21', textColor='FFE5E5E7', focusedColor=self.palette[0])
            self.dynamic.append(button)
            self.cells[position] = button
        if self.start <= now < self.start + epg.SPAN:
            x = 360 + int((now - self.start) / epg.SPAN * 1500)
            self.dynamic.append(xbmcgui.ControlImage(x, 240, 3, 590, WHITE, colorDiffuse=self.palette[6]))
        if not self.entries:
            self.label(360, 300, 1450, 60, 'No loaded sports listings. Choose a sports list first.')
        self.addControls(self.dynamic)
        for button in self.cells.values():
            button.setNavigation(button, button, button, button)
        if toolbar is not None:
            self.setFocusId(toolbar)
        elif self.selected in self.cells:
            self.setFocus(self.cells[self.selected])
        self.update_details()

    def update_details(self):
        if not self.entries:
            self.setProperty('guide_title', '')
            self.setProperty('guide_description', '')
            return
        value = self.entries[self.selected]
        self.setProperty('guide_title', value['title'] + ' · ' + epg.caption(value, time.time()))
        self.setProperty('guide_description', value['description'] or 'No description supplied.')

    def onFocus(self, control):
        for position, button in self.cells.items():
            if button.getId() == control:
                self.selected = position
                self.update_details()
                break

    def onAction(self, action):
        aid = action.getId()
        if aid in (10, 92, 216, 247):
            self.close()
            return
        focus = self.getFocusId()
        if focus in (100, 101, 102, 103, 104):
            if aid == 4 and self.cells:
                self.setFocus(self.cells[self.selected])
            return
        if aid in (1, 2):
            self.start += -epg.STEP if aid == 1 else epg.STEP
            self.render()
        elif aid in (3, 4, 5, 6):
            delta = {3: -1, 4: 1, 5: -epg.PAGE_ROWS, 6: epg.PAGE_ROWS}[aid]
            target = self.selected + delta
            if target < 0:
                self.setFocusId(101)
                return
            self.selected = min(max(0, len(self.entries) - 1), target)
            if self.selected in self.cells:
                self.setFocus(self.cells[self.selected])
                self.update_details()
            else:
                self.render()

    def onClick(self, control):
        if control == 103:
            self.close()
        elif control == 104 and self.more_row is not None:
            self.result = self.more_row
            self.close()
        elif control in (100, 101, 102):
            self.start = epg.window_start(time.time()) if control == 101 else self.start + (-epg.SPAN if control == 100 else epg.SPAN)
            self.render(toolbar=control)
        else:
            for position, button in self.cells.items():
                if button.getId() == control:
                    self.result = self.entries[position]['row']
                    self.close()
                    break


def show(path, rows, heading, position=0):
    guide = themed_window(SportsGuide, 'script-stremio-sports-guide.xml', path, 'Main', '1080i',
                          rows=rows, heading=heading, position=position)
    try:
        guide.doModal()
        return guide.result
    finally:
        guide.close()
