"""Private repository sync of viewer roster and isolated watch/list state."""
import base64
from copy import deepcopy
import json
import gzip
import zlib
from pathlib import Path
import re
import threading
import time

from account import Store, storage_lock
from lib.credits_sync import request, SyncError, LIMIT
from lib import viewer_profiles as profiles

ROSTER = '/contents/viewers.json'
DATA_LIMIT=8*1024*1024


def clean_library(rows):
    """Share title IDs/state only; artwork is rehydrated through configured providers."""
    result = {}
    if not isinstance(rows, list):return []
    for row in rows:
        if not isinstance(row, dict) or row.get('type') not in ('movie', 'series'):continue
        if row.get('state') is not None and not isinstance(row['state'],dict):continue
        identity = row.get('_id')
        if not isinstance(identity, str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,200}',identity):continue
        item = dict(_id=identity, type=row['type'], removed=row.get('removed') is True, temp=row.get('temp') is True)
        for key,limit in (('name',200),('_mtime',64),('_ctime',64),('posterShape',20)):
            if isinstance(row.get(key), str):item[key]=row[key][:limit]
        state={}
        for key in ('timeWatched','timeOffset','overallTimeWatched','timesWatched','flaggedWatched','duration'):
            value=(row.get('state') or {}).get(key)
            if type(value) in (int,float) and 0 <= value <= 1e15:state[key]=value
        for key,limit in (('video_id',200),('lastWatched',64),('watched',100000)):
            value=(row.get('state') or {}).get(key)
            if isinstance(value,str):state[key]=value[:limit]
        item['state']=state
        result[(row['type'],identity)]=item
    return [result[key] for key in sorted(result)]


def merge_library(left, right):
    result={}
    for row in clean_library(left)+clean_library(right):
        key=(row['type'],row['_id']);old=result.get(key)
        if old is None or profiles.library_order(row)>profiles.library_order(old):result[key]=row
    return [result[key] for key in sorted(result)]


def decode(response):
    if response is None:return None,None
    try:
        raw=base64.b64decode(response['content'],validate=False)
        if len(raw)>LIMIT:raise ValueError()
        if raw.startswith(b'\x1f\x8b'):
            decoder=zlib.decompressobj(16+zlib.MAX_WBITS)
            raw=decoder.decompress(raw,DATA_LIMIT+1)
            if len(raw)>DATA_LIMIT or not decoder.eof or decoder.unused_data:raise ValueError()
        value=json.loads(raw)
        if response.get('encoding')!='base64' or not isinstance(response.get('sha'),str) or len(raw)>DATA_LIMIT or value.get('version')!=1:raise ValueError()
        return value,response['sha']
    except Exception:raise SyncError('Invalid viewer sync file; data was kept') from None


def upload(token,path,data,sha,transport):
    raw=json.dumps(dict(data,version=1),sort_keys=True,separators=(',',':')).encode()
    if len(raw)>DATA_LIMIT:raise SyncError('Viewer data is too large; local data was kept')
    if path.endswith('.gz'):raw=gzip.compress(raw,mtime=0)
    if len(raw)>LIMIT//2:raise SyncError('Viewer data is too large; local data was kept')
    payload=dict(message='Merge viewer profiles',content=base64.b64encode(raw).decode())
    if sha:payload['sha']=sha
    transport(token,path,payload)


def synchronize_roster(root, token, transport=request):
    account=profiles._token(root)
    def valid():return profiles._token(root)==account
    if transport(token).get('private') is not True:raise SyncError('Viewer sync requires a private repository')
    for _ in range(3):
        if not valid():return False
        remote,sha=decode(transport(token,ROSTER))
        if not valid():return False
        if remote is not None and (not isinstance(remote.get('records'),dict) or profiles.clean(remote['records'])!=remote['records']):
            raise SyncError('Invalid viewer roster; local profiles were kept')
        local=profiles.state(root)
        if not local and remote is None:return False
        if not local:local=profiles.enable(root)
        records=profiles.merge(local.get('records',{}), (remote or {}).get('records',{}))
        if not records or not any(not r['deleted'] for r in records.values()):raise SyncError('Viewer roster has no available profiles; local data was kept')
        with storage_lock(Path(root)/'viewer-control'),storage_lock(Path(root)):
            if not valid():return False
            latest=profiles.state(root)
            records=profiles.merge(records,latest.get('records',{}))
            active=latest.get('active')
            if active not in records or records[active]['deleted']:active=next(k for k in sorted(records) if not records[k]['deleted'])
            # Active selection is deliberately local to this device.
            profiles.registry(root).save(dict(owner=profiles._owner(profiles._token(root)),records=records,active=active))
        if remote is not None and profiles.clean(remote.get('records'))==records:return True
        if not valid():return False
        try:upload(token,ROSTER,dict(records=records),sha,transport)
        except SyncError:continue
        verified,_=decode(transport(token,ROSTER))
        if verified and profiles.merge(verified.get('records'),records)==profiles.clean(verified.get('records')):return True
    raise SyncError('Viewer roster sync will retry; local profiles were kept')


def synchronize_viewer(root, identity, token, transport=request):
    if transport(token).get('private') is not True:raise SyncError('Viewer sync requires a private repository')
    from lib.saved_lists import SavedLists,clean as clean_tags,merge as merge_tags
    from lib.home_state import HomeState,clean as clean_home,merge as merge_home
    path='/contents/viewers/'+identity+'.json.gz'
    # Capture the directory once; switching during HTTP must not retarget data.
    directory=profiles.directory(root,identity)
    account_token=profiles._token(root)
    lists=SavedLists(root,account_token,viewer_id=identity)
    home=HomeState(root,account_token,viewer_id=identity)
    before=(clean_library(profiles.read_library(root,identity)),lists.snapshot(),home.snapshot())
    def valid():
        data=profiles.state(root)
        return (profiles._token(root)==account_token and
                identity in data.get('records',{}) and not data['records'][identity]['deleted'])
    for _ in range(3):
        if not valid():return False
        remote,sha=decode(transport(token,path));remote=remote or {}
        if not valid():return False
        if remote and (not isinstance(remote.get('library'),list) or not isinstance(remote.get('tags'),dict) or not isinstance(remote.get('home'),dict)):
            raise SyncError('Invalid viewer state; local progress was kept')
        if remote and (clean_library(remote['library'])!=remote['library'] or clean_tags(remote['tags'])!=remote['tags'] or clean_home(remote['home'])!=remote['home']):
            raise SyncError('Invalid viewer state; local progress was kept')
        library=merge_library(profiles.read_library(root,identity),remote.get('library',[]))
        tags=merge_tags(lists.snapshot(),remote.get('tags',{}))
        records=merge_home(home.snapshot(),remote.get('home',{}))
        data=dict(library=library,tags=tags,home=records)
        normalized=dict(library=clean_library(remote.get('library',[])),tags=clean_tags(remote.get('tags',{})),home=clean_home(remote.get('home',{})))
        if data!=normalized:
            if not valid():return False
            try:upload(token,path,data,sha,transport)
            except SyncError:continue
            verified,_=decode(transport(token,path))
            if not verified or (merge_library(verified.get('library',[]),library)!=clean_library(verified.get('library',[]))
                    or merge_tags(verified.get('tags',{}),tags)!=clean_tags(verified.get('tags',{}))
                    or merge_home(verified.get('home',{}),records)!=clean_home(verified.get('home',{}))):continue
            remote=verified
        if not valid():return False
        # Re-merge current data after HTTP, preserving concurrent local actions.
        latest=profiles.read_library(root,identity)
        joined=merge_library(latest,remote.get('library',[]))
        if clean_library(latest)!=joined:profiles.write_library(root,identity,joined)
        lists.merge(remote.get('tags',{}));home.merge(remote.get('home',{}))
        return before!=(clean_library(profiles.read_library(root,identity)),lists.snapshot(),home.snapshot())
    raise SyncError('Viewer sync will retry; local progress was kept')


class ViewerSync:
    def __init__(self,root,addon):
        self.root,self.addon=Path(root),addon
        self.busy=False;self.next_check=0

    def tick(self):
        if self.busy or time.monotonic()<self.next_check:return
        try:
            import xbmc
            from lib.native_playback import busy
            if xbmc.Player().isPlayingVideo() or busy():return
        except (ImportError,AttributeError,RuntimeError):pass
        if self.addon.getSetting('lists_github_enabled')!='true':return
        token=self.addon.getSetting('credits_github_token').strip()
        account=profiles._token(self.root)
        if not token or not account:return
        self.busy=True;self.next_check=time.monotonic()+60
        def run():
            try:
                if synchronize_roster(self.root,token):
                    data=profiles.state(self.root)
                    changed=False
                    # Include inactive dirty profiles so a switch never strands
                    # a final progress update on the previous viewer.
                    for identity,row in data['records'].items():
                        if profiles._token(self.root)!=account:return
                        if not row['deleted']:changed=synchronize_viewer(self.root,identity,token) or changed
                    Store(self.root/'viewer-sync-status').save(dict(status='Synced with private GitHub',updated=time.time()))
                    if changed:
                        import xbmcgui
                        xbmcgui.Window(10000).setProperty('strem4kodi.saved_lists.revision',str(time.time_ns()))
                        xbmcgui.Window(10000).setProperty('strem4kodi.home.recommendations.revision',str(time.time_ns()))
                        from lib.progress_signal import publish
                        publish(dict(meta_id='*',video_id=''))
            except Exception:
                Store(self.root/'viewer-sync-status').save(dict(status='Sync will retry; local viewer data was kept'))
            finally:self.busy=False
        try:threading.Thread(target=run,daemon=True).start()
        except RuntimeError:self.busy=False
