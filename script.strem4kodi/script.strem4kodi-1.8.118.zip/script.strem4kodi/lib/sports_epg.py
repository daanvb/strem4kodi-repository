"""Sports catalogue timeline geometry; never invent programme durations."""
from datetime import datetime, timezone
import math
import re
from lib.title_text import plain

SPAN = 3 * 60 * 60
STEP = 30 * 60
PAGE_ROWS = 7


def timestamp(value):
    """Only accept a full timestamp with an explicit timezone (or Unix time)."""
    try:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            stamp = float(value)
            if stamp > 100000000000:
                stamp /= 1000
            return stamp if math.isfinite(stamp) and 0 < stamp < 253402300800 else None
        if not isinstance(value, str) or 'T' not in value:
            return None
        date = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
        return date.timestamp() if date.tzinfo is not None else None
    except (ValueError, TypeError, OverflowError, OSError):
        return None


def first_time(row, fields):
    for field in fields:
        value = timestamp(row.get(field))
        if value is not None:
            return value
    return None


def entry(row):
    start = first_time(row, ('startTime', 'start_time', 'start', 'released'))
    end = first_time(row, ('endTime', 'end_time', 'end'))
    if start is None or end is None or end <= start:
        start = end = None
    release = plain(row.get('releaseInfo'))
    description = plain(row.get('description'))
    live = row.get('isLive') is True or bool(re.fullmatch(r'LIVE(?: NOW)?', release, re.I))
    live = live or any(line.strip().upper() == 'LIVE NOW' for line in description.splitlines())
    return dict(row=row, title=plain(row.get('name') or row.get('title')) or 'Sports stream',
                description=description, release=release, live=live, start=start, end=end)


def entries(rows):
    """Retain supplied ordering and identity, omitting catalogue paging actions."""
    return [entry(row) for row in rows if isinstance(row, dict) and row.get('id')
            and not row.get('_discover_load_more') and not row.get('_discover_more')]


def window_start(now):
    return math.floor(now / STEP) * STEP


def block(value, start, width=1500):
    """Clip confirmed timings; untimed listings occupy a clearly labelled lane."""
    if value['start'] is None:
        return 0, width
    left = max(start, value['start'])
    right = min(start + SPAN, value['end'])
    if right <= left:
        return None
    return (left - start) / SPAN * width, (right - left) / SPAN * width


def status(value, now):
    if value['start'] is not None:
        if now < value['start']:
            return 'Upcoming'
        return 'Live' if now < value['end'] else 'Ended'
    return 'Live' if value['live'] else value['release'] or 'Time unavailable'


def local_time(stamp, date=False):
    return datetime.fromtimestamp(stamp, timezone.utc).astimezone().strftime(
        '%a %d %b · %H:%M %Z' if date else '%H:%M')


def caption(value, now):
    if value['start'] is None:
        return status(value, now) + ' · Programme times unavailable'
    return '{}–{} · {}'.format(local_time(value['start']), local_time(value['end']), status(value, now))
