# Strem4Kodi — source status

**Reviewed:** 18 October 2026. Source: private `daanvb/Stremio-for-Kodi-private`, branch `strem4kodi`.

## Verified repository state
- Last inspected branch commit: `e1a01cf071c690e1a6a1a04ad0d81616038cad9a` (17 October 2026): clarification of staggered device updates for viewer profiles.
- Source addon manifest `addon.xml` declares **1.8.118** and player skin dependency **0.1.25**. The sports-guide release is being prepared for user-authorised publication.
- Public distribution repository `daanvb/strem4kodi-repository` has a 17 October commit publishing **1.8.117**; its `addons.xml` also declares **1.8.117**. This does **not** verify the version installed on any Kodi device.
- Recent work recorded by source commit titles: viewer profiles with isolated progress/private sync (17 October), playback cancellation safeguards (1.8.116), English-provider labels (1.8.115) and autoplay quality preferences (1.8.114).
- Latest inspected branch GitHub Actions: **Validate addon** and **Public source safety** passed on 17 October 2026 for that source commit. Real-device playback and CoreELEC compatibility are **not** proved by CI.
- Distribution documentation needs housekeeping: the source/public README headings still identify 1.8.112 as latest, even though the published feed is 1.8.117. The public package-directory `script.strem4kodi/addon.xml` displays an older 1.8.90 manifest while `addons.xml` declares 1.8.117; check the packaging/serving conventions before interpreting or changing that file. **Do not modify release artefacts as documentation housekeeping.**

## Boundaries and open verification
- Main development: private source branch `strem4kodi`; public update feed: separate repository `main`; private data: `strem4kodi-sync` (never move into source/public feed).
- Active features include Kodi/Stremio browsing, audio/source preferences, configurable playback, private device setup, viewer profiles, credits and diagnostic sync. Look up relevant focused docs before changing their invariants.
- User-observed on physical CoreELEC/Kodi devices (from 15–17 October conversations, **not verified against current repo/device in this audit**): a Dolby Vision trailer black-screen case occurred with Kodi's GUI configured to 4K; Aerial HDR priming with a temporary 30 Hz mode followed by 60 Hz was reported working on one boot. Do **not** assume these are resolved in source, reproducible on all devices, or defects requiring a release.
- Outstanding: verify latest release documentation/index consistency separately, and use targeted on-device checks for HDMI/CEC/audio/HDR changes. Avoid claiming unrelated historical issues remain open without fresh evidence.

## Development and handover
- Release work on `codex/sports-epg`: Sports now has a **TV guide** action with channel/event rows, a local-time ruler, Now marker, live status, descriptions and catalogue pagination. Selection retains the existing sports source picker. The inspected Sports Streams catalogue/metadata supplied no structured programme timings; untimed rows are labelled explicitly, with no external feed or invented durations. No configured provider URL or response was saved to source.
- Guide verification: 120 focused tests passed across guide behaviour, home layout, catalogue paging, return navigation and inline sources. Kodi/CoreELEC rendering, physical remote input and playback from the guide still require device validation. This change has not been released or deployed.
- Start with root `AGENTS.md` then `docs/PROJECT_HANDOVER.md`. Use `tools/run-tests.py` and matching focused tests for changes, plus existing release-verification scripts for authorised publication.
- Update this status only when material facts change; distinguish verified Git source, public feed, installed runtime and user observations. See `docs/repository-layout.md` for repository roles.
