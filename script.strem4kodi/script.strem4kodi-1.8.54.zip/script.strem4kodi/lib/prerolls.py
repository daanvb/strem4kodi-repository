"""Movie pre-roll selection from trusted public release assets; no title queries."""
import json
import random
import re
from pathlib import Path
from core.stream_ui import stream_card
from lib.preroll_catalog import ORIGIN, clean

PROPERTY = 'strem4kodi.preroll'


def assets(profile=None):
    if profile is not None:
        from lib.preroll_catalog import catalogue
        cache=catalogue(profile)
        cache.request()
        rows=cache.cached()
        if rows is not None:return rows  # An empty release intentionally disables all clips.
    try:
        rows = json.loads((Path(__file__).resolve().parents[1]/'resources/prerolls.json').read_text(encoding='utf-8'))
        return clean(rows)
    except (OSError,ValueError):return []


def profile_for(addon):
    try:
        import xbmcvfs
        value=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        return value if isinstance(value,str) and value else None
    except (ImportError,AttributeError,TypeError):return None


def audio_family(tags):
    text = ' '.join(tags).lower()
    if 'atmos' in text:return 'atmos'
    if 'truehd' in text:return 'truehd'
    if 'dolby digital plus' in text:return 'ddplus'
    if 'dolby digital' in text:return 'dd'
    if 'dts' in text:return 'dts'
    return ''


def asset_family(name):
    text = re.sub(r'[._-]+',' ',str(name)).lower()
    if 'atmos' in text:return 'atmos'
    if 'truehd' in text:return 'truehd'
    if 'digital plus' in text:return 'ddplus'
    if 'digital' in text:return 'dd'
    return ''


def select(meta, stream, resume_ms, addon, rows=None, choose=random.choice):
    from continue_playback import resume_seconds
    if meta.get('type') != 'movie' or resume_seconds(resume_ms) or stream.get('_preroll_done'):
        return None
    if addon.getSetting('prerolls_enabled') != 'true':return None
    card = stream_card(stream)
    family = audio_family(card.get('audio_tags',[]))
    if family == 'dts':
        if addon.getSetting('prerolls_dts') == '1':return None
        family = 'dd'
    if not family:return None
    from lib.player_tests import fel7_asset
    candidates = [row for row in (assets(profile_for(addon)) if rows is None else rows)
                  if not fel7_asset(row.get('name')) and asset_family(row.get('name')) == family]
    # SDR introductions work for both HDR and SDR movies. DoVi-only intros
    # must not be selected for a source which does not report Dolby Vision.
    vision = 'Dolby Vision' in card.get('video_tags',[])
    candidates = [row for row in candidates if vision or not re.search(r'(?i)dovi|dolby[ .]vision',row['name'])]
    sdr = [row for row in candidates if re.search(r'(?i)\bSDR\b',row['name'])]
    return choose(sdr or candidates) if candidates else None


def phase(gui=None):
    try:
        if gui is None:import xbmcgui as gui
        return gui.Window(10000).getProperty(PROPERTY)
    except Exception:return ''


def clear_phase(expected):
    try:
        import xbmcgui
        window=xbmcgui.Window(10000)
        if window.getProperty(PROPERTY) == expected:window.clearProperty(PROPERTY)
    except Exception:pass
