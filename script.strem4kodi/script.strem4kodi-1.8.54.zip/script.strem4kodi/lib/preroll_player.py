"""Pre-roll lifecycle: end/skip/error starts movie; Stop/Back cancels it."""
import time
from urllib.parse import urlencode
from lib.prerolls import PROPERTY, select


class Outcome:
    def __init__(self):
        self.started = False
        self.result = ''
    def finish(self, result):
        # A user's cancellation wins; a skip's Stop callback must not cancel.
        if not self.result:self.result = result
    def action(self, action, visible):
        if action in (10,13,92,216,247):
            self.finish('cancel')
        elif action == 14:
            self.finish('skip')
        elif action == 7 and visible:
            self.finish('skip')
        return visible or action == 7


def skip_window(outcome, gui, addon):
    from lib.theme import window as themed_window
    class SkipWindow(gui.WindowXMLDialog):
        visible = False
        def onInit(self):self.setProperty('skip_visible','false')
        def onAction(self, action):
            self.visible = outcome.action(action.getId(),self.visible)
            if self.visible:
                self.setProperty('skip_visible','true')
                self.setFocusId(201)
        def onClick(self, control_id):
            if control_id == 201:
                if self.visible:outcome.finish('skip')
                else:
                    self.visible = True
                    self.setProperty('skip_visible','true')
                    self.setFocusId(201)
    return themed_window(SkipWindow,'script-strem4kodi-preroll.xml',addon.getAddonInfo('path'),'Main','1080i')


def play_intro(asset, addon, key, attempt, kodi, gui, window, monitor, cancelled,
               clock=time.monotonic, factory=skip_window):
    outcome = Outcome()
    def owns(player):
        try:
            if player.getPlayingItem().getProperty('Strem4KodiPreRoll') == key:return True
        except Exception:pass
        try:return player.getPlayingFile() == asset['url']
        except Exception:return False
    class IntroPlayer(kodi.Player):
        def onAVStarted(self):
            if owns(self):outcome.started = True
            else:outcome.finish('cancel')
        def onPlayBackEnded(self):
            if outcome.started:outcome.finish('ended')
        def onPlayBackError(self):outcome.finish('error')
        def onPlayBackStopped(self):
            if outcome.started:outcome.finish('cancel')
    player = IntroPlayer()
    overlay = None
    started = clock()
    try:
        item = gui.ListItem(label='Audio pre-roll',path=asset['url'])
        item.setProperty('Strem4KodiPreRoll',key)
        item.setProperty('IsPlayable','true')
        player.play(asset['url'],item)
        while not outcome.result:
            if cancelled(attempt) or monitor.abortRequested() or window.getProperty(PROPERTY) != key:
                outcome.finish('cancel')
                break
            if outcome.started and overlay is None:
                overlay = factory(outcome,gui,addon)
                overlay.show()
            elapsed = clock()-started
            if (not outcome.started and elapsed > 20) or elapsed > 600:
                outcome.finish('error')
                break
            monitor.waitForAbort(0.1)
    except Exception:
        outcome.finish('error')
    finally:
        if overlay is not None:
            try:overlay.close()
            except Exception:pass
        # Only stop our pre-roll. Never interrupt another playback request.
        if window.getProperty(PROPERTY) == key and outcome.result != 'ended':
            if outcome.result != 'cancel':window.setProperty(PROPERTY,'handoff:'+key)
            try:
                if player.isPlayingVideo() and owns(player):player.stop()
            except Exception:pass
    return outcome.result


def run(key, kodi=None, gui=None, addon=None, store=None, intro=play_intro):
    if kodi is None:import xbmc as kodi
    if gui is None:import xbmcgui as gui
    if addon is None:
        from addon_state import get_addon
        addon=get_addon()
    if store is None:
        import xbmcvfs
        from account import Store
        store=Store(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
    from account import Store
    from lib.playback_loading import cancelled
    window=gui.Window(10000)
    if window.getProperty(PROPERTY) != key:return
    proceed=False
    valid=False
    attempt=''
    try:
        cache=Store(store.directory/'streams').load()
        stream=(cache.get('urls') or {}).get(key) or {}
        if not isinstance(stream,dict) or not stream.get('url'):return
        attempt=stream.get('_playback_attempt','')
        if cancelled(attempt) or time.time()-float(cache.get('created') or 0)>3600:return
        valid=True
        asset=select(stream.get('meta') or {},stream,stream.get('resume_ms'),addon)
        monitor=kodi.Monitor()
        result=intro(asset,addon,key,attempt,kodi,gui,window,monitor,cancelled) if asset else 'ended'
        proceed=result in ('ended','skip','error') and not cancelled(attempt) and not monitor.abortRequested()
    except Exception:
        proceed=valid and not cancelled(attempt)
    finally:
        # A newer request owns the player now; this script must not launch over it.
        if window.getProperty(PROPERTY) not in (key,'handoff:'+key):proceed=False
        elif proceed:window.setProperty(PROPERTY,'handoff:'+key)
        else:window.clearProperty(PROPERTY)
    if proceed:
        url='plugin://script.strem4kodi/?'+urlencode({'action':'play','key':key})
        kodi.executebuiltin('PlayMedia('+url+')')
