"""Source-reported availability, never inferred from artwork or another episode."""
from core.stream_ui import stream_card


def formats(rows):
    cards = [stream_card(row) for row in rows if isinstance(row, dict)
             and not row.get('_session_failed')]
    qualities = ('4K', '1080p', '720p', '480p', '360p')
    best = next((q for q in qualities if any(c.get('quality') == q for c in cards)), '')
    video = {tag for c in cards for tag in c.get('video_tags', [])}
    audio = {tag.split(' 2.')[0].split(' 5.')[0].split(' 7.')[0]
             for c in cards for tag in c.get('audio_tags', [])}
    formats = [best] if best else []
    if 'Dolby Vision' in video:
        formats.append('Dolby Vision')
    if 'HDR10+' in video:
        formats.append('HDR10+')
    elif 'HDR10' in video:
        formats.append('HDR10')
    elif 'HDR' in video:
        formats.append('HDR')
    sound = next((v for v in ('Atmos', 'TrueHD', 'DTS-HD MA', 'Dolby Digital Plus', 'DTS', 'Dolby Digital') if v in audio), '')
    if sound:
        formats.append(sound)
    return formats


def merge_formats(*groups):
    """Rank cumulative availability without keeping source URLs in memory."""
    tags = {tag for group in groups for tag in group}
    result = [q for q in ('4K','1080p','720p','480p','360p') if q in tags][:1]
    if 'Dolby Vision' in tags:result.append('Dolby Vision')
    result += [v for v in ('HDR10+','HDR10','HDR') if v in tags][:1]
    result += [a for a in ('Atmos','TrueHD','DTS-HD MA','Dolby Digital Plus','DTS','Dolby Digital') if a in tags][:1]
    return result


ASSETS = {'4K': 'ui/4k', '1080p': 'ui/1080p', '720p': 'ui/720p',
          'Dolby Vision': 'dolbyvision', 'HDR10+': 'ui/hdr10plus', 'HDR10': 'ui/hdr10', 'HDR': 'ui/hdr',
          'Atmos': 'atmos', 'TrueHD': 'truehd', 'DTS-HD MA': 'dtshd_ma',
          'DTS': 'dts', 'Dolby Digital Plus': 'eac3', 'Dolby Digital': 'ac3'}


def properties(found):
    paths = ['special://home/addons/script.strem4kodi/resources/skins/Main/media/formats/display/hero/' + ASSETS[v] + '.png'
             for v in found if v in ASSETS]
    values = {'available_format_' + str(i): paths[i] if i < len(paths) else '' for i in range(4)}
    values.update({'available_format_' + str(i) + '_tint': 'FFFFFFFF' for i in range(4)})
    return values


def apply(window, rows):
    for key, value in properties(formats(rows)).items():
        window.setProperty(key, value)


def catalogue_formats(meta):
    """Read explicit technical fields only, with no network or artwork guessing."""
    fields = ('quality', 'resolution', 'height', 'audio', 'audioCodec', 'hdr', 'bitDepth')
    values = {key: meta[key] for key in fields if key in meta}
    for key in ('availableFormats', 'videoFormats', 'audioFormats'):
        value = meta.get(key)
        if isinstance(value, (str, list, tuple)):
            values['label'] = values.get('label', '') + ' ' + (' '.join(str(v) for v in value) if isinstance(value, (list, tuple)) else value)
    return formats([values]) if values else []


def display_formats(meta, api, identity=None):
    """Show retained badges immediately; source URL freshness stays separate."""
    # Browsing a future/selected episode still presents the series overview.
    # Keep the original context for playback and on-demand source requests.
    overview = dict(meta)
    if meta.get('type') == 'series':
        overview.pop('_focus_video_id', None)
    summary = api.availability_summary(overview)
    if isinstance(summary, dict) and 'formats' in summary:
        if summary['formats'] or meta.get('type') != 'series':
            return summary['formats']
        # An empty episode lookup cannot erase explicit series-level metadata.
        return catalogue_formats(meta)
    if meta.get('type') == 'series' and not meta.get('_focus_video_id'):
        return catalogue_formats(meta)  # Explicit title metadata; never another episode's cache.
    return for_title(meta, api.stream_cache_state, identity) or catalogue_formats(meta)


def for_title(meta, cache_reader, identity=None):
    if meta.get('type') not in ('movie', 'series'):
        return []
    state = meta.get('state') if isinstance(meta.get('state'), dict) else {}
    target = identity or meta.get('_focus_video_id') or state.get('video_id')
    if meta.get('type') == 'movie':
        target = meta.get('id')
    # A series-level cache must never stand in for a particular episode.
    if not target or (meta.get('type') == 'series' and target == meta.get('id')):
        return []
    cached = cache_reader(meta, target)
    # Last-known technical badges remain useful after playable URLs expire.
    return formats(cached[0]) if cached else []
