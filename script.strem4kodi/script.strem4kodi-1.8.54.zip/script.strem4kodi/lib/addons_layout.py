"""Compact Stremio add-on cards with explicit return navigation."""
import xml.etree.ElementTree as ET

MEDIA = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/'
PAGE = 'String.IsEqual(Window.Property(page),Addons)'
PAGE_GROUP = 9400


def node(parent, kind, cid=None, **tags):
    control = ET.SubElement(parent, 'control', type=kind)
    if cid is not None:
        control.set('id', str(cid))
    for key, value in tags.items():
        ET.SubElement(control, key).text = str(value)
    return control


def label(parent, text, x, y, width, height=40, font='font27', color='FFE5E5E7', kind='label'):
    return node(parent, kind, left=x, top=y, width=width, height=height,
                font=font, textcolor=color, label=text)


def surface(parent, texture, color):
    control = node(parent, 'image', left=0, top=0, width=1280, height=148)
    ET.SubElement(control, 'texture', border='24', colordiffuse=color).text = (
        MEDIA + 'streams-local/' + texture + '.png')
    return control


def action_button(parent, cid, x, text, left, right, enable='true', y=910, width=300):
    target = 'SetFocus($INFO[Window.Property(addons_list_focus)])'
    control = node(parent, 'button', cid, left=x, top=y, width=width, height=65,
                   label=text, font='font23_title', align='center', aligny='center',
                   textcolor='FFE5E5E7', focusedcolor='FF15161D', disabledcolor='FF65616F',
                   onleft=left, onright=right, onup=target, ondown=target, enable=enable)
    for tag, color in (('texturenofocus', 'C0302B41'), ('texturefocus', 'FFC4ACFF')):
        ET.SubElement(control, tag, border='24', colordiffuse=color).text = (
            MEDIA + 'streams-local/row-fill.png')
    return control


def build(tree):
    controls = tree.find('controls')
    sidebar = None
    for control in list(controls)[1:]:
        if control.find('.//control[@id="9000"]') is not None:
            # Leave its focus-only animation intact; Addons must not pin it open.
            sidebar = control
            continue
        visible = control.find('visible')
        if visible is None:
            visible = ET.SubElement(control, 'visible')
            visible.text = '!' + PAGE
        else:
            visible.text = '[' + (visible.text or 'true') + '] + !' + PAGE
    # Four complete cards, with actions and a persistent return button outside the list.
    group = node(controls, 'group', PAGE_GROUP, left=320, top=0, visible=PAGE)
    try:
        drawer_width = abs(int(sidebar.findtext('left', '0'))) if sidebar is not None else 0
    except (TypeError, ValueError):
        drawer_width = 0
    if drawer_width:
        ET.SubElement(group, 'animation', effect='slide', start='0,0',
                      end='{},0'.format(drawer_width // 2), time='500', tween='cubic',
                      easing='inout', condition='Control.HasFocus(9000)',
                      reversible='true').text = 'Conditional'
    label(group, 'Stremio add-ons', 0, 65, 990, 70, 'font52_title')
    action_button(group, 9305, 1015, '$INFO[Window.Property(addons_back)]',
                  'SetFocus($INFO[Window.Property(addons_list_focus)])',
                  'SetFocus($INFO[Window.Property(addons_list_focus)])', y=70, width=260)
    label(group, '$INFO[Window.Property(addons_summary)]', 0, 145, 1280, 45, 'font23', 'FFADACB5')
    listing = node(group, 'list', 9300, left=0, top=230, width=1280, height=656,
                   onleft=9000, onright=9301, onup=9305, ondown=9304,
                   pagecontrol=9310, scrolltime=180, orientation='vertical')
    for layout, fill, edge in (('itemlayout', 'B8242333', '6042365C'),
                               ('focusedlayout', 'DC42365C', 'C0C4ACFF')):
        box = ET.SubElement(listing, layout, width='1280', height='164')
        surface(box, 'row-fill', fill)
        surface(box, 'row-outline', edge)
        icon = node(box, 'image', left=24, top=30, width=88, height=88, aspectratio='keep')
        ET.SubElement(icon, 'texture', fallback='DefaultAddon.png').text = '$INFO[ListItem.Art(thumb)]'
        title = label(box, '$INFO[ListItem.Label]', 140, 12, 855, 42, 'font27_title',
                      'FFFFFFFF' if layout == 'focusedlayout' else 'FFE5E5E7')
        ET.SubElement(title, 'scroll').text = 'true' if layout == 'focusedlayout' else 'false'
        version = label(box, '$INFO[ListItem.Property(version)]', 1020, 16, 235, 35, 'font23', 'FFADACB5')
        ET.SubElement(version, 'align').text = 'right'
        label(box, '$INFO[ListItem.Property(types)]', 140, 55, 850, 30, 'font23', 'FFB5A4E8')
        pill = node(box, 'image', left=1045, top=55, width=210, height=32)
        ET.SubElement(pill, 'texture', border='16', colordiffuse='C0302B41').text = MEDIA + 'streams-local/row-fill.png'
        status = label(box, '$INFO[ListItem.Property(status)]', 1045, 55, 210, 32,
                       'font23', '$INFO[ListItem.Property(status_color)]')
        ET.SubElement(status, 'align').text = 'center'
        label(box, '$INFO[ListItem.Property(description)]', 140, 90, 1115, 56,
              'font23', 'FFE5E5E7' if layout == 'focusedlayout' else 'FFADACB5', 'textbox')
    scrollbar = node(group, 'scrollbar', 9310, left=1292, top=230, width=8, height=640,
                     orientation='vertical', showonepage='false', onleft=9300, onright=9301)
    for tag, color in (('texturesliderbackground', '40242333'), ('texturesliderbar', 'FFB5A4E8'),
                       ('texturesliderbarfocus', 'FFC4ACFF'), ('textureslidernib', '00FFFFFF'),
                       ('textureslidernibfocus', '00FFFFFF')):
        ET.SubElement(scrollbar, tag, colordiffuse=color).text = MEDIA + 'white.png'
    label(group, '$INFO[Window.Property(addons_empty)]', 0, 260, 1260, 160, kind='textbox')
    selected = '!String.IsEmpty(Window.Property(addon_selected))'
    action_button(group, 9301, 0, '$INFO[Window.Property(addon_toggle)]', 9300, 9302, selected)
    action_button(group, 9302, 325, 'Configure', 9301, 9303,
                  'String.IsEqual(Window.Property(addon_configurable),true)')
    action_button(group, 9303, 650, 'Remove', 9302, 9304, selected)
    add = action_button(group, 9304, 975, '+ Add addon', 9303, 9304)
    add.find('onup').text = '9305'
    label(group, 'OK: actions     Back: return     Left: navigation',
          0, 995, 1280, 40, 'font23', 'FFADACB5')
