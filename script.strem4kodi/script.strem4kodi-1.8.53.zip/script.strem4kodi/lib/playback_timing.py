"""Last local playback stages; no disk/network, media names or source URLs."""
import json
import time

PROPERTY='strem4kodi.playback.timing'
STAGES=('selected','resolved','playing','cancelled')

def _window():
    import xbmcgui
    return xbmcgui.Window(10000)

def load():
    try:
        data=json.loads(_window().getProperty(PROPERTY) or '{}')
        return data if isinstance(data,dict) else {}
    except (ValueError,TypeError,RuntimeError,ImportError,AttributeError):return {}

def _write(data):
    try:_window().setProperty(PROPERTY,json.dumps(data))
    except (RuntimeError,ImportError,AttributeError):pass  # Optional measurements must never delay Cancel/playback.

def begin(attempt,clock=time.monotonic):
    _write({'attempt':attempt,'created':clock(),'stages':{}})

def transfer(previous,attempt,clock=time.monotonic):
    data=load()
    if data.get('attempt')!=previous:return
    data['attempt']=attempt
    data['stages']['selected']=max(0,int((clock()-data['created'])*1000))
    _write(data)

def mark(attempt,stage,clock=time.monotonic):
    if stage not in STAGES or not attempt:return
    data=load()
    if data.get('attempt')!=attempt or not attempt:return
    stages=data.get('stages') or {}
    if stage in stages:return
    stages[stage]=max(0,int((clock()-data['created'])*1000))
    data['stages']=stages
    _write(data)

def details():
    stages=load().get('stages') or {}
    labels=(('selected','Finding a suitable source'),('resolved','Preparing the source'),
            ('playing','Kodi opening and buffering'))
    lines=[];previous=0
    for stage,label in labels:
        value=stages.get(stage)
        if isinstance(value,int):
            lines.append('{}: {:.2f} seconds'.format(label,max(0,value-previous)/1000))
            previous=value
    if 'cancelled' in stages:lines.append('Cancelled after {:.2f} seconds'.format(stages['cancelled']/1000))
    return '\n'.join(lines) or 'Start a title to record playback stages.'
