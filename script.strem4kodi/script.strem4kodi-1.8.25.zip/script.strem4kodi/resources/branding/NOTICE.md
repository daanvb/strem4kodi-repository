# Strem4Kodi branding

Original cyan geometric wordmark and matching play-symbol icon, generated with the built-in image tool from the owner's typography reference.
Unofficial community addon; not endorsed by Stremio or Kodi.
Software copyright and GPL notices remain preserved.
