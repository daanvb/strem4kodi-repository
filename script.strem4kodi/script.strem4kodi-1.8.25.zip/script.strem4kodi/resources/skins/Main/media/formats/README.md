Format logos are shown only for Kodi-reported formats, not source claims.

`atmos.png`: unmodified Dolby Atmos Horizontal logo from Dolby Newsroom:
https://news.dolby.com/en-WW/assets/228229/

Other assets reuse the format flags bundled with the Kodi Estuary companion
skin. Original product names and logos belong to their respective owners.

Resolution flags (720p, 1080p, 4K and 8K) reuse the bundled Estuary videoresolution assets. Resolution names and icons use decoded stream dimensions, including common cropped widescreen sizes; unknown sizes retain their exact dimensions without an invented format badge. Dolby Atmos is shown alongside its reported Dolby Digital Plus or TrueHD base format.
