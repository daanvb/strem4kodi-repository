"""Optional cached TMDB enrichment; Stremio metadata remains usable offline."""
import hashlib
from addon_state import get_addon
from lib.cache_policy import open_cache, read_policy


def lookup(meta, operation):
    key = get_addon().getSetting('tmdb_api_key').strip()
    if not key:
        return None
    policy = read_policy()
    cache = open_cache('metadata', policy)
    cache_key = 'tmdb-v1:' + hashlib.sha256(key.encode()).hexdigest() + ':' + operation + ':' + str(meta.get('type')) + ':' + str(meta.get('id'))
    try:
        cached = cache.get(cache_key) if cache else None
        if cached is not None:
            return cached
        from tmdb_metadata import credits, recommendations, certificate_gb
        result = (certificate_gb(meta, key) if operation == 'certificate_gb' else
                  recommendations(meta, key) if operation == 'recommendations' else credits(meta, key, operation))
        if cache:
            cache.put(cache_key, result, policy['metadata'])
        return result
    except Exception:
        return None


def people(meta, role='cast'):
    from metadata_bridge import people as provider_people, _merge_people
    base = provider_people(meta, role)
    extra = lookup(meta, role) or []
    # Keep provider order and supplement missing portraits and specific jobs.
    return _merge_people(base + extra)


def age_enrich(meta):
    result = dict(meta)
    value = lookup(meta, 'certificate_gb')
    if value:
        result.update(certificate_gb=value, certificate_country='GB')
    return result


def recommendations(meta, providers=()):
    from metadata_bridge import recommendations as catalog_recommendations
    rows = lookup(meta, 'recommendations')
    return rows if rows else catalog_recommendations(meta, providers)


def episode_scores(meta, season, rows):
    from lib.mdblist import enrich_episodes
    rows = enrich_episodes(meta, season, rows)
    addon=get_addon();key=addon.getSetting('tmdb_api_key').strip()
    if not key:return rows
    show_ratings = addon.getSetting('episode_rating_tmdb')!='false' and addon.getSetting('rating_tmdb')!='false'
    cache_key='episode-details-v1:'+hashlib.sha256(key.encode()).hexdigest()+':'+str(meta.get('id'))+':'+str(season)
    try:
        policy=read_policy();cache=open_cache('metadata',policy)
        scores=cache.get(cache_key) if cache else None
        if scores is None:
            from tmdb_metadata import season_details
            scores=season_details(meta,season,key)
            if cache:cache.put(cache_key,scores,policy['metadata'])
        by_number = {e['episode']: e for e in scores}
        result = []
        for row in rows:
            extra = by_number.get(row.get('episode') or row.get('number'), {})
            enriched = dict(row)
            if not row.get('description') and not row.get('overview') and extra.get('description'):
                enriched['description'] = extra['description']
            if show_ratings and 'tmdbRating' in extra:
                enriched['tmdbRating'] = extra['tmdbRating']
            result.append(enriched)
        return result
    except Exception:return rows
