"""Chapter selection on the existing timeline; browsing never seeks."""
import math
from lib.player_media_info import safe


def valid(rows, duration):
    if not math.isfinite(duration) or duration <= 0 or not isinstance(rows, list):
        return []
    result = []
    previous = -1
    for row in rows[:300]:
        try:
            start = float(row['time'])
            if not math.isfinite(start) or not 0 <= start < duration or start <= previous:
                return []
            result.append({'start': start, 'name': safe(row.get('name')) or 'Chapter {}'.format(len(result) + 1)})
            previous = start
        except (TypeError, ValueError, KeyError):
            return []
    return result


def from_ranges(raw, count, duration, current=0, current_name=''):
    # Kodi 21 exports successive (previous,start) percentage pairs, omitting 0.
    try:
        values = [float(v) for v in str(raw).split(',')] if raw else []
        if len(values) % 2 or not 1 <= count <= 300:
            return []
        if any(not math.isfinite(v) or not 0 <= v < 100 for v in values):
            return []
        starts = values[1::2]
        if len(starts) == count - 1:
            starts.insert(0, 0)
        if len(starts) != count:
            return []
        rows = [{'time': value * duration / 100, 'name': current_name if i + 1 == current else ''}
                for i, value in enumerate(starts)]
        return valid(rows, duration)
    except (TypeError, ValueError):
        return []


def load(rpc, label, duration):
    try:
        players = rpc('Player.GetActivePlayers') or []
        player = next((p for p in players if p.get('type') == 'video'), None)
        rows = valid(rpc('Player.GetChapters', {'playerid': player['playerid']}).get('chapters'), duration) if player else []
        if rows:
            return rows
    except Exception:
        pass  # GetChapters is absent on Kodi 21.
    try:
        return from_ranges(label('Player.Chapters'), int(label('Player.ChapterCount') or 0), duration,
                           int(label('Player.Chapter') or 0), label('Player.ChapterName'))
    except (TypeError, ValueError):
        return []


def timestamp(seconds):
    seconds = int(seconds)
    h, remaining = divmod(seconds, 3600)
    m, s = divmod(remaining, 60)
    return '{}:{:02}:{:02}'.format(h, m, s) if h else '{}:{:02}'.format(m, s)


class Selection:
    def __init__(self, rows, duration, position):
        self.rows = rows
        self.duration = duration
        self.index = max((i for i, row in enumerate(rows) if row['start'] <= position), default=0)

    def move(self, direction):
        self.index = max(0, min(len(self.rows) - 1, self.index + direction))

    @property
    def row(self):
        return self.rows[self.index]

    @property
    def x(self):
        return round(80 + 1760 * self.row['start'] / self.duration - 4)

    @property
    def label(self):
        return 'Chapters · {}/{} · {} · {}'.format(self.index + 1, len(self.rows), self.row['name'], timestamp(self.row['start']))


def show():
    import threading
    import xbmc
    import xbmcgui
    from setup_profile import rpc
    from addon_state import get_addon
    from lib.theme import window
    from lib.player_controls import menu_session_active
    home = xbmcgui.Window(10000)
    key = 'strem4kodi.player.chapter_selection'
    if home.getProperty(key):
        return
    player = xbmc.Player()
    file = player.getPlayingFile()
    if not menu_session_active(player, file) or not xbmc.getCondVisibility('Player.SeekEnabled'):
        return
    home.setProperty(key, 'true')
    try:
        duration = player.getTotalTime()
        rows = load(rpc, xbmc.getInfoLabel, duration)
        if not menu_session_active(player, file):
            return
        if not rows:
            from pathlib import Path
            import xbmcvfs
            from lib.player_controls import open_chapters, AudioDialog
            profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
            open_chapters(player, profile, xbmc, AudioDialog('Choose a chapter to jump to its start.'))
            return
        selection = Selection(rows, duration, player.getTime())
        class Timeline(xbmcgui.WindowXMLDialog):
            def onInit(self):
                self.closed = False
                self.exit_controls = False
                if not menu_session_active(player, file):
                    self.close(); return
                self.render()
                self.setFocusId(600)
                def watch():
                    monitor = xbmc.Monitor()
                    while not self.closed and not monitor.waitForAbort(.25):
                        if not menu_session_active(player, file):
                            self.close(); return
                threading.Thread(target=watch, daemon=True).start()

            def render(self):
                self.setProperty('chapter_selection_title', selection.label)
                self.getControl(600).setPosition(selection.x, 918)

            def close(self):
                self.closed = True
                super().close()

            def jump(self):
                if self.closed:
                    return
                if menu_session_active(player, file) and xbmc.getCondVisibility('Player.SeekEnabled'):
                    player.seekTime(selection.row['start'])
                self.close()

            def onClick(self, cid):
                if cid == 600:
                    self.jump()

            def onAction(self, action):
                aid = action.getId()
                if aid in (1, 2):
                    selection.move(-1 if aid == 1 else 1)
                    self.render()
                elif aid == 7:
                    self.jump()
                elif aid == 4:  # Down returns to the focused scrub bar.
                    self.close()
                elif aid in (10, 92, 216, 247):
                    self.exit_controls = True
                    self.close()
                # Up stays in Chapters mode; other player actions are not forwarded.
        dialog = window(Timeline, 'script-strem4kodi-player-timeline.xml', get_addon().getAddonInfo('path'), 'Main', '1080i')
        dialog.exit_controls = False
        dialog.doModal()
        if menu_session_active(player, file):
            if dialog.exit_controls:
                xbmc.executebuiltin('Dialog.Close(videoosd)')
            else:
                xbmc.executebuiltin('SetFocus(9007)')
    finally:
        home.clearProperty(key)
