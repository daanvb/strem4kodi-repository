"""Treat installed BetterPosters as artwork, rather than duplicate catalogue rows."""
import re
from urllib.parse import urlsplit


def _host(value):
    try:return urlsplit(str(value or '')).hostname or ''
    except ValueError:return ''


def enabled(addons):
    if isinstance(addons, dict):
        from addons_core import active_addons
        addons = active_addons(addons)
    return any(is_provider(a) for a in addons)


def is_provider(addon):
    manifest = addon.get('manifest') or {}
    name = re.sub(r'\W', '', str(manifest.get('name') or manifest.get('id') or '')).casefold()
    return 'betterposters' in name


def template(rows):
    for row in rows:
        poster=str(row.get('poster') or '')
        host=_host(poster)
        if host=='btttr.cc' or host.endswith('.btttr.cc'):
            if re.search(r'tt\d+',poster):return re.sub(r'tt\d+','{imdb}',poster,count=1)
    # A default style can reintroduce ratings the user disabled in the provider.
    # Only apply a style actually supplied by the configured addon.
    return ''


def decorate(rows, addons, pattern=None):
    active=enabled(addons)
    installed=addons.get('addons',[]) if isinstance(addons,dict) else addons
    has_aiometadata=any('aiometadata' in re.sub(r'\W','',str((a.get('manifest') or {}).get('name') or (a.get('manifest') or {}).get('id') or '')).casefold()
                        for a in installed)
    def provider_art(row):
        provider=re.sub(r'\W','',str(row.get('_poster_provider') or '')).casefold()
        host=_host(row.get('poster'))
        better=host=='btttr.cc' or host.endswith('.btttr.cc')
        # The image service is shared by standalone BetterPosters and
        # AIOMetadata. Its hostname alone does not identify who configured it.
        return (row.get('_poster_preferred') or 'aiometadata' in provider or
                (better and provider and 'betterposters' not in provider) or
                (better and not provider and has_aiometadata and not row.get('_original_poster')))
    pattern=pattern or template([row for row in rows if not provider_art(row)])
    result=[]
    for row in rows:
        copy=dict(row)
        identity=str(copy.get('imdb_id') or copy.get('imdbId') or copy.get('id') or '').partition(':')[0]
        if not provider_art(copy) and re.fullmatch(r'tt\d+',identity) and copy.get('type') in ('movie','series'):
            host=_host(copy.get('poster'))
            decorated = host=='btttr.cc' or host.endswith('.btttr.cc')
            if not active and decorated:
                # CW/library snapshots can retain an old decorated image even
                # after disabling the provider. Restore only known BetterPosters
                # URLs, leaving other providers and account metadata untouched.
                copy['poster']=copy.get('_original_poster') or (
                    'https://images.metahub.space/poster/medium/'+identity+'/img')
            elif active and pattern:
                if not decorated:
                    copy['_original_poster']=copy.get('poster','')
                copy['poster']=pattern.replace('{imdb}',identity)
        result.append(copy)
    return result


def prepare_catalogs(catalogs, state):
    """Apply the current artwork choice to both cached and refreshed Home rows."""
    catalogs=[dict(catalog,items=[dict(row,**({'_poster_provider':catalog['addon']}
                      if catalog.get('addon') and not row.get('_poster_provider') else {}))
                      for row in catalog.get('items',[])]) for catalog in catalogs]
    configured={}
    for catalog in catalogs:
        if catalog.get('label') in ('Continue Watching','Up Next'):
            continue
        for row in catalog.get('items',[]):
            if row.get('poster') and 'aiometadata' in re.sub(r'\W','',str(row.get('_poster_provider') or '')).casefold():
                configured.setdefault((row.get('type'),row.get('id')),row)
    for catalog in catalogs:
        if catalog.get('label') in ('Continue Watching','Up Next'):
            for row in catalog.get('items',[]):
                fresh=configured.get((row.get('type'),row.get('id')))
                if fresh:
                    row['poster']=fresh['poster']
                    row['_poster_provider']=fresh['_poster_provider']
    pattern=template([row for catalog in catalogs
                      if catalog.get('label') not in ('Continue Watching','Up Next')
                      and 'betterposters' in re.sub(r'\W','',str(catalog.get('addon') or '')).casefold()
                      for row in catalog.get('items',[])])
    # Legacy snapshots did not record their supplying addon.
    if not pattern and not any('aiometadata' in re.sub(r'\W','',str((a.get('manifest') or {}).get('name') or '')).casefold()
                               for a in state.get('addons',[])):
        pattern=template([row for catalog in catalogs
                          if catalog.get('label') not in ('Continue Watching','Up Next')
                          for row in catalog.get('items',[])])
    return [dict(catalog,items=decorate(catalog.get('items',[]),state,pattern))
            for catalog in catalogs]


def consolidate(specs):
    """Use the artwork wrapper when it duplicates an installed catalogue."""
    def key(row):
        label=re.sub(r'(?i)better\s*posters?', '',row.get('label',''))
        label=re.sub(r'\W+',' ',label).strip().casefold()
        return row.get('kind'),label
    decorated={key(s):s for s in specs if 'betterposters' in re.sub(r'\W','',str(s.get('addon') or '')).casefold()}
    result=[];seen=set()
    for spec in specs:
        identity=key(spec)
        chosen=decorated.get(identity,spec)
        if identity in decorated:
            if identity in seen:continue
            seen.add(identity)
            chosen=dict(chosen)
            chosen['label']=re.sub(r'(?i)\s*[-|:]?\s*better\s*posters?\s*[-|:]?\s*','',chosen['label']).strip() or spec['label']
        result.append(chosen)
    return result
