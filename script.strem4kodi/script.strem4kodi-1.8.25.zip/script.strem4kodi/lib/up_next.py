"""Floating, manual next-episode prompt for Strem4Kodi playback only."""
import hashlib
import threading
import time
from pathlib import Path
from datetime import datetime, timezone
import xbmc
import xbmcgui
from account import Store
from addon_state import get_addon
from lib.theme import window as themed_window
ROOT = str(Path(__file__).resolve().parents[1])

def following_episode(videos, current_id, now=None):
    rows=[]
    for row in videos or []:
        try:
            season=int(row.get('season'));episode=int(row.get('episode',row.get('number')))
            if season>0 and episode>0 and row.get('id'):rows.append((season,episode,row))
        except (TypeError,ValueError,AttributeError):pass
    rows.sort(key=lambda r:r[:2])
    index=next((i for i,r in enumerate(rows) if r[2]['id']==current_id),None)
    if index is None or index+1==len(rows):return None
    candidate=rows[index+1][2]
    released=candidate.get('released') or candidate.get('firstAired')
    if not released:return None
    try:
        date=datetime.fromisoformat(str(released).replace('Z','+00:00'))
        if date.tzinfo is None:date=date.replace(tzinfo=timezone.utc)
        if date>(now or datetime.now(timezone.utc)):return None
    except (TypeError,ValueError):return None
    return candidate

def prompt_due(position,duration,lead=60,credits=None):
    if duration<=120:return False
    threshold=max(duration/2,duration-lead)
    if isinstance(credits,dict):
        try:
            start=float(credits['start']);end=float(credits['end'])
            if duration/2<=start<end<=duration+10:threshold=start
        except (TypeError,ValueError,KeyError):pass
    return threshold<=position<duration

class UpNextWindow(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        self.episode=kwargs.pop('episode');self.meta=kwargs.pop('meta');self.accept=kwargs.pop('accept');self.dismiss=kwargs.pop('dismiss')
        super().__init__(*args,**kwargs)
    def onInit(self):
        row=self.episode
        self.setProperty('next_title',str(row.get('title') or row.get('name') or 'Next episode'))
        self.setProperty('next_series',str(self.meta.get('name') or ''))
        self.setProperty('next_number','S{:02d} · E{:02d}'.format(int(row['season']),int(row.get('episode',row.get('number')))))
        self.setProperty('next_art',str(row.get('thumbnail') or self.meta.get('background') or self.meta.get('poster') or ''))
        from lib.auto_source import select
        mode, _, _ = select([], get_addon(), self.meta)
        self.setProperty('next_action', 'Play Next' if mode == 2 else 'Choose Source')
        self.setFocusId(201)
    def onClick(self,cid):
        self.close()
        (self.accept if cid==201 else self.dismiss)()
    def onAction(self,action):
        if action.getId() in (10,92,216,247):self.close();self.dismiss()

class UpNextWatcher:
    def __init__(self,profile):
        self.profile=Path(profile);self.player=xbmc.Player();self.digest=None;self.ready=None;self.window=None;self.dismissed=False;self.lock=threading.Lock()
        from lib.smart_credits import CreditsMemory
        self.credits_memory=CreditsMemory(profile);self.credits_recorded=False
    def close(self):
        if self.window:
            try:self.window.close()
            except Exception:pass
        self.window=None
    def current_digest(self):
        try:
            from source_probe import error_video
            if error_video(self.player.getPlayingFile()):return None
            return hashlib.sha256(self.player.getPlayingFile().encode()).hexdigest() if self.player.isPlayingVideo() else None
        except Exception:return None
    def load(self,digest):
        try:
            # Resolve only a playback entry belonging to this addon and this URL.
            stream={}
            for attempt in range(5):
                if self.current_digest()!=digest:return
                key=Store(self.profile/'playback-context').load().get('key')
                stream=(Store(self.profile/'streams').load().get('urls') or {}).get(key) or {}
                if hashlib.sha256(str(stream.get('url','')).encode()).hexdigest()==digest:break
                time.sleep(0.25)
            if stream.get('kind')!='series' or hashlib.sha256(str(stream.get('url','')).encode()).hexdigest()!=digest:return
            from lib import backend as api
            meta=api.metadata(stream.get('meta') or {})
            from lib.skip_segments import fetch_segments
            credits=next((x for x in fetch_segments(self.profile,'series',stream.get('id')) if x.get('type')=='outro'),None)
            row=following_episode(meta.get('videos'),stream.get('id'))
            with self.lock:
                if self.digest==digest and row:self.ready=(meta,row,credits,stream.get('id'))
        except Exception:pass
    def hide(self):self.dismissed=True;self.close()
    def play(self,digest,meta,row):
        self.hide()
        def choose():
            try:
                from lib import backend as api
                from lib.ui_dialogs import dialog
                rows,_,_=api.source_rows(meta,row['id'])
                if self.current_digest()!=digest:return
                from lib.source_preferences import preferences,rank_rows,limit_quality,picker_filters
                from lib.stream_presenter import filter_rows
                prefs=preferences(get_addon())
                rows=filter_rows(rank_rows(limit_quality(rows,prefs['maximum']),prefs),*picker_filters(get_addon()))
                if not rows:dialog().notification('Up Next','No sources match your device preferences and filters.');return
                from lib.stream_presenter import presentation
                from lib.auto_source import select
                mode, best, _ = select(rows, get_addon(), meta)
                if mode == 2:
                    from source_probe import unavailable
                    try:limit=(3,5,10,25)[int(get_addon().getSetting('auto_source_attempts') or '1')]
                    except (ValueError,IndexError):limit=5
                    for _ in range(limit):
                        if best is None or self.current_digest()!=digest:break
                        if not unavailable(best['url']):
                            api.play(meta,row['id'],best)
                            return
                        failed_url=best['url']
                        for source in rows:
                            if source.get('url')==failed_url:source['_session_failed']=True
                        _, best, _ = select(rows, get_addon(), meta)
                    dialog().notification('Up Next','Automatic sources were unavailable. Choose a source manually from the episode page.')
                    return
                preselect = rows.index(best) if best in rows else 0
                index = preselect if mode == 2 and best is not None else dialog().select('Next episode — choose a source',[presentation(r)['title'] for r in rows], preselect=preselect)
                if index>=0 and self.current_digest()==digest:api.play(meta,row['id'],rows[index])
            except Exception:
                from lib.ui_dialogs import dialog
                dialog().notification('Up Next','Could not load the next episode.')
        threading.Thread(target=choose,daemon=True).start()
    def tick(self):
        if get_addon().getSetting('up_next_enabled')=='false':self.close();return
        digest=self.current_digest()
        if digest!=self.digest:
            self.close();self.digest=digest;self.ready=None;self.dismissed=False;self.credits_recorded=False
            if digest:threading.Thread(target=self.load,args=(digest,),daemon=True).start()
        if not digest or self.dismissed or not self.ready:return
        try:
            position=self.player.getTime();duration=self.player.getTotalTime()
        except Exception:return
        meta,row,credits,identity=self.ready
        try:lead=(60,120,180,300)[int(get_addon().getSetting('up_next_lead') or '0')]
        except (ValueError,IndexError):lead=60
        from lib.smart_credits import marker_start
        start=marker_start(credits,duration)
        smart=get_addon().getSetting('up_next_smart')!='false'
        if smart and not self.credits_recorded and start is not None and position>=start:
            try:self.credits_memory.observe(identity,duration,credits,position)
            except Exception:pass
            self.credits_recorded=True
        threshold,_=self.credits_memory.timing(identity,duration,credits,lead,smart)
        if duration<=120 or not threshold<=position<duration:self.close();return
        if self.window:return
        try:
            self.window=themed_window(UpNextWindow,'script-strem4kodi-up-next.xml',ROOT,'Main','1080i',meta=meta,episode=row,accept=lambda:self.play(digest,meta,row),dismiss=self.hide)
            self.window.show()
        except Exception:
            self.dismissed=True;self.close()
