"""Cached credits estimates learned only from observed IntroDB markers."""
import math
import statistics
import threading
import time
from pathlib import Path
from account import Store

_LOCK = threading.RLock()
CHOICES = (None, 30, 60, 120, 180, 300)
LABELS = ('Automatic', '30 seconds', '1 minute', '2 minutes', '3 minutes', '5 minutes')


def series_key(identity):
    value = str(identity or '').split(':')[0]
    return value if value.startswith('tt') and value[2:].isdigit() else ''


def marker_start(credits, duration):
    try:
        start, end = float(credits['start']), float(credits['end'])
        if all(math.isfinite(x) for x in (duration, start, end)) and duration > 120 and duration / 2 <= start < end <= duration + 10:
            return start
    except (TypeError, ValueError, KeyError):pass
    return None


class CreditsMemory:
    def __init__(self, profile):self.store = Store(Path(profile) / 'smart-credits')

    def _load(self):
        try:
            data = self.store.load()
            if not isinstance(data, dict):return {}
            clean = {}
            for key, row in data.items():
                if series_key(key) != key or not isinstance(row, dict):continue
                samples = row.get('samples')
                samples = samples if isinstance(samples, dict) else {}
                clean[key] = {'override':row.get('override') if row.get('override') in CHOICES else None,
                              'updated':row.get('updated',0) if isinstance(row.get('updated',0),(int,float)) and math.isfinite(row.get('updated',0)) else 0,
                              'samples':{k:v for k,v in samples.items() if series_key(k)==key and isinstance(v,dict)
                              and all(isinstance(v.get(n),(int,float)) and math.isfinite(v[n]) for n in ('duration','lead'))}}
            return clean
        except Exception:return {}

    def override(self, identity):
        value = self._load().get(series_key(identity), {}).get('override')
        return value if value in CHOICES[1:] else None

    def set_override(self, identity, value):
        key = series_key(identity)
        if not key or value not in CHOICES:return
        with _LOCK:
            data = self._load()
            row=data.setdefault(key,{})
            row['override']=value
            row['updated']=time.time()
            self.store.save(data)

    def observe(self, identity, duration, credits, position):
        key = series_key(identity)
        start = marker_start(credits, duration)
        try:confidence = float(credits.get('confidence') or 0)
        except (TypeError, ValueError, AttributeError):return False
        # Do not learn from abandoned playback, weak markers, or extreme tails.
        if not key or start is None or position < start or not math.isfinite(confidence) or confidence < .8:return False
        lead = duration - start
        if not 20 <= lead <= min(600, duration * .35):return False
        with _LOCK:
            data = self._load()
            row = data.setdefault(key, {})
            samples = row.setdefault('samples', {})
            sample = {'duration':round(duration), 'lead':round(lead)}
            if all(samples.get(identity,{}).get(k)==v for k,v in sample.items()):return False
            sample['updated']=time.time()
            samples.pop(identity, None)
            samples[identity] = sample
            row['samples'] = dict(list(samples.items())[-24:])
            # Bound local storage while retaining explicit overrides.
            while len(data) > 200:
                removable = next((k for k, v in data.items() if not v.get('override') and k != key), None)
                if removable is None:break
                del data[removable]
            self.store.save(data)
        return True

    def merge(self, incoming):
        """Merge per-field timestamps, including Automatic override tombstones."""
        from lib.credits_sync import merge
        with _LOCK:
            data=merge(self._load(),incoming)
            self.store.save(data)
            return data

    def snapshot(self):
        with _LOCK:return self._load()

    def estimate(self, identity, duration):
        samples = self._load().get(series_key(identity), {}).get('samples', {})
        season = ':'.join(str(identity).split(':')[:2]) + ':'
        candidates = [(k, v) for k, v in samples.items()
                      if k != identity and isinstance(v, dict) and .75 * duration <= v.get('duration', 0) <= 1.25 * duration
                      and 20 <= v.get('lead', 0) <= min(600, duration * .35)]
        same_season = [v['lead'] for k, v in candidates if k.startswith(season)]
        leads = same_season if len(same_season) >= 3 else [v['lead'] for k, v in candidates]
        if len(leads) < 3:return None
        middle = statistics.median(leads)
        # Highly inconsistent editions/episodes keep the global fallback.
        if statistics.median(abs(v-middle) for v in leads) > max(30, middle * .4):return None
        return round(middle)

    def timing(self, identity, duration, credits, fallback, smart=True):
        start = marker_start(credits, duration)
        if start is not None:return start, 'IntroDB credits'
        lead = self.override(identity)
        source = 'Series timing'
        if lead is None and smart:
            lead = self.estimate(identity, duration)
            source = 'Estimated credits'
        if lead is None:lead, source = fallback, 'Fallback timing'
        return max(duration / 2, duration - lead), source


def choose_timing(profile, identity, title):
    from lib.ui_dialogs import dialog
    memory = CreditsMemory(profile)
    value = memory.override(identity)
    selected = dialog().select('Up Next timing · ' + str(title or 'This series'), list(LABELS), preselect=CHOICES.index(value))
    if selected >= 0:memory.set_override(identity, CHOICES[selected])
