"""Names for the active Kodi audio track, never inferred from a release name."""
import re

FORMATS = {
    'ac3': 'Dolby Digital', 'eac3': 'Dolby Digital Plus',
    'eac3_ddp_atmos': 'Dolby Digital Plus / Dolby Atmos',
    'truehd': 'Dolby TrueHD', 'truehd_atmos': 'Dolby TrueHD / Dolby Atmos',
    'dca': 'DTS', 'dts': 'DTS', 'dtshd_ma': 'DTS-HD Master Audio',
    'dtshd_hra': 'DTS-HD High Resolution', 'dtshd_ma_x': 'DTS-HD Master Audio / DTS:X',
    'dtshd_ma_x_imax': 'DTS-HD Master Audio / DTS:X IMAX',
    'aac': 'AAC', 'aac_lc': 'AAC', 'he_aac': 'HE-AAC', 'he_aac_v2': 'HE-AAC v2',
    'flac': 'FLAC', 'vorbis': 'Vorbis', 'opus': 'Opus', 'mp3': 'MP3',
    'mp2': 'MPEG Audio', 'alac': 'Apple Lossless',
}


def clean(value):
    return re.sub(r'[\x00-\x1f\x7f\[\]]', '', str(value or '')).strip()


def audio_description(track, language_name=None, active_codec=''):
    track = track if isinstance(track, dict) else {}
    codec = clean(track.get('codec')).lower()
    # Some Kodi builds expose the extension in the infolabel but only the base
    # codec over JSON-RPC. Enrich only when both describe the same base format.
    active = clean(active_codec).lower()
    if active in FORMATS and active.startswith(codec + '_') and codec:
        codec = active
    format_name = FORMATS.get(codec)
    if not format_name:
        format_name = 'PCM' if codec.startswith('pcm_') else codec.upper() or 'Format unknown'
    language = clean(track.get('language'))
    if language.lower() in ('', 'und', 'unk', 'unknown'):
        language = 'Language unknown'
    elif language_name:
        try:
            language = clean(language_name(language)) or language
        except Exception:
            pass
    try:
        channels = int(track.get('channels') or 0)
    except (ValueError, TypeError):
        channels = 0
    channels_label = {1: 'Mono', 2: 'Stereo', 6: '5.1', 8: '7.1'}.get(channels)
    if not channels_label and channels > 0:
        channels_label = '{} channels'.format(channels)
    parts = [language, format_name]
    if channels_label:
        parts.append(channels_label)
    name = clean(track.get('name'))
    # A track title is useful for commentary/accessibility and optional Atmos
    # hints, but is not proof that Kodi detected an object-audio extension.
    if name and name.lower() not in (language.lower(), format_name.lower()):
        parts.append('Track: ' + name)
    return ' | '.join(parts)


class FinishEstimate:
    """Hold sub-second jitter steady; still follow pauses, seeks and buffering."""
    def __init__(self):
        self.value = None

    def update(self, now, duration, position, speed=1):
        if duration <= 0 or speed < 0 or speed > 1:
            self.value = None
            return None
        candidate = now + max(0, duration - position)
        if self.value is None or abs(candidate - self.value) > 2:
            self.value = candidate
        return self.value
