"""Bounded local request summaries. Never persist URLs, queries or exception messages."""
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit
from account import Store, AccountError
from provider_roles import key, name

_lock = threading.RLock()
_profile = None
_providers = []
_rows = {}
_saved = 0
_FAILURE_REASONS = frozenset((
    'Request timed out', 'Server address could not be resolved',
    'Server certificate could not be verified', 'Secure connection failed',
    'Connection to server failed', 'Addon returned invalid JSON',
    'Addon response is too large', 'Addon returned an invalid response',
    'Addon returned an error', 'Request failed',
))


def configure(profile, providers):
    global _profile, _providers, _rows, _saved
    with _lock:
        root = Path(profile) / 'diagnostics'
        if root != _profile:
            _profile, _rows, _saved = root, {}, 0
        _providers = [(p.get('transportUrl', '')[:-len('/manifest.json')], key(p), name(p))
                      for p in providers if str(p.get('transportUrl', '')).endswith('/manifest.json')]


def classify(url):
    for base, identity, label in sorted(_providers, key=lambda r: len(r[0]), reverse=True):
        if not url.startswith(base + '/'):
            continue
        tail = url[len(base) + 1:]
        resource = tail.split('/', 1)[0]
        if resource == 'manifest.json':
            resource = 'manifest'
        if resource in ('catalog', 'meta', 'stream', 'subtitles', 'manifest'):
            return identity + ':' + resource, label, resource
    parsed = urlsplit(url)
    if parsed.hostname == 'v3-cinemeta.strem.io':
        resource = parsed.path.lstrip('/').split('/', 1)[0]
        if resource in ('catalog', 'meta', 'manifest.json'):
            return 'cinemeta:' + resource, 'Cinemeta', resource.replace('.json', '')
    return None


def record(url, started, status, http=None, reason=None):
    global _saved
    with _lock:
        if _profile is None:
            return
        source = classify(url)
        if source is None or status not in ('refreshed', 'cached', 'failed'):
            return
        identity, label, resource = source
        now = time.time()
        previous = _rows.get(identity, {})
        row = {'provider': label, 'resource': resource, 'status': status, 'checked': now,
               'ms': max(0, min(1800000, int((time.monotonic() - started) * 1000)))}
        if status == 'refreshed':
            row['refreshed'] = now
        elif previous.get('refreshed'):
            row['refreshed'] = previous['refreshed']
        if status == 'failed':
            row['reason'] = ('HTTP {}'.format(http) if isinstance(http, int) and 100 <= http <= 599
                             else reason if reason in _FAILURE_REASONS else 'Request failed')
        _rows[identity] = row
        if len(_rows) > 48:
            del _rows[min(_rows, key=lambda k: _rows[k]['checked'])]
        # Do not fsync for every cache read or fan out extra work during startup.
        if status == 'failed' or now - _saved >= 15:
            Store(_profile).save({'requests': list(_rows.values())})
            _saved = now


def rows(profile):
    with _lock:
        try:
            saved = Store(Path(profile) / 'diagnostics').load().get('requests') or []
        except AccountError:
            saved = []
        current = list(_rows.values()) if _profile == Path(profile) / 'diagnostics' else []
        merged = {(r.get('provider'), r.get('resource')): r for r in saved if isinstance(r, dict)}
        merged.update({(r['provider'], r['resource']): dict(r) for r in current})
        return sorted(merged.values(), key=lambda r: r.get('checked', 0), reverse=True)[:48]
