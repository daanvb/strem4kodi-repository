"""Community disc-release hints, never proof of a stream's enhancement layer.

Source: https://github.com/Appz4Fun/fel-dolby-vision-movies
Only movie IDs are retained. Refreshes run in the background at most weekly.
"""
import json
import re
import threading
import time
from pathlib import Path
from urllib.request import urlopen

URL='https://raw.githubusercontent.com/Appz4Fun/fel-dolby-vision-movies/main/data/releases.json'
_ids=set()
_lock=threading.Lock()
_busy=False
_retry=0
_loaded=None

def movie_ids(releases):
    return {r['imdb_id'] for r in releases if isinstance(r,dict) and
            r.get('fel_confirmed') is True and r.get('media_type')=='movie' and
            re.fullmatch(r'tt\d+',str(r.get('imdb_id','')))}

def request(profile):
    global _ids,_busy,_retry,_loaded
    path=Path(profile)/'fel-catalog.json'
    with _lock:
        saved=0
        if _loaded!=path:
            _loaded=path
            try:
                data=json.loads(path.read_text(encoding='utf-8'))
                _ids={x for x in data['ids'] if re.fullmatch(r'tt\d+',str(x))}
                saved=float(data['updated'])
            except (OSError,ValueError,KeyError,TypeError):
                _ids=set()
        else:
            try:saved=path.stat().st_mtime
            except OSError:pass
        if _busy or time.time()-saved<7*86400 or time.time()<_retry:return
        _busy=True
        _retry=time.time()+3600
    def refresh():
        global _ids,_busy
        try:
            with urlopen(URL,timeout=8) as response:
                raw=response.read(8*1024*1024+1)
            if len(raw)>8*1024*1024:return
            releases=json.loads(raw)
            if not isinstance(releases,list):return
            ids=movie_ids(releases)
            if not ids:return
            path.parent.mkdir(parents=True,exist_ok=True)
            temporary=path.with_suffix('.tmp')
            temporary.write_text(json.dumps({'updated':time.time(),'ids':sorted(ids)}),encoding='utf-8')
            temporary.replace(path)
            with _lock:_ids=ids
        except (OSError,ValueError,TypeError):pass
        finally:
            with _lock:_busy=False
    threading.Thread(target=refresh,daemon=True).start()

def badge(row):
    # Filename/provider text is a claim, including when it says "verified".
    card=row.get('card') if isinstance(row.get('card'),dict) else {}
    text=' '.join(str(row.get(k) or '') for k in ('label','detail','name','title','filename')).upper()
    text+=' '+str(card.get('filename') or '').upper()+' '+str(card.get('tech') or '').upper()
    text=text.replace('_',' ')
    profile=row.get('dolbyVisionProfile') or row.get('dvProfile')
    layer=str(row.get('enhancementLayer') or row.get('dvEnhancementLayer') or '').upper()
    if str(profile) == '7':text+=' PROFILE 7'
    if layer in ('FEL','MEL'):text+=' '+layer
    text=re.sub(r'(?:HTTPS?|PLUGIN|MAGNET)://\S+','',text)
    fel=bool(re.search(r'\bFEL(?:[ ._-]*7)?\b|\bP7[ ._-]*FEL\b',text))
    p7=bool(re.search(r'\b(?:P(?:ROFILE)?[ ._-]*7|DVHE[ ._-]*07)\b',text))
    if fel and not re.search(r'\b(?:MEL|P8|PROFILE[ ._-]*8)\b|FEL[ ._-]*(?:REMOVED|STRIPPED|BAKED)',text):
        return 'P7 FEL reported' if p7 or 'FEL7' in text or 'FEL 7' in text else 'FEL reported'
    if p7 and not re.search(r'\b(?:P8|PROFILE[ ._-]*8)\b',text):return 'P7 MEL reported' if re.search(r'\bMEL\b',text) else 'P7 reported; FEL unknown'
    with _lock:known=row.get('_fel_movie_id') in _ids
    return 'FEL disc available; stream unverified' if known else ''
