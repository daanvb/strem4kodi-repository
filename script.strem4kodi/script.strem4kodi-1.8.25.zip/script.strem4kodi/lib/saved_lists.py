"""Account-scoped Favourite/Watchlist tags; Stremio owns saved membership."""
import hashlib
import math
import re
import sqlite3
import time
from contextlib import closing
from pathlib import Path

ROLES = ('watchlist', 'favourite')


def clean(data):
    out = {}
    if not isinstance(data, dict):
        return out
    for identity, roles in data.items():
        if not isinstance(identity, str) or not re.fullmatch(r'(movie|series):[A-Za-z0-9_.:-]{1,200}', identity) or not isinstance(roles, dict):
            continue
        row = {}
        for role in ROLES:
            value = roles.get(role)
            if not isinstance(value, dict) or not isinstance(value.get('value'), bool):
                continue
            stamp = value.get('updated')
            if isinstance(stamp, bool) or not isinstance(stamp, (int, float)) or not math.isfinite(stamp) or stamp < 0:
                continue
            row[role] = {'value': value['value'], 'updated': stamp}
        if row:
            out[identity] = row
    return out


def merge(left, right):
    out = clean(left)
    for identity, roles in clean(right).items():
        row = out.setdefault(identity, {})
        for role, value in roles.items():
            previous = row.get(role)
            # Equal timestamps resolve to removal on every device.
            if previous is None or (value['updated'], not value['value']) > (previous['updated'], not previous['value']):
                row[role] = value
    return out


class SavedLists:
    def __init__(self, profile, token):
        scope = hashlib.sha256(str(token or '').encode()).hexdigest()
        directory = Path(profile) / 'saved-list-tags' / scope
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / 'tags.sqlite'
        with closing(self.connect()) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS tags (identity TEXT, role TEXT, value INTEGER, updated REAL, PRIMARY KEY(identity, role))')

    def connect(self):
        return sqlite3.connect(str(self.path), timeout=5)

    def key(self, meta):
        return str(meta.get('type')) + ':' + str(meta.get('_id') or meta.get('id'))

    def _snapshot(self, db):
        out = {}
        for identity, role, value, stamp in db.execute('SELECT identity, role, value, updated FROM tags'):
            out.setdefault(identity, {})[role] = {'value': bool(value), 'updated': stamp}
        return out

    def snapshot(self):
        with closing(self.connect()) as db:
            return self._snapshot(db)

    def merge(self, remote):
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            out = merge(self._snapshot(db), remote)
            db.executemany('INSERT OR REPLACE INTO tags VALUES (?, ?, ?, ?)',
                           [(identity, role, int(value['value']), value['updated']) for identity, roles in out.items() for role, value in roles.items()])
            return out

    def _roles(self, meta, saved, snapshot):
        if not saved:
            return {role: False for role in ROLES}
        row = snapshot.get(self.key(meta), {})
        return {role: bool(row.get(role, {}).get('value', role == 'watchlist')) for role in ROLES}

    def roles(self, meta, saved):
        return self._roles(meta, saved, self.snapshot())

    def set_role(self, meta, role, enabled, previously_saved):
        if role not in ROLES:
            raise ValueError('Unknown saved list')
        return self.set_roles(meta, {role: bool(enabled)}, previously_saved)

    def set_roles(self, meta, values, previously_saved):
        if not values or any(role not in ROLES for role in values):
            raise ValueError('Unknown saved list')
        identity = self.key(meta)
        if not clean({identity: {role: {'value': bool(value), 'updated': 0} for role, value in values.items()}}):
            raise ValueError('Unsupported saved title identity')
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            now = time.time()
            latest = db.execute('SELECT MAX(updated) FROM tags WHERE identity=?', (identity,)).fetchone()[0] or 0
            now = max(now, latest + .000001)
            db.executemany('INSERT OR IGNORE INTO tags VALUES (?, ?, ?, ?)',
                           [(identity, name, int(previously_saved and name == 'watchlist'), now) for name in ROLES])
            db.executemany('INSERT OR REPLACE INTO tags VALUES (?, ?, ?, ?)', [(identity, role, int(value), now) for role, value in values.items()])

    def entries(self, entries, role):
        if role not in ROLES:
            raise ValueError('Unknown saved list')
        snapshot = self.snapshot()
        return [row for row in entries if not row.get('removed') and not row.get('temp') and self._roles(row, True, snapshot)[role]]
