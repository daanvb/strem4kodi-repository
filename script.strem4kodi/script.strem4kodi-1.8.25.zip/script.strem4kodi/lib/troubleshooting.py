"""Readable local status, using fixed fields rather than raw logs."""
import time


def age(timestamp):
    if not isinstance(timestamp, (int, float)) or timestamp <= 0:
        return 'Not recorded'
    minutes = max(0, int((time.time() - timestamp) / 60))
    return 'Just now' if minutes == 0 else '{} min ago'.format(minutes)


def info(label, value, help_text):
    return {'kind': 'info', 'label': label, 'summary': value, 'help': help_text}


def benchmark_summary(result):
    labels = {'benchmark.cached_home': 'Cached Home', 'benchmark.snapshot_load': 'Catalogue snapshot',
              'benchmark.continue_index': 'Continue Watching', 'benchmark.account_load': 'Account data',
              'benchmark.stream_cache': 'Source cache'}
    return '\n'.join('{}: {} ms'.format(labels.get(stage, stage), ms)
                     for stage, ms in result['metrics'].items()) + '\n\nLocal cached browsing only; network refresh and video loading are separate.'


def player_rows(kodi, gui):
    skin = kodi.getSkinDir()
    playing = bool(kodi.Player().isPlayingVideo())
    owned = gui.Window(10000).getProperty('strem4kodi.player.active') == 'true'
    return [info('Player appearance', 'Strem4Kodi' if skin == 'skin.strem4kodi' else 'Kodi skin',
                 'The companion skin supplies the customised player. Current skin: ' + skin),
            info('Playback controls', 'Active' if playing and owned else ('Other playback' if playing else 'Idle'),
                 'Only videos started by Strem4Kodi use its player controls. Live TV retains the Kodi controls.'),
            info('Player check', 'Device check required',
                 'During a video, open Audio, Subtitles and Settings. Back should close each menu. Seek left/right, pause/resume and wait for controls to hide. Confirm the scrub handle sits on the progress line. Automated checks cannot confirm remote focus or rendering.')]


def settings_rows(profile):
    from lib.perf_report import load, startup_measurements
    from lib.provider_diagnostics import rows as requests
    timings = load(profile)
    launches = startup_measurements(profile)
    help_text = 'Time from opening Strem4Kodi until Home is visible; excludes Kodi boot. Values are medians of recent launches. Sign-in and prompts can add time. '
    rows = [info('First launch after Kodi starts', '{:.2f} seconds'.format(launches['first'] / 1000)
                 if 'first' in launches else 'Not recorded',
                 help_text + 'Restart Kodi and open Strem4Kodi to record this measurement.'),
            info('Repeat app launch', '{:.2f} seconds'.format(launches['repeat'] / 1000)
                 if 'repeat' in launches else 'Not recorded',
                 help_text + 'Close and reopen Strem4Kodi without restarting Kodi.'),
            info('Background Home refresh', '{:.2f} seconds'.format(timings['ui.home.background.total']['ms'] / 1000)
                 if timings.get('ui.home.background.total', {}).get('ms') is not None else 'Not recorded',
                 'Provider catalogue refresh runs after Home is usable. This duration is separate from startup.'),
            {'kind': 'action', 'action': 'startup_benchmark', 'label': 'Measure cached browsing',
             'summary': 'Run checks', 'help': 'Measure local Home, snapshots and caches on this device. Makes no network requests and does not upload results.'}]
    try:
        import xbmc
        import xbmcgui
        rows.extend(player_rows(xbmc, xbmcgui))
    except (ImportError, AttributeError):
        pass
    history = requests(profile)
    for request in history:
        status = {'refreshed': 'Updated', 'cached': 'Cached', 'failed': 'Failed'}.get(request.get('status'), 'Unknown')
        rows.append(info(request.get('provider', 'Add-on') + ' · ' + request.get('resource', 'Request'), status,
                         'Checked: ' + age(request.get('checked')) + '. Last network refresh: ' +
                         age(request.get('refreshed')) + '. Request: {} ms. '.format(request.get('ms', 0)) +
                         request.get('reason', 'No error reported.') +
                         ' Local request summary only; private configuration links and search text are excluded.'))
    if not history:
        rows.append(info('Provider requests', 'No requests recorded', 'Browse, search or choose a source, then return here for request status.'))
    return rows
