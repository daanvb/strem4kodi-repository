"""Reveal applicable controls without modifying hidden saved preferences."""


def applicable(rows, get_setting):
    result = []
    for row in rows:
        identity = row.get('id', '')
        parent = None
        if identity == 'startup_delay': parent = 'startup_autostart'
        elif identity.startswith('trailers_') and identity != 'trailers_enabled':
            parent = 'trailers_auto' if identity in ('trailers_auto_scope', 'trailers_delay') else 'trailers_enabled'
        elif identity.startswith('introdb_') and identity != 'introdb_enabled': parent = 'introdb_enabled'
        elif identity.startswith('up_next_') and identity != 'up_next_enabled': parent = 'up_next_enabled'
        elif identity.startswith('episode_rating_'): parent = identity.replace('episode_', '', 1)
        if parent and get_setting(parent).lower() == 'false':
            continue
        if identity.startswith(('auto_movie_', 'auto_series_', 'auto_animation_')) and not identity.endswith('_mode'):
            if get_setting(identity.rsplit('_', 1)[0] + '_mode') in ('', '0'):
                continue
        if identity == 'auto_source_attempts' and not any(get_setting('auto_' + scope + '_mode') == '2' for scope in ('movie', 'series', 'animation')):
            continue
        if identity in ('ai_subtitles_source', 'ai_subtitles_target') and get_setting('ai_subtitles_enabled').lower() != 'true':
            continue
        result.append(row)
    return result
