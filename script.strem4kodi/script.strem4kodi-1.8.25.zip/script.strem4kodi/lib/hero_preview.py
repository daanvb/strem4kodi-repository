"""Keep only an owned trailer in its original browsing window."""


def keep_windowed(kodi, gui, player, url, window_id):
    try:
        if not url or not isinstance(window_id, int) or window_id == 12005:
            return False
        if (gui.getCurrentWindowId() != 12005 or gui.getCurrentWindowDialogId() not in (0, -1)
                or not player.isPlayingVideo() or player.getPlayingFile() != url):
            return False
        kodi.executebuiltin('ActivateWindow({})'.format(window_id))
        return True
    except Exception:
        return False
