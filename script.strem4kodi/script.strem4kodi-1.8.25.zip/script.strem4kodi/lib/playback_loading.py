"""Attempt-bound playback loading screen; never stores stream URLs."""
import json
import threading
import time
from lib.stream_presenter import line

CANCEL_KEY='strem4kodi.playback.cancelled'

def cancelled(attempt):
    if not attempt:return False
    import xbmcgui
    try:return attempt in json.loads(xbmcgui.Window(10000).getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):return False

def signal_cancel(attempt):
    if not attempt:return
    import xbmcgui
    window=xbmcgui.Window(10000)
    try:rows=json.loads(window.getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):rows=[]
    if not isinstance(rows,list):rows=[]
    window.setProperty(CANCEL_KEY,json.dumps((rows+[attempt])[-16:]))

def _make_window(title,detail,on_cancel):
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window as themed_window
    class LoadingWindow(xbmcgui.WindowXMLDialog):
        def onInit(self):
            self.setProperty('loading_title',title)
            self.setProperty('loading_detail',detail)
            self.setFocusId(201)
        def onAction(self,action):
            if action.getId() in (10,92,216,247):on_cancel()
        def onClick(self,control_id):
            if control_id==201:on_cancel()
    return themed_window(LoadingWindow,'script-strem4kodi-loading.xml',
                         get_addon().getAddonInfo('path'),'Main','1080i')

class LoadingSession:
    def __init__(self,on_cancel,factory=_make_window,state=None,ready=None,clock=time.monotonic):
        self.on_cancel=on_cancel;self.factory=factory
        self.lock=threading.RLock();self.attempt='';self.window=None
        self.state=state;self.ready=ready;self.clock=clock
        self.created=0;self.wake=threading.Event()
    def begin(self,attempt,title,detail=''):
        with self.lock:
            self.finish()
            self.attempt=attempt
            self.created=self.clock();self.wake=threading.Event()
            try:
                self.window=self.factory(line(title,110),line(detail,140),lambda:self.cancel(attempt))
                self.window.show()
                if self.state is not None:
                    threading.Thread(target=self._watch,args=(attempt,self.wake),daemon=True).start()
            except Exception:
                self.finish(attempt)
    def _watch(self,attempt,wake):
        """Keep overlay cleanup independent of the media-details refresh thread."""
        while not wake.wait(.2):
            try:
                pending=self.state()
                ready=bool(self.ready and self.ready())
                self.check(attempt,pending,ready)
            except Exception:
                # Even unavailable player/state queries cannot strand the dialog.
                self.check(attempt,{'attempt':attempt,'started':False})
    def check(self,attempt,pending,ready=False):
        with self.lock:
            if self.attempt!=attempt:return
            if ready or self.clock()-self.created>=50:
                self.finish(attempt)
            else:self.observe(pending)
    def cancel(self,attempt):
        with self.lock:
            if self.attempt!=attempt:return
            signal_cancel(attempt)
            self.finish(attempt)
            self.on_cancel()
    def observe(self,pending):
        with self.lock:
            if self.attempt and (not pending or pending.get('attempt')!=self.attempt or pending.get('started')):
                self.finish(self.attempt)
    def finish(self,attempt=None):
        with self.lock:
            if attempt is not None and self.attempt!=attempt:return
            window=self.window;self.window=None;self.attempt=''
            self.wake.set()
            if window:
                try:window.close()
                except Exception:pass
