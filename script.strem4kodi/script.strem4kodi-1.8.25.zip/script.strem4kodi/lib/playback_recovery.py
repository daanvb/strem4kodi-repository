"""Session-only recovery for explicitly selected sources; no URL logging/storage."""
import hashlib
import threading
import time
import uuid

def digest(url):
    return hashlib.sha256(str(url).encode('utf-8')).hexdigest()

class RecoveryTracker:
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.lock=threading.RLock();self.pending=None;self.event=None
    def arm(self,url,identity,resume_ms,window):
        with self.lock:
            self.event=None
            self.pending={'hash':digest(url),'identity':identity,'resume':resume_ms,
                          'window':window,'created':self.clock(),'started':False,'attempt':uuid.uuid4().hex}
            return self.pending['attempt']
    def poll_failure(self, profile):
        from pathlib import Path
        if not isinstance(profile, (str, Path)):return
        with self.lock:
            if not self.pending:return
            from account import Store
            try:row = Store(Path(profile)/'source-failure').load()
            except Exception:return
            if row.get('hash') == self.pending['hash'] and row.get('attempt') == self.pending['attempt']:
                self.event = dict(self.pending)
                self.pending = None
    def startup_timeout(self):
        with self.lock:
            if self.pending and not self.pending['started'] and self.clock()-self.pending['created']>45:
                self.event=dict(self.pending)
                self.pending=None
    def started(self,url):
        with self.lock:
            if self.pending:
                attempt=self.pending['attempt']
                if digest(url)!=self.pending['hash']:self.pending=None
                else:self.pending['started']=True
                return attempt
    def snapshot(self):
        with self.lock:
            return dict(self.pending) if self.pending else None
    def position(self,url,seconds):
        with self.lock:
            if self.pending and digest(url)==self.pending['hash']:
                self.pending['resume']=max(0,int(seconds*1000))
    def failed(self):
        with self.lock:
            if self.pending and (self.pending['started'] or self.clock()-self.pending['created']<120):
                self.event=dict(self.pending)
            self.pending=None
    def stopped(self):
        with self.lock:self.pending=None
    def take(self):
        with self.lock:
            event=self.event;self.event=None;return event
    def clear(self):
        with self.lock:self.pending=None;self.event=None

def player(tracker, profile=None, on_started=None):
    import xbmc
    class RecoveryPlayer(xbmc.Player):
        def onAVStarted(self):
            try:
                from source_probe import error_video
                if error_video(self.getPlayingFile()):
                    tracker.failed();self.stop()
                else:
                    attempt=tracker.started(self.getPlayingFile())
                    if attempt and on_started:on_started(attempt)
            except Exception:tracker.stopped()
        def onPlayBackError(self):tracker.failed()
        def onPlayBackStopped(self):
            tracker.poll_failure(profile)
            tracker.stopped()
        def onPlayBackEnded(self):tracker.stopped()
    return RecoveryPlayer()
