from addon_state import get_addon
import xbmcgui
from lib.nimbus import HomeWindow, InfoWindow
from lib.theme import window as themed_window

ADDON = get_addon()
ADDON_PATH = ADDON.getAddonInfo('path')
SKIN = 'Main'
RES = '1080i'
SESSION_WINDOW_ID = 10000
APP_RUNNING = 'stremioforkodi.running'


def run(started=None):
    from lib.perf_trace import now, log
    started = now() if started is None else started
    from lib.launch_guard import LaunchGuard, mark_window, unmark_window
    guard = LaunchGuard()
    if not guard.acquire():
        return
    from lib.perf_report import begin_launch
    session = xbmcgui.Window(SESSION_WINDOW_ID)
    begin_launch(session.getProperty('strem4kodi.startup.seen') != 'true')
    session.setProperty('strem4kodi.startup.seen', 'true')
    confirmed_exit = False
    closing_window_id = None
    try:
        from lib.signin import signed_in, show_signin
        if not signed_in() and not show_signin():
            return
        import xbmcvfs
        from lib import backend
        from lib.home_layout import build_layout
        from lib.appearance import options
        # Startup is stale-while-revalidate: never hold the UI behind catalog
        # network requests. HomeWindow refreshes account/catalog data in background.
        rows = backend.account_home(False)
        layout_started = now()
        filename, path, count = build_layout(
            ADDON_PATH,
            xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
            max(8, len(rows), backend.account_home_capacity()),
            options(ADDON)
        )
        log('startup.layout', layout_started, profile=xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), rows=count)
        browse_state = None
        while True:
            window = HomeWindow(filename, path, SKIN, RES, account_rows=rows, row_count=count, browse_state=browse_state, launch_started=started)
            mark_window(window, 'home')
            try:
                window.doModal()
                reload_appearance = getattr(window, 'reload_appearance', False)
                browse_state = getattr(window, 'reload_browse_state', None)
                details_request = getattr(window, 'details_request', None)
                confirmed_exit = getattr(window, 'exit_requested', False) is True
                closing_window_id = getattr(window, 'exit_window_id', None)
            finally:
                unmark_window(window)
                del window
            if isinstance(details_request, dict):
                details = themed_window(InfoWindow, 'script-stremio-info.xml',
                                        ADDON_PATH, SKIN, RES, **details_request)
                mark_window(details, 'info')
                try:
                    details.doModal()
                finally:
                    if (getattr(details, 'load_failed', False) is True
                            and isinstance(browse_state, dict)):
                        browse_state['return_status'] = 'Unable to open this title. Please try again.'
                    unmark_window(details)
                    del details
                # Recreate Search from its exact loaded rows and selection.
                # The details WindowXML is fully destroyed first, avoiding the
                # overlapping full-window lifetime that crashes some devices.
                continue
            if not reload_appearance:
                break
            filename, path, count = build_layout(
                ADDON_PATH, xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
                max(8, len(rows), backend.account_home_capacity()), options(ADDON))
    finally:
        try:
            if confirmed_exit:
                # Exit returns to Kodi Home, rather than the addon launcher
                # underneath the modal. Keep the lease until navigation finishes.
                import xbmc
                # doModal can return before Kodi handles its queued native
                # previous-window message. Let that restore the launcher first.
                for _ in range(20):
                    if (xbmcgui.getCurrentWindowId() != closing_window_id
                            and not xbmc.getCondVisibility('System.HasVisibleModalDialog')):
                        break
                    xbmc.sleep(50)
                guard.defer_relaunch()
                xbmc.executebuiltin('ActivateWindow(Home)', True)
        finally:
            guard.release()
