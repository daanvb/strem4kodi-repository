"""Fast IMDb title autocomplete with a Cinemeta fallback."""
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
import re
import unicodedata
from urllib.parse import quote
from protocol import fetch, resource_url

HOME = 'https://v3-cinemeta.strem.io/manifest.json'


def normalized(value):
    value = unicodedata.normalize('NFKD', str(value or '').casefold())
    value = ''.join(c for c in value if not unicodedata.combining(c))
    return ' '.join(re.sub(r"[’']", '', re.sub(r'[^\w\s’\']', ' ', value)).split())


def relevance(query, title):
    key, text = normalized(query), normalized(title)
    if not key or not text:return None
    if key == text:return 0
    if text.startswith(key):return 1
    if key in text:return 2
    words, terms = text.split(), key.split()
    if all(any(word.startswith(term) for word in words) for term in terms):return 3
    # Conservative prefix typo tolerance; never accept mere related-title results.
    if len(key) >= 5 and any(SequenceMatcher(None,key,text[i:i+len(key)]).ratio() >= .82
                             for i in (0,) + tuple(m.end() for m in re.finditer(' ',text))):return 4
    return None


def ranked(query, rows, limit=8):
    output, seen = [], set()
    for row in rows:
        if not isinstance(row,dict) or row.get('type') not in ('movie','series'):continue
        score = relevance(query,row.get('name'))
        key = (row.get('type'),row.get('id'))
        if score is None or not row.get('id') or key in seen:continue
        seen.add(key);output.append((score,len(output),row))
    return [row for _,_,row in sorted(output,key=lambda r:r[:2])][:limit]


def imdb_titles(payload):
    types = {'movie':'movie','tvMovie':'movie','tvSeries':'series','tvMiniSeries':'series'}
    rows=[]
    for row in payload.get('d',[]) if isinstance(payload,dict) else []:
        if not isinstance(row,dict) or row.get('qid') not in types:continue
        if not re.fullmatch(r'tt[0-9]+',str(row.get('id',''))):continue
        image=row.get('i') if isinstance(row.get('i'),dict) else {}
        rows.append({'id':row['id'],'type':types[row['qid']],'name':row.get('l') or '',
                     'year':row.get('y') or '', 'poster':image.get('imageUrl') or ''})
    return rows


def lookup(query, fetcher=None, imdb_fetcher=None):
    term = str(query or '').strip()[:200]
    if len(term) < 2:return []
    imdb_fetcher = imdb_fetcher or (lambda url:fetch(url,timeout=2))
    try:
        rows=ranked(term,imdb_titles(imdb_fetcher('https://v3.sg.media-imdb.com/suggestion/' + quote(term[0].lower(),safe='') + '/' + quote(term,safe='') + '.json')))
        if rows:return rows
    except Exception:pass
    fetcher = fetcher or (lambda url:fetch(url,timeout=3))
    def request(kind):
        try:
            data = fetcher(resource_url(HOME,'catalog',kind,'top',{'search':term}))
            return [dict(row,type=kind) for row in data.get('metas',[])[:40] if isinstance(row,dict) and row.get('type',kind)==kind]
        except Exception:return []
    with ThreadPoolExecutor(max_workers=2) as pool:
        batches = list(pool.map(request,('movie','series')))
    return ranked(term,[row for batch in batches for row in batch])


def entries(query, history, matches=()):
    key = normalized(query)
    rows = [{'query':r['name'],'name':r['name'],
             'subtitle':('Movie' if r['type']=='movie' else 'Series') + (' · '+str(r.get('year') or r.get('releaseInfo') or '')[:14] if r.get('year') or r.get('releaseInfo') else ''),
             'poster':r.get('poster') or '', 'kind':'title'} for r in ranked(query,matches)] if key else []
    seen = {normalized(row['query']) for row in rows}
    for value in history:
        if isinstance(value,str) and (not key or key in normalized(value)) and normalized(value) not in seen:
            rows.append({'query':value,'name':value,'subtitle':'Recent search','poster':'','kind':'recent'})
            seen.add(normalized(value))
    return rows[:5]
