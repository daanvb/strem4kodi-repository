"""Bounded selection-repeat guards; directional navigation and Back stay immediate."""
import time

QUIET = 0.25


def ready(window, clock=time.monotonic):
    window._input_ready_at = clock() + QUIET


def accept(window, token, clock=time.monotonic):
    now = clock()
    deadline = getattr(window, '_input_ready_at', 0)
    if isinstance(deadline, (int, float)) and now < deadline:
        return False
    previous = getattr(window, '_last_activation', None)
    if isinstance(previous, tuple) and previous[0] == token and now - previous[1] < QUIET:
        return False
    window._last_activation = (token, now)
    return True
