"""Keep only an owned trailer in its original browsing window."""


# Kodi Omega returns WINDOW_INVALID (9999) when no modal dialog is active.
# Retain the older sentinel values used by compatible hosts.
NO_DIALOG = (0, -1, 9999)


def can_start(gui, window_id):
    """A delayed preview belongs only to the unobstructed originating window."""
    try:
        return (isinstance(window_id, int) and window_id not in (0, -1, 9999, 12005)
                and gui.getCurrentWindowId() == window_id
                and gui.getCurrentWindowDialogId() in NO_DIALOG)
    except Exception:
        return False


def capture_focus(window):
    """Capture immediately before playback; buttons have no list position."""
    try:
        control = window.getFocusId()
        if type(control) is not int or not 0 < control <= 100000:
            return None
        try:
            position = window.getControl(control).getSelectedPosition()
        except (AttributeError, RuntimeError):
            position = 0
        if type(position) is not int or not 0 <= position <= 100000:
            position = 0
        return control, position
    except Exception:
        return None


def keep_windowed(kodi, gui, player, url, window_id, focus=None):
    try:
        if not url or not isinstance(window_id, int) or window_id in (0, -1, 9999, 12005):
            return False
        if (gui.getCurrentWindowId() != 12005 or gui.getCurrentWindowDialogId() not in NO_DIALOG
                or not player.isPlayingVideo() or player.getPlayingFile() != url):
            return False
        if (isinstance(focus, tuple) and len(focus) == 2 and type(focus[0]) is int
                and type(focus[1]) is int and 0 < focus[0] <= 100000 and 0 <= focus[1] <= 100000):
            # One native operation restores the window AND selection. A later
            # Python SetFocus would race input after the user resumes browsing.
            kodi.executebuiltin('ActivateWindowAndFocus({},{},{},{},{})'.format(
                window_id, focus[0], focus[1], focus[0], focus[1]))
        else:
            kodi.executebuiltin('ActivateWindow({})'.format(window_id))
        return True
    except Exception:
        return False
