"""Kodi adapter for private device setup; runs before allocating the app shell."""
import xbmc
from device_kodi_profile import KODI_DEFAULTS, SKIN_DEFAULTS, TARGET_SKIN, AERIAL_ADDON
from setup_profile import rpc


class KodiBackend:
    def skin(self):
        return xbmc.getSkinDir()

    def get(self, group, name):
        if group == 'skin_settings' and name in SKIN_DEFAULTS:
            if self.skin() != TARGET_SKIN:raise ValueError('Setup skin is not active')
            return bool(xbmc.getCondVisibility('Skin.HasSetting({})'.format(name)))
        if group == 'settings' and name in KODI_DEFAULTS:
            return rpc('Settings.GetSettingValue', {'setting': name})['value']
        raise ValueError('Unsupported setup setting')

    def set(self, group, name, value):
        if group == 'skin_settings' and name in SKIN_DEFAULTS and type(value) is bool:
            if self.skin() != TARGET_SKIN:raise ValueError('Setup skin is not active')
            xbmc.executebuiltin('{}({})'.format('Skin.SetBool' if value else 'Skin.Reset', name), True)
        elif group == 'settings' and name in KODI_DEFAULTS:
            if name == 'screensaver.mode' and value == AERIAL_ADDON:
                if not xbmc.getCondVisibility('System.AddonIsEnabled({})'.format(AERIAL_ADDON)):
                    raise ValueError('Aerial screensaver is not enabled')
            if not rpc('Settings.SetSettingValue', {'setting': name, 'value': value}):
                raise ValueError('Kodi declined the setting')
        else:
            raise ValueError('Unsupported setup setting')
