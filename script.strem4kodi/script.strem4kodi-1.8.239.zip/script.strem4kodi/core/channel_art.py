"""Use explicitly supplied channel artwork without deriving URLs from streams."""
from urllib.parse import urlsplit


def channel_logo(row):
    if not isinstance(row, dict):
        return ''
    channel = row.get('channel')
    channel = channel if isinstance(channel, dict) else {}
    for value in (row.get('channel_logo'), row.get('channelLogo'), channel.get('logo'), row.get('logo')):
        if not isinstance(value, str) or not value or len(value) > 4096 or any(ord(c) < 33 for c in value):
            continue
        try:
            url = urlsplit(value)
            if url.scheme in ('http', 'https') and url.hostname and not url.username and not url.password:
                return value
        except ValueError:
            pass
    return ''
