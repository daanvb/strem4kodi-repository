import runpy
import sys
from pathlib import Path
import xbmc
if len(sys.argv) > 1:
    if sys.argv[1] == 'legacy':
        sys.argv.pop(1)
    runpy.run_path(str(Path(__file__).with_name('legacy_default.py')), run_name='__main__')
else:
    xbmc.executebuiltin('RunScript(script.freebird)')
