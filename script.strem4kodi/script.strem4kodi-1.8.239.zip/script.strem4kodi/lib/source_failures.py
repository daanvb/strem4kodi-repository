"""Local failed-link blacklist. Store hashes only, with no automatic expiry."""
import re
import sqlite3
import time
from pathlib import Path
from contextlib import closing


def _path(profile):
    if not isinstance(profile,(str,Path)):return None
    root=Path(profile)
    return root/'failed-sources.sqlite' if root.is_absolute() and root.is_dir() else None


def _connect(path):
    db=sqlite3.connect(str(path),timeout=.25)
    try:db.execute('CREATE TABLE IF NOT EXISTS failures (hash TEXT PRIMARY KEY, created REAL NOT NULL)')
    except sqlite3.Error:
        db.close()
        raise
    return db


def record(profile,identity):
    path=_path(profile)
    if path is None or not isinstance(identity,str) or not re.fullmatch('[0-9a-f]{64}',identity):return False
    try:
        with closing(_connect(path)) as db, db:
            db.execute('INSERT OR IGNORE INTO failures VALUES (?,?)',(identity,time.time()))
        return True
    except sqlite3.Error:
        return False  # The current attempt still has its in-memory exclusion.


def blocked(profile):
    """None means unreadable: automatic selection must fail closed."""
    path=_path(profile)
    if path is None:return set()
    if not path.exists():
        # Carry forward the last already-confirmed native failure on upgrade.
        try:
            from account import Store
            previous=Store(Path(profile)/'source-failure').load()
            if previous.get('reason') in ('provider-error-video','http-unavailable','playback-error',
                    'playback-stopped','caching-stall','premature-end','startup-timeout'):
                record(profile,previous.get('hash'))
        except Exception:pass
        if not path.exists():return set()
    try:
        with closing(sqlite3.connect(str(path),timeout=.25)) as db:
            return {row[0] for row in db.execute('SELECT hash FROM failures')
                    if isinstance(row[0],str) and re.fullmatch('[0-9a-f]{64}',row[0])}
    except sqlite3.Error:return None


def clear(profile):
    path=_path(profile)
    if path is None:return
    with closing(_connect(path)) as db, db:db.execute('DELETE FROM failures')
