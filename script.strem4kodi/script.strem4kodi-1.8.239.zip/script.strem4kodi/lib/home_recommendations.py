"""Local Home suggestions with bounded, single-flight background TMDB refresh."""
import hashlib
import math
import re
import threading
import time
from datetime import date
from pathlib import Path

_lock = threading.Lock()
_running = set()
RANKING_VERSION = 3


def completed(row):
    """A playback timestamp alone also covers checkpoints and marking unwatched."""
    state = row.get('state') or {}
    if not state.get('lastWatched'):
        return False
    try:
        offset = max(0, float(state.get('timeOffset') or 0))
        duration = max(0, float(state.get('duration') or 0))
    except (TypeError, ValueError):
        return False
    if duration and offset >= duration * .90:
        return True
    if offset > 1:
        return False
    if state.get('flaggedWatched'):
        return True
    # Completed episodes advance to the next aired episode at a 1ms sentinel
    # and clear flaggedWatched on that next episode.
    return row.get('type') == 'series' and offset == 1 and bool(state.get('timesWatched'))


def identities(row):
    from lib.catalogue_identity import aliases
    kind = row.get('type')
    result = aliases(row)
    result.update((kind, value.split(':', 1)[1]) for _, value in list(result) if value.startswith('tmdb:'))
    return result


def tracked(row):
    state = row.get('state') if isinstance(row.get('state'), dict) else {}
    try:offset = float(state.get('timeOffset') or 0)
    except (ValueError, TypeError):offset = 0
    return bool(row.get('_continue_watching') or completed(row) or
                math.isfinite(offset) and offset >= 1 and state.get('lastWatched') or
                not row.get('removed') and not row.get('temp'))


def excluded(library):
    return set().union(*(identities(row) for row in library if row.get('type') in ('movie', 'series') and tracked(row)))


def seeds(library):
    rows = [dict(row, id=row.get('id') or row.get('_id')) for row in library
            if row.get('type') in ('movie', 'series') and tracked(row)]
    rows.sort(key=lambda row: (str((row.get('state') or {}).get('lastWatched') or row.get('_mtime') or row.get('_ctime') or ''),
                              row.get('type'), str(row.get('id'))), reverse=True)
    result, seen = [], set()
    for row in rows:
        keys = identities(row)
        if keys and not keys & seen:
            result.append(row)
            seen.update(keys)
    return result[:5]


def signature(library):
    values = [(row.get('type'), row.get('id'), (row.get('state') or {}).get('lastWatched')) for row in seeds(library)]
    return hashlib.sha256(repr((RANKING_VERSION, values, sorted(excluded(library)))).encode()).hexdigest()


def recent(library):
    rows = [dict(row, id=row.get('id') or row.get('_id')) for row in library
            if row.get('type') in ('movie', 'series') and completed(row)]
    rows.sort(key=lambda row: (str(row['state']['lastWatched']), row.get('type'), str(row.get('id'))), reverse=True)
    seen, result = set(), []
    for row in rows:
        keys = identities(row)
        if keys and not keys & seen:
            seen.update(keys)
            result.append(row)
    return result[:5]


def genres(row):
    """TMDB details and discovery responses use different genre shapes."""
    values = row.get('genre_ids') or [item.get('id') for item in row.get('genres') or []
                                     if isinstance(item, dict)]
    return {str(value) for value in values if value}


def relevance(row, seed_genres, rank):
    """Genre fit dominates provider order; confidence is a small tie-breaker."""
    candidate_genres = genres(row)
    overlap = seed_genres & candidate_genres
    fit = len(overlap) / len(seed_genres | candidate_genres) if seed_genres and candidate_genres else 0
    try:
        votes = max(0, float(row.get('vote_count') or 0))
        rating = min(10, max(0, float(row.get('vote_average') or 0)))
        quality = rating / 10 * votes / (votes + 100)
    except (TypeError, ValueError):
        quality = 0
    return 4 * fit + 1 / (rank + 1) + .5 * quality


def suitable(row, seed_genres, trending=False):
    """No weakly rated or genre-only popular filler."""
    if not isinstance(row, dict) or row.get('adult'):
        return False
    try:
        rating, votes = float(row.get('vote_average') or 0), float(row.get('vote_count') or 0)
        if not math.isfinite(rating) or not math.isfinite(votes) or rating < 7 or votes < 100:
            return False
    except (ValueError, TypeError):return False
    candidate = genres(row)
    if seed_genres:
        overlap = seed_genres & candidate
        fit = len(overlap) / len(seed_genres | candidate) if candidate else 0
        if fit < (0.5 if trending else 1 / 3):return False
        # Animation and documentary should not turn into generic drama suggestions.
        if any(tag in seed_genres and tag not in candidate for tag in ('16', '99')):return False
    elif trending:
        return False
    return True


def build(library, key, fetcher):
    """Five taste seeds, one weekly chart per media kind and ten ID lookups."""
    from tmdb_metadata import identity, request, photo
    watched = excluded(library)
    candidate_groups, preferred = [], []
    had_error = False
    id_budget = 10
    today = date.today().isoformat()
    charts = {}
    for seed in seeds(library):
        try:
            resolved = identity(seed, key, fetcher)
            if not resolved:
                continue
            kind, tid = resolved
            watched.add((seed['type'], tid))
            sequel = None
            seed_genres = genres(seed)
            if kind == 'movie':
                details = request(key, 'movie/' + tid, fetcher)
                seed_genres = genres(details) or seed_genres
                collection = details.get('belongs_to_collection') or {}
                cid = str(collection.get('id') or '')
                if re.fullmatch(r'[1-9]\d*', cid):
                    parts = request(key, 'collection/' + cid, fetcher).get('parts') or []
                    parts = sorted((r for r in parts if isinstance(r, dict)),
                                   key=lambda r: str(r.get('release_date') or '9999'))
                    after = False
                    for row in parts:
                        if str(row.get('id')) == tid:
                            after = True
                            continue
                        if (after and not row.get('adult') and row.get('release_date') and row['release_date'] <= today
                                and ('movie', str(row.get('id'))) not in watched):
                            if id_budget <= 0:
                                break
                            id_budget -= 1
                            imdb = request(key, 'movie/' + str(row.get('id')) + '/external_ids', fetcher).get('imdb_id')
                            if re.fullmatch(r'tt\d+', str(imdb or '')) and ('movie', imdb) not in watched:
                                sequel = (kind, dict(row, _imdb=imdb))
                                break
            if sequel:
                preferred.append(sequel)
            else:
                if kind != 'movie':
                    try:
                        seed_genres = genres(request(key, kind + '/' + tid, fetcher)) or seed_genres
                    except Exception:
                        # Metadata enrichment must not suppress discovery results.
                        had_error = True
                rows = request(key, kind + '/' + tid + '/recommendations', fetcher).get('results') or []
                candidate_groups.append([(kind, row, relevance(row, seed_genres, rank))
                                         for rank, row in enumerate(rows[:20]) if suitable(row, seed_genres)])
            if kind not in charts:
                try:charts[kind] = request(key, 'trending/' + kind + '/week', fetcher).get('results') or []
                except Exception:
                    charts[kind] = []
                    had_error = True
            # Trending must fit this seed; popularity alone never qualifies.
            trending = [(kind, row, relevance(row, seed_genres, rank) + .25)
                        for rank, row in enumerate(charts[kind][:20]) if suitable(row, seed_genres, True)]
            if sequel:
                candidate_groups.append(trending)
            else:
                # One seed is one corroboration, even if a title is in both endpoints.
                candidate_groups[-1].extend(trending)
        except Exception:
            had_error = True
            continue
    # Combine corroboration across seeds before spending the external-ID budget.
    # A repeated row within one provider response is not independent support.
    ranked = {}
    for group in candidate_groups:
        group_seen = set()
        for kind, row, score in group:
            candidate_key = (kind, str(row.get('id') or ''))
            if candidate_key in group_seen:
                continue
            group_seen.add(candidate_key)
            if candidate_key in ranked:
                old_kind, old_row, best, support = ranked[candidate_key]
                ranked[candidate_key] = (kind, row if score > best else old_row,
                                         max(best, score), support + 1)
            else:
                ranked[candidate_key] = (kind, row, score, 1)
    candidates = [(kind, row) for kind, row, score, support in
                  sorted(ranked.values(), key=lambda value: value[2] + .75 * (value[3] - 1), reverse=True)]
    result, seen = [], set(watched)
    # Converting at most ten candidates bounds external-ID requests even when
    # the supplier returns invalid IDs or already-watched IMDb identities.
    for kind, row in preferred + candidates:
        if len(result) >= 10:
            break
        tid = str(row.get('id') or '')
        media = 'movie' if kind == 'movie' else 'series'
        released = str(row.get('release_date') or row.get('first_air_date') or '')
        if (not re.fullmatch(r'[1-9]\d*', tid) or row.get('adult') or
                not released or released > today or (media, tid) in seen):
            continue
        try:
            imdb = row.get('_imdb')
            if not imdb:
                if id_budget <= 0:
                    continue
                id_budget -= 1
                imdb = request(key, kind + '/' + tid + '/external_ids', fetcher).get('imdb_id')
            if not re.fullmatch(r'tt\d+', str(imdb or '')) or (media, imdb) in seen:
                continue
            seen.update(((media, tid), (media, imdb)))
            result.append(dict(id=imdb, imdb_id=imdb, moviedb_id=tid, type=media,
                               name=row.get('title') or row.get('name') or '',
                               poster=photo(row.get('poster_path')), released=released,
                               year=released[:4], description=row.get('overview') or ''))
        except Exception:
            had_error = True
            continue
    if not result and had_error:
        raise RuntimeError('Recommendation lookup failed; keep the previous cache')
    return result


def sections(directory, state, allow_refresh=True):
    """Return persisted cards immediately; never perform HTTP on the Home thread."""
    from account import Store
    from addon_state import get_addon
    library = state.get('library') or []
    key = get_addon().getSetting('tmdb_api_key').strip()
    if not seeds(library):
        return []
    namespace = hashlib.sha256((str(state.get('token') or '') + key).encode()).hexdigest()
    current_signature = signature(library)
    store = Store(Path(directory) / ('home-recommendations-v3-' + namespace))
    try:
        cached = store.load()
    except Exception:
        cached = {}
    from lib.home_state import HomeState
    shared = None
    try:
        shared = HomeState(directory, state.get('token'))
        record = shared.snapshot().get('recommendations', {})
    except Exception:
        record = {}
    if record.get('signature') == current_signature and record.get('updated', 0) > float(cached.get('created') or 0):
        cached = {'created': record['updated'], 'signature': current_signature, 'items': record['items']}
    watched = excluded(library)
    rows = [row for row in cached.get('items', []) if isinstance(row, dict)
            and not identities(row) & watched][:10]
    if (allow_refresh and key and (cached.get('signature') != current_signature or time.time() - float(cached.get('created') or 0) >= 3600)
            and time.time() >= float(cached.get('retry_after') or 0)):
        flight = str(store.directory)
        with _lock:
            if flight not in _running:
                from lib.browse_background import budgeted, request_scope
                scope = request_scope(directory)
                current_owner = lambda: request_scope(directory) == scope
                _running.add(flight)
                @budgeted
                def refresh():
                    try:
                        if not current_owner():return
                        from protocol import fetch
                        def fetch_owned(url):
                            if not current_owner():raise RuntimeError('Refresh retired')
                            return fetch(url, timeout=4)
                        items = build(library, key, fetch_owned)
                        if not current_owner():return
                        store.save({'created': time.time(), 'signature': current_signature, 'items': items})
                        if shared:
                            try: shared.recommendations(current_signature, items)
                            except Exception: pass
                        try:
                            import xbmcgui
                            xbmcgui.Window(10000).setProperty(
                                'strem4kodi.home.recommendations.revision', str(time.time_ns()))
                        except Exception:
                            pass
                    except Exception:
                        if not current_owner():return
                        try:
                            store.save(dict(cached, retry_after=time.time() + 300))
                        except Exception:
                            pass
                    finally:
                        with _lock:
                            _running.discard(flight)
                try:
                    threading.Thread(target=refresh, daemon=True).start()
                except RuntimeError:
                    _running.discard(flight)
    return [{'label': 'You May Also Like', 'items': rows, 'failed': False,
             '_recommendation_version': RANKING_VERSION}] if rows else []
