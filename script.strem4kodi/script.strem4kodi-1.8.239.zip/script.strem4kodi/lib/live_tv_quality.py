"""Platform-independent, fail-closed admission of live HD video renditions.

Providers supply measured manifest metadata, never channel-name quality hints.
This module does not assert DRM entitlement or actual device playback support.
"""
from dataclasses import dataclass
from typing import Optional


class HDUnavailable(ValueError):
    """No verified HD representation can be offered to the player."""


@dataclass(frozen=True)
class Rendition:
    identity: str
    width: Optional[int]
    height: Optional[int]
    codec: str = ''
    bandwidth: int = 0


def is_hd(rendition):
    """Require both dimensions; neither names nor bitrates establish HD."""
    width, height = rendition.width, rendition.height
    return (type(width) is int and type(height) is int
            and width >= 1280 and height >= 720)


def admit(renditions, supported_codecs=None):
    """Return only HD video choices, best resolution first.

    A caller may restrict codecs using capabilities established for this device.
    No platform is presumed capable merely because another device played it.
    Audio/subtitle tracks must be retained separately by the manifest adapter.
    """
    allowed = None if supported_codecs is None else set(supported_codecs)
    result = [r for r in renditions if is_hd(r)
              and (allowed is None or r.codec in allowed)]
    if not result:
        raise HDUnavailable('HD playback is unavailable for this channel on this device.')
    return tuple(sorted(result, key=lambda r: (r.height, r.width, r.bandwidth), reverse=True))
