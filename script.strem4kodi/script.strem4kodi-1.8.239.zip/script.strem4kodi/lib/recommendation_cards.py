"""Compact source-labelled scores for recommendations and filmographies."""
import math
import threading


def apply_ratings(item, row, get_setting):
    badges = []
    if get_setting('ui_show_rating') != 'false':
        supplied = {badge.get('source'): badge for badge in (row.get('rating_badges') or [])
                    if isinstance(badge, dict)}
        for source in ('imdb', 'tomatoes', 'tomatoesaudience'):
            badge = supplied.get(source, {})
            try:
                value = float(str(badge.get('value', row.get('imdbRating', '') if source == 'imdb' else '')).rstrip('%'))
            except (ValueError, TypeError):
                continue
            if math.isfinite(value) and 0 <= value <= (10 if source == 'imdb' else 100) and get_setting('rating_' + source) != 'false':
                from lib.rating_awards import icon
                artwork = badge.get('icon') or ('imdb' if source == 'imdb' else icon({}, source, value)) + '.png'
                badges.append((artwork, '{:.1f}'.format(value) if source == 'imdb' else '{:g}%'.format(value)))
    item.setProperty('card_rating_count', str(len(badges)) if badges else '')
    for index in range(3):
        artwork, value = badges[index] if index < len(badges) else ('', '')
        item.setProperty('card_rating%d' % index, value)
        item.setProperty('card_rating_icon%d' % index,
                         'special://home/addons/script.strem4kodi/resources/skins/Main/media/ratings/'
                         + artwork if artwork else '')


def start(window, rows, get_setting, control_id=503):
    """Enrich optional scores without delaying navigation or resetting the list."""
    from lib import mdblist
    if not rows or get_setting('ui_show_rating') == 'false' or not mdblist.enabled():
        return
    token = object()
    window._similar_ratings_token = token

    page = window.getProperty('page') if control_id == 9500 else None
    generation = getattr(window, '_poster_generation', None)

    def current():
        if control_id == 9500:
            owned = (window.getProperty('page') == page and window.rows.get(control_id) is rows
                     and window._poster_generation == generation)
        else:
            owned = window.section == 'Similar' and window.cards is rows
        return not window.closed and owned and window._similar_ratings_token is token

    def work():
        for position, row in enumerate(rows):
            if not current():return
            try:
                fresh = mdblist.enrich(row)
                with window._row_update_lock:
                    if not current():return
                    for field in ('rating_badges', 'imdbRating'):
                        if field in fresh:row[field] = fresh[field]
                    apply_ratings(window.getControl(control_id).getListItem(position), row, get_setting)
            except Exception:
                pass
    try:threading.Thread(target=work, daemon=True).start()
    except RuntimeError:pass


def append_layout(layout, top, left=4):
    """Use only native list-item groups; grouplists cannot carry card scores."""
    from lib.cinematic_cards import control
    row = control(layout, 'group', description='Card ratings', left=left, top=top,
                  width=216, height=22)
    for count in (1, 2, 3):
        width = count * 68 + (count-1) * 6
        branch = control(row, 'group', description='Ratings: %d' % count,
                         left=(216-width)//2, top=0, width=width, height=22,
                         visible='String.IsEqual(ListItem.Property(card_rating_count),%d)' % count)
        for index in range(count):
            x = index * 74
            control(branch, 'image', left=x, top=2, width=22, height=18,
                    texture='$INFO[ListItem.Property(card_rating_icon%d)]' % index, aspectratio='keep')
            control(branch, 'label', left=x+24, top=0, width=44, height=22,
                    label='$INFO[ListItem.Property(card_rating%d)]' % index,
                    font='Strem4Kodi18', textcolor='FFBFC4CE', align='center', aligny='center')
