"""Warm the resized Kodi texture before exposing it to a sidebar control.

On a cache miss Kodi can return the decoder's larger texture to the renderer
before saving the requested 32x18 copy. Reading through its image VFS first
ensures even the first displayed frame uses the resized, cached bytes.
"""
import threading
import weakref

from lib.background_artwork import frosted_sidebar

_lock = threading.RLock()
_pending = None
_running = False


def request(window, artwork):
    global _pending, _running
    texture = frosted_sidebar(artwork)
    with _lock:
        if (texture and getattr(window, '_sidebar_frost_texture', None) == texture
                and getattr(window, '_sidebar_frost_request', None) is not None):
            return
        token = object()
        window._sidebar_frost_request = token
        window._sidebar_frost_texture = texture
        window.setProperty('sidebar_frosted', '')
        if not texture:
            return
        # Only the latest waiting selection matters; never queue whole rows.
        _pending = (weakref.ref(window), token, texture)
        if not _running:
            _running = True
            try:
                threading.Thread(target=_run, name='s4k-sidebar-frost', daemon=True).start()
            except RuntimeError:
                _running = False
                _pending = None
                window._sidebar_frost_request = None


def _warm(texture):
    import xbmcvfs
    stream = xbmcvfs.File(texture)
    try:
        return bool(stream.readBytes(1))
    finally:
        stream.close()


def _run():
    global _pending, _running
    while True:
        with _lock:
            job, _pending = _pending, None
            if job is None:
                _running = False
                return
        reference, token, texture = job
        try:
            if not _warm(texture):
                continue
            with _lock:
                window = reference()
                if (window is not None and
                        getattr(window, '_sidebar_frost_request', None) is token and
                        getattr(window, 'closed', False) is not True):
                    window.setProperty('sidebar_frosted', texture)
                window = None
        except Exception:
            # Artwork failure must retain the opaque fallback, never interrupt
            # navigation or publish the original sharp image.
            pass
