"""Small failure history with fixed contexts and package-only stack locations."""
import re
import threading
import time
import traceback
from pathlib import Path

CONTEXTS = {'app', 'worker', 'home.refresh', 'sources.search', 'sources.render', 'sources.play',
            'progress.save', 'service', 'diagnostics.source'}
_ROOT = Path(__file__).resolve().parents[1]
_LOCK = threading.RLock()
_ERRORS = {'MemoryError', 'RuntimeError', 'TypeError', 'ValueError', 'AttributeError',
           'KeyError', 'OSError', 'ImportError', 'IndexError', 'UnknownError', 'SyncError'}


def record(context, error, profile=None):
    try:
        from account import Store
        if profile is None:
            from lib import backend
            profile = backend.STORE.directory
        # Never create a relative/fallback profile beside the installed addon.
        # In Kodi the translated addon-data profile is absolute and exists.
        profile = Path(profile)
        if not profile.is_absolute() or not profile.is_dir():return
        frames = []
        for frame in traceback.extract_tb(error.__traceback__)[-12:]:
            try:path = Path(frame.filename).resolve().relative_to(_ROOT)
            except ValueError:continue
            if (path.suffix != '.py' or len(path.parts) > 2 or
                    (len(path.parts) == 2 and path.parts[0] not in ('lib', 'core'))):continue
            frames.append('{}:{}'.format(path.as_posix(), frame.lineno))
        kind = type(error).__name__
        row = dict(time=int(time.time()), context=context if context in CONTEXTS else 'app',
                   error_type=kind if kind in _ERRORS else 'UnknownError', frames=frames[-8:])
        with _LOCK:
            store = Store(Path(profile) / 'diagnostic-failures')
            state = store.load()
            rows = load(profile)
            if rows and all(rows[-1].get(k) == row[k] for k in ('context','error_type','frames')) and row['time'] - rows[-1]['time'] < 60:
                return
            state['events'] = (rows + [row])[-40:]
            store.save(state)
    except Exception:
        pass


def load(profile):
    from account import Store
    result = []
    rows = Store(Path(profile) / 'diagnostic-failures').load().get('events', [])
    for row in rows[-40:] if isinstance(rows, list) else []:
        if not isinstance(row, dict) or row.get('context') not in CONTEXTS or row.get('error_type') not in _ERRORS:continue
        frames = row.get('frames', [])
        if not isinstance(frames, list):frames = []
        result.append(dict(context=row['context'], error_type=row['error_type'],
                           time=row.get('time') if type(row.get('time')) is int else 0,
                           frames=[f for f in frames if isinstance(f, str) and
                                   re.fullmatch(r'(?:lib/|core/)?[a-zA-Z0-9_]+\.py:[0-9]{1,7}', f)][:8]))
    return result


def install(profile):
    """Observe unhandled addon worker failures; preserve Kodi's own handler."""
    previous = getattr(threading, 'excepthook', None)
    if previous is None or getattr(previous, '_s4k_failure_hook', False):return
    def hook(args):
        try:
            tb = args.exc_traceback
            owned = False
            while tb:
                try:
                    Path(tb.tb_frame.f_code.co_filename).resolve().relative_to(_ROOT)
                    owned = True
                except ValueError:pass
                tb = tb.tb_next
            if owned and isinstance(args.exc_value, Exception):record('worker', args.exc_value, profile)
        except Exception:pass
        finally:
            previous(args)
    hook._s4k_failure_hook = True
    threading.excepthook = hook
