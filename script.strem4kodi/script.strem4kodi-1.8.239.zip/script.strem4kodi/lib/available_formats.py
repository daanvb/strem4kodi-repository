"""Source-reported availability, never inferred from artwork or another episode."""
from core.stream_ui import stream_card
from lib.dolby_variants import FEL, TRUEHD_ATMOS, reported_variants
import threading

_HERO_LOCK = threading.RLock()

AUDIO_ORDER = (TRUEHD_ATMOS, 'Atmos', 'TrueHD', 'Dolby Digital Plus', 'Dolby Digital', 'DTS-HD MA', 'DTS')


class FormatFacts(list):
    """Backwards-compatible badge list with anonymous alternative capabilities."""
    def __init__(self, found=(), available=None, groups=None):
        super().__init__(found)
        self.available_formats = tuple(sorted(set(available if available is not None else getattr(found, 'available_formats', found))))
        source_groups = groups if groups is not None else getattr(found, 'source_formats', ())
        self.source_formats = tuple(sorted({tuple(sorted(set(group))) for group in source_groups if group})[:4096])


def formats(rows, prepared=None):
    rows = [row for row in rows if isinstance(row, dict) and not row.get('_session_failed')]
    cards = [(prepared.card(row) if prepared is not None else stream_card(row)) for row in rows]
    reported = [reported_variants(row) for row in rows]
    variants = {tag for group in reported for tag in group}
    qualities = ('4K', '1080p', '720p', '480p', '360p')
    best = next((q for q in qualities if any(c.get('quality') == q for c in cards)), '')
    video = {tag for c in cards for tag in c.get('video_tags', [])}
    audio = {tag.split(' 2.')[0].split(' 5.')[0].split(' 7.')[0]
             for c in cards for tag in c.get('audio_tags', [])}
    formats = [best] if best else []
    if FEL in variants:
        formats.append(FEL)
    elif 'Dolby Vision' in video:
        formats.append('Dolby Vision')
    if 'HDR10+' in video:
        formats.append('HDR10+')
    elif 'HDR10' in video:
        formats.append('HDR10')
    elif 'HDR' in video:
        formats.append('HDR')
    sound = next((v for v in AUDIO_ORDER if v in audio or v in variants), '')
    if sound:
        formats.append(sound)
    groups = []
    for card, extra in zip(cards, reported):
        tags = [card.get('quality')] + card.get('video_tags', []) + extra
        tags += [tag.split(' 2.')[0].split(' 5.')[0].split(' 7.')[0] for tag in card.get('audio_tags', [])]
        groups.append([tag for tag in ASSETS if tag in tags])
    return FormatFacts(formats, available={tag for group in groups for tag in group}, groups=groups)


def merge_formats(*groups):
    """Rank cumulative availability without keeping source URLs in memory."""
    tags = {tag for group in groups for tag in group}
    result = [q for q in ('4K','1080p','720p','480p','360p') if q in tags][:1]
    if FEL in tags:result.append(FEL)
    elif 'Dolby Vision' in tags:result.append('Dolby Vision')
    result += [v for v in ('HDR10+','HDR10','HDR') if v in tags][:1]
    result += [a for a in AUDIO_ORDER if a in tags][:1]
    available = {tag for group in groups for tag in getattr(group, 'available_formats', group)}
    sources = {tuple(group) for tags in groups for group in getattr(tags, 'source_formats', ())}
    return FormatFacts(result, available=available, groups=sorted(sources))


ASSETS = {'4K': 'ui/4k-compact', '1080p': 'ui/1080p-compact',
          '720p': 'ui/720p-compact', '480p': 'ui/480p-compact', '360p': 'ui/360p-compact',
          'Dolby Vision': 'ui/dolbyvision-v3', 'HDR10+': 'ui/hdr10plus-compact',
          'HDR10': 'ui/hdr10-compact', 'HDR': 'ui/hdr-compact',
          'Atmos': 'ui/atmos-v3', 'TrueHD': 'ui/truehd-v3',
          'DTS-HD MA': 'ui/dtshd_ma-readable', 'DTS': 'ui/dts-readable',
          'Dolby Digital Plus': 'ui/eac3-v3', 'Dolby Digital': 'ui/ac3-v3'}
ASSETS = {key: path + '-even-v1' for key, path in ASSETS.items()}
ASSETS['4K'] = 'ui/4k-compact-even-v2'
for tag, stem in (('Dolby Vision','dolbyvision'), ('Atmos','atmos'),
                  ('TrueHD','truehd'), ('Dolby Digital Plus','eac3'), ('Dolby Digital','ac3')):
    ASSETS[tag] = 'ui/' + stem + ('-compact-master-v3' if stem in ('atmos','eac3','ac3') else '-compact-master-v2')


# Preserve branded masters for rebuilding; ship prefiltered pixels for the
# current 64x28 GUI controls instead of relying on GPU minification.
HERO_MASTERS = dict(ASSETS)
DOLBY_HERO_TAGS = frozenset(('Dolby Vision', 'Atmos', 'TrueHD', 'Dolby Digital Plus', 'Dolby Digital'))
SMALLER_HERO_TAGS = frozenset(('Dolby Vision', 'Atmos'))
ASSETS = {tag: path + ('-1080-v2' if tag in DOLBY_HERO_TAGS else '-1080-v1')
          for tag, path in HERO_MASTERS.items()}
ASSETS.update({tag: HERO_MASTERS[tag] + '-1080-v3' for tag in SMALLER_HERO_TAGS})
ASSETS.update({FEL: 'ui/dolbyvision-fel-custom-v1-1080',
               TRUEHD_ATMOS: 'ui/truehd-atmos-custom-v1-1080'})


def properties(found):
    # Browsing uses our compact artwork; source facts still choose the format.
    paths = ['special://home/addons/script.strem4kodi/resources/skins/Main/media/formats/display/hero/' + ASSETS[v] + '.png'
             for v in found if v in ASSETS]
    values = {'available_format_' + str(i): paths[i] if i < len(paths) else '' for i in range(4)}
    values.update({'available_format_' + str(i) + '_tint': 'FFFFFFFF' for i in range(4)})
    return values


def hero_properties(window, meta, found):
    """All hero writers share positive variant facts for the visible title.

    Generic DV/Atmos metadata cannot negate an explicit source/playback report.
    Only the two detailed variants are retained; resolution still follows the
    latest result. A different title resets the window-local memory.
    """
    from lib.catalogue_identity import aliases
    context = set(aliases(meta)) if isinstance(meta, dict) and meta.get('type') in ('movie', 'series') else set()
    if not context:
        return _output_properties(window, meta, found)
    with _HERO_LOCK:
        visible = getattr(window, '_format_row', None)
        active = set(aliases(visible)) if isinstance(visible, dict) else set()
        if active and not active.intersection(context):
            return {}  # A completed worker no longer owns the visible title.
        previous = getattr(window, '_hero_format_aliases', set())
        same_title = isinstance(previous, set) and bool(context.intersection(previous))
        known = set(getattr(window, '_hero_format_variants', ())) if same_title else set()
        known.update(tag for tag in found if tag in (FEL, TRUEHD_ATMOS))
        window._hero_format_aliases = context.union(previous) if same_title else context
        window._hero_format_variants = known
        selected = merge_formats(found, known)
    return _output_properties(window, meta, selected)


def _output_properties(window, meta, found):
    if getattr(window, '_hero_supported_output', False) is True:
        try:
            found = window._hero_output_filter(meta, found)
        except Exception:
            found = []  # Output capability failures must not advertise support.
    return properties(found)


def apply(window, rows, prepared=None):
    meta = getattr(window, '_format_row', None)
    if not isinstance(meta, dict):
        meta = getattr(window, 'meta', None)
    for key, value in hero_properties(window, meta, formats(rows,prepared)).items():
        window.setProperty(key, value)


def catalogue_formats(meta):
    """Read explicit technical fields only, with no network or artwork guessing."""
    fields = ('quality', 'resolution', 'height', 'audio', 'audioCodec', 'hdr', 'bitDepth')
    values = {key: meta[key] for key in fields if key in meta}
    for key in ('availableFormats', 'videoFormats', 'audioFormats'):
        value = meta.get(key)
        if isinstance(value, (str, list, tuple)):
            values['label'] = values.get('label', '') + ' ' + (' '.join(str(v) for v in value) if isinstance(value, (list, tuple)) else value)
    # Static title/disc facts are not evidence that these variants are offered.
    found = formats([values]) if values else []
    return [{FEL: 'Dolby Vision', TRUEHD_ATMOS: 'Atmos'}.get(tag, tag) for tag in found]


FORMAT_GROUPS = (('4K', '1080p', '720p', '480p', '360p'),
                 (FEL, 'Dolby Vision', 'HDR10+', 'HDR10', 'HDR'), AUDIO_ORDER)


def complete_formats(values):
    """Every displayed technical family is already known."""
    return all(any(tag in values for tag in group) for group in FORMAT_GROUPS)


def fill_gaps(primary, fallback):
    """Secondary title facts cannot upgrade an already known technical family."""
    result = list(primary)
    for group in FORMAT_GROUPS:
        if not any(tag in primary for tag in group):
            result.extend(tag for tag in fallback if tag in group)
    return merge_formats(primary, result)


def display_formats(meta, api, identity=None):
    """Retained source facts lead; PostersPlus fills missing overview families."""
    try:
        found = primary_formats(meta, api, identity)
    except Exception:
        found = catalogue_formats(meta)
    # PostersPlus has title-level facts, never an exact episode/source probe.
    if meta.get('type') == 'series' and (meta.get('_focus_video_id') or identity):
        return merge_formats(found)
    return fill_gaps(found, meta.get('_postersplus_quality') or [])


def primary_formats(meta, api, identity=None):
    """Show retained badges immediately; source URL freshness stays separate."""
    # Browsing a future/selected episode still presents the series overview.
    # Keep the original context for playback and on-demand source requests.
    overview = dict(meta)
    if meta.get('type') == 'series':
        overview.pop('_focus_video_id', None)
    summary = api.availability_summary(overview)
    if isinstance(summary, dict) and 'formats' in summary:
        if summary['formats'] or meta.get('type') != 'series':
            return FormatFacts(summary['formats'], available=summary.get('available_formats'), groups=summary.get('source_formats'))
        # An empty episode lookup cannot erase explicit series-level metadata.
        return catalogue_formats(meta)
    if meta.get('type') == 'series' and not meta.get('_focus_video_id'):
        return catalogue_formats(meta)  # Explicit title metadata; never another episode's cache.
    return for_title(meta, api.stream_cache_state, identity) or catalogue_formats(meta)


def for_title(meta, cache_reader, identity=None):
    if meta.get('type') not in ('movie', 'series'):
        return []
    state = meta.get('state') if isinstance(meta.get('state'), dict) else {}
    target = identity or meta.get('_focus_video_id') or state.get('video_id')
    if meta.get('type') == 'movie':
        target = meta.get('id')
    # A series-level cache must never stand in for a particular episode.
    if not target or (meta.get('type') == 'series' and target == meta.get('id')):
        return []
    cached = cache_reader(meta, target)
    # Last-known technical badges remain useful after playable URLs expire.
    return formats(cached[0]) if cached else []
