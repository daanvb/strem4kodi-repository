"""Channel 4 anonymous live authorisation and Widevine licence envelope.

Protocol reference: Catch-up TV & More, resources/lib/channels/uk/channel4.py
https://github.com/Catch-up-TV-and-More/plugin.video.catchuptvandmore
The public web-client AES parameters unwrap API metadata, not DRM media keys.
Account/client credentials and Widevine content keys are never handled here.
"""
import base64
import json
from urllib.parse import urlsplit, urlunsplit

from lib.live_tv_commercial import LiveStream, aes_unwrap
from lib.live_tv_http import json_request, request, secure_url
from lib.live_tv_quality import HDUnavailable

CHANNEL_IDS = {'c4': 'C4', 'e4': 'E4', 'more4': 'M4', 'film4': 'F4', '4seven': '4S'}
LICENSE_URL = 'https://c4.eme.lp.aws.redbeemedia.com/wvlicenceproxy-service/widevine/acquire'


def full_quality_url(url):
    """Select the full ladder; the existing manifest filter must verify HD."""
    secure_url(url)
    parts = urlsplit(url)
    directory, _, filename = parts.path.rpartition('/')
    if filename == 'manifest_sd.mpd':
        parts = parts._replace(path=directory + '/manifest.mpd')
    elif filename != 'manifest.mpd':
        raise HDUnavailable('Channel 4 live manifest format has changed.')
    return urlunsplit(parts)


def resolve_c4(channel, fetch=json_request):
    if channel not in CHANNEL_IDS:
        raise HDUnavailable('Unknown Channel 4 channel.')
    try:
        data = fetch('https://www.channel4.com/simulcast/channels/' + CHANNEL_IDS[channel])
        profiles = data.get('channelInfo', data).get('videoProfiles', [])
        for profile in profiles:
            if profile.get('name') != 'dashwv-live-stream-iso-dash-sp-tl':
                continue
            stream = profile['streams'][0]
            url = full_quality_url(stream['uri'])
            # Published web-player metadata envelope parameters. There is no
            # personal secret, OAuth bootstrap credential or media key here.
            plain = aes_unwrap(base64.b64decode(stream['token'], validate=True),
                               b'n9cLieYkqwzNCqvi', b'odzcU3WdUiXLucVd').decode('utf-8')
            prefix, separator, token = plain.rpartition('&t=')
            if not separator or not prefix or not token or len(token) > 16384:
                raise ValueError('Invalid authorisation envelope')
            return LiveStream(url, LICENSE_URL,
                              {'Content-Type': 'application/json', 'Referer': 'https://www.channel4.com'},
                              provider='c4', license_token=token)
    except HDUnavailable:
        raise
    except Exception:
        raise HDUnavailable('Channel 4 live authorisation is unavailable. Please retry later.') from None
    raise HDUnavailable('No compatible Channel 4 live stream is available.')


def c4_license_response(stream, challenge, fetch=request):
    """Wrap the CDM challenge for Redbee and return its binary licence."""
    try:
        if stream.license_url != LICENSE_URL or not stream.license_token:
            raise ValueError('Invalid licence configuration')
        body = json.dumps({'token': stream.license_token,
                           'video': {'type': 'simulcast', 'url': stream.url},
                           'message': base64.b64encode(challenge).decode('ascii')}).encode('utf-8')
        raw = fetch(LICENSE_URL, data=body, headers=stream.license_headers, limit=1024 * 1024)
        if len(raw) > 1024 * 1024:
            raise ValueError('Oversized licence')
        licence = base64.b64decode(json.loads(raw)['license'], validate=True)
        if not licence:
            raise ValueError('Empty licence')
        return licence
    except Exception:
        raise HDUnavailable('Channel 4 playback licence was not granted. Please retry later.') from None
