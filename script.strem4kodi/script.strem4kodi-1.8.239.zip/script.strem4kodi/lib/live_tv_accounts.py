"""Device-local ITV session. No password persistence, settings or sync export."""
import json
import os
import tempfile
import time
from pathlib import Path
from urllib.parse import urlencode

from lib.live_tv_http import json_request
from lib.live_tv_quality import HDUnavailable

AUTH = 'https://auth.prd.user.itv.com/v2/auth'
REFRESH = 'https://auth.prd.user.itv.com/token'
HEADERS = {'Accept': 'application/vnd.user.auth.v2+json',
           'Origin': 'https://app.10ft.itv.com', 'Referer': 'https://app.10ft.itv.com/'}


def session_path():
    import xbmcaddon
    import xbmcvfs
    return Path(xbmcvfs.translatePath(xbmcaddon.Addon('script.strem4kodi').getAddonInfo('profile'))) / 'live-tv-itv-session'


class ITVAccount:
    def __init__(self, path=None, fetch=json_request, clock=time.time):
        self.path = Path(path) if path is not None else session_path()
        self.fetch, self.clock = fetch, clock

    def load(self):
        try:
            value = json.loads(self.path.read_text(encoding='utf-8'))
            return value if isinstance(value, dict) else {}
        except (ValueError, OSError):
            return {}

    def save(self, response, previous=None):
        access = response.get('access_token')
        refresh = response.get('refresh_token') or (previous or {}).get('refresh_token')
        if not isinstance(access, str) or not access or not isinstance(refresh, str) or not refresh:
            raise HDUnavailable('ITVX sign-in failed. Check your account details.')
        # Keep a conservative renewal interval even if expires_in is absent.
        lifetime = min(3600, max(60, int(response.get('expires_in', 3600))))
        value = {'access_token': access, 'refresh_token': refresh,
                 'expires': self.clock() + lifetime - 30}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary_name = tempfile.mkstemp(prefix='.live-tv-itv-', dir=str(self.path.parent))
        temporary = Path(temporary_name)
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as output:
                json.dump(value, output)
            os.replace(str(temporary), str(self.path))
        finally:
            if temporary.exists():
                temporary.unlink()
        return access

    def login(self, email, password):
        result = self.fetch(AUTH, {'grant_type': 'password', 'username': email,
                                  'password': password, 'scope': 'content',
                                  'nonce': 'cerberus-auth-request-' + str(int(self.clock() * 1000))}, HEADERS)
        return self.save(result)

    def token(self):
        value = self.load()
        if value.get('access_token') and float(value.get('expires', 0)) > self.clock():
            return value['access_token']
        if not value.get('refresh_token'):
            raise HDUnavailable('Sign in to ITVX from Live TV setup first.')
        try:
            response = self.fetch(REFRESH + '?' + urlencode({'refresh': value['refresh_token']}), headers=HEADERS)
            return self.save(response, value)
        except Exception:
            raise HDUnavailable('ITVX session expired. Sign in again from Live TV setup.') from None

    def logout(self):
        try:
            self.path.unlink()
        except FileNotFoundError:
            pass
