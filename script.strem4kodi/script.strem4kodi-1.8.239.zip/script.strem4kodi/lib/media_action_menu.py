"""Addon-owned vertical long-press action menu for media cards."""
import time
import xbmcgui

BACK = (10, 92, 216, 247)
LIST = 600
ACTION_ICONS = {
    'play': 'resume', 'source': 'source', 'manual-source': 'source',
    'restart': 'restart-v3', 'random-episode': 'random-episode',
    'trailer': 'trailer', 'mark-watched': 'watched-eye-v1',
    'mark-unwatched': 'unwatched-eye-v1', 'through-watched': 'through-watch-eye-v1',
    'through-unwatched': 'through-unwatch-eye-v1', 'save_favourite': 'favourite',
    'save_watchlist': 'watch-later', 'move_favourite': 'favourite',
    'move_watchlist': 'watch-later', 'remove_lists': 'remove',
    'remove-continue': 'remove', 'share-progress': 'share',
    'filters': 'settings', 'credits-timing': 'timer', 'credits-manage': 'settings',
}

# Font glyphs correspond to the existing semantic menu icons.
ICON_GLYPHS = {
    'resume': 0xf009, 'source': 0xf0cf, 'restart-v3': 0xf080,
    'random-episode': 0xf124, 'trailer': 0xeb8f, 'watched-eye-v1': 0xecb1,
    'unwatched-eye-v1': 0xecb3, 'through-watch-eye-v1': 0xf217,
    'through-unwatch-eye-v1': 0xeb89, 'favourite': 0xee0f,
    'watch-later': 0xeae5, 'remove': 0xec2a, 'share': 0xf0fd,
    'episode': 0xf00d, 'series': 0xed21, 'info': 0xee59,
    'settings': 0xf0e6, 'timer': 0xf211, 'play': 0xf009,
}



def icon_filename(option):
    """Pick a semantic per-action glyph, falling back to the option's icon."""
    action = str(option.get('action') or '')
    if action in ACTION_ICONS:
        return ACTION_ICONS[action] + '.png'
    icon = str(option.get('icon') or 'info')
    return {'restart': 'restart-v3', 'watched': 'watched-eye-v1',
            'unwatched': 'unwatched-eye-v1', 'through-watch': 'through-watch-eye-v1',
            'through-unwatch': 'through-unwatch-eye-v1'}.get(icon, icon) + '.png'


class MediaActionMenu(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.options = list(kwargs.pop('options'))
        self.result = None
        from lib.remote_hold import take_context_guard
        self._hold_guard_last = time.monotonic() if take_context_guard() else None
        super().__init__(*args, **kwargs)

    def onInit(self):
        from addon_state import get_addon
        path = get_addon().getAddonInfo('path')
        listing = self.getControl(LIST)
        listing.reset()
        items = []
        for option in self.options:
            li = xbmcgui.ListItem(label=str(option.get('label') or ''))
            filename = icon_filename(option)
            li.setProperty('icon_glyph', chr(ICON_GLYPHS.get(filename[:-4], ICON_GLYPHS['info'])))
            items.append(li)
        listing.addItems(items)
        from lib.context_frost import media_bounds
        _, top, _, panel_height = media_bounds(len(items))
        height = panel_height - 28
        listing.setPosition(654, top + 14)
        listing.setHeight(height)
        self.setFocusId(LIST)

    def onClick(self, cid):
        if self._hold_guard_last is not None:
            if time.monotonic() - self._hold_guard_last < .75:return
            self._hold_guard_last = None
        if cid != LIST:
            return
        pos = self.getControl(LIST).getSelectedPosition()
        if 0 <= pos < len(self.options):
            self.result = self.options[pos].get('action')
        self.close()

    def onAction(self, action):
        if self._hold_guard_last is not None and action.getId() in (7, 58):
            now = time.monotonic()
            if now - self._hold_guard_last >= .75:self._hold_guard_last = None
            else:self._hold_guard_last = now
        if action.getId() in BACK:
            self.close()


def choose(path, options):
    from lib.theme import window as themed_window
    window = themed_window(MediaActionMenu, 'script-stremio-media-actions.xml',
                           path, 'Main', '1080i', options=options)
    window.doModal()
    result = window.result
    del window
    return result
