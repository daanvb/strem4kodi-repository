"""Embedded Nimbus selector shared by account browsing filters."""
import xbmcgui


from lib.theme import window as themed_window


class Selector(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.left = kwargs.pop('left', 50)
        self.top = kwargs.pop('top', 600)
        self.width = kwargs.pop('width', 640)
        self.heading = kwargs.pop('heading')
        self.options = kwargs.pop('options')
        self.preselect = kwargs.pop('preselect', -1)
        self.result = -1
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('heading', self.heading)
        from lib.context_frost import selector_bounds
        left, top, _, height = selector_bounds(len(self.options), self.left, self.top, self.width)
        for cid, x, y in ((602,20,13),(600,10,75)):
            self.getControl(cid).setPosition(left+x, top+y)
        self.getControl(600).setHeight(height - 90)
        listing = self.getControl(600)
        listing.reset()
        listing.addItems([xbmcgui.ListItem(str(value)) for value in self.options])
        if 0 <= self.preselect < len(self.options):listing.selectItem(self.preselect)
        self.setFocusId(600)

    def onAction(self, action):
        if action.getId() in (10, 92, 216, 247):
            self.close()

    def onClick(self, control):
        if control == 600:
            self.result = self.getControl(600).getSelectedPosition()
            self.close()


class Dialog:
    def __init__(self, path, left=50, top=600, width=640):
        self.width = width
        self.top = top
        self.path = path
        self.left = left

    def select(self, heading, options, preselect=-1):
        if not options:
            return -1
        window = themed_window(Selector, 'script-stremio-select.xml', self.path, 'Main', '1080i',
                          heading=heading, options=options, left=self.left, top=self.top, width=self.width, preselect=preselect)
        window.doModal()
        result = window.result
        del window
        return result
