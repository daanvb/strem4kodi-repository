"""Shared palettes for addon-owned windows; never modifies the Kodi skin."""
from pathlib import Path
import xml.etree.ElementTree as ET

NAMES = ('Charcoal', 'Black', 'Blue', 'Green', 'Gold', 'Purple')
# background, sidebar, surface, button, selected card, focus, accent
PALETTES = (
 ('FF171717','FF292929','FF303030','FF3B3B3B','FF575757','FFE6E6E6','FFBDBDBD'),
 ('FF080808','FF101010','FF202020','FF303030','FF464646','FFE5E5E5','FFCCCCCC'),
 ('FF0B1421','FF101C2C','FF1C2C41','FF263C56','FF31577A','FFA4D8FF','FF85C7F2'),
 ('FF0B1814','FF10241C','FF1C352A','FF294839','FF35644C','FFA7EAC2','FF83CEA1'),
 ('FF19140B','FF241D10','FF352B1C','FF493B27','FF665233','FFF4D59B','FFDDB875'),
 ('FF100E1C','FF14111E','FF242333','FF302B41','FF42365C','FFC4ACFF','FFB5A4E8'),
)
KEYS = ('background','sidebar','surface','button','selected','focus','accent')


def index(addon):
    try:
        value = int(addon.getSetting('ui_theme') or 0)
        return value if 0 <= value < len(PALETTES) else 0
    except (TypeError, ValueError):
        return 0


def apply(tree, selected=0, poster_color=None):
    palette = dict(zip(KEYS, PALETTES[selected if 0 <= selected < len(PALETTES) else 0]))
    from lib.ui_style import apply as apply_style
    apply_style(tree, palette['background'])
    roles = {
        'background': ('0F1017','0B0B12','171322','090711','050505','100E1C','17171B'),
        'sidebar': ('121212','14111E','2B3038'),
        'surface': ('242333','242530','20222F','252333','17151F','191526','2A2736','141518','25272D','181720','181B20'),
        'button': ('302B41','30313B','353238','403650','303238','253E50','343B47','30343C'),
        'selected': ('42365C','7355DE'),
        'focus': ('C4ACFF','F0F0F2','4564FF'),
        'accent': ('B5A4E8','9B7CFF','9B7BFF'),
    }
    mapping = {color:palette[role][2:] for role,colors in roles.items() for color in colors}
    color_tags = {'textcolor','focusedcolor','disabledcolor','selectedcolor','shadowcolor','colordiffuse'}
    for element in tree.iter():
        # Strip our source-only annotation before Kodi reads the layout.
        if element.attrib.pop('theme-colour', None) == 'fixed':
            continue
        if element.tag in color_tags:
            old = element.text or ''
            if old == 'focused_text':element.text = palette['focus']
            if len(old)==8 and old[2:] in mapping:
                element.text=old[:2]+mapping[old[2:]]
        for key in ('colordiffuse','start','end'):
            value=element.get(key,'')
            if len(value)==8 and value[2:] in mapping:
                element.set(key,value[:2]+mapping[value[2:]])
        if element.tag in ('texture','bordertexture') and any(part in (element.text or '') for part in ('poster-glow','poster-border','cinematic/poster-focus','cinematic/wide-focus')):
            element.set('colordiffuse',poster_color or palette['focus'])


def window(cls, filename, source, *args, **kwargs):
    """Compile a themed copy in the addon profile before WindowXML allocates it."""
    import xbmcvfs
    from addon_state import get_addon
    addon=get_addon()
    selected=index(addon)
    original=Path(source)/'resources/skins/Main/1080i'/filename
    if not original.exists():
        original=Path(addon.getAddonInfo('path'))/'resources/skins/Main/1080i'/filename
    transform=kwargs.pop('layout_transform',None)
    unique=kwargs.pop('unique_layout',False)
    tree=ET.parse(original)
    if transform:transform(tree)
    from lib.context_frost import FROST_MENUS, PROPERTY, current_artwork, apply as apply_frost
    context_artwork = current_artwork() if filename in FROST_MENUS else ''
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    apply_frost(tree, filename, profile, kwargs)
    from lib.appearance import options
    appearance = options(addon)
    apply(tree,selected,appearance['color'])
    from lib.appearance import apply as apply_appearance
    apply_appearance(tree, appearance)
    base=Path(profile)/'theme-layout'/str(selected)
    dest=base/'resources/skins/Main/1080i'
    dest.mkdir(parents=True,exist_ok=True)
    name='themed-'+filename
    if unique:
        import uuid
        name='themed-'+uuid.uuid4().hex+'-'+filename
    tree.write(dest/name,encoding='utf-8',xml_declaration=True)
    try:
        result=cls(name,str(base),*args,**kwargs)
    except Exception:
        if unique:
            try:(dest/name).unlink()
            except OSError:pass
        raise
    if unique:result._theme_layout_path=dest/name
    if filename in FROST_MENUS:
        result.setProperty(PROPERTY, context_artwork)
    return result
