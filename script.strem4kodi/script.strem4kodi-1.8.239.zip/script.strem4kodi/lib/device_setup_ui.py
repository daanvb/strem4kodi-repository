"""Guided enrollment and explicit private preference export from a working TV."""
from pathlib import Path
import time
import threading
import uuid
import xbmc
import xbmcgui
import xbmcvfs
from addon_state import get_addon
from account import Store, create_link_details, read_link, pull_addons, pull_library
from addons_core import merge_account
from device_profile import apply, export, restore
from device_setup import Client, DEFAULT_SERVER, SetupError
from lib.signin import WelcomeWindow, account_store, signed_in
from lib.ui_dialogs import dialog
from lib.theme import window as themed_window


def profile_path():return Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))


class SetupWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.purpose = kwargs.pop('purpose', 'enroll')
        self.completed = False
        self.cancel = threading.Event()
        self.refresh = threading.Event()
        self.worker = None
        self._ui_lock = threading.RLock()
        self._qr_paths = []
        self._dialog_id = None
        super().__init__(*args, **kwargs)

    def label(self, cid, text):
        with self._ui_lock:WelcomeWindow.label(self, cid, text)
    start_link = WelcomeWindow.start_link
    onClick = WelcomeWindow.onClick
    onAction = WelcomeWindow.onAction

    def onInit(self):
        identity = xbmcgui.getCurrentWindowDialogId()
        self._dialog_id = identity if type(identity) is int and 13000 <= identity < 14000 else None
        self.setFocusId(103)
        self.label(110, 'Copy the Shield master profile' if self.purpose == 'publish' else 'Apply the Shield master profile')
        self.start_link()

    def close(self):
        with self._ui_lock:
            self.cancel.set()
            super().close()

    def link_account(self):
        addon = get_addon()
        state_store = Store(profile_path() / 'device-enrollment')
        qr_path = profile_path() / ('device-setup-qr-'+uuid.uuid4().hex+'.png')
        self._qr_paths.append(qr_path)
        try:
            server = addon.getSetting('device_setup_server') or DEFAULT_SERVER
            client = Client(server)
            saved = state_store.load()
            pairing = saved.get('pairing') if saved.get('server') == server and saved.get('purpose') == self.purpose else None
            if not isinstance(pairing, dict) or pairing.get('expires', 0) <= time.time():
                link_code, link = '', ''
                if self.purpose == 'enroll' and not signed_in():
                    link_code, link, _ = create_link_details()
                label = 'freeBird - ' + (xbmc.getInfoLabel('System.FriendlyName') or 'Kodi device')[:60]
                pairing = client.start(label, self.purpose, link)
                saved = {'server':server, 'purpose':self.purpose, 'pairing':pairing, 'link_code':link_code}
                state_store.save(saved)
            from lib.vendor import segno
            qr_path.parent.mkdir(parents=True, exist_ok=True)
            segno.make(pairing['verification_url']).save(str(qr_path), scale=6, border=3)
            with self._ui_lock:
                if self.cancel.is_set():return
                self.getControl(120).setImage(str(qr_path))
            self.label(111, 'Approve this device on your phone')
            self.label(112, 'Code: '+pairing['code']+'\n'+pairing['verification_url'])
            while time.time() < pairing['expires'] and not self.cancel.is_set() and not self.refresh.is_set():
                try:
                    result = client.poll(pairing)
                except Exception:
                    self.label(111, 'Connection interrupted. Retrying…')
                    self.cancel.wait(2);continue
                if self.cancel.is_set():return
                if result['state'] == 'denied':
                    self.label(111, 'Device request rejected. Request a new code to retry.')
                    return
                if result['state'] in ('approved','completed'):
                    if self.purpose == 'publish':
                        exported = export(addon.getSetting)
                        exported['providerPreferences'] = Store(profile_path() / 'providers').load().get('providerPreferences', {})
                        exported['settings']['device_setup_player_skin'] = 'true' if xbmc.getSkinDir() == 'skin.strem4kodi' else 'false'
                        client.finish(pairing, exported)
                    elif result['state'] == 'approved':
                        self.label(111, 'Saving your setup profile…')
                        apply(result['profile'], addon, Store(profile_path() / 'device-setup-backup'),
                              self.cancel.is_set, Store(profile_path() / 'providers'))
                        if self.cancel.is_set():return
                        client.finish(pairing)
                    status = Store(profile_path() / 'device-setup-status')
                    current = status.load()
                    if self.purpose == 'enroll' and current.get('last_pairing') != pairing['code']:
                        current['completed'] = True
                        current['last_pairing'] = pairing['code']
                        current['skin_pending'] = addon.getSetting('device_setup_player_skin') == 'true'
                        current['kodi_pending'] = True
                        current['skin_settings_pending'] = current['skin_pending']
                        status.save(current)
                    if self.purpose == 'enroll' and not signed_in() and saved.get('link_code'):
                        self.label(111, 'Settings ready. Finish Connect Stremio on your phone.')
                        try:token = read_link(saved['link_code'])
                        except Exception:token = None
                        if self.cancel.is_set() or self.refresh.is_set():return
                        if not token:
                            self.cancel.wait(2);continue
                        account = account_store()
                        data = account.load();data['token'] = token;account.save(data)
                        self.label(111, 'Importing your Stremio add-ons and library…')
                        try:
                            addons, _ = pull_addons(token)
                            data['addons'] = merge_account(data, addons)
                            data['library'] = pull_library(token)
                            account.save(data)
                        except Exception:pass  # The existing idle sync retries imports.
                    if not self.cancel.is_set():
                        self.completed = True
                        state_store.forget()
                        self.close()
                    return
                self.cancel.wait(2)
            self.label(111, 'This code expired. Request a new code to retry.')
        except SetupError as error:
            self.label(111, str(error))
        except Exception:
            self.label(111, 'Setup could not finish. Retry to continue; any saved changes have a backup.')
        finally:
            if (self.cancel.is_set() or self.refresh.is_set()) and qr_path.exists():
                try:qr_path.unlink()
                except OSError:pass
            if self.refresh.is_set() and not self.cancel.is_set():
                self.refresh.clear();state_store.forget();self.worker = None;self.start_link()


def run(purpose='enroll'):
    from lib.launch_guard import mark_window, unmark_window
    win = themed_window(SetupWindow, 'script-strem4kodi-device-setup.xml', get_addon().getAddonInfo('path'), 'Main', '1080i', purpose=purpose)
    try:
        mark_window(win, 'device-setup')
        win.doModal()
        completed = win.completed
    finally:
        win.cancel.set();unmark_window(win)
        for path in win._qr_paths:
            try:path.unlink(missing_ok=True)
            except OSError:pass
    if win._dialog_id is not None:
        for _ in range(20):
            if not xbmc.getCondVisibility('Window.IsVisible({})'.format(win._dialog_id)):break
            xbmc.sleep(50)
        else:return False  # Never activate a skin/Home over a closing dialog.
    return completed


def activate_pending_skin(before_apply=None):
    # Called by the app shell before allocating Home/Sign-in, never Settings.
    status = Store(profile_path() / 'device-setup-status')
    try:data = status.load()
    except Exception:return  # Optional setup state must not break normal startup.
    if not any(data.get(key) for key in ('skin_pending', 'skin_restore_pending', 'kodi_pending')):return
    # Native skin reload can destroy the shared modeless window. Dispose of
    # temporary controls before the reload, then let the app recreate its cover.
    if before_apply is not None:before_apply()
    try:
        from setup_profile import rpc
        if data.get('skin_restore_pending'):
            import re
            target = data['skin_restore_pending']
            if not isinstance(target, str) or not re.fullmatch(r'skin\.[A-Za-z0-9_.-]+', target):return
            if not rpc('Settings.SetSettingValue', {'setting':'lookandfeel.skin', 'value':target}):return
            data.pop('skin_restore_pending', None)
        else:
            if data.get('skin_pending'):
                configure_skin()
                data['skin_pending'] = xbmc.getSkinDir() != 'skin.strem4kodi'
            if data.get('kodi_pending'):
                from device_kodi_profile import apply as apply_kodi
                from lib.device_kodi_setup import KodiBackend
                pending = apply_kodi(Store(profile_path() / 'device-setup-kodi-backup'),
                                     KodiBackend(), data.get('skin_settings_pending', False))
                data['kodi_pending'] = bool(pending)
                if not pending:data['skin_settings_pending'] = False
                issues = [item for item in pending if item != 'skin_settings']
                if issues and issues != data.get('kodi_issues'):
                    dialog().ok('Kodi setup', 'Kodi could not apply these settings: {}. Check them in Kodi Settings; setup will retry next time the app opens.'.format(', '.join(issues)))
                data['kodi_issues'] = issues
        status.save(data)
    except Exception:
        dialog().ok('Kodi setup', 'Kodi setup could not finish. Reopen the app to retry pending changes, or use Undo device setup.')


def configure_skin():
    from setup_profile import get_setting, rpc
    target = 'skin.strem4kodi'
    before = get_setting('lookandfeel.skin')
    if before == target:return
    journal = Store(profile_path() / 'device-setup-kodi-backup')
    backup = journal.load()
    if 'skin_before' not in backup:
        backup.update(skin_before=before, skin_applied=target)
        journal.save(backup)
    if not rpc('Settings.SetSettingValue', {'setting':'lookandfeel.skin', 'value':target}):
        dialog().ok('Player appearance', 'Your freeBird settings are ready. Enable the freeBird skin in Kodi Appearance to finish the player setup.')


def first_run():
    status = Store(profile_path() / 'device-setup-status')
    if signed_in() or status.load().get('completed') or status.load().get('skipped'):
        return True
    choice = dialog().select('Set up this device', ['Use my private setup profile', 'Standard Stremio sign-in', 'Cancel'])
    if choice == 0:return run()
    if choice == 1:
        status.save({'skipped':True})
        return True
    return False


def undo():
    if dialog().yesno('Undo device setup', 'Restore the settings backed up before setup? Preferences you changed afterwards will be kept.'):
        count = restore(get_addon(), Store(profile_path() / 'device-setup-backup'), Store(profile_path() / 'providers'))
        from setup_profile import get_setting, rpc
        journal = Store(profile_path() / 'device-setup-kodi-backup').load()
        status = Store(profile_path() / 'device-setup-status')
        data = status.load();data['skin_pending'] = False;data['kodi_pending'] = False
        data['skin_settings_pending'] = False
        from device_kodi_profile import restore as restore_kodi
        from lib.device_kodi_setup import KodiBackend
        restored, pending = restore_kodi(Store(profile_path() / 'device-setup-kodi-backup'), KodiBackend())
        count += restored
        if journal.get('skin_before') and get_setting('lookandfeel.skin') == journal.get('skin_applied'):
            data['skin_restore_pending'] = journal['skin_before']
        status.save(data)
        message = 'Restored {} settings.'.format(count)
        if pending:message += ' Kodi could not restore: {}. Retry Undo device setup to finish.'.format(', '.join(pending))
        dialog().ok('Device setup', message)
