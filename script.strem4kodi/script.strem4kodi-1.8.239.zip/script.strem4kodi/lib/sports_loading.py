"""One cancellable sports request per browser, without worker-owned browse UI."""
import threading


class PendingRequest(RuntimeError):
    pass


class Requests:
    def __init__(self, thread_factory=threading.Thread):
        self.thread_factory = thread_factory
        self.lock = threading.Lock()
        self.active = None
        self.cancelled = False

    def run(self, work, display, cancellable=False):
        with self.lock:
            if self.active is not None:
                raise PendingRequest('Previous sports request is finishing')
            request = self.active = Request(self, work)
            if cancellable:
                request.work = lambda: work(request.cancelled.is_set)
        self.cancelled = False
        try:
            display(request)
            self.cancelled = request.cancelled.is_set()
            return None if self.cancelled or request.failed else request.value
        finally:
            request.cancelled.set()
            request.value = None
            # Construction/activation can fail before onInit starts the thread.
            if not request.started:
                request.work = None
                self.finished(request)

    def finished(self, request):
        with self.lock:
            if self.active is request:
                self.active = None

    def cancel(self):
        with self.lock:
            request = self.active
        if request is not None:
            request.cancelled.set()
            finish = request.finish
            if finish is not None:
                finish()


class Request:
    def __init__(self, owner, work):
        self.owner, self.work = owner, work
        self.cancelled = threading.Event()
        self.done = threading.Event()
        self.started = self.failed = False
        self.value = None
        self.finish = None

    def start(self, finish):
        self.finish = finish
        def run():
            try:
                if not self.cancelled.is_set():
                    value = self.work()
                    if not self.cancelled.is_set():
                        self.value = value
            except Exception:
                # Provider exceptions may contain private URLs or API keys.
                self.failed = True
            finally:
                self.work = None
                self.owner.finished(self)
                self.done.set()
                try:
                    if not self.cancelled.is_set():
                        finish()
                finally:
                    self.finish = None
        self.started = True
        try:
            self.owner.thread_factory(target=run, daemon=True).start()
        except (RuntimeError, OSError):
            self.failed = True
            self.work = None
            self.owner.finished(self)
            self.done.set()
            try:finish()
            finally:self.finish = None


def show(path, label, request):
    """A native modal owns Cancel; network work runs outside its onInit callback."""
    from lib.ui_dialogs import ProgressWindow
    from lib.theme import window
    from lib.window_lifetime import Lifetime

    class SportsProgress(ProgressWindow):
        def __init__(self, *args, **kwargs):
            self.lifetime = Lifetime()
            self.closed = False
            super().__init__(*args, **kwargs)

        def onInit(self):
            super().onInit()
            if request.cancelled.is_set():
                self.close()
                return
            request.start(lambda: self.lifetime.publish(self.close))

        def onClick(self, control):
            if control == 201:
                request.cancelled.set()
                self.close()

        def onAction(self, action):
            if action.getId() in (10, 92, 216, 247):
                request.cancelled.set()
                self.close()

        def close(self):
            with self.lifetime.lock:
                if self.closed:
                    return
                self.closed = True
            if not request.done.is_set():
                request.cancelled.set()
            self.lifetime.retire(super().close)

    dialog = window(SportsProgress, 'script-stremio-dialog-progress.xml', path, 'Main', '1080i')
    try:
        dialog.setProperty('dialog_title', 'freeBird')
        dialog.setProperty('dialog_message', label)
        dialog.doModal()
    finally:
        dialog.close()
