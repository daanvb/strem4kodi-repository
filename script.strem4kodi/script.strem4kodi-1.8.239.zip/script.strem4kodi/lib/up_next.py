"""Floating next-episode prompt for Strem4Kodi playback only."""
import hashlib
import threading
import time
import uuid
from pathlib import Path
from datetime import datetime, timezone
import xbmc
import xbmcgui
from account import Store
from addon_state import get_addon
from lib.theme import window as themed_window
from lib.runtime_trace import playback as trace_playback
from lib.playback_loading import LoadingSession
ROOT = str(Path(__file__).resolve().parents[1])
VISIBLE = 'strem4kodi.up_next.visible'
AUTOPLAY_LIMIT = 3


def card_visible(value):
    try:
        session = xbmcgui.Window(10000)
        if value:
            session.setProperty(VISIBLE, 'true')
        else:
            session.clearProperty(VISIBLE)
    except Exception:
        pass

def following_episode(videos, current_id, now=None):
    rows=[]
    for row in videos or []:
        try:
            season=int(row.get('season'));episode=int(row.get('episode',row.get('number')))
            if season>0 and episode>0 and row.get('id'):rows.append((season,episode,row))
        except (TypeError,ValueError,AttributeError):pass
    rows.sort(key=lambda r:r[:2])
    index=next((i for i,r in enumerate(rows) if r[2]['id']==current_id),None)
    if index is None or index+1==len(rows):return None
    candidate=rows[index+1][2]
    released=candidate.get('released') or candidate.get('firstAired')
    if not released:return None
    try:
        date=datetime.fromisoformat(str(released).replace('Z','+00:00'))
        if date.tzinfo is None:date=date.replace(tzinfo=timezone.utc)
        if date>(now or datetime.now(timezone.utc)):return None
    except (TypeError,ValueError):return None
    # Providers sometimes shift the previous episode title into the next row.
    # The metadata merger already uses corroborating fallback titles. If it
    # cannot repair a duplicate, avoid advertising the previous title again.
    previous = rows[index][2]
    title = str(candidate.get('title') or candidate.get('name') or '').strip()
    previous_title = str(previous.get('title') or previous.get('name') or '').strip()
    if title and title.casefold() == previous_title.casefold():
        candidate = dict(candidate, title='Next episode', name='Next episode')
    elif title:
        # Some merged rows retain an older name alongside a corrected title.
        candidate = dict(candidate, title=title, name=title)
    return candidate

def prompt_due(position,duration,lead=60,credits=None):
    if duration<=120:return False
    threshold=max(duration/2,duration-lead)
    if isinstance(credits,dict):
        try:
            start=float(credits['start']);end=float(credits['end'])
            if duration/2<=start<end<=duration+10:threshold=start
        except (TypeError,ValueError,KeyError):pass
    return threshold<=position<duration


def series_metadata(stream):
    """Restore the series identity/name from the episode playback handoff."""
    meta = dict(stream.get('meta') or {})
    identity = meta.get('_stremio_meta_id') or meta.get('_series_id') or meta.get('series_id')
    if not identity:
        parts = str(stream.get('id') or meta.get('id') or '').rsplit(':', 2)
        if len(parts) == 3 and all(part.isdigit() for part in parts[1:]):
            identity = parts[0]
    if identity:
        meta['id'] = identity
    if meta.get('tvshowtitle'):
        meta['name'] = meta['tvshowtitle']
    elif meta.get('_media_type') == 'episode':
        # An unavailable series refresh must not label the card with this
        # episode's display name.
        meta.pop('name', None)
    for key in ('season', 'episode', '_media_type'):
        meta.pop(key, None)
    return meta

class UpNextWindow(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        self.episode=kwargs.pop('episode');self.meta=kwargs.pop('meta');self.accept=kwargs.pop('accept');self.dismiss=kwargs.pop('dismiss')
        self.loading = False
        super().__init__(*args,**kwargs)
    def onInit(self):
        row=self.episode
        protected = get_addon().getSetting('episode_spoilers') not in ('', '0')
        self.setProperty('next_title',str(row.get('title') or row.get('name') or 'Next episode'))
        self.setProperty('next_series',str(self.meta.get('name') or ''))
        self.setProperty('next_number','S{:02d} · E{:02d}'.format(int(row['season']),int(row.get('episode',row.get('number')))))
        self.setProperty('next_art',str((None if protected else row.get('thumbnail')) or self.meta.get('background') or self.meta.get('poster') or ''))
        from lib.auto_source import select
        mode, _, _ = select([], get_addon(), self.meta)
        self.action_label = 'Play Next' if mode == 2 else 'Choose Source'
        self.set_loading(False)
        self.set_status('')
        self.setFocusId(201)
    def set_loading(self, loading):
        self.loading = loading
        self.setProperty('next_loading', 'true' if loading else '')
        self.setProperty('next_action', 'Loading…' if loading else self.action_label)
    def set_status(self, text):
        self.setProperty('next_status', text)
    def onClick(self,cid):
        if cid == 201:
            if self.loading:
                return
            trace_playback('next.click')
            self.set_loading(True)
            self.accept()
        elif cid == 202:
            self.dismiss()
    def onAction(self,action):
        if action.getId() in (10,92,216,247):self.dismiss()
        elif action.getId() == 13:
            self.dismiss()
            xbmc.Player().stop()

class UpNextWatcher:
    def __init__(self,profile,player=None):
        self.profile=Path(profile);self.player=player or xbmc.Player();self.digest=None;self.session=None;self.ready=None;self.window=None;self.dismissed=False;self.lock=threading.Lock()
        self.pending = None
        self.loading = None
        self.prepared = None
        self.autoplay_advances = 0
        self._autoplay_started_digest = None
        from lib.playback_recovery import RecoveryTracker
        self.recovery=RecoveryTracker(profile=self.profile)
        self.recovery_player=None
        card_visible(False)
        from lib.smart_credits import CreditsMemory
        self.credits_memory=CreditsMemory(profile);self.credits_recorded=False
    def close(self, keep_prepared=False):
        self.finish_loading()
        self.recovery.clear()
        if not keep_prepared:self.prepared = None
        if self.pending and self.pending.get('early_timer'):
            self.pending['early_timer'].cancel()
        self.pending = None
        if self.window:
            trace_playback('next.close')
            try:self.window.close()
            except Exception as error:trace_playback('next.error', error=error)
            else:trace_playback('next.closed')
        self.window=None
        card_visible(False)
    def finish_loading(self):
        loading,self.loading=self.loading,None
        if loading:loading.finish()
    def loading_state(self):
        request=self.pending
        if not request or not self.loading:return None
        state=self.recovery.loading_state()
        if state and state.get('attempt')==self.loading.attempt:
            return dict(state,started=bool(state.get('started') and request.get('confirmed')))
        return {'attempt':self.loading.attempt,'started':False}
    def current_digest(self):
        try:
            if not self.player.isPlayingVideo():return None
            from source_probe import error_video
            if error_video(self.player.getPlayingFile()):return None
            return hashlib.sha256(self.player.getPlayingFile().encode()).hexdigest() if self.player.isPlayingVideo() else None
        except Exception:return None
    def current_session(self):
        value = getattr(self.player, '_track_session', None)
        return value if type(value) is int else None
    def switch_playback(self, digest, session, continuing_chain=False):
        """Drop the previous episode's card before loading a new playback."""
        if not continuing_chain:self.autoplay_advances = 0
        self._autoplay_started_digest = None
        self.close()
        self.digest=digest;self.session=session;self.ready=None
        self.dismissed=False;self.credits_recorded=False
        if digest:threading.Thread(target=self.load,args=(digest,session),daemon=True).start()
    def load(self,digest,session):
        try:
            # Resolve only this video's payload. Redirects can change the URL,
            # but the playing item's attempt still identifies our request.
            from lib.playback_recovery import playing_attempt
            stream={}
            owned=False
            for attempt in range(5):
                if self.current_digest()!=digest or self.current_session()!=session:return
                try:key=self.player.getPlayingItem().getProperty('StremioPlaybackKey')
                except (AttributeError,RuntimeError):key=''
                if not isinstance(key,str) or not key:
                    key=Store(self.profile/'playback-context').load().get('key')
                from lib.playback_payload import load
                stream=(load(self.profile,key).get('urls') or {}).get(key) or {}
                token=playing_attempt(self.player)
                expected=stream.get('_playback_attempt')
                owned=(token==expected if token else
                       hashlib.sha256(str(stream.get('url','')).encode()).hexdigest()==digest)
                if owned:break
                time.sleep(0.25)
            if stream.get('kind')!='series' or not owned:return
            from lib import backend as api
            # Episode playback needs episode data, not an optional quality-logo
            # network lookup for the series hero.
            meta=dict(api.metadata(dict(series_metadata(stream), _focus_video_id=stream.get('id'))))
            meta.pop('_random_episode',None)
            meta.pop('_random_previous',None)
            if stream.get('_random_episode'):
                from lib.random_episode import choose
                row=choose(meta.get('videos'),stream.get('id'),stream.get('_random_previous'))
                meta=dict(meta,_random_episode=True,_random_previous=stream.get('id'))
            else:
                row=following_episode(meta.get('videos'),stream.get('id'))
            if row:
                meta['_focus_video_id']=row['id']
                # Carry the same episode label into the loading/player payload.
                meta['videos']=[dict(video,**row) if video.get('id')==row['id'] else video
                                for video in meta.get('videos',[])]
            with self.lock:
                if self.digest!=digest or self.session!=session or not row:return
                self.ready=(meta,row,None,stream.get('id'))
            # Slow/unavailable credits services must not hold back the title.
            from lib.skip_segments import fetch_segments
            credits=next((x for x in fetch_segments(self.profile,'series',stream.get('id')) if x.get('type')=='outro'),None)
            with self.lock:
                if self.digest==digest and self.session==session:self.ready=(meta,row,credits,stream.get('id'))
        except Exception:pass
    def prepare(self, digest, meta, row):
        """Warm one next-episode search, without starting or stopping playback."""
        if self.prepared is not None or not row.get('id'):return
        work = dict(digest=digest, session=self.current_session(), identity=row['id'], checked={}, failed={})
        self.prepared = work
        def current():
            return (self.prepared is work and not self.dismissed and
                    self.current_session()==work['session'] and self.current_digest()==digest)
        def warm():
            try:
                if not current():return
                from lib import backend as api
                work['signature'] = api._stream_provider_signature()
                cached = api.stream_cache_state(meta,row['id'])
                result = api.cached_source_rows(meta,row['id']) if cached and not cached[4] else None
                rows,_,_ = result if result is not None else api.source_rows(meta,row['id'],cancelled=lambda:not current())
                if not current():return
                from lib.auto_source import select
                from lib.source_preferences import preferences,rank_rows,limit_quality,picker_filters
                from lib.stream_presenter import filter_rows
                prefs=preferences(get_addon())
                rows=filter_rows(rank_rows(limit_quality(rows,prefs['maximum']),prefs),*picker_filters(get_addon()))
                mode,best,_=select(rows,get_addon(),meta,identity=row['id'],profile=api.STORE.directory)
                if mode!=2 or not best:return
                if current():
                    with self.lock:
                        work['candidate'] = best
            except Exception:
                pass  # Warm-up is optional; the normal foreground flow retries.
        try:threading.Thread(target=warm,daemon=True).start()
        except RuntimeError:self.prepared=None
    def check_prepared(self, digest):
        work=self.prepared
        if not work or not work.get('candidate') or work.get('checking'):return
        work['checking']=True
        def check():
            def current():
                return (self.prepared is work and not self.dismissed and
                        self.current_session()==work['session'] and self.current_digest()==digest)
            try:
                if not current():return
                from source_probe import unavailable
                source=work['candidate']
                failure=unavailable(source['url'],live=bool(source.get('isLive') or '.m3u8' in source['url']))
                if current():
                    if failure:
                        from lib.source_failures import record
                        from lib.playback_recovery import digest as failed_digest
                        record(self.profile,failed_digest(source['url']))
                    with self.lock:
                        work['failed' if failure else 'checked'][source['url']] = time.monotonic()
            except Exception:pass
        try:threading.Thread(target=check,daemon=True).start()
        except RuntimeError:work['checking']=False
    def hide(self):
        self.dismissed=True
        if self.pending:
            from lib.playback_loading import signal_cancel
            try:signal_cancel(self.pending.get('attempt') or self.pending.get('cover_token'))
            except (ImportError,AttributeError,RuntimeError):pass
        self.close()
    def play(self,digest,meta,row,automatic_handoff=False):
        if self.pending is not None:
            return
        trace_playback('next.request')
        # Construct the callback listener on the lasting service thread, not
        # the source-search worker whose callback pump ends after dispatch.
        if self.recovery_player is None:
            from lib.playback_recovery import player
            trace_playback('next.listener')
            self.recovery_player=player(self.recovery,self.profile)
        # Freeze the intended episode against later UI/metadata mutations.
        row = dict(row)
        meta = dict(meta)
        session = self.current_session()
        request = dict(digest=digest, session=session, origin_session=session, stage='searching', deadline=time.monotonic() + 120,
                       early_lock=threading.RLock(), early_done=threading.Event(), search_done=False,
                       failed=set(), attempts=0, automatic_handoff=automatic_handoff)
        request['cover_token']=uuid.uuid4().hex
        request['early_done'].set()
        self.pending = request
        self.dismissed = True
        if self.window:
            self.window.set_loading(True)
        if self.window:
            self.window.set_status('Finding sources...')
        def current():
            if self.pending is not request or self.current_session()!=request['session']:return False
            playing = self.current_digest()
            if playing == digest:return True
            # Before the first dispatch, stopping the current episode cancels
            # Play Next. A no-video gap is valid once handoff has begun.
            if playing is None and not request.get('dispatched'):
                return bool(getattr(self.player, '_naturally_ended_session', None) == request['session'] and
                            type(request['session']) is int)
            if playing in (None,request.get('failed_hash')):return True
            from lib.playback_recovery import playing_attempt
            return bool(request.get('attempt') and playing_attempt(self.player)==request['attempt'])
        def retry(message=None):
            if self.pending is not request:
                return
            trace_playback('next.error' if message else 'next.cancel')
            self.pending = None
            self.finish_loading()
            self.dismissed = False
            if self.window:
                self.window.set_loading(False)
                self.window.set_status(message or 'Selection cancelled')
            if message:
                from lib.ui_dialogs import dialog
                from lib.diagnostic_export import report_reference
                dialog().notification('Up Next', message+' '+report_reference(self.profile))
        def start(api, source, validate=True):
            if not current():
                return
            from lib.source_failures import blocked
            from lib.playback_recovery import digest as failed_digest
            failures=blocked(self.profile)
            if failures is None or failed_digest(source['url']) in failures:
                retry('That link is blacklisted or the failed-source list is unavailable. Choose another source from the episode page.')
                return
            trace_playback('next.selected')
            request.update(stage='starting', deadline=time.monotonic() + 60)
            if self.window:self.window.set_status('Checking selected source...')
            from lib.stream_presenter import stream_traits
            attempt=self.recovery.arm(source['url'],row['id'],0,0,automatic=bool(request.get('automatic')),provider=stream_traits(source)['provider'])
            request['attempt']=attempt
            if not self.loading or not self.loading.advance(attempt,
                    str(row.get('title') or row.get('name') or 'Next episode'),
                    'Starting next episode...',state=self.loading_state,
                    art={'poster':meta.get('poster') or '', 'background':meta.get('background') or ''}):
                retry('Could not open the loading screen. Please try again.')
                return
            from lib.playback_recovery import digest as source_digest
            request['source_hash']=source_digest(source['url'])
            request['attempts']+=1
            request['failed'].add(source['url'])
            if request.get('automatic') and validate:
                from source_probe import unavailable
                failure=unavailable(source['url'],live=bool(source.get('isLive') or '.m3u8' in source['url']))
                if failure:
                    self.recovery.failed(failure)
                    return
            if not current():return
            if not self.loading or not self.loading.wait_visible(attempt):
                if current():retry('Could not show the loading screen. Please try again.')
                return
            if current():
                if self.window:self.window.set_status('Starting next episode...')
                from lib.auto_source import selection_details
                automatic = bool(request.get('automatic'))
                details=[]
                if automatic:
                    try:details=selection_details(source,get_addon(),meta,row['id'])
                    except Exception:pass
                request['dispatched'] = True
                trace_playback('next.dispatch', attempt_number=request['attempts'])
                api.play(meta, row['id'], dict(source,_playback_attempt=attempt, _automatic_selection=automatic,
                         _selection_details=details, _random_episode=bool(meta.get('_random_episode')),
                         _random_previous=meta.get('_random_previous')))
        def choose():
            try:
                if not current():return
                trace_playback('next.search')
                from lib import backend as api
                from lib.ui_dialogs import dialog
                cached = api.stream_cache_state(meta, row['id'])
                result = api.cached_source_rows(meta, row['id']) if cached and not cached[4] else None
                # Reuse only recent preflight verdicts belonging to this exact
                # playback session, episode and current provider configuration.
                verified = {}
                warm = self.prepared
                if (warm and warm['digest']==digest and warm['session']==request['session']
                        and warm['identity']==row['id'] and
                        warm.get('signature')==api._stream_provider_signature()):
                    with self.lock:
                        verified = {url:stamp for url,stamp in warm['checked'].items()
                                    if 0 <= time.monotonic()-stamp < 30}
                        request['failed'].update(url for url,stamp in warm['failed'].items()
                                                if 0 <= time.monotonic()-stamp < 30)
                early_failed = request['failed']
                try:limit=(3,5,10,25)[int(get_addon().getSetting('auto_source_attempts') or '1')]
                except (ValueError,IndexError):limit=5
                def early_match():
                    from lib.auto_source import early_select
                    from lib.source_preferences import picker_filters
                    candidates = [dict(source, _session_failed=source.get('url') in early_failed)
                                  for source in request.get('early_rows', [])]
                    return early_select(candidates, get_addon(), meta, picker_filters(get_addon()),identity=row['id'],profile=api.STORE.directory)
                def settled():
                    with request['early_lock']:
                        if not current() or request['search_done'] or request['stage'] != 'searching':return
                        best = early_match()
                        if best is None:return
                        request['stage'] = 'checking'
                        request['early_done'].clear()
                    try:
                        from source_probe import unavailable
                        if unavailable(best['url']):
                            from lib.source_failures import record
                            from lib.playback_recovery import digest as failed_digest
                            record(self.profile,failed_digest(best['url']))
                            early_failed.add(best['url'])
                            request['stage'] = 'searching'
                        elif current():
                            request['automatic']=True
                            start(api, best,validate=False)
                    except Exception as error:
                        trace_playback('next.error', error=error)
                        retry('Could not start the next episode. Please try again.')
                    finally:
                        with request['early_lock']:
                            request['early_timer'] = None
                            request['early_done'].set()
                def arriving(found):
                    with request['early_lock']:
                        if not current() or request['search_done']:return
                        request['early_rows'] = found
                        if (request['stage'] == 'searching' and len(early_failed) < limit
                                and request.get('early_timer') is None and early_match() is not None):
                            timer = threading.Timer(0.0, settled)
                            timer.daemon = True
                            request['early_timer'] = timer
                            try:timer.start()
                            except RuntimeError:request['early_timer'] = None
                result = result if result is not None else api.source_rows(meta,row['id'],on_formats=arriving,
                                                                           cancelled=lambda:not current())
                if not current():return
                if result is None:
                    retry('Could not load the next episode. Please try again.')
                    return
                rows,_,_ = result
                with request['early_lock']:
                    request['search_done'] = True
                    if request.get('early_timer'):request['early_timer'].cancel()
                request['early_done'].wait()
                request['rows']=rows
                for source in rows:
                    if source.get('url') in early_failed:source['_session_failed'] = True
                if not current():return
                from lib.source_preferences import preferences,rank_rows,limit_quality,picker_filters
                from lib.stream_presenter import filter_rows
                prefs=preferences(get_addon())
                rows=filter_rows(rank_rows(limit_quality(rows,prefs['maximum']),prefs),*picker_filters(get_addon()))
                if not rows:
                    retry('No sources match your device preferences and filters.')
                    return
                from lib.stream_presenter import presentation
                request['rows']=rows
                from lib.auto_source import select
                mode, best, _ = select(rows, get_addon(), meta,identity=row['id'],profile=api.STORE.directory)
                request['automatic']=mode==2
                def advance():
                    if self.pending is not request:return
                    candidates=[dict(source,_session_failed=source.get('url') in request['failed']) for source in request['rows']]
                    _, candidate, _=select(candidates,get_addon(),meta,identity=row['id'],profile=api.STORE.directory)
                    if candidate is None or len(request['failed'])>=limit:
                        retry('Automatic sources were unavailable. Choose a source manually from the episode page.')
                        return
                    request['stage']='searching'
                    if self.window:self.window.set_status('Trying another source for this episode...')
                    start(api,candidate)
                request['advance']=advance
                if request['stage'] != 'searching':return
                if mode == 2:
                    from source_probe import unavailable
                    try:limit=(3,5,10,25)[int(get_addon().getSetting('auto_source_attempts') or '1')]
                    except (ValueError,IndexError):limit=5
                    for _ in range(max(0, limit - len(early_failed))):
                        if best is None or not current():break
                        if (best['url'] in verified and 0 <= time.monotonic()-verified[best['url']] < 30) or not unavailable(best['url']):
                            start(api, best,validate=False)
                            return
                        failed_url=best['url']
                        from lib.source_failures import record
                        from lib.playback_recovery import digest as failed_digest
                        record(self.profile,failed_digest(failed_url))
                        early_failed.add(failed_url)
                        for source in rows:
                            if source.get('url')==failed_url:source['_session_failed']=True
                        _, best, _ = select(rows, get_addon(), meta,identity=row['id'],profile=api.STORE.directory)
                    retry('Automatic sources were unavailable. Choose a source manually from the episode page.')
                    return
                preselect = rows.index(best) if best in rows else 0
                request['stage'] = 'picking'
                index = dialog().select('Next episode - choose a source',[presentation(r)['title'] for r in rows], preselect=preselect)
                if index>=0 and current():start(api, rows[index])
                else:retry()
            except Exception as error:
                trace_playback('next.error', error=error)
                retry('Could not load the next episode. Please try again.')
        try:
            self.loading=LoadingSession(self.hide,state=self.loading_state)
            self.loading.begin(request['cover_token'],str(row.get('title') or row.get('name') or 'Next episode'),
                'Finding sources...',art={'poster':meta.get('poster') or '',
                                          'background':meta.get('background') or ''})
            threading.Thread(target=choose,daemon=True).start()
        except Exception as error:
            trace_playback('next.error', error=error)
            retry('Could not start loading. Please try again.')
    def tick(self):
        if get_addon().getSetting('up_next_enabled')=='false':self.close();return
        digest=self.current_digest()
        session=self.current_session()
        if self.pending is not None:
            request = self.pending
            if session != request['session']:
                from lib.playback_recovery import playing_attempt, digest as source_digest
                token=playing_attempt(self.player)
                try:
                    owned=bool(request.get('dispatched') and request.get('attempt') and
                               (token==request['attempt'] or
                                (not token and source_digest(self.player.getPlayingFile())==request.get('source_hash'))))
                except (AttributeError,RuntimeError):owned=False
                # A failed player may already have cleared its item and URL.
                # The attempt-scoped recovery event still proves ownership.
                event=self.recovery.loading_state()
                if (not owned and request.get('dispatched') and event and event.get('failed')
                        and event.get('attempt')==request.get('attempt')):
                    owned=True
                if not owned:
                    self.close()
                    return
                # ProgressPlayer creates the intended next episode's session at
                # AVStarted. That event must not revoke its startup verdict.
                request['session']=session
            if digest is None and not request.get('dispatched'):
                naturally_ended = bool(type(request['session']) is int and
                    getattr(self.player, '_naturally_ended_session', None) == request['session'])
                if not naturally_ended:
                    self.close()
                    return
            self.recovery.poll_failure(self.profile)
            startup_state=None
            owned=False
            state=self.recovery.snapshot()
            if state:
                try:
                    from lib.playback_recovery import playing_attempt, digest as source_digest, startup_video_state, persist_failure
                    if self.player.isPlayingVideo():
                        token=playing_attempt(self.player)
                        url=self.player.getPlayingFile()
                        startup_state=startup_video_state(self.player,state)
                        owned=(token==state['attempt'] or (not token and
                               (source_digest(url)==state['hash'] or startup_state=='failed')))
                        if owned and startup_state=='failed':
                            persist_failure(self.profile,state,'provider-error-video')
                            self.recovery.failed('provider-error-video')
                        elif owned and startup_state=='ready' and self.player.getTime()>.5:
                            self.recovery.started(url,token)
                except (AttributeError,RuntimeError,TypeError,ValueError):pass
            self.recovery.startup_timeout()
            failure=self.recovery.take()
            if failure and failure.get('attempt')==request.get('attempt'):
                request['failure']=failure
                request['failed_hash']=failure['hash']
            if request.get('failure'):
                failure=request['failure']
                from lib.playback_recovery import stop_failed
                state=stop_failed(self.player,failure)
                if state=='waiting':return
                if state in ('blocked','unrelated'):
                    self.close()
                    if state=='blocked':
                        from lib.ui_dialogs import dialog
                        dialog().notification('Up Next','Kodi is still busy with the failed stream. Automatic retries have stopped.')
                    return
                if request.get('automatic') and request.get('advance'):
                    request.pop('failure')
                    try:
                        threading.Thread(target=request['advance'],daemon=True).start()
                    except RuntimeError:
                        self.recovery.clear()
                        self.finish_loading()
                        self.pending=None;self.dismissed=False
                        if self.window:
                            self.window.set_loading(False)
                            self.window.set_status('Could not start retry. Please try again.')
                elif request.get('search_done'):
                    self.recovery.clear()
                    self.finish_loading()
                    self.pending=None;self.dismissed=False
                    if self.window:self.window.set_loading(False)
                return
            state=self.recovery.snapshot()
            # PlayMedia can expose a different URL while Kodi is still using
            # the old item/clock. Require the selected attempt's ready video,
            # and the progress observer's new AV session when available.
            confirmed = bool(request.get('dispatched') and owned and state and
                             state.get('attempt')==request.get('attempt') and
                             state.get('started') and not state.get('checking') and
                             startup_state=='ready')
            session_started = (type(request['origin_session']) is not int or
                               session != request['origin_session'])
            if digest and confirmed and session_started:
                try:
                    if self.player.getTime() <= 0.25:return
                except Exception:
                    return
                automatic_handoff = bool(request.get('automatic_handoff'))
                request['confirmed']=True
                if self.loading:
                    self.loading.finish_started(request['attempt'])
                    if self.loading.attempt:return
                trace_playback('next.started', started=True, owned=True)
                if automatic_handoff:
                    self.autoplay_advances = min(AUTOPLAY_LIMIT, self.autoplay_advances + 1)
                self.switch_playback(digest,session,continuing_chain=automatic_handoff)
                return  # Never reuse the old episode's ready data or clock.
            elif request['stage'] != 'picking' and time.monotonic() >= request['deadline']:
                self.recovery.clear()
                self.finish_loading()
                self.pending = None
                self.dismissed = False
                if self.window:self.window.set_loading(False)
                from lib.ui_dialogs import dialog
                dialog().notification('Up Next','The next episode took too long to load. Please try again.')
            else:
                return  # Keep the card visible through searching and hand-off.
        if digest!=self.digest or session!=self.session:
            # Autoplay begins only after Kodi confirms the owned episode ended
            # naturally. Starting near the end can cut off post-credit audio or
            # the final seconds when source discovery returns immediately.
            if (not digest and self.digest and not self.dismissed and self.ready
                    and getattr(self.player, '_naturally_ended_session', None) == self.session
                    and type(self.session) is int
                    and self.autoplay_advances < AUTOPLAY_LIMIT
                    and get_addon().getSetting('up_next_autoplay') == 'true'):
                meta, row, _, _ = self.ready
                from lib.auto_source import configured
                if configured(get_addon(), meta)[0] == 2:
                    self.play(self.digest, meta, row, automatic_handoff=True)
                    return
            continuing_chain = bool(digest and digest == self._autoplay_started_digest)
            self.switch_playback(digest,session,continuing_chain=continuing_chain)
            return
        if not digest or self.dismissed or not self.ready:return
        try:
            position=self.player.getTime();duration=self.player.getTotalTime()
        except Exception:return
        meta,row,credits,identity=self.ready
        try:lead=(60,120,180,300)[int(get_addon().getSetting('up_next_lead') or '0')]
        except (ValueError,IndexError):lead=60
        from lib.smart_credits import marker_start
        start=marker_start(credits,duration)
        smart=get_addon().getSetting('up_next_smart')!='false'
        if smart and not self.credits_recorded and start is not None and position>=start:
            try:self.credits_memory.observe(identity,duration,credits,position)
            except Exception:pass
            self.credits_recorded=True
        threshold,_=self.credits_memory.timing(identity,duration,credits,lead,smart)
        if duration>120 and position>=max(duration/2,min(threshold,duration-120)-30):
            self.prepare(digest,meta,row)
            if 0<duration-position<=25:self.check_prepared(digest)
        if duration<=120 or not threshold<=position<duration:self.close(keep_prepared=duration>120);return
        if self.window:return
        try:
            trace_playback('next.show')
            self.window=themed_window(UpNextWindow,'script-strem4kodi-up-next.xml',ROOT,'Main','1080i',meta=meta,episode=row,accept=lambda:self.play(digest,meta,row),dismiss=self.hide)
            self.window.show()
            trace_playback('next.shown')
            card_visible(True)
            from lib.credits_watched import signal
            signal(self.profile, self.player, expected_hash=digest, expected_id=identity)
        except Exception as error:
            trace_playback('next.error', error=error)
            self.dismissed=True;self.close()
