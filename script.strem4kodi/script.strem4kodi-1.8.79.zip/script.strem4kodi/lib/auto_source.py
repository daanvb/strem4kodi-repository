"""Per-device, per-content source selection; never bypass the quality ceiling."""
from lib.source_preferences import preferences, rank_rows, limit_quality
from lib.stream_presenter import stream_traits, presentation, filter_rows
import re

PROFILES = ('movie', 'series', 'animation')
FIELDS = {'quality': ('Any', '4K', '1080p', '720p'),
          'dynamic': ('Any', 'Dolby Vision', 'HDR10', 'FEL reported'),
          'audio': ('Any', 'Atmos', 'TrueHD', 'Dolby Digital Plus', 'AAC'),
          'sort': ('recommended', 'provider', 'smallest', 'largest')}


def profile(meta):
    genres = meta.get('genres') or []
    if isinstance(genres, str):genres = [genres]
    if meta.get('type') == 'series' and any(str(g).casefold() == 'animation' for g in genres):return 'animation'
    return 'series' if meta.get('type') == 'series' else 'movie'


def configured(addon, meta):
    scope = profile(meta)
    prefs = preferences(addon)
    for field, values in FIELDS.items():
        try:index = int(addon.getSetting('auto_' + scope + '_' + field) or '0') - 1
        except (ValueError, TypeError):index = -1
        if 0 <= index < len(values):prefs[field] = values[index]
    for field in ('provider', 'language'):
        value = addon.getSetting('auto_' + scope + '_' + field)
        if value and value != '__inherit__':prefs[field] = '' if value == '__any__' else value
    try:mode = int(addon.getSetting('auto_' + scope + '_mode') or '0')
    except (ValueError, TypeError):mode = 0
    return mode if mode in (0, 1, 2) else 0, prefs


def matches(row, prefs):
    traits = stream_traits(row)
    if prefs.get('provider') and traits['provider'].casefold() != prefs['provider'].casefold():return False
    if prefs.get('quality') not in (None, 'Any') and traits['quality'] != prefs['quality']:return False
    if prefs.get('dynamic') not in (None, 'Any') and prefs['dynamic'] not in traits['dynamic']:return False
    audio = presentation(row)['audio']
    if prefs.get('audio') not in (None, 'Any') and prefs['audio'].casefold() not in audio.casefold():return False
    language = prefs.get('language', '').casefold()
    if language and language != 'any':
        aliases = {'english', 'eng', 'en'} if language in ('english', 'eng', 'en') else {language}
        if not aliases & set(re.findall(r'[a-z]+', audio.partition(' | Language: ')[2].casefold())):return False
    return True


def default_resolution(rows, prefs):
    """Any favours HD; UHD is a last resort, not an implicit preference."""
    if prefs.get('quality') not in (None, 'Any') or not rows:
        return rows
    order = {'1080p': 0, '720p': 1, '480p': 2, '360p': 3, 'AUTO': 4, '4K': 5}
    tier = min(order.get(stream_traits(row)['quality'], 4) for row in rows)
    return [row for row in rows if order.get(stream_traits(row)['quality'], 4) == tier]


def select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None, identity=None):
    mode, prefs = configured(addon, meta)
    if mode == 0:return mode, None, False
    from lib.source_identity import eligible as matching_episode
    from source_probe import unsupported_disc
    rows = matching_episode([r for r in rows if not unsupported_disc(r.get('url',''),r)],
                            meta, identity, require_match=True)
    eligible = [r for r in filter_rows(limit_quality(rows, prefs['maximum']), *filters)
                if r.get('url') and not r.get('_session_failed')]
    from lib.source_identity import target, title_verified
    if target(meta, identity) is not None:
        titled = [r for r in eligible if title_verified(r, meta, identity)]
        if titled:
            eligible = titled
    eligible = default_resolution(eligible, prefs)
    from lib.last_source import match
    previous = match(eligible, remembered)
    if previous is not None:
        return mode, previous, False
    ranked = rank_rows(eligible, prefs)
    exact = [r for r in ranked if matches(r, prefs)]
    closest = rank_rows(ranked, dict(prefs, sort='recommended'))
    return mode, (exact or closest or [None])[0], bool(ranked and not exact)


def early_select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None, identity=None):
    """Early autoplay requires an exact match at a known target resolution."""
    from source_probe import unsupported_disc
    rows = [r for r in rows if not unsupported_disc(r.get('url',''),r)]
    mode, prefs = configured(addon, meta)
    # Explicit order/size rules require all results. Recommended mode can
    # start from a small exact-match shortlist without relaxing preferences.
    if mode != 2 or prefs.get('sort') != 'recommended':
        return None
    from lib.source_identity import status, target, title_verified, comparable_title
    if target(meta, identity) is not None:
        # Wait for the complete provider search before taking a number-only
        # result only when a verifiable title may arrive from another add-on.
        if comparable_title(meta, identity):
            rows = [row for row in rows if title_verified(row, meta, identity)]
        else:
            rows = [row for row in rows if status(row, meta, identity) == 'match']
    eligible = filter_rows(limit_quality(rows, prefs['maximum']), *filters)
    if remembered:
        from lib.last_source import match
        previous = match([row for row in eligible if not row.get('_session_failed')], remembered)
        if previous is None:
            return None  # A resumed title waits for its previously working release.
        # Any's HD default also applies when the saved release was UHD.
        # Preserve resume position while allowing a newly suitable HD source.
        if prefs.get('quality') not in (None, 'Any') or stream_traits(previous)['quality'] == (
                '720p' if prefs['maximum'] == '720p' else '1080p'):
            eligible = [previous]
    target = prefs.get('quality')
    if target in (None, 'Any'):
        # Wait for the preferred HD result; lower-quality/UHD fallbacks are
        # selected only after the search finishes. A 720p ceiling is honoured.
        target = '720p' if prefs['maximum'] == '720p' else '1080p'
    unique = {}
    for row in eligible:
        if (row.get('url') and not row.get('_session_failed') and matches(row, prefs)
                and stream_traits(row)['quality'] == target):
            unique.setdefault(row['url'], row)
    if not unique:
        return None
    # Duplicate releases do not count as evidence. Group them for selection,
    # then hand the original provider row to the existing playback path.
    from lib.source_groups import group_rows
    grouped = group_rows(rank_rows(list(unique.values()), prefs))
    return (grouped[0].get('_alternatives') or [grouped[0]])[0]


def selection_details(row, addon, meta, identity):
    """Explain observed autoplay rules, without claiming provider truth."""
    from lib.source_identity import status, target, title_verified
    _, prefs = configured(addon, meta)
    details = ['Selected automatically using this device\'s source preferences']
    if target(meta, identity) is not None:
        verdict = status(row, meta, identity)
        details.append(('Filename title matches the requested episode' if title_verified(row, meta, identity)
                        else 'Episode number matches; filename title is unconfirmed') if verdict == 'match'
                       else 'Episode identity not confirmed by source labels')
    details.append('Reported quality: ' + stream_traits(row)['quality'])
    details.append('Source preferences matched' if matches(row, prefs) else 'Closest available match to source preferences')
    return details
