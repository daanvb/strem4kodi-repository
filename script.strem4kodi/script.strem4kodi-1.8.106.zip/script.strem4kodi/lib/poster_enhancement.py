"""Use provider artwork as supplied; retire native tags and old wrapper images."""
import re
from urllib.parse import parse_qs, parse_qsl, urlencode, urlsplit, urlunsplit

# Refresh preferred artwork once after raising private poster output to 780px.
ARTWORK_GENERATION = 4
NATIVE_FIELDS = {'_poster_rank', '_poster_trending', '_poster_tag_context'}


def legacy_art(value):
    """Recognise old baked-in BetterPosters images, including image proxies."""
    for _ in range(3):
        if not isinstance(value, str):
            return False
        try:
            parsed = urlsplit(value)
            host = (parsed.hostname or '').lower()
            if host == 'btttr.cc' or host.endswith('.btttr.cc'):
                return True
            value = parse_qs(parsed.query).get('url', [''])[0]
        except ValueError:
            return False
    return False


def clean(row):
    copy = {key: value for key, value in row.items()
            if key not in NATIVE_FIELDS and not key.startswith(('_poster_context_', 'poster_sash_'))}
    if not copy.get('landscape') and copy.get('landscapePoster'):
        copy['landscape'] = copy['landscapePoster']
    # AIOMetadata signs the upstream URL, not its fallback. Keep that upstream
    # and signature intact while removing old baked tags from a failure image.
    for field in ('poster', 'background', 'landscape', 'landscapePoster', 'logo'):
        value = copy.get(field)
        if not isinstance(value, str):
            continue
        try:
            parsed = urlsplit(value)
            pairs = parse_qsl(parsed.query, keep_blank_values=True)
            if '/poster-cache/proxy/' in parsed.path and any(key == 'fallback' and legacy_art(image) for key, image in pairs):
                copy[field] = urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
                    urlencode([(key, '' if key == 'fallback' and legacy_art(image) else image)
                               for key, image in pairs]), parsed.fragment))
        except ValueError:
            pass
    if copy.get('_artwork_generation') != ARTWORK_GENERATION:
        for field in ('poster', 'background', 'landscape', 'landscapePoster', 'logo'):
            if not legacy_art(copy.get(field)):
                continue
            if field == 'poster':
                original = copy.get('_original_poster')
                if not isinstance(original, str) or not original.startswith(('https://', 'http://')) or legacy_art(original):
                    from lib.catalogue_identity import identity
                    title = identity(copy)
                    original = ('https://images.metahub.space/poster/medium/' + title[1] + '/img'
                                if title and re.fullmatch(r'tt\d+', title[1]) else '')
                copy[field] = original
                for stale in ('_poster_preferred', '_poster_signature', '_poster_resolved_at', '_original_poster'):
                    copy.pop(stale, None)
            else:
                copy.pop(field, None)
    return copy


def decorate(rows, addons=None, pattern=None):
    """Compatibility adapter: no URL templates or local decoration are applied."""
    return [clean(row) for row in rows]


def prepare_catalogs(catalogs, state):
    from lib.catalogue_identity import identity, share_missing
    catalogs = [dict(catalog, items=[clean(dict(row, **({'_poster_provider': catalog['addon']}
                 if catalog.get('addon') and not row.get('_poster_provider') else {})))
                 for row in catalog.get('items', [])]) for catalog in catalogs]
    configured = {}
    for catalog in catalogs:
        for row in catalog.get('items', []):
            title = identity(row)
            if title and row.get('poster') and 'aiometadata' in re.sub(r'\W', '', str(row.get('_poster_provider') or '')).lower():
                configured.setdefault(title, row)
    for catalog in catalogs:
        if catalog.get('label') in ('Continue Watching', 'Up Next', 'You May Also Like', 'Upcoming Episodes', "Don't Forget About Me"):
            for row in catalog.get('items', []):
                fresh = configured.get(identity(row))
                if fresh:
                    for field in ('poster', 'landscape', 'landscapePoster', 'logo', '_poster_provider'):
                        if fresh.get(field): row[field] = fresh[field]
    from lib.catalog_poster import configured as artwork_resolver
    result = artwork_resolver(state).cached(share_missing(catalogs))
    from lib.artwork_cache import remember
    remember(result)
    return result


def consolidate(specs):
    """Keep the original catalogue when a legacy wrapper duplicates it."""
    def key(row):
        label = re.sub(r'(?i)better\s*posters?', '', row.get('label', ''))
        return row.get('kind'), re.sub(r'\W+', ' ', label).strip().casefold()
    originals = {key(row) for row in specs
                 if 'betterposters' not in re.sub(r'\W', '', str(row.get('addon') or '')).lower()}
    return [row for row in specs if not ('betterposters' in re.sub(r'\W', '', str(row.get('addon') or '')).lower()
                                       and key(row) in originals)]
