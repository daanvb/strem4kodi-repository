"""Long OK bindings owned only by currently open Strem4Kodi browse windows."""
from pathlib import Path
import xml.etree.ElementTree as ET

NAME = 'zz-strem4kodi-context.xml'
_windows = set()


def content(window_ids):
    root = ET.Element('keymap')
    for identity in sorted(window_ids):
        # Kodi accepts numeric custom windows. Python XML windows use 13000+.
        if type(identity) is not int or not 13000 <= identity < 14000:
            continue
        window = ET.SubElement(root, 'window' + str(identity))
        keyboard = ET.SubElement(window, 'keyboard')
        for key in ('return', 'enter', 'ok', 'select'):
            ET.SubElement(keyboard, key, mod='longpress').text = 'ContextMenu'
        # Kodi's IR remote translator ignores the mod attribute. A remote
        # select entry would replace ordinary OK, so only HID/keyboard devices
        # that actually support longpress modifiers receive these bindings.
        remote = ET.SubElement(window, 'remote')
        for key in ('menu', 'title', 'info'):
            ET.SubElement(remote, key).text = 'ContextMenu'
    return ET.tostring(root, encoding='unicode') + '\n'


def write(directory, window_ids):
    target = Path(directory) / NAME
    value = content(window_ids)
    if not ET.fromstring(value).findall('*'):
        if target.exists():
            target.unlink()
            return True
        return False
    if target.exists() and target.read_text(encoding='utf-8') == value:
        return False
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(value, encoding='utf-8', newline='\n')
    return True


def _apply():
    import xbmc
    import xbmcvfs
    try:
        if write(xbmcvfs.translatePath('special://profile/keymaps/'), _windows):
            xbmc.executebuiltin('Action(ReloadKeymaps)')
    except Exception as error:
        xbmc.log('Strem4Kodi: context keymap unavailable: ' + type(error).__name__, xbmc.LOGWARNING)


def register(identity):
    if type(identity) is int and 13000 <= identity < 14000:
        _windows.add(identity)
        _apply()


def unregister(identity):
    _windows.discard(identity)
    _apply()
