"""Prepare one recap seek while paused; never seek after playback resumes."""
import math
import time

PAUSE_SECONDS = (5, 10, 15, 30, 60, 120, 300)
REWIND_SECONDS = (3, 5, 7, 10, 12, 15, 20, 30)


def choice(addon, key, values, default):
    try:
        index = int(addon.getSetting(key))
        return values[index] if 0 <= index < len(values) else default
    except (TypeError, ValueError):
        return default


class UnpauseRewind:
    def __init__(self, clock=time.monotonic, ready=lambda: False, trace=lambda stage: None):
        self.clock = clock
        # True only while the native player is paused and not buffering.
        self.ready = ready
        self.trace = trace
        self.reset()

    def reset(self):
        self.paused = None
        self.attempted = False
        self.prepared = False
        self.own_seek = None

    def event(self, stage):
        try:self.trace(stage)
        except Exception:pass

    def pause(self, session, filename, position):
        if not session or not filename or not math.isfinite(position):
            self.reset()
            return
        if self.paused and self.paused[:2] != (session, filename):self.reset()
        # A duplicate callback must not restart the timer or repeat our seek.
        if self.paused is None:
            self.paused = (session, filename, max(0, position), self.clock())
            self.event('rewind.pause')

    def resume(self, addon, session, filename, position):
        del addon, session, filename, position
        if self.paused:self.event('rewind.resume')
        # Native Play remains immediate. Never queue a post-resume rewind,
        # even when Play wins the race with the service's preparation tick.
        self.reset()

    def seeked(self, time_ms):
        """Distinguish our native callback from a user's seek while paused."""
        own = self.own_seek
        if own and 0 <= self.clock()-own[1] <= 5 and abs(time_ms-own[0]*1000) <= 1000:
            self.own_seek = None
            self.event('rewind.prepared')
            return
        if self.paused:
            # Keep the active pause disarmed through duplicate pause callbacks.
            self.attempted = True
            self.prepared = False
            self.own_seek = None
            self.event('rewind.skipped')

    def apply(self, player, addon, session, filename):
        paused = self.paused
        if paused is None or self.attempted:return False
        if paused[:2] != (session, filename):
            self.reset()
            return False
        if addon.getSetting('unpause_rewind_enabled') != 'true':
            self.attempted = True
            return False
        if self.clock()-paused[3] < choice(addon,'unpause_rewind_pause',PAUSE_SECONDS,30):return False
        try:
            if not player.isPlayingVideo() or player.getPlayingFile() != filename:
                self.reset()
                return False
            if not self.ready():return False
            position = float(player.getTime())
            if not math.isfinite(position) or abs(position-paused[2]) > 2:
                self.attempted = True
                self.event('rewind.skipped')
                return False
            target = max(0, paused[2]-choice(addon,'unpause_rewind_seconds',REWIND_SECONDS,10))
            # Recheck after querying the native player: a resume callback may
            # have arrived while this tick was preparing the request.
            if not self.ready() or self.paused is not paused:return False
            self.attempted = True  # Consume before synchronous seek callbacks.
            if abs(position-target) < .25:return False
            self.prepared = True
            self.own_seek = (target,self.clock())
            player.seekTime(target)
            # File-backed tracing must not sit between the final native
            # pause check and dispatch, widening the resume/seek race.
            self.event('rewind.seek')
            return True
        except Exception:
            self.attempted = True
            self.prepared = False
            self.own_seek = None
            self.event('rewind.error')
            return False
