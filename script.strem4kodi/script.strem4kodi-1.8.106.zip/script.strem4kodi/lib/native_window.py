"""Retire a full Kodi window before releasing its reusable native ID."""


def modal(window, kodi, gui):
    """Verify native activation before entering Python's unbounded modal loop.

    Window.show sends a synchronous activation request, but Kodi can refuse it
    without raising. doModal alone then waits forever for an onInit that will
    never arrive. An already active WindowXML is not shown again by doModal.
    """
    from uuid import uuid4
    marker=uuid4().hex
    key='strem4kodi.activation'
    # An existing notification (including duplicate-launch feedback) may still
    # be fading out. Give it a bounded chance to close; never dismiss somebody
    # else's dialog or enter a modal loop when activation cannot succeed.
    for _ in range(80):
        if kodi.getCondVisibility('System.HasVisibleModalDialog') is not True:break
        kodi.sleep(50)
    else:
        kodi.log('Strem4Kodi: window activation blocked',kodi.LOGWARNING)
        return False
    try:
        window.setProperty(key,marker)
        window.show()
        active=gui.Window(gui.getCurrentWindowId()).getProperty(key) == marker
    except RuntimeError:
        # A disappearing native window is also an unsuccessful activation;
        # let the shell clean up and restore results instead of entering a wait.
        active=False
    if not active:
        kodi.log('Strem4Kodi: window activation blocked',kodi.LOGWARNING)
        return False
    window.doModal()
    return True


def wait_retired(window_id, kodi, gui):
    if type(window_id) is not int or not 13000 <= window_id < 13200:
        return True
    for _ in range(40):
        if (gui.getCurrentWindowId() != window_id
                and kodi.getCondVisibility('Window.IsVisible({})'.format(window_id)) is not True):
            return True
        kodi.sleep(50)
    return False
