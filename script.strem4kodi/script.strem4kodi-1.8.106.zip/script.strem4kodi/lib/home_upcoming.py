"""Account-scoped airing reminders; Home reads locally, metadata refresh is bounded."""
import hashlib
import math
import threading
import time
from datetime import date, datetime
from pathlib import Path

_lock = threading.Lock()
_running = set()
REFRESH_LIMIT = 8


def schedule_records(value):
    """Treat malformed local schedule records as absent and refresh them."""
    if not isinstance(value, dict):
        return {}
    records = {}
    for key, record in value.items():
        if not isinstance(record, dict):
            continue
        meta = record.get('meta')
        if not isinstance(meta, dict):
            meta = {}
        if not isinstance(meta.get('videos'), list):
            meta = dict(meta, videos=[])
        try:
            next_check = float(record.get('next_check') or 0)
        except (TypeError, ValueError, OverflowError):
            next_check = 0
        if not math.isfinite(next_check) or not meta.get('videos'):
            next_check = 0
        records[key] = {'meta': meta, 'next_check': next_check}
    return records


def identity(row):
    return str(row.get('_id') or row.get('id') or '')


def eligible(library, continuing, saved):
    """Only current Continue Watching, Favourite and Watch Later series."""
    members = list(continuing or [])
    members += saved.entries(library, 'favourite') + saved.entries(library, 'watchlist')
    result = {}
    for row in members:
        if row.get('type') != 'series' or not identity(row):
            continue
        key = identity(row)
        previous = result.get(key, {})
        result[key] = dict(previous, **row)
        result[key]['id'] = key
        if not row.get('videos') and previous.get('videos'):
            result[key]['videos'] = previous['videos']
    return list(result.values())


def airdate(video):
    try:
        return date.fromisoformat(str(video.get('released') or video.get('firstAired') or '')[:10])
    except (TypeError, ValueError):
        return None


def number(video, field):
    try:
        return max(0, int(video.get(field) or (video.get('number') if field == 'episode' else 0) or 0))
    except (TypeError, ValueError):
        return 0


def build(series, now=None, limit=100):
    today = now.date() if isinstance(now, datetime) else now or date.today()
    upcoming, reminders, seen = [], [], set()
    for row in series:
        key = identity(row)
        if not key or key in seen:
            continue
        seen.add(key)
        videos = [v for v in row.get('videos') or [] if isinstance(v, dict)
                  and v.get('id') and number(v, 'season') > 0 and number(v, 'episode') > 0]
        if not videos:
            continue
        season = max(number(v, 'season') for v in videos)
        latest = [v for v in videos if number(v, 'season') == season]
        dated = [(airdate(v), v) for v in latest if airdate(v)]
        if not dated:
            continue
        # The last numbered episode defines the finale, never a previous season
        # or an earlier episode whose date happens to be the latest known date.
        finale = airdate(max(latest, key=lambda v: number(v, 'episode')))
        age = (today - finale).days if finale else None
        if age is not None and 7 < age <= 30:
            card = {k: v for k, v in row.items() if k not in
                    ('_focus_video_id', '_upcoming_episode', '_release_label', '_next_episode', '_continue_watching')}
            reminders.append((finale, key, card))
            continue
        if age is not None and age > 30:
            continue
        future = [(day, v) for day, v in dated if 0 <= (day - today).days <= 14]
        aired = [(day, v) for day, v in dated if day <= today]
        # An episode more than two weeks away cannot admit a series. Previously
        # aired latest-season episodes keep an ongoing season present afterward.
        if future:
            day, episode = min(future, key=lambda pair: (pair[0], number(pair[1], 'episode')))
        elif aired and finale and today <= finale:
            day, episode = max(aired, key=lambda pair: (pair[0], number(pair[1], 'episode')))
        elif aired and age is not None and 0 <= age <= 7:
            day, episode = max(aired, key=lambda pair: (pair[0], number(pair[1], 'episode')))
        else:
            continue
        card = dict(row, id=key, _focus_video_id=episode['id'], _upcoming_episode=True)
        card.pop('_next_episode', None)
        card.pop('_continue_watching', None)
        card['name'] = '{} - S{:02d}E{:02d}'.format(row.get('name', ''), season, number(episode, 'episode'))
        days = (day - today).days
        card['_release_label'] = ('Airs today' if days == 0 else 'Airs tomorrow' if days == 1 else
                                  ('Expected ' if days > 0 else 'Aired ') + day.strftime('%d %b %Y'))
        card['description'] = episode.get('description') or episode.get('overview') or row.get('description', '')
        upcoming.append((day, key, card))
    result = []
    for label, rows in (('Upcoming Episodes', upcoming), ("Don't Forget About Me", reminders)):
        if rows:
            result.append({'label': label, 'items': [r[2] for r in sorted(rows, key=lambda r: (r[0], r[1]))[:limit]],
                           'failed': False})
    return result


def combine_reminders(seasonal, aged, continuing, library, limit=100):
    """Playback clocks take precedence over seasonal and cached reminder cards."""
    from lib.catalogue_identity import aliases
    from lib.continue_index import watch_age
    blocked = set()
    for row in continuing or []:
        blocked.update(aliases(row))
    # A played title uses only its 30–60 day window. Do not let a finale or an
    # old Home snapshot bring it back early, after expiry, or after removal.
    played = set()
    for row in (library or []) if seasonal else []:
        if isinstance(row, dict) and watch_age(row) is not None:
            played.update(aliases(row))
    result = []
    for row in list(aged or []) + list(seasonal or []):
        keys = aliases(row)
        if not keys or keys & blocked:
            continue
        if not row.get('_continue_watching') and (keys & played or watch_age(row) is not None):
            continue
        result.append(row)
        blocked.update(keys)
        if len(result) >= limit:
            break
    return result


def sections(directory, state, continuing, resolver, reminder_items=None):
    """Render local dates immediately and refresh at most eight stale series."""
    from account import AccountError, Store
    from lib.saved_lists import SavedLists
    from lib.continue_index import resolved_series, airing_series, reminders
    token = state.get('token')
    if not token:
        return []
    candidates = eligible(state.get('library') or [], list(continuing or []) + airing_series(directory),
                          SavedLists(directory, token))
    namespace = hashlib.sha256(str(token).encode()).hexdigest()
    store = Store(Path(directory) / ('home-upcoming-' + namespace))
    try:
        cached = schedule_records(store.load().get('series'))
    except (AccountError, OSError, ValueError):
        cached = {}
    known = {identity(r): r for r in resolved_series(directory)}
    display = []
    for row in candidates:
        metadata = (cached.get(identity(row)) or {}).get('meta') or known.get(identity(row)) or {}
        merged = dict(metadata, **row)
        merged['videos'] = metadata.get('videos') or row.get('videos') or []
        display.append(merged)
    stale = sorted((r for r in candidates if time.time() >= float(
        (cached.get(identity(r)) or {}).get('next_check') or 0)),
        key=lambda r: float((cached.get(identity(r)) or {}).get('next_check') or 0))[:REFRESH_LIMIT]
    flight = str(store.directory)
    if stale:
        with _lock:
            if flight not in _running:
                _running.add(flight)
                def refresh():
                    try:
                        records = dict(cached)
                        for row in stale:
                            # Sign-out/account switch and active playback stop fan-out.
                            if Store(directory).load().get('token') != token:
                                return
                            try:
                                import xbmc
                                if xbmc.Player().isPlayingVideo():
                                    return
                            except ImportError:
                                pass
                            key = identity(row)
                            record = dict(records.get(key) or {})
                            try:
                                meta = resolver(row)
                                if not meta.get('videos'):
                                    raise ValueError('Episode schedule unavailable')
                                # Cache schedule/artwork only; playback state stays live.
                                record['meta'] = {k: v for k, v in meta.items() if k in
                                                  ('id', 'imdb_id', 'moviedb_id', 'type', 'name', 'poster',
                                                   'background', 'logo', 'description', 'videos', 'status', 'year')}
                                record['next_check'] = time.time() + 21600
                            except Exception:
                                record['next_check'] = time.time() + 300
                            records[key] = record
                        store.save({'series': {identity(r): records[identity(r)] for r in candidates
                                               if identity(r) in records}})
                        try:
                            import xbmcgui
                            xbmcgui.Window(10000).setProperty('strem4kodi.home.recommendations.revision', str(time.time_ns()))
                        except Exception:
                            pass
                    finally:
                        with _lock:
                            _running.discard(flight)
                try:
                    threading.Thread(target=refresh, daemon=True).start()
                except RuntimeError:
                    _running.discard(flight)
    result = build(display)
    seasonal = next((r['items'] for r in result if r['label'] == "Don't Forget About Me"), [])
    forgotten = combine_reminders(seasonal, reminders(directory) if reminder_items is None else reminder_items, continuing,
                                 state.get('library') or [])
    result = [r for r in result if r['label'] != "Don't Forget About Me"]
    if forgotten:
        result.append({'label': "Don't Forget About Me", 'items': forgotten, 'failed': False})
    return result
