"""Strem4Kodi program entry."""
import sys
from pathlib import Path
_CORE = Path(__file__).resolve().parent / 'core'
if str(_CORE) not in sys.path:
    sys.path.insert(0, str(_CORE))


def main():
    import time
    launch_started = time.monotonic()
    commands={'cache_configure','cache_clear_selected','cache_info','cache_clear','locale',
              'run_low_power_benchmark','send_performance_report','report_last_error','report_issue'}
    if not commands.intersection(sys.argv[1:]):
        from lib.app import run
        run(started=launch_started)
        return
    from lib.playback_settings import apply
    from lib.error_report import show_reporting_notice_once
    apply()
    show_reporting_notice_once()
    if 'cache_configure' in sys.argv[1:]:
        from lib.maintenance import configure_cache
        configure_cache()
    elif 'cache_clear_selected' in sys.argv[1:]:
        from lib.maintenance import clear_selected
        clear_selected()
    elif any(arg in ('cache_info', 'cache_clear') for arg in sys.argv[1:]):
        from lib.maintenance import cache_action
        cache_action('cache_clear' in sys.argv[1:])
    elif 'locale' in sys.argv[1:]:
        from lib.settings import locale_menu
        locale_menu()
    elif 'run_low_power_benchmark' in sys.argv[1:]:
        import xbmcvfs
        from pathlib import Path
        from addon_state import get_addon
        from lib.low_power_benchmark import run, confirm_couch_pass
        from lib.ui_dialogs import dialog
        addon = get_addon()
        profile = Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
        result = run(profile)
        labels = {
            'benchmark.cached_home': 'Cached Home',
            'benchmark.snapshot_load': 'Snapshot read',
            'benchmark.continue_index': 'Continue Watching SQLite',
            'benchmark.account_load': 'Account state read',
            'benchmark.stream_cache': 'Stream cache SQLite',
        }
        lines = []
        for stage, elapsed in result['metrics'].items():
            mark = 'PASS' if result['checks'][stage] else 'REVIEW'
            lines.append('{}: {} ms / {} ms - {}'.format(
                labels[stage], elapsed, result['targets'][stage], mark))
        lines += ['', 'Local engineering budget only; a real Pi 3 run is required for certification.',
                  'Use Send performance report next to share the reviewed timing sample.']
        ui = dialog()
        ui.ok('Low-power benchmark', '\n'.join(lines))
        if confirm_couch_pass(profile, result, ui):
            ui.notification('Pi 3 validation', 'Couch test saved. Use Send performance report to submit the evidence.')
    elif 'send_performance_report' in sys.argv[1:]:
        import xbmcvfs
        from pathlib import Path
        from addon_state import get_addon
        from lib.perf_report import build_payload
        from lib.error_report import show_report_dialog
        addon = get_addon()
        profile = Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))
        payload = build_payload(profile)
        if payload:
            timings = payload.get('performance') or {}
            lines = ['{}: {} ms'.format(stage, values.get('ms', 0))
                     for stage, values in timings.items() if 'ms' in values]
            show_report_dialog(payload, 'Home performance report\n' + '\n'.join(lines), replay=True)
        else:
            from lib.ui_dialogs import dialog
            dialog().notification('Performance report', 'No Home performance sample is available yet. Open Home first.')
    elif 'report_last_error' in sys.argv[1:]:
        from lib.error_report import report_last_error
        report_last_error()
    elif 'report_issue' in sys.argv[1:]:
        from lib.error_report import manual_report
        manual_report()
    else:
        from lib.app import run
        run(started=launch_started)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        from lib.error_report import handle_error
        handle_error('Program entry', error, 'Strem4Kodi stopped unexpectedly.')
