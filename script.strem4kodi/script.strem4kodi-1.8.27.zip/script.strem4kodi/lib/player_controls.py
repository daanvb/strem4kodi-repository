"""Readable audio/subtitle pickers and a compact playback settings menu."""
from lib.player_audio import audio_description


def menu_session_active(player, file):
    try:
        return bool(file and player.isPlayingVideo() and player.getPlayingFile() == file)
    except Exception:
        return False


def open_chapters(player, profile, kodi, picker):
    # Use the same chapter data as the timeline, in an accessible named list.
    file = player.getPlayingFile()
    if not menu_session_active(player, file) or not kodi.getCondVisibility('Player.SeekEnabled'):
        return
    embedded = kodi.getCondVisibility('Integer.IsGreater(Player.ChapterCount,0)')
    if embedded:
        from setup_profile import rpc
        from lib.player_chapter_timeline import load, timestamp
        rows = load(rpc, kodi.getInfoLabel, player.getTotalTime())
        if not menu_session_active(player, file):
            return
        if rows:
            current = max((i for i, row in enumerate(rows) if row['start'] <= player.getTime()), default=0)
            choice = picker.select('Chapters', [row['name'] + ' | ' + timestamp(row['start']) for row in rows], preselect=current)
            if 0 <= choice < len(rows) and menu_session_active(player, file) and kodi.getCondVisibility('Player.SeekEnabled'):
                player.seekTime(rows[choice]['start'])
            return
        # A chapter count is insufficient: only validated jump times can block
        # the online fallback. Never guess times from the count.
    from addon_state import get_addon
    if get_addon().getSetting('chaptersdb_enabled') == 'false':
        reason = 'Kodi detects embedded chapters, but their start times could not be read.' if embedded else 'This video has no embedded chapters.'
        picker.ok('Chapters', reason + ' Enable ChaptersDB fallback in Playback settings to look for a chapter list.')
        return
    import hashlib
    from account import Store
    context = Store(profile / 'playback').load()
    if context.get('url_hash') != hashlib.sha256(file.encode()).hexdigest():
        picker.ok('Chapters', 'Chapter timings are unavailable, and this playback has no title information for ChaptersDB lookup.')
        return
    if menu_session_active(player, file):
        online_chapters(player, profile, kodi, picker)


def online_chapters(player, profile, kodi, picker):
    import hashlib
    from account import Store
    from chapters_db import lookup, identity, rank_editions
    from lib.ui_dialogs import progress_bg
    file = player.getPlayingFile()
    context = Store(profile / 'playback').load()
    if context.get('url_hash') != hashlib.sha256(file.encode()).hexdigest():
        return
    if not identity(context.get('kind'), context.get('id')):
        picker.ok('Chapters', 'This title has no supported IMDb identity for chapter lookup.')
        return
    progress = progress_bg()
    try:
        progress.create('Chapters', 'Looking for chapter lists on ChaptersDB…')
        try:
            editions = lookup(profile, context['kind'], context['id'], player.getTotalTime())
        except Exception:
            editions = None
    finally:
        progress.close()
    def matches():
        return player.isPlayingVideo() and player.getPlayingFile() == file
    if not matches():
        return
    if editions is None:
        picker.ok('Chapters', 'ChaptersDB could not be reached. Try again later; playback is unaffected.')
        return
    if not editions:
        picker.ok('Chapters', 'No compatible chapter list was found. Availability depends on the title and release.')
        return
    editions = rank_editions(editions, context.get('filename', ''), player.getTotalTime())
    edition = picker.select('ChaptersDB — choose your edition',
                            [row['note'] + ' | ' + row['confidence'] + ': ' + row['match_reason']
                             for row in editions], preselect=-1)
    if edition < 0 or edition >= len(editions) or not matches():
        return
    chapters = editions[edition]['chapters']
    position = player.getTime()
    current = max((i for i, row in enumerate(chapters) if row['start'] <= position), default=0)
    choice = picker.select('Chapters', [row['name'] + ' | ' + row['time'] for row in chapters], preselect=current)
    if 0 <= choice < len(chapters) and matches() and kodi.getCondVisibility('Player.SeekEnabled'):
        player.seekTime(chapters[choice]['start'])


def choose_audio(rpc, dialog, language_name, playing_file):
    file = playing_file()
    players = rpc('Player.GetActivePlayers') or []
    video = next((p for p in players if p.get('type') == 'video'), None)
    if not video:
        return
    player_id = video['playerid']
    properties = rpc('Player.GetProperties', {
        'playerid': player_id, 'properties': ['audiostreams', 'currentaudiostream']})
    tracks = properties.get('audiostreams') or []
    if not tracks:
        dialog.ok('Audio', 'Kodi has not reported any audio tracks yet.')
        return
    current = (properties.get('currentaudiostream') or {}).get('index')
    selected = next((i for i, track in enumerate(tracks) if track.get('index') == current), 0)
    choice = dialog.select('Audio track', [audio_description(t, language_name) for t in tracks], preselect=selected)
    if choice < 0 or choice >= len(tracks) or playing_file() != file:
        return
    latest = rpc('Player.GetActivePlayers') or []
    if not any(p.get('type') == 'video' and p.get('playerid') == player_id for p in latest):
        return
    rpc('Player.SetAudioStream', {'playerid': player_id, 'stream': tracks[choice]['index']})


def choose_subtitles(rpc, dialog, language_name, playing_file, open_window):
    file = playing_file()
    players = rpc('Player.GetActivePlayers') or []
    video = next((p for p in players if p.get('type') == 'video'), None)
    if not video:
        return
    player_id = video['playerid']
    properties = rpc('Player.GetProperties', {
        'playerid': player_id, 'properties': ['subtitles', 'currentsubtitle', 'subtitleenabled']})
    tracks = properties.get('subtitles') or []
    labels = ['Off | Hide subtitles']
    for track in tracks:
        code = track.get('language') or ''
        language = language_name(code) if code else ''
        details = [track.get('name') or 'Subtitle track']
        if track.get('isforced'):
            details.append('Forced')
        if track.get('isimpaired'):
            details.append('Hearing impaired')
        labels.append((language or code or 'Unknown language') + ' | ' + ' / '.join(details))
    labels.extend(['Download subtitles | Find subtitles with your installed services',
                   'Subtitle settings | Timing, position and appearance'])
    current = (properties.get('currentsubtitle') or {}).get('index')
    selected = next((i + 1 for i, t in enumerate(tracks) if t.get('index') == current), 0)
    if not properties.get('subtitleenabled'):
        selected = 0
    choice = dialog.select('Subtitles', labels, preselect=selected)
    if choice < 0 or choice >= len(labels) or playing_file() != file:
        return
    latest = rpc('Player.GetActivePlayers') or []
    if not any(p.get('type') == 'video' and p.get('playerid') == player_id for p in latest):
        return
    if choice == 0:
        rpc('Player.SetSubtitle', {'playerid': player_id, 'subtitle': 'off'})
    elif choice <= len(tracks):
        rpc('Player.SetSubtitle', {'playerid': player_id,
                                 'subtitle': tracks[choice - 1]['index'], 'enable': True})
    else:
        open_window('ActivateWindow(subtitlesearch)' if choice == len(tracks) + 1
                    else 'ActivateWindow(osdsubtitlesettings)')


def choose_settings(dialog, playing_file, execute, has_chapters=False, media_info=None, credits=None, chapter_db=None):
    file = playing_file()
    labels = ['Audio adjustments | Volume, amplification and audio delay',
              'Subtitle settings | Timing, position and appearance',
              'Picture settings | Aspect ratio, zoom and video processing',
              'Stop playback | Return to browsing']
    actions = ['ActivateWindow(osdaudiosettings)', 'ActivateWindow(osdsubtitlesettings)',
               'ActivateWindow(osdvideosettings)', 'PlayerControl(Stop)']
    if has_chapters:
        labels.insert(0, 'Chapters | Jump to a chapter in this video')
        actions.insert(0, 'ActivateWindow(videobookmarks)')
    if media_info:
        labels.append('Media info | Video format, Dolby Vision and audio details')
        actions.append('strem4kodi:media-info')
    if credits:
        labels.append('Smart credits | Review or remove episode timings')
        actions.append('strem4kodi:credits')
    if chapter_db:
        labels.append('Use ChaptersDB instead | Choose an online chapter list and matching edition')
        actions.append('strem4kodi:chapter-db')
    choice = dialog.select('Playback settings', labels, preselect=-1)
    if 0 <= choice < len(actions) and playing_file() == file:
        if actions[choice] == 'strem4kodi:media-info':
            media_info()
        elif actions[choice] == 'strem4kodi:credits':
            credits()
        elif actions[choice] == 'strem4kodi:chapter-db':
            chapter_db()
        else:
            execute(actions[choice])


def mark_credits_start(player, profile, picker, position=None, duration=None, file=None):
    """Capture before opening UI; never save against another playback session."""
    import hashlib
    from account import Store
    from lib.smart_credits import CreditsMemory
    file = file or player.getPlayingFile()
    position = player.getTime() if position is None else position
    duration = player.getTotalTime() if duration is None else duration
    context = Store(profile / 'playback').load()
    if (context.get('kind') != 'series' or context.get('url_hash') != hashlib.sha256(file.encode()).hexdigest()
            or not menu_session_active(player, file)):
        picker.ok('Smart credits', 'Credits marking is available for an episode started through Strem4Kodi.')
        return False
    saved = CreditsMemory(profile).mark_start(context.get('id'), duration, position)
    if saved:
        from lib.credits_watched import signal
        signal(profile, player, expected_hash=hashlib.sha256(file.encode()).hexdigest(), expected_id=context.get('id'))
        from lib.player_chapter_timeline import timestamp
        picker.notification('Smart credits', 'Credits start saved at ' + timestamp(position))
    else:
        picker.ok('Smart credits', 'Mark the start of closing credits in the final part of an episode, at least 20 seconds before its end.')
    return saved


def quick_credits(player, profile, picker):
    from account import Store
    from lib.smart_credits import manage
    file = player.getPlayingFile()
    position, duration = player.getTime(), player.getTotalTime()
    choice = picker.select('Smart credits', ['Mark credits start here', 'Manage smart credits'], preselect=-1)
    if not menu_session_active(player, file):
        return
    if choice == 0:
        mark_credits_start(player, profile, picker, position, duration, file)
    elif choice == 1:
        import hashlib
        context = Store(profile / 'playback').load()
        if context.get('kind') == 'series' and context.get('url_hash') == hashlib.sha256(file.encode()).hexdigest():
            manage(profile, context.get('id'), picker=picker)


def run(action):
    import xbmc
    from setup_profile import rpc
    from lib.ui_dialogs import dialog
    try:
        if action == 'credits-quick':
            from pathlib import Path
            import xbmcvfs
            from addon_state import get_addon
            profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
            quick_credits(xbmc.Player(), profile, dialog())
        elif action == 'credits-manage':
            from pathlib import Path
            import xbmcvfs
            import hashlib
            from account import Store
            from addon_state import get_addon
            from lib.smart_credits import manage
            player = xbmc.Player()
            profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
            file = player.getPlayingFile()
            context = Store(profile / 'playback').load()
            if context.get('kind') == 'series' and context.get('url_hash') == hashlib.sha256(file.encode()).hexdigest() and menu_session_active(player, file):
                manage(profile, context.get('id'))
        elif action == 'mark-credits':
            from pathlib import Path
            import xbmcvfs
            from addon_state import get_addon
            profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
            mark_credits_start(xbmc.Player(), profile, dialog())
        elif action == 'scrub':
            from lib.player_scrub import show
            show()
        elif action == 'chapter-timeline':
            from lib.player_chapter_timeline import show
            show()
        elif action == 'chapters':
            from pathlib import Path
            import xbmcvfs
            from addon_state import get_addon
            profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
            open_chapters(xbmc.Player(), profile, xbmc,
                          AudioDialog('Choose a chapter to jump to its start.'))
        elif action == 'media-info':
            from lib.player_media_info import show
            show()
        elif action == 'audio':
            choose_audio(rpc, AudioDialog(), lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME),
                         xbmc.Player().getPlayingFile)
        elif action == 'subtitles':
            # A manual subtitle menu takes priority over automatic selection.
            import hashlib
            import xbmcgui
            xbmcgui.Window(10000).setProperty('strem4kodi.subtitles.manual',
                hashlib.sha256(xbmc.Player().getPlayingFile().encode()).hexdigest())
            choose_subtitles(rpc, AudioDialog('Choose a subtitle language, or turn subtitles off.'),
                             lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME),
                             xbmc.Player().getPlayingFile, xbmc.executebuiltin)
        elif action == 'settings':
            from pathlib import Path
            import xbmcvfs
            from account import Store
            from addon_state import get_addon
            from chapters_db import identity
            import hashlib
            player = xbmc.Player()
            profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
            context = Store(profile / 'playback').load()
            native = xbmc.getCondVisibility('Integer.IsGreater(Player.ChapterCount,0) + Player.SeekEnabled')
            online_available = (xbmc.getCondVisibility('Player.SeekEnabled')
                        and context.get('url_hash') == hashlib.sha256(player.getPlayingFile().encode()).hexdigest()
                        and identity(context.get('kind'), context.get('id')))
            fallback = get_addon().getSetting('chaptersdb_enabled') != 'false' and online_available
            def execute(command):
                if command == 'ActivateWindow(videobookmarks)':
                    open_chapters(player, profile, xbmc,
                                  AudioDialog('Choose a chapter to jump to its start.'))
                else:
                    xbmc.executebuiltin(command)
            choose_settings(AudioDialog('Adjust playback, or return to browsing.'),
                            player.getPlayingFile, execute, native or bool(fallback),
                            media_info=lambda: run('media-info'),
                            credits=(lambda: run('credits-manage')) if context.get('kind') == 'series' and context.get('url_hash') == hashlib.sha256(player.getPlayingFile().encode()).hexdigest() else None,
                            chapter_db=(lambda: online_chapters(player, profile, xbmc,
                                AudioDialog('Choose the matching edition, then a chapter. Online names and timings depend on the submitted list.'))) if online_available else None)
    except Exception as error:
        # Log the type only: playback exceptions can contain private source URLs.
        xbmc.log('Strem4Kodi player menu (%s) failed: %s' %
                 (action, type(error).__name__), xbmc.LOGERROR)
        titles = {'audio': 'Audio', 'subtitles': 'Subtitles', 'settings': 'Playback settings', 'chapters': 'Chapters', 'media-info': 'Media info'}
        dialog().ok(titles.get(action, 'Playback'),
                    'Unable to open this menu. Close the controls and try again.')


class AudioDialog:
    def __init__(self, help_text='Choose a language and format. Track names are supplied by the file.'):
        self.help_text = help_text

    def ok(self, title, message):
        from lib.ui_dialogs import dialog
        return dialog().ok(title, message)

    def select(self, title, labels, preselect=0):
        import xbmcgui
        from lib.theme import window
        from addon_state import get_addon
        help_text = self.help_text

        class AudioWindow(xbmcgui.WindowXMLDialog):
            def onInit(self):
                import xbmc
                import threading
                self.closed = False
                self.result = -1
                player = xbmc.Player()
                try:
                    self.playback_file = player.getPlayingFile()
                except Exception:
                    self.close()
                    return
                self.setProperty('dialog_title', title)
                self.setProperty('dialog_help', help_text)
                listing = self.getControl(600)
                items = []
                for index, label in enumerate(labels):
                    language, _, details = label.partition(' | ')
                    item = xbmcgui.ListItem(label=language, label2=details)
                    item.setProperty('active', 'true' if index == preselect else '')
                    items.append(item)
                listing.addItems(items)
                listing.selectItem(max(0, preselect))
                self.setFocusId(600)
                def watch_session():
                    monitor = xbmc.Monitor()
                    while not self.closed and not monitor.waitForAbort(.25):
                        if not menu_session_active(player, self.playback_file):
                            self.result = -1
                            self.close()
                            return
                threading.Thread(target=watch_session, daemon=True).start()

            def close(self):
                self.closed = True
                super().close()

            def onClick(self, control):
                if control == 600:
                    self.result = self.getControl(600).getSelectedPosition()
                    self.close()

            def onAction(self, action):
                if action.getId() in (10, 92, 216, 247):
                    self.close()

        picker = window(AudioWindow, 'script-strem4kodi-player-audio.xml',
                        get_addon().getAddonInfo('path'), 'Main', '1080i')
        picker.result = -1
        picker.doModal()
        result = picker.result
        del picker
        return result
