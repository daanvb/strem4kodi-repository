"""Per-device, per-content source selection; never bypass the quality ceiling."""
from lib.source_preferences import preferences, rank_rows, limit_quality
from lib.stream_presenter import stream_traits, presentation, filter_rows
import re

PROFILES = ('movie', 'series', 'animation')
FIELDS = {'quality': ('Any', '4K', '1080p', '720p'),
          'dynamic': ('Any', 'Dolby Vision', 'HDR10', 'FEL reported'),
          'audio': ('Any', 'Atmos', 'TrueHD', 'Dolby Digital Plus', 'AAC'),
          'sort': ('recommended', 'provider', 'smallest', 'largest')}


def profile(meta):
    genres = meta.get('genres') or []
    if isinstance(genres, str):genres = [genres]
    if meta.get('type') == 'series' and any(str(g).casefold() == 'animation' for g in genres):return 'animation'
    return 'series' if meta.get('type') == 'series' else 'movie'


def configured(addon, meta):
    scope = profile(meta)
    prefs = preferences(addon)
    for field, values in FIELDS.items():
        try:index = int(addon.getSetting('auto_' + scope + '_' + field) or '0') - 1
        except (ValueError, TypeError):index = -1
        if 0 <= index < len(values):prefs[field] = values[index]
    for field in ('provider', 'language'):
        value = addon.getSetting('auto_' + scope + '_' + field)
        if value and value != '__inherit__':prefs[field] = '' if value == '__any__' else value
    try:mode = int(addon.getSetting('auto_' + scope + '_mode') or '0')
    except (ValueError, TypeError):mode = 0
    return mode if mode in (0, 1, 2) else 0, prefs


def matches(row, prefs):
    traits = stream_traits(row)
    if prefs.get('provider') and traits['provider'].casefold() != prefs['provider'].casefold():return False
    if prefs.get('quality') not in (None, 'Any') and traits['quality'] != prefs['quality']:return False
    if prefs.get('dynamic') not in (None, 'Any') and prefs['dynamic'] not in traits['dynamic']:return False
    audio = presentation(row)['audio']
    if prefs.get('audio') not in (None, 'Any') and prefs['audio'].casefold() not in audio.casefold():return False
    language = prefs.get('language', '').casefold()
    if language and language != 'any':
        aliases = {'english', 'eng', 'en'} if language in ('english', 'eng', 'en') else {language}
        if not aliases & set(re.findall(r'[a-z]+', audio.partition(' | Language: ')[2].casefold())):return False
    return True


def select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None):
    mode, prefs = configured(addon, meta)
    if mode == 0:return mode, None, False
    eligible = [r for r in filter_rows(limit_quality(rows, prefs['maximum']), *filters)
                if r.get('url') and not r.get('_session_failed')]
    from lib.last_source import match
    previous = match(eligible, remembered)
    if previous is not None:
        return mode, previous, False
    ranked = rank_rows(eligible, prefs)
    exact = [r for r in ranked if matches(r, prefs)]
    closest = rank_rows(ranked, dict(prefs, sort='recommended'))
    return mode, (exact or closest or [None])[0], bool(ranked and not exact)


def early_select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None):
    """Early autoplay requires an exact match at a known target resolution."""
    mode, prefs = configured(addon, meta)
    # Explicit order/size rules require all results. Recommended mode can
    # start from a small exact-match shortlist without relaxing preferences.
    if mode != 2 or prefs.get('sort') != 'recommended':
        return None
    eligible = filter_rows(limit_quality(rows, prefs['maximum']), *filters)
    if remembered:
        from lib.last_source import match
        previous = match([row for row in eligible if not row.get('_session_failed')], remembered)
        if previous is None:
            return None  # A resumed title waits for its previously working release.
        eligible = [previous]
    target = prefs.get('quality')
    if target in (None, 'Any'):
        target = prefs['maximum'] if prefs['maximum'] != 'Any' else '4K'
    unique = {}
    for row in eligible:
        if (row.get('url') and not row.get('_session_failed') and matches(row, prefs)
                and stream_traits(row)['quality'] == target):
            unique.setdefault(row['url'], row)
    if not unique:
        return None
    # Duplicate releases do not count as evidence. Group them for selection,
    # then hand the original provider row to the existing playback path.
    from lib.source_groups import group_rows
    grouped = group_rows(rank_rows(list(unique.values()), prefs))
    return (grouped[0].get('_alternatives') or [grouped[0]])[0]
