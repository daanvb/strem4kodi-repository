"""Compact, source-labelled scores for the title's recommendation row."""
import math
import threading


def apply_ratings(item, row, get_setting):
    badges = []
    if get_setting('ui_show_rating') != 'false':
        supplied = {badge.get('source'): badge for badge in (row.get('rating_badges') or [])
                    if isinstance(badge, dict)}
        for source in ('tomatoes', 'tomatoesaudience'):
            badge = supplied.get(source, {})
            try:
                value = float(str(badge.get('value', '')).rstrip('%'))
            except (ValueError, TypeError):
                continue
            if math.isfinite(value) and 0 <= value <= 100 and get_setting('rating_' + source) != 'false':
                from lib.rating_awards import icon
                artwork = badge.get('icon') or icon({}, source, value) + '.png'
                badges.append((artwork, '{:g}%'.format(value)))
    for index in range(2):
        artwork, value = badges[index] if index < len(badges) else ('', '')
        item.setProperty('card_rating%d' % index, value)
        item.setProperty('card_rating_icon%d' % index,
                         'special://home/addons/script.strem4kodi/resources/skins/Main/media/ratings/'
                         + artwork if artwork else '')


def start(window, rows, get_setting):
    """Enrich optional scores without delaying navigation or resetting the list."""
    from lib import mdblist
    if not rows or get_setting('ui_show_rating') == 'false' or not mdblist.enabled():
        return
    token = object()
    window._similar_ratings_token = token

    def current():
        return (not window.closed and window.section == 'Similar' and window.cards is rows
                and window._similar_ratings_token is token)

    def work():
        for position, row in enumerate(rows):
            if not current():return
            try:
                fresh = mdblist.enrich(row)
                with window._row_update_lock:
                    if not current():return
                    if 'rating_badges' in fresh:
                        row['rating_badges'] = fresh['rating_badges']
                        apply_ratings(window.getControl(503).getListItem(position), row, get_setting)
            except Exception:
                pass
    try:threading.Thread(target=work, daemon=True).start()
    except RuntimeError:pass
