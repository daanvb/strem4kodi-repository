Player Media info logos describe Kodi-reported formats. Browsing logos above the title rows describe source-reported availability from a fresh source lookup for the exact movie or episode; they are not playback detection or a guarantee that one source contains every displayed format. Unknown and stale availability is omitted.

`atmos.png`: unmodified Dolby Atmos Horizontal logo from Dolby Newsroom:
https://news.dolby.com/en-WW/assets/228229/

Other assets reuse the format flags bundled with the Kodi Estuary companion
skin. Original product names and logos belong to their respective owners.

Resolution flags (720p, 1080p, 4K and 8K) reuse the bundled Estuary videoresolution assets. Resolution names and icons use decoded stream dimensions, including common cropped widescreen sizes; unknown sizes retain their exact dimensions without an invented format badge. Dolby Atmos is shown alongside its reported Dolby Digital Plus or TrueHD base format.

Updated Dolby logos retain their original artwork and aspect ratios:
- dolbyvision.png: official Dolby Vision Vertical PNG, https://news.dolby.com/en-WW/assets/228231/
- eac3.png: Dolby Digital Plus SVG by Dolby Laboratories, rendered to PNG at 700px without changing paths or colours, https://commons.wikimedia.org/wiki/File:Dolby-Digital-Plus.svg
- truehd.png: Dolby TrueHD SVG by Dolby Laboratories, rendered to PNG at 700px without changing paths or colours, https://commons.wikimedia.org/wiki/File:Dolby_TrueHD.svg
Original dark artwork is retained here for attribution. The UI uses the transparent display variants described below.

The ui/ folder contains original typographic resolution and dynamic-range badges, supplied as editable SVGs and PNGs for Kodi. These are interface labels, not official certification marks. All badges share a 240 × 64 display frame. Dolby artwork retains its original proportions. Codec badges are omitted from the player.

Reference-style HDR badges: ui/hdr10.svg is an original outlined text badge. ui/hdr10plus.svg and its rendered PNG retain the Samsung HDR10+ artwork and colours, sourced from https://commons.wikimedia.org/wiki/File:HDR10%2B_Logo.svg (Samsung Group; uploaded by Coasterghost; CC BY-SA 4.0 https://creativecommons.org/licenses/by-sa/4.0/). SVG unchanged; PNG rendered at 800px. That artwork remains under CC BY-SA 4.0. Dolby Vision uses the unmodified official vertical PNG from the Dolby Newsroom kit linked above.

Audio artwork updates (SVG originals retained; PNG rendering only, 800px): ac3.svg from Dolby Laboratories https://commons.wikimedia.org/wiki/File:Dolby-Digital.svg; dts.svg from DTS/Xperi https://commons.wikimedia.org/wiki/File:DTS_(2020).svg; dtshd_ma.svg from DTS, vector extraction by Locke Cole https://commons.wikimedia.org/wiki/File:DTS-HD-MA.svg. These Commons files are labelled public-domain text logos. Original colour gradients are retained for DTS.

The clean/ display variants use the original alpha contours in white, cropped to artwork bounds for consistent optical sizing on dark backgrounds. HDR10+ retains its coloured panels, with dark lettering changed to white (adapted CC BY-SA 4.0 artwork; original and attribution above). No background tiles are used. All logo files are bundled locally. Focused browsing titles preload source availability in the background, reusing the exact movie/episode source cache.

The refined/ display variants render available vector artwork at higher resolution and retain high-resolution originals for raster logos. They use smaller, consistently fitted image slots; resolution lettering uses medium weight. HDR10+ retains its attribution and adapted colours as above. Availability badges sit at the lower right above the title rows. Background checks also run during the app-owned hero preview, so unwatched focused titles can display available formats.
