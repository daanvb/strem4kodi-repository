"""Idle control-bar cleanup limited to video started by Strem4Kodi."""
import time

DELAYS = (None, 5, 10, 15)


class PlayerOSD:
    def __init__(self, player, addon, kodi=None, gui=None, clock=time.monotonic):
        if kodi is None:
            import xbmc as kodi
        if gui is None:
            import xbmcgui as gui
        self.player=player;self.addon=addon;self.kodi=kodi;self.gui=gui
        self.clock=clock;self.visible_since=None

    def tick(self):
        try:
            index=int(self.addon.getSetting('playback_controls_hide') or '1')
            delay=DELAYS[index] if 0 <= index < len(DELAYS) else 5
            # The top dialog must be the control bar itself, never a submenu.
            if delay is None or self.gui.getCurrentWindowDialogId()!=12901:
                self.visible_since=None;return
            file=getattr(self.player,'_playing_file',None)
            if not file or not self.player.isPlayingVideo() or self.player.getPlayingFile()!=file:
                self.visible_since=None;return
            if self.kodi.getCondVisibility('Player.Paused | Player.Seeking | Player.Forwarding | Player.Rewinding'):
                self.visible_since=None;return
            now=self.clock()
            if self.visible_since is None:self.visible_since=now
            if now-self.visible_since>=delay and self.kodi.getGlobalIdleTime()>=delay:
                self.kodi.executebuiltin('Dialog.Close(videoosd)')
                self.visible_since=None
        except Exception:
            self.visible_since=None
