"""Read-only ChaptersDB fallback; never infer an edition from the last marker."""
import json
import math
import re
import time
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError
from account import Store

BASE = 'https://chaptersdb.com/api/v1'


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def fetch(path):
    try:
        with build_opener(NoRedirect()).open(Request(BASE + path, headers={
                'Accept': 'application/json', 'User-Agent': 'Strem4Kodi/1'}), timeout=6) as response:
            data = response.read(2 * 1024 * 1024 + 1)
    except HTTPError as error:
        if error.code == 404:
            return {}
        raise
    if len(data) > 2 * 1024 * 1024:
        raise ValueError('Chapter response too large')
    result = json.loads(data)
    if not isinstance(result, dict):
        raise ValueError('Invalid chapter response')
    return result


def identity(kind, value):
    match = re.fullmatch(r'(tt\d+)(?::(\d+):(\d+))?', str(value or ''))
    if not match or kind not in ('movie', 'series'):
        return None
    imdb, season, episode = match.groups()
    if kind == 'movie' and season is None:
        return imdb, None, None
    if kind == 'series' and season is not None and int(episode) > 0:
        return imdb, int(season), int(episode)
    return None


def seconds(value):
    match = re.fullmatch(r'(\d{1,3}):([0-5]\d):([0-5]\d(?:\.\d{1,3})?)', str(value))
    if not match:
        raise ValueError('Invalid chapter time')
    h, m, s = match.groups()
    return int(h) * 3600 + int(m) * 60 + float(s)


def valid_editions(rows, duration):
    if not isinstance(rows, list) or not math.isfinite(duration) or duration <= 0:
        return []
    editions = []
    for row in rows[:30]:
        if not isinstance(row, dict):
            continue
        entries = row.get('entries')
        if not isinstance(entries, list) or not 2 <= len(entries) <= 300:
            continue
        chapters, previous = [], -1
        for entry in entries:
            try:
                start = seconds(entry.get('time'))
                if start <= previous or start >= duration:
                    break
                name = re.sub(r'[\x00-\x1f\x7f\[\]]', '', str(entry.get('name') or '')).strip()
                chapters.append({'start': start, 'name': name[:180] or 'Chapter {}'.format(len(chapters) + 1),
                                 'time': str(entry['time'])})
                previous = start
            except (AttributeError, ValueError, TypeError):
                break
        else:
            note = re.sub(r'[\x00-\x1f\x7f\[\]]', '', str(row.get('note') or 'Edition not specified'))
            editions.append({'note': note[:240], 'chapters': chapters})
    return editions


def lookup(profile, kind, value, duration, fetcher=fetch, now=None):
    parsed = identity(kind, value)
    if not parsed:
        return []
    now = time.time() if now is None else now
    store = Store(Path(profile) / 'chaptersdb-cache')
    key = kind + ':' + value
    cache = store.load()
    cached = cache.get(key, {})
    if isinstance(cached, dict) and 'checked' in cached and 0 <= now - cached['checked'] < 86400:
        return valid_editions(cached.get('rows'), duration)
    imdb, season, episode = parsed
    show = fetcher('/show/' + quote(imdb, safe=''))
    if show.get('imdbId') and show['imdbId'] != imdb:
        return []
    rows = []
    if kind == 'movie' and show.get('type') == 'movie':
        rows = show.get('chapters', [])
    elif kind == 'series' and show.get('type') == 'tv':
        matches = []
        for row in show.get('episodes', []):
            if not isinstance(row, dict):
                continue
            marker = re.search(r'(?i)\bS(\d+)E(\d+)\b', str(row.get('title') or ''))
            if marker and (int(marker[1]), int(marker[2])) == (season, episode) and row.get('id'):
                matches.append(row)
        if len(matches) == 1:
            response = fetcher('/chapters/' + quote(str(matches[0]['id']), safe=''))
            rows = response.get('chapters', [])
    if not isinstance(rows, list):
        rows = []
    cache[key] = {'checked': now, 'rows': rows[:30]}
    # Keep the cache bounded and local; no stream URLs or account tokens.
    cache = dict(sorted(cache.items(), key=lambda item: item[1].get('checked', 0), reverse=True)[:100])
    store.save(cache)
    return valid_editions(rows, duration)
