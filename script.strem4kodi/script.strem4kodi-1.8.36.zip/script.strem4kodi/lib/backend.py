"""Program-window adapter to the existing Strem4Kodi backend.

No video-plugin navigation and no global skin settings are used here.
"""
import sys
import time
import uuid
from urllib.parse import urlencode

import xbmc
import xbmcaddon
from addon_state import get_addon
import xbmcvfs

CORE = get_addon()
CORE_PATH = xbmcvfs.translatePath(CORE.getAddonInfo('path'))
if CORE_PATH not in sys.path:
    sys.path.append(CORE_PATH)

from account import Store, library_rows
from addons_core import active_addons
from metadata_bridge import details, seasons, episodes, search as metadata_search, trailer_rows
from lib.title_metadata import people, recommendations
from protocol import fetch, resource_url
from sources import collect
from continue_playback import next_series_episode, resume_seconds
from stream_ui import stream_card
from library_actions import member, change

STORE = Store(xbmcvfs.translatePath(CORE.getAddonInfo('profile')))
HOME = 'https://v3-cinemeta.strem.io/manifest.json'


def providers(role=None):
    from provider_roles import ordered, selected, artwork_providers, key
    from lib.provider_config import state as provider_state
    state = provider_state(STORE.directory, STORE.load())
    result = ordered(state, role) if role else list(active_addons(state))
    from lib.provider_diagnostics import configure
    configure(STORE.directory, active_addons(state))
    if role == 'metadata':
        artwork = artwork_providers(state)
        rating = selected(state, 'ratings')
        preferred = {'artwork': key(artwork[0]) if artwork else '',
                     'ratings': key(rating) if rating else ''}
        result = [dict(p, _preferred_roles=[r for r, value in preferred.items() if value == key(p)])
                  for p in result]
    return list(result)


def search_catalogues(query, limit=8):
    from lib.browse import discover_catalogs
    from lib.catalogue_search import matches
    return matches(query, discover_catalogs(providers()), limit)


def search_titles(query, limit=60):
    catalogues = search_catalogues(query)
    try:
        result = metadata_search(query, providers('search'), limit=limit, provider_first=True)
    except Exception:
        result = []
    from lib.catalog_poster import configured
    return catalogues + configured(STORE.load()).cached([{'items': result}])[0]['items']


def suggestions(query):
    catalogues = search_catalogues(query, limit=2)
    try:
        return catalogues + _title_suggestions(query)
    except Exception:
        return catalogues


def _title_suggestions(query):
    from provider_roles import selected
    from lib.title_suggestions import lookup
    from lib.provider_config import state as provider_state
    state = provider_state(STORE.directory, STORE.load())
    primary = selected(state, 'search')
    if primary:
        # Autocomplete and full search share the same supplier and ranking.
        from lib.title_suggestions import ranked
        matches = ranked(query, metadata_search(query, [primary], limit=8, provider_first=True,
                         fetcher=lambda url: fetch(url, timeout=3), fallback_only=True))
    else:
        matches = lookup(query)
    from lib.catalog_poster import configured
    return configured(state).cached([{'items': matches}])[0]['items']


def catalog(kind, genre=''):
    payload = fetch(resource_url(HOME, 'catalog', kind, 'top', {'genre': genre} if genre else None))
    return [r for r in payload.get('metas', []) if isinstance(r, dict) and r.get('id')][:40]


def metadata(row):
    _request_fel_catalog()
    result = dict(row)
    full = details(row['type'], row['id'], providers=providers('metadata'))
    result.update({k: v for k, v in full.items() if v not in ('', None, [], {})})
    from lib.poster_enhancement import decorate
    return decorate([result], STORE.load())[0]


def availability_metadata(row):
    from metadata_bridge import availability_episodes
    return availability_episodes(row.get('type'), row.get('id'), providers('metadata'))


def library():
    return [dict(r, id=r.get('_id') or r.get('id')) for r in library_rows(STORE.load().get('library', []))]


def saved(meta):
    return next((r for r in STORE.load().get('library', [])
                 if r.get('_id') == meta['id'] and r.get('type') == meta['type']), {})


def in_library(meta):
    return member(STORE.load().get('library', []), meta['id'], meta['type'])


def toggle_library(meta):
    return toggle_saved_list(meta, 'watchlist')


def saved_list_roles(meta):
    from lib.saved_lists import SavedLists
    state = STORE.load()
    return SavedLists(STORE.directory, state.get('token')).roles(meta, in_library(meta))


def saved_list_entries(entries, role):
    from lib.saved_lists import SavedLists
    return SavedLists(STORE.directory, STORE.load().get('token')).entries(entries, role)


def toggle_saved_list(meta, role):
    return update_saved_lists(meta, {role: not saved_list_roles(meta)[role]})


def move_saved_list(meta, role):
    from lib.saved_lists import ROLES
    if role not in ROLES:
        raise ValueError('Unknown saved list')
    return update_saved_lists(meta, {name: name == role for name in ROLES})


def update_saved_lists(meta, values):
    from lib.saved_lists import SavedLists, ROLES, clean
    if not values or any(role not in ROLES for role in values):
        raise ValueError('Unknown saved list')
    state = STORE.load()
    if not state.get('token'):
        raise ValueError('Connect your Stremio account in Settings first.')
    memory = SavedLists(STORE.directory, state['token'])
    if not clean({memory.key(meta): {role:{'value':bool(value),'updated':0} for role,value in values.items()}}):
        raise ValueError('My Lists supports movie and series titles.')
    saved_before = member(state.get('library', []), meta['id'], meta['type'])
    roles = memory.roles(meta, saved_before)
    roles.update(values)
    state['library'] = change(state['token'], meta['id'], meta['type'],
                              meta.get('name', ''), meta.get('poster', ''), any(roles.values()))
    STORE.save(state)
    memory.set_roles(meta, values, saved_before)
    return True


def mark_episodes_through(meta, target_id, watched=True):
    from episode_actions import sync_through
    remote, selected = sync_through(STORE, meta, target_id, watched)
    return remote, selected


def mark_episode(meta, target_id, watched=True):
    from episode_actions import sync_single
    remote, selected = sync_single(STORE, meta, target_id, watched)
    return remote, selected


def mark_movie(meta, watched=True):
    from media_actions import sync_movie_watched
    return sync_movie_watched(STORE, meta, watched)


def remove_continue(meta):
    from media_actions import sync_remove_continue
    return sync_remove_continue(STORE, meta)


def languages(meta):
    raw = (meta.get('languages') or meta.get('spokenLanguages') or
           meta.get('audioLanguages') or meta.get('language') or [])
    if isinstance(raw, (str, dict)):
        raw = [raw]
    rows = []
    for value in raw if isinstance(raw, list) else []:
        if isinstance(value, dict):
            code = value.get('iso_639_1') or value.get('code') or ''
            name = value.get('english_name') or value.get('name') or code
        else:
            name = str(value).strip()
            code = name if len(name) in (2, 3) else ''
        if code:
            name = xbmc.convertLanguage(str(code), xbmc.ENGLISH_NAME) or name
        row = {'name': str(name), 'code': str(code).upper() or str(name)[:2].upper()}
        if name and row not in rows:
            rows.append(row)
    return rows


def _stream_provider_signature():
    from lib.stream_index import provider_signature
    return provider_signature(providers('streams'))

def stream_cache_state(meta, identity):
    from lib.stream_index import get
    return get(STORE.directory, meta['type'], identity, _stream_provider_signature())


def availability_summary(meta):
    from lib.availability_index import get, scope
    context = scope(meta, saved(meta) if meta.get('type') == 'series' and not meta.get('_focus_video_id') else None)
    return get(STORE.directory, meta, context) or dict(scope=context)


def remember_availability(meta, target, rows, context=None):
    from lib.availability_index import put, scope
    from lib.available_formats import formats
    if not rows:
        return  # Failed lookups must not erase last-known availability.
    context = context or availability_summary(meta)['scope']
    found = formats(rows)
    put(STORE.directory, meta, context, target, found)
    # The same episode may subsequently be opened explicitly in details.
    put(STORE.directory, meta, scope(dict(meta, _focus_video_id=target)), target, found)

def _request_fel_catalog():
    if CORE.getSetting("fel_labels") != "false" and not xbmc.Player().isPlayingVideo():
        from lib.fel_catalog import request
        request(STORE.directory)

def _fel_row(row, meta):
    row["_fel_movie_id"] = str(meta.get("imdb_id") or meta.get("id") or "") if meta.get("type") == "movie" else ""
    row["_fel_labels"] = CORE.getSetting("fel_labels") != "false"
    return row

def cached_source_rows(meta, identity):
    from sources import embedded_sources
    embedded = embedded_sources(meta, identity)
    if embedded is not None:
        for row in embedded[0]:
            row['card'] = stream_card(row)
            _fel_row(row, meta)
        return embedded
    cached=stream_cache_state(meta, identity)
    if not cached:return None
    rows,skipped,failed,_,_,_=cached
    _request_fel_catalog()
    for row in rows:
        row['card']=stream_card(row)
        _fel_row(row, meta)
    return rows,skipped,failed

def source_rows(meta, identity):
    from lib.stream_index import put
    from sources import embedded_sources
    embedded = embedded_sources(meta, identity)
    if embedded is not None:
        for row in embedded[0]:
            row['card'] = stream_card(row)
            _fel_row(row, meta)
        return embedded
    _request_fel_catalog()
    active = providers('streams')
    timing = []
    context = meta.get('_availability_scope') or str(identity)
    retained = availability_summary(meta).get('formats')
    def early_badges(rows):
        if not retained:
            remember_availability(meta, identity, rows, context=context)
    rows, skipped, failed = collect(active, meta['type'], identity, timing=timing,
                                    on_results=early_badges)
    try:
        from lib.perf_report import record_stream_providers
        record_stream_providers(STORE.directory, timing)
    except Exception:
        pass
    for row in rows:
        row['card'] = stream_card(row)
        _fel_row(row, meta)
    result=(rows,skipped,failed)
    if rows:put(STORE.directory,meta['type'],identity,result,_stream_provider_signature())
    remember_availability(meta, identity, rows, context=context)
    return result


def play(meta, identity, stream, resume_ms=0):
    # Reuse the core resolver, subtitles and playback observer rather than
    # introducing a second playback implementation in the program addon.
    key = uuid.uuid4().hex
    state = Store(STORE.directory / 'streams')
    cache = state.load()
    cache.update(created=time.time())
    urls = dict(cache.get('urls') or {})
    urls[key] = dict(stream, meta=meta, kind=meta['type'], id=identity, resume_ms=resume_ms)
    cache['urls'] = urls
    state.save(cache)
    url = 'plugin://script.strem4kodi/?' + urlencode({'action': 'play', 'key': key})
    xbmc.executebuiltin('PlayMedia(' + url + ')')


def _continue_rows(state, catalogs=(), allow_network=False):
    from lib import continue_index
    library = state.get('library', [])
    # Seed is local SQLite work only and keeps every Stremio CW pointer.
    continue_index.seed(STORE.directory, library)

    if allow_network:
        from continue_playback import continue_series_target
        # Resolve a bounded batch of changed/completed series each refresh. SQLite
        # retains all prior resolutions, so subsequent refreshes continue the queue.
        for media_id, row in continue_index.unresolved_series(STORE.directory, 8):
            try:
                full = metadata(row)
                target, resume_ms = continue_series_target(full.get('videos') or [], row)
            except Exception:
                continue
            projected = dict(row)
            projected.update({key: value for key, value in full.items()
                              if value not in ('', None, [], {})})
            projected['id'] = media_id
            series_status=str(full.get('status') or '').strip().lower()
            confirmed_finished = target is None and series_status in ('ended','canceled','cancelled')
            continue_index.resolve_series(STORE.directory, media_id, projected, target, resume_ms, confirmed_finished)

    continuing = continue_index.rows(STORE.directory, 100)
    if continuing:
        from lib.hero_metadata import prepare
        continuing = prepare(continuing, catalogs, None)
        return {'label': 'Continue Watching', 'items': continuing, 'failed': False}
    return None


def account_home_capacity():
    """Reserve Home rows and six Discover overview rows plus More lists."""
    state = STORE.load()
    from lib import continue_index
    continue_index.seed(STORE.directory, state.get('library', []))
    return 7


def _progress_sections(continuing):
    """Separate unfinished playback from the next confirmed aired episodes."""
    if not continuing:
        return []
    watching, upcoming = [], []
    for row in continuing.get('items', []):
        episode = row.get('_next_episode')
        if episode and row.get('type') == 'series':
            card = dict(row, _continue_watching=True, _focus_video_id=episode['id'])
            card['name'] = '{} - S{:02d}E{:02d}'.format(row.get('name', ''), int(episode.get('season') or 0), int(episode.get('episode') or episode.get('number') or 0))
            card['description'] = episode.get('description') or episode.get('overview') or row.get('description', '')
            upcoming.append(card)
        else:
            watching.append(row)
    return ([dict(continuing, items=watching)] if watching else []) + (
        [{'label': 'Up Next', 'items': upcoming, 'failed': False}] if upcoming else [])


def account_home(refresh=True):
    from lib.perf_trace import now as perf_now, log as perf_log
    total_started = perf_now()
    """Return Home without blocking startup when refresh=False.

    Both modes read local playback state. Catalogue browsing belongs in Discover
    and Sports; metadata and account sync remain in the background service.
    """
    from lib.home_snapshot import load as load_snapshot, save as save_snapshot
    state = STORE.load()
    if not state.get('token'):
        return []

    if not refresh:
        stage_started = perf_now()
        from lib.home_snapshot import active_rows
        rows = active_rows(load_snapshot(STORE.directory),
                           [a for a in active_addons(state) if a.get('account') is True])
        continuing = _continue_rows(state, rows, False)
        result = _progress_sections(continuing) + _upcoming_sections()
        from lib.catalog_poster import configured
        result = configured(state).cached(result)
        perf_log('home.cached', stage_started, profile=STORE.directory, rows=len(result),
                 items=sum(len(row.get('items') or []) for row in result))
        perf_log('home.cached.total', total_started, profile=STORE.directory)
        return result

    # Account/provider sync runs in the periodic service worker.
    addons_started = perf_now()
    perf_log('home.refresh.account.local', addons_started, profile=STORE.directory)
    from lib.provider_diagnostics import configure
    configure(STORE.directory, active_addons(state))
    catalogs_started = perf_now()
    catalog_rows = []
    perf_log('home.refresh.catalogs', catalogs_started, profile=STORE.directory, rows=len(catalog_rows),
             items=sum(len(row.get('items') or []) for row in catalog_rows))
    # Clear legacy catalogue snapshots after migrating to the focused Home.
    save_snapshot(STORE.directory, catalog_rows)

    # Library/CW network sync and series resolution run in the 15-minute service
    # worker. Home only reads the latest local SQLite state, avoiding a 2-3s
    # 4k+ library pull plus metadata fan-out on every window open.
    library_started = perf_now()
    continuing = _continue_rows(state, catalog_rows, False)
    perf_log('home.refresh.library.local', library_started, profile=STORE.directory)
    result = _progress_sections(continuing) + _upcoming_sections()
    from lib.catalog_poster import configured
    result = configured(state).cached(result)
    perf_log('home.refresh.total', total_started, profile=STORE.directory, rows=len(result),
             items=sum(len(row.get('items') or []) for row in result))
    return result


def _upcoming_sections():
    from lib.continue_index import upcoming
    rows = upcoming(STORE.directory)
    return [{'label': 'Upcoming Episodes', 'items': rows, 'failed': False}] if rows else []


def collection_progress(rows, unwatched=False):
    from lib.catalogue_search import with_progress
    from lib.continue_index import resolved_series
    from lib.discovery_groups import item_key
    known = {item_key(r): r.get('videos') for r in resolved_series(STORE.directory)}
    library = [dict(r, videos=known.get(item_key(dict(r, id=r.get('_id') or r.get('id'))), r.get('videos') or []))
               for r in account_library(False) if isinstance(r, dict)]
    return with_progress(rows, library, unwatched)


def discover_choices(sports=False):
    from lib.browse import discover_catalogs
    from lib.discovery_groups import groups
    return groups(discover_catalogs(providers()), sports=sports)


def discover_items(catalog, extras=None):
    if catalog.get('members'):
        from lib.discovery_groups import merge_pages
        return merge_pages(catalog, discover_items, extras)
    if not any(p.get('transportUrl') == catalog.get('url') for p in providers()):
        return []
    values = dict(catalog['defaults'])
    values.update(extras or {})
    data = fetch(resource_url(catalog['url'], 'catalog', catalog['kind'], catalog['id'], values))
    return [dict(row, type=row.get('type') or catalog['kind']) for row in data.get('metas', [])
            if isinstance(row, dict) and row.get('id')][:100]


def account_library(refresh=True):
    from account import pull_library
    state = STORE.load()
    if refresh and state.get('token'):
        state['library'] = pull_library(state['token'])
        STORE.save(state)
    return state.get('library', [])
