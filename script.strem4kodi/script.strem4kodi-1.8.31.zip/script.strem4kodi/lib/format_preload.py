"""Debounced, single-flight availability checks for the focused browsing title."""
import threading


def lookup(meta, api, current=lambda: True):
    meta = dict(meta)
    if meta.get('type') not in ('movie', 'series') or meta.get('_catalogue'):
        return None
    target = meta.get('id') if meta['type'] == 'movie' else meta.get('_focus_video_id')
    if not target:
        saved = api.saved(meta)
        if not meta.get('videos'):
            meta.update(api.metadata(meta))
        video, _ = api.next_series_episode(meta.get('videos', []), meta['id'], saved)
        if video:
            target = video['id']
    if not target or (meta['type'] == 'series' and target == meta['id']):
        return None
    if not current():
        return None
    cached = api.stream_cache_state(meta, target)
    if not cached or cached[4]:
        api.source_rows(meta, target)
    meta['_focus_video_id'] = target
    return meta


class Preloader:
    def __init__(self, delay=0.8):
        self.delay = delay
        self.lock = threading.Lock()
        self.timer = None
        self.pending = None
        self.loading = False
        self.closed = False
        self.revision = 0

    def request(self, work):
        with self.lock:
            if self.closed:
                return
            self.pending = work
            self.revision += 1
            if self.timer:
                self.timer.cancel()
            if not self.loading:
                self._schedule()

    def _schedule(self):
        self.timer = threading.Timer(self.delay, self._run, args=(self.revision,))
        self.timer.daemon = True
        self.timer.start()

    def _run(self, revision):
        with self.lock:
            if self.closed or self.loading or not self.pending or revision != self.revision:
                return
            work, self.pending = self.pending, None
            self.loading = True
        try:
            work()
        except Exception:
            pass  # Optional artwork metadata must never interrupt browsing.
        finally:
            with self.lock:
                self.loading = False
                if self.pending and not self.closed:
                    self._schedule()

    def close(self):
        with self.lock:
            self.closed = True
            self.pending = None
            if self.timer:
                self.timer.cancel()
