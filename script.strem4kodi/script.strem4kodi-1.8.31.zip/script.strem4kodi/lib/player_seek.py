"""Use queued scrubbing only for the owned companion player."""
def run(direction, kodi=None, gui=None):
    if kodi is None:
        import xbmc as kodi
    if gui is None:
        import xbmcgui as gui
    top = gui.getCurrentWindowDialogId()
    if top not in (-1, 0, 10115, 12901):
        return  # Never forward a seek through an options or chapter dialog.
    if (kodi.getSkinDir() == 'skin.strem4kodi'
            and gui.Window(10000).getProperty('strem4kodi.player.active') == 'true'
            and kodi.Player().isPlayingVideo()
            and not kodi.getCondVisibility('VideoPlayer.Content(livetv)')):
        if gui.Window(10000).getProperty('strem4kodi.player.scrubbing'):
            return
        from lib.player_scrub import show
        show(direction)
    else:
        kodi.executebuiltin('Action(StepBack)' if direction < 0 else 'Action(StepForward)')
