"""Append catalogue pages without disturbing supplier order or showing repeats."""
from lib.discovery_groups import item_key


def combine(previous, incoming):
    seen, result = set(), []
    for row in previous + incoming:
        key = item_key(row)
        if key not in seen:
            seen.add(key)
            result.append(row)
    return result


def more_card():
    return {'id': 'discover:load-more', 'type': 'collection', 'name': 'Load more titles',
            'description': 'Add the next titles below this list.', '_discover_load_more': True}
