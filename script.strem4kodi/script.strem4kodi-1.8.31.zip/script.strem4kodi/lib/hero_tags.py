"""Map provider metadata to Nimbus FlixInfoIcon labels."""
import re


def upcoming_preview(full, preview):
    """Keep episode presentation separate from cached series metadata."""
    result = dict(full)
    for key in ('_focus_video_id', 'state'):
        if key in preview:
            result[key] = preview[key]
    if preview.get('_upcoming_episode'):
        result.update({key: preview[key] for key in
                       ('name', 'description', '_release_label', '_upcoming_episode') if key in preview})
    return result


def tags(row):
    date = str(row.get('released') or row.get('releaseInfo') or row.get('year') or '')
    match_year = re.match(r'^(\d{4})',date)
    date = match_year.group(0) if match_year else ''
    runtime = str(row.get('runtime') or '')
    match = re.fullmatch(r'(\d+)\s*(?:min|mins|minutes)?', runtime.strip(), re.I)
    if match:
        minutes = int(match[1])
        runtime = ('{}h'.format(minutes // 60) + (' {}m'.format(minutes % 60) if minutes % 60 else '')) if minutes >= 60 else '{}m'.format(minutes)
    value = str(row.get('certificate_gb') or '')
    if not value and row.get('certificate_country') == 'GB':
        value = str(row.get('certification') or row.get('mpaa') or '')
    value = value.upper().strip()
    if value not in ('U', 'PG', '12', '12A', '15', '18', 'R18'):value = ''
    return {'premiered': date, 'certificate': 'UK ' + value if value else '',
            'genre_tag':' · '.join((row.get('genres') or [])[:2]), 'runtime_tag':runtime}
