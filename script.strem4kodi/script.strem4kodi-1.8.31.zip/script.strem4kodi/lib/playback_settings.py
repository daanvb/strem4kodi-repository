"""Addon-owned, reversible fullscreen Back keymap."""
from pathlib import Path

LEGACY_KEYMAP = '''<keymap>
  <FullscreenVideo>
    <keyboard><escape>Stop</escape><backspace>Stop</backspace><browser_back>Stop</browser_back></keyboard>
    <remote><back>Stop</back></remote>
    <joystick profile="game.controller.default"><b>Stop</b></joystick>
  </FullscreenVideo>
</keymap>
'''


_DIALOG_BACK = '''    <keyboard><escape>Back</escape><backspace>Back</backspace><browser_back>Back</browser_back></keyboard>
    <remote><back>Back</back></remote>
    <joystick profile="game.controller.default"><b>Back</b></joystick>'''
# Explicit dialog bindings prevent a fullscreen Stop/RunScript override from
# swallowing Back while a native playback menu or nested slider has focus.
KEYMAP = LEGACY_KEYMAP.replace('</keymap>', '\n'.join(
    '  <{0}>\n{1}\n  </{0}>'.format(context, _DIALOG_BACK)
    for context in ('OSDAudioSettings', 'OSDSubtitleSettings', 'OSDVideoSettings',
                    'OSDCMSSettings', 'VideoOSD', 'VideoBookmarks', 'SliderDialog',
                    'FullscreenInfo', 'SubtitleSearch')) + '\n</keymap>')
DOUBLE_KEYMAP = KEYMAP.replace('Stop', 'RunScript(special://home/addons/script.strem4kodi/player_back.py)')

UP_KEYMAP = '''<keymap>
  <FullscreenVideo>
    <keyboard><up>RunScript(special://home/addons/script.strem4kodi/player_up.py)</up></keyboard>
    <remote><up>RunScript(special://home/addons/script.strem4kodi/player_up.py)</up></remote>
    <joystick profile="game.controller.default"><up>RunScript(special://home/addons/script.strem4kodi/player_up.py)</up></joystick>
  </FullscreenVideo>
  <VideoOSD>
    <keyboard><up>RunScript(special://home/addons/script.strem4kodi/player_up.py)</up></keyboard>
    <remote><up>RunScript(special://home/addons/script.strem4kodi/player_up.py)</up></remote>
    <joystick profile="game.controller.default"><up>RunScript(special://home/addons/script.strem4kodi/player_up.py)</up></joystick>
  </VideoOSD>
</keymap>
'''

# Fullscreen horizontal shortcuts use the same preview; other skins/media keep
# Kodi's normal steps. Modal menus retain their own directional navigation.
for device in ('keyboard', 'remote', 'joystick'):
    closing = '</' + device + '>'
    steps = ''.join('<{0}>RunScript(special://home/addons/script.strem4kodi/player_seek.py,{0})</{0}>'.format(key)
                    for key in ('left', 'right'))
    UP_KEYMAP = UP_KEYMAP.replace(closing, steps + closing, 1)


# Explicit window-scoped long presses retain short-OK defaults and avoid
# intercepting selection inside modal chapter, audio or subtitle menus.
import xml.etree.ElementTree as ET
_navigation = ET.fromstring(UP_KEYMAP)
for _window in _navigation:
    for _device in _window:
        if _device.tag == 'keyboard':
            for _key in ('return','enter','ok','select'):
                _fallback = 'PlayPause' if _window.tag == 'FullscreenVideo' and _key != 'select' else 'ContextMenu'
                ET.SubElement(_device, _key, mod='longpress').text = 'RunScript(special://home/addons/script.strem4kodi/player_credits.py,' + _fallback + ')'
        elif _device.tag == 'remote':
            _fallback = 'OSD' if _window.tag == 'FullscreenVideo' else 'Select'
            ET.SubElement(_device, 'select', mod='longpress').text = 'RunScript(special://home/addons/script.strem4kodi/player_credits.py,' + _fallback + ')'
UP_KEYMAP = ET.tostring(_navigation, encoding='unicode') + '\n'


def write_navigation(directory):
    target = Path(directory) / 'zz-strem4kodi-navigation.xml'
    if target.exists() and target.read_text(encoding='utf-8') == UP_KEYMAP:
        return False
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(UP_KEYMAP, encoding='utf-8', newline='\n')
    return True


def back_mode(addon):
    if addon.getSetting('playback_back_migrated') != 'true':
        if addon.getSetting('playback_back_stops') == 'false':
            addon.setSetting('playback_back_action', '0')
        addon.setSetting('playback_back_migrated', 'true')
    try:
        value = int(addon.getSetting('playback_back_action') or '2')
        return value if value in (0, 1, 2) else 2
    except (ValueError, TypeError):
        return 2


def write_keymap(directory, enabled, double=False):
    target = Path(directory) / 'zz-strem4kodi-back.xml'
    legacy = Path(directory) / 'zz-stremio-for-kodi-back.xml'
    migrated = False
    if legacy.exists() and legacy.read_text(encoding='utf-8') in (
            KEYMAP, DOUBLE_KEYMAP, LEGACY_KEYMAP,
            LEGACY_KEYMAP.replace('Stop', 'RunScript(special://home/addons/script.strem4kodi/player_back.py)')):
        legacy.unlink()
        migrated = True
    content = DOUBLE_KEYMAP if double else KEYMAP
    if enabled:
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and target.read_text(encoding='utf-8') == content:
            return migrated
        target.write_text(content, encoding='utf-8', newline='\n')
        return True
    if target.exists():
        target.unlink()
        return True
    return migrated


def apply():
    import xbmc
    import xbmcvfs
    try:
        from addon_state import get_addon
    except ModuleNotFoundError:
        # Report/repository entry points can import this helper without default.py
        # having first inserted core/ on sys.path. Keep startup independent.
        from core.addon_state import get_addon
    mode = back_mode(get_addon())
    directory = xbmcvfs.translatePath('special://profile/keymaps/')
    changed = write_keymap(directory, mode != 0, double=mode == 2)
    changed = write_navigation(directory) or changed
    if changed:
        xbmc.executebuiltin('Action(ReloadKeymaps)')
