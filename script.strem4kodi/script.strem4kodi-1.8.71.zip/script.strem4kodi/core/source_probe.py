"""Recognise provider error slates before treating them as playable titles."""
import json
from urllib.parse import urlsplit, unquote
from urllib.request import Request, urlopen
from urllib.error import HTTPError


# AIOStreams redirects failed playback to these bundled videos on the instance
# host. Match only the exact dedicated asset paths: a normal short/static video
# or an opaque playback URL is not evidence of a provider failure.
_AIOSTREAMS_ERROR_PATHS = frozenset('/static/' + name + '.mp4' for name in (
    'download_failed', 'downloading', 'unavailable_for_legal_reasons',
    'store_limit_exceeded', 'content_proxy_limit_reached', '500', '429',
    '403', '401', 'no_matching_file', 'payment_required',
))

def error_video(url):
    try:
        # Kodi may append its HTTP options after a literal pipe.
        parsed = urlsplit(str(url).partition('|')[0])
        return (parsed.hostname == 'slate.elfhosted.com' or
                (parsed.scheme in ('http', 'https') and bool(parsed.hostname) and
                 unquote(parsed.path) in _AIOSTREAMS_ERROR_PATHS))
    except ValueError:return False

def unsupported_disc(url, row=None):
    """Only reject explicitly identified disc images, never opaque media URLs."""
    row=row if isinstance(row,dict) else {}
    names=[row.get('filename'), (row.get('card') or {}).get('filename')]
    candidates=row.get('filename_candidates')
    if isinstance(candidates,(list,tuple)):names.extend(candidates)
    try:names.append(unquote(urlsplit(str(url)).path))
    except ValueError:pass
    return any(isinstance(name,str) and name.lower().endswith(('.iso','.img','.nrg','.ifo')) for name in names)

def startup_failure(url,owned=False,live=False,opener=urlopen,row=None):
    """Owned playback uses Kodi/recovery, without connecting to the file twice."""
    if error_video(url):return 'provider-error-video'
    if unsupported_disc(url,row):return 'unsupported-disc-image'
    if owned:return ''
    return unavailable(url,opener=opener,live=live)


def unavailable(url, opener=urlopen, live=False):
    if error_video(url):return 'provider-error-video'
    if unsupported_disc(url):return 'unsupported-disc-image'
    # A range probe can consume a one-use live session or be rejected even
    # though the player can open it. Let Kodi establish the live connection.
    if live:return ''
    try:
        # Small bounded GET follows the same redirects as playback. HEAD may lie
        # or be unsupported; file size / short duration alone never imply failure.
        # This is a best-effort error-slate check, not player buffering. A slow
        # proxy must not hold playback behind a second eight-second connection.
        response = opener(Request(url, headers={'Range':'bytes=0-4095'}), timeout=3)
        try:
            if error_video(response.geturl()):return 'provider-error-video'
            if unsupported_disc(response.geturl()):return 'unsupported-disc-image'
            kind = response.headers.get('Content-Type', '').split(';')[0].lower()
            if kind in ('application/x-iso9660-image','application/x-cd-image'):
                return 'unsupported-disc-image'
            if kind == 'application/json':
                try:payload = json.loads(response.read(4096))
                except (ValueError, UnicodeError):return ''
                if isinstance(payload, dict) and (payload.get('error') or payload.get('errorCode')):
                    return 'provider-error-response'
        finally:response.close()
    except HTTPError as error:
        # The probe is a separate client with a partial Range request. Private
        # proxies may reject it for auth, throttling or startup, while Kodi's
        # real media request succeeds. Only an identified error slate is proof.
        failed_url=error.geturl()
        error.close()
        if error_video(failed_url):return 'provider-error-video'
    except Exception:
        # Unknown transport / range failures are left to Kodi, not guessed.
        pass
    return ''


def redirect_failure(url, opener=urlopen, live=False):
    """Follow a settled VOD redirect without downloading media a second time."""
    if live:return ''
    if error_video(url):return 'provider-error-video'
    try:
        response = opener(Request(url, method='HEAD'), timeout=3)
        try:
            return 'provider-error-video' if error_video(response.geturl()) else ''
        finally:response.close()
    except HTTPError as error:
        final = error.geturl()
        error.close()
        return 'provider-error-video' if error_video(final) else ''
    except Exception:
        return ''


def delayed_redirect_check(url):
    """Only dedicated AIOStreams resolver paths warrant the follow-up HEAD."""
    try:
        parsed=urlsplit(str(url))
        return (parsed.scheme in ('http','https') and bool(parsed.hostname) and
                parsed.path.startswith(('/api/debrid/', '/api/usenet/')))
    except ValueError:return False
