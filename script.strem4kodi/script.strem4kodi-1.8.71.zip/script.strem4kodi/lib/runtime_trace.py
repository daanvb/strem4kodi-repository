"""Fixed-field device traces; never include queries, titles or media URLs."""
import threading
import time

_LOCK = threading.Lock()
_STAGES = {'catalogue.open', 'browse.back', 'search.restored', 'details.back',
           'poll', 'redirect.failed', 'redirect.inconclusive', 'retry'}
_REASONS = {'provider-error-video', 'http-unavailable', 'startup-timeout',
            'playback-stopped', 'playback-error', 'unknown'}
_OUTCOMES = {'same-episode-retry', 'retry-limit', 'manual-fallback',
             'cancelled', 'blocked', 'unrelated'}


def load(profile):
    from pathlib import Path
    from account import Store
    events=Store(Path(profile)/'diagnostic-runtime').load().get('events', [])
    result=[]
    for row in events[-40:] if isinstance(events, list) else []:
        if not isinstance(row, dict) or row.get('stage') not in _STAGES:continue
        event={'stage':row['stage']}
        for field in ('time', 'action', 'focus'):
            value=row.get(field)
            if type(value) is int and 0 <= value <= (2000000000 if field == 'time' else 100000):event[field]=value
        if row.get('page') in ('search','home','discover','library','sports','addons','details'):event['page']=row['page']
        for field in ('search_return', 'preview', 'started', 'owned', 'slate', 'redirected'):
            if type(row.get(field)) is bool:event[field]=row[field]
        for field, allowed in (('reason', _REASONS), ('outcome', _OUTCOMES)):
            if row.get(field) in allowed:event[field]=row[field]
        for field in ('attempt_number', 'attempt_limit'):
            value=row.get(field)
            if type(value) is int and 0 <= value <= 25:event[field]=value
        result.append(event)
    return result


def _record(event):
    try:
        from account import Store
        from lib import backend
        from pathlib import Path
        if event.get('stage') not in _STAGES:return
        with _LOCK:
            events=load(backend.STORE.directory)
            Store(Path(backend.STORE.directory)/'diagnostic-runtime').save({
                'events':(events+[dict(event,time=int(time.time()))])[-40:]})
    except Exception:pass


def navigation(window, stage, action=0):
    try:
        import xbmc
        page = window.getProperty('page')
        page = 'search' if page.startswith('Search:') else page.lower()
        if page not in ('search', 'home', 'discover', 'library', 'sports', 'addons'):
            page = 'details'
        _record(dict(stage=stage,page=page,action=int(action),focus=int(window.getFocusId()),
                     search_return=isinstance(getattr(window, '_search_return_state', None), dict),
                     preview=bool(getattr(window, 'preview_url', None))))
        xbmc.log('Strem4Kodi NAV | {} | page={} | action={} | focus={} | search_return={} | preview={}'.format(
            stage, page, int(action), int(window.getFocusId()),
            int(isinstance(getattr(window, '_search_return_state', None), dict)),
            int(bool(getattr(window, 'preview_url', None)))), xbmc.LOGINFO)
    except Exception:
        pass


def playback(stage, started=False, owned=False, slate=False, redirected=False,
             attempt_number=None, attempt_limit=None, reason=None, outcome=None):
    try:
        import xbmc
        event=dict(stage=stage,started=bool(started),owned=bool(owned),slate=bool(slate),redirected=bool(redirected))
        if type(attempt_number) is int and 0 <= attempt_number <= 25:event['attempt_number']=attempt_number
        if type(attempt_limit) is int and 0 <= attempt_limit <= 25:event['attempt_limit']=attempt_limit
        if reason in _REASONS:event['reason']=reason
        if outcome in _OUTCOMES:event['outcome']=outcome
        _record(event)
        xbmc.log('Strem4Kodi RECOVERY | {} | started={} | owned={} | slate={} | redirected={} | attempt={} | limit={} | reason={} | outcome={}'.format(
            stage, int(bool(started)), int(bool(owned)), int(bool(slate)), int(bool(redirected)),
            event.get('attempt_number','-'), event.get('attempt_limit','-'),
            event.get('reason','-'), event.get('outcome','-')), xbmc.LOGINFO)
    except Exception:
        pass
