"""Two deliberate Left presses at the same browse edge open the sidebar."""

def activate(previous,focus,position,edge,now):
    return bool(edge and isinstance(previous,tuple) and len(previous)==3
                and previous[:2]==(focus,position) and 0 < now-previous[2] <= 1.2)
