"""Durable account-bound progress updates with retry and pre-write snapshots."""
from datetime import datetime, timezone
import hashlib
import threading
import time
import uuid
import re
from account import Store

_lock=threading.RLock()
_worker=None
_next=0

def failure_label(error):
    message=str(error)
    match=re.fullmatch(r'Stremio service returned HTTP (\d{3})\. Please retry shortly\.',message)
    if match:return 'Stremio HTTP '+match.group(1)
    return {
        'Could not reach the Stremio service. Check your connection and retry.':'Stremio unreachable - retrying',
        'Stremio returned an unexpected response. Please retry shortly.':'Unexpected Stremio response - retrying',
        'Unable to read the Stremio library. Existing local data was kept.':'Unable to read Stremio library - retrying',
        'Stremio rejected the watch-progress update.':'Stremio rejected progress - retrying',
        'Stremio did not confirm the watch-progress update.':'Awaiting Stremio confirmation - retrying',
        'Account changed during sync.':'Account changed - waiting for retry',
    }.get(message,'Progress upload failed - retrying')

def owner(token):return hashlib.sha256(str(token).encode()).hexdigest()

def enqueue(store,pending):
    if (pending.get('context') or {}).get('kind') not in ('movie','series'):return False
    token=store.load().get('token')
    if not token:return False
    queue=Store(store.directory/'progress-outbox')
    with _lock:
        data=queue.load();rows=data.get('rows') or []
        row=dict(pending,owner=owner(token),captured_at=datetime.now(timezone.utc).isoformat(timespec='milliseconds'),event_id=uuid.uuid4().hex)
        prior=next((r for r in reversed(rows) if row.get('session') and r.get('owner')==row['owner'] and r.get('session')==row.get('session') and (r.get('context') or {}).get('kind') in ('movie','series') and not r.get('prepared') and not r.get('in_flight')),None)
        if prior:
            row['watched_ms']+=prior.get('watched_ms',0)
            row['credits_watched']=bool(row.get('credits_watched') or prior.get('credits_watched'))
            rows.remove(prior)
        rows.append(row);queue.save({'rows':rows})
    return True

def process_one(store,syncer=None):
    from core.playback_progress import sync_progress
    syncer=syncer or sync_progress
    token=store.load().get('token')
    if not token:return False
    queue=Store(store.directory/'progress-outbox')
    with _lock:
        rows=queue.load().get('rows') or []
        unsupported=[r for r in rows if r.get('owner')==owner(token) and (r.get('context') or {}).get('kind') not in ('movie','series')]
        if unsupported:
            archive=Store(store.directory/'progress-outbox-unsupported')
            archive.save({'rows':(archive.load().get('rows') or [])+unsupported})
            rows=[r for r in rows if r not in unsupported]
            queue.save({'rows':rows})
        pending=next((r for r in rows if r.get('owner')==owner(token)),None)
        if pending is None:return False
        pending['in_flight']=True
        queue.save({'rows':rows})
        pending=dict(pending)
    def prepare(item):
        with _lock:
            rows=queue.load().get('rows') or []
            for r in rows:
                if r['event_id']==pending['event_id']:r['prepared']=item
            queue.save({'rows':rows})
    credits_args = {'credits_watched': True} if pending.get('credits_watched') else {}
    remote=syncer(store,pending['context'],pending['position_ms'],pending['duration_ms'],pending['watched_ms'],
        ended=pending['ended'],checkpoint=pending.get('checkpoint',False),captured_at=pending['captured_at'],
        prepared_item=pending.get('prepared'),prepare_func=prepare,expected_owner=pending['owner'],**credits_args)
    if remote is None:return False
    with _lock:
        rows=queue.load().get('rows') or []
        queue.save({'rows':[r for r in rows if r['event_id']!=pending['event_id']]})
    Store(store.directory/'sync-status').save({'updated':time.time()})
    Store(store.directory/'progress-sync-status').save({'updated':time.time()})
    from lib.playback_refresh import refresh_continue_index
    from lib.progress_signal import publish
    refresh_continue_index(store,pending['context'],remote)
    publish(pending['context'])
    return True

def summary(profile,token):
    if not token:return 'Connect Stremio first'
    try:
        rows=Store(profile/'progress-outbox').load().get('rows') or []
        count=sum(r.get('owner')==owner(token) for r in rows)
        if count:return '{} progress uploads pending'.format(count)
        stamp=Store(profile/'sync-status').load().get('updated')
        return 'Synced '+time.strftime('%H:%M',time.localtime(stamp)) if stamp else 'Ready'
    except Exception:return 'Sync status unavailable'

def tick(store):
    global _worker,_next
    if time.monotonic()<_next:return
    with _lock:
        if _worker is not None and _worker.is_alive():return
        _next=time.monotonic()+5
        def run():
            global _next
            try:
                while process_one(store):pass
            except Exception as error:
                Store(store.directory/'progress-sync-status').save({'error':failure_label(error),'attempt':time.time()})
                _next=time.monotonic()+60
        _worker=threading.Thread(target=run,daemon=True)
        try:_worker.start()
        except RuntimeError:
            _worker=None
            _next=time.monotonic()+5

def retry_now():
    global _next
    _next=0
