"""One rewind per genuine pause, applied outside Kodi's resume callback."""
import time

PAUSE_SECONDS = (5, 10, 15, 30, 60, 120, 300)
REWIND_SECONDS = (3, 5, 7, 10, 12, 15, 20, 30)

def choice(addon, key, values, default):
    try:
        index = int(addon.getSetting(key))
        return values[index] if 0 <= index < len(values) else default
    except (TypeError, ValueError):
        return default

class UnpauseRewind:
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.reset()

    def reset(self):
        self.paused = None
        self.pending = None

    def pause(self, session, filename, position):
        if not session or not filename:
            self.reset()
            return
        # Repeated callbacks must not restart the pause timer.
        if self.paused is None:
            self.pending = None
            self.paused = (session, filename, max(0, position), self.clock())

    def resume(self, addon, session, filename, position):
        paused = self.paused
        self.reset()
        if not paused or addon.getSetting('unpause_rewind_enabled') != 'true':
            return
        if paused[:2] != (session, filename):
            return
        if self.clock() - paused[3] < choice(addon, 'unpause_rewind_pause', PAUSE_SECONDS, 30):
            return
        if abs(position - paused[2]) > 2:
            return  # Honour a manual seek made while paused.
        rewind = choice(addon, 'unpause_rewind_seconds', REWIND_SECONDS, 10)
        self.pending = (session, filename, max(0, position - rewind), self.clock())

    def apply(self, player, addon, session, filename):
        pending = self.pending
        self.pending = None  # One attempt only, including unseekable streams.
        if not pending or addon.getSetting('unpause_rewind_enabled') != 'true':
            return False
        if pending[:2] != (session, filename) or self.clock() - pending[3] > 3:
            return False
        try:
            if not player.isPlayingVideo() or player.getPlayingFile() != filename:
                return False
            player.seekTime(pending[2])
            return True
        except Exception:
            return False
