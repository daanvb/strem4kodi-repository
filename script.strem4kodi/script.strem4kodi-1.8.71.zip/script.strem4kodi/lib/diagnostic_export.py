"""Bounded diagnostic summaries uploaded only to the private sync repository."""
import base64
import hashlib
import json
import re
import threading
import time
import uuid
from pathlib import Path

_LOCK = threading.Lock()
PATTERNS = {
    'errors': r'\bERROR\b', 'fatal': r'\bFATAL\b',
    'python_tracebacks': r'Traceback \(most recent call last\)',
    'stream_failure': r'error opening|failed to open|error loading stream|couldn.t start this stream',
    'no_matching_file': r'no matching file', 'torrent_pending': r'torrent.*download',
    'disc_failure': r'VIDEO_TS|UDF.*fail', 'native_crash': r'SIGSEGV|segmentation fault|fatal signal',
}

def log_summary(path):
    """Classify a bounded tail. Never export raw lines, paths or messages."""
    try:
        with Path(path).open('rb') as stream:
            stream.seek(0, 2)
            size = stream.tell()
            stream.seek(max(0, size - 256 * 1024))
            text = stream.read(256 * 1024).decode('utf-8', 'replace')
        return {'available': True, 'tail_only': size > 256 * 1024,
                'counts': {key: len(re.findall(pattern, text, re.I)) for key, pattern in PATTERNS.items()}}
    except OSError:
        return {'available': False}

def record_search(profile, query, counts, failed=False):
    try:
        from account import Store
        with _LOCK:
            store = Store(Path(profile) / 'diagnostic-search')
            rows = store.load().get('events', [])
            # No search text or deterministic query hash: avoid reconstructing viewing interests.
            rows.append({'time': int(time.time()), 'query_length': min(len(str(query)), 200),
                         'failed': bool(failed), 'results': {k: min(max(int(v), 0), 10000)
                         for k, v in counts.items() if k in ('titles', 'collections', 'lists', 'catalogues')}})
            store.save({'events': rows[-30:]})
    except Exception:
        pass

def record_source(profile, identity, row):
    try:
        from account import Store
        target = str(identity)
        target = target if re.fullmatch(r'tt[0-9]+(?::[0-9]+:[0-9]+)?', target) else 'unknown'
        hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
        data = row.get('streamData') if isinstance(row.get('streamData'), dict) else {}
        evidence = ' '.join(str(v) for v in (row.get('filename'), hints.get('filename'), data.get('filename'), row.get('description')) if v)
        episode_tags = sorted(set(re.findall(r'\bS[0-9]{1,3}E[0-9]{1,3}\b', evidence, re.I)))[:10]
        event = {'time': int(time.time()), 'requested_id': target,
                 'episode_tags': [v.upper() for v in episode_tags],
                 'fields_present': sorted(k for k in row if k in ('behaviorHints','streamData','filename','description','season','episode')),
                 'formats': [label for label, pattern in (('Atmos', r'\batmos\b'), ('TrueHD', r'\btrue[ .-]?hd\b'),
                    ('DTS', r'\bdts\b'), ('Dolby Vision', r'\bdolby vision\b'), ('HDR', r'\bhdr\b')) if re.search(pattern, evidence, re.I)]}
        with _LOCK:
            store = Store(Path(profile) / 'diagnostic-source')
            events = store.load().get('events', [])
            store.save({'events': (events + [event])[-30:]})
    except Exception:
        pass

def build(profile, addon, log_directory):
    from account import Store
    from lib.provider_diagnostics import rows
    from lib.playback_timing import load as timing
    from lib.perf_report import load as performance
    from lib.error_report import _environment
    report = {'version': 1, 'environment': _environment(),
              'logs': {name: log_summary(Path(log_directory) / name) for name in ('kodi.log', 'kodi.old.log')},
              'search': Store(Path(profile) / 'diagnostic-search').load().get('events', [])[-30:]}
    # Only fixed numeric timing fields; attempt identifiers and arbitrary properties are excluded.
    report['playback_ms'] = {k: v for k, v in timing().get('stages', {}).items()
                            if k in ('selected','dispatch','resolver','metadata','subtitles','resolved','playing','cancelled')
                            and isinstance(v, int) and 0 <= v <= 1800000}
    from lib.perf_report import STAGES
    report['performance'] = {k: {'ms': v.get('ms')} for k, v in performance(profile).items()
                             if k in STAGES and isinstance(v, dict) and isinstance(v.get('ms'), (int, float))}
    report['requests'] = [{k: r[k] for k in ('resource','status','ms','timeout') if k in r} for r in rows(profile)]
    report['sources'] = Store(Path(profile) / 'diagnostic-source').load().get('events', [])[-30:]
    from lib.runtime_trace import load as runtime_events
    report['runtime'] = runtime_events(profile)
    try:
        from setup_profile import get_setting
        report['display'] = {k: get_setting(k) for k in ('videoplayer.adjustrefreshrate', 'videoplayer.usedisplayasclock')}
    except Exception:
        report['display'] = {}
    report['options'] = {key: addon.getSetting(key) == 'true' for key in
                         ('prerolls_enabled','up_next_enabled','ui_animations')}
    return report

def upload(token, report, identity, transport=None, still_current=lambda: True):
    from lib.credits_sync import request, SyncError
    transport = transport or request
    if transport(token).get('private') is not True:
        raise SyncError('Diagnostic export requires a private repository')
    if not isinstance(identity, str) or not re.fullmatch(r'[0-9a-f]{32}', identity):
        raise SyncError('Invalid diagnostic client identity')
    path = '/contents/diagnostics/' + identity + '.json'
    previous = transport(token, path)
    if not still_current():
        return False
    raw = json.dumps(report, sort_keys=True, separators=(',', ':')).encode()
    if len(raw) > 128 * 1024:
        raise SyncError('Diagnostic report exceeds the size limit')
    payload = {'message': 'Update private client diagnostic summary', 'content': base64.b64encode(raw).decode()}
    if previous:
        payload['sha'] = previous['sha']
    transport(token, path, payload)
    verified = transport(token, path)
    if not verified or base64.b64decode(verified.get('content', '')) != raw:
        raise SyncError('Diagnostic upload could not be verified')
    return True

class Reporter:
    def __init__(self, profile, addon, log_directory, idle=lambda: True):
        self.profile, self.addon, self.logs, self.idle = profile, addon, log_directory, idle
        self.next_check, self.busy = 0, False

    def tick(self):
        if self.busy or time.monotonic() < self.next_check:
            return
        self.next_check = time.monotonic() + 900
        if self.addon.getSetting('diagnostics_github_enabled') != 'true' or not self.idle():
            return
        token = self.addon.getSetting('credits_github_token').strip()
        if not token:
            return
        self.busy = True
        try:
            threading.Thread(target=self.run, args=(token,), daemon=True).start()
        except RuntimeError:
            self.busy = False

    def run(self, token):
        try:
            from account import Store
            store = Store(Path(self.profile) / 'diagnostic-export')
            state = store.load()
            identity = state.get('client')
            if not isinstance(identity, str) or not re.fullmatch(r'[0-9a-f]{32}', identity):
                identity = uuid.uuid4().hex
                state['client'] = identity
                store.save(state)
            report = build(self.profile, self.addon, self.logs)
            digest = hashlib.sha256(json.dumps(report, sort_keys=True).encode()).hexdigest()
            if state.get('digest') == digest:
                return
            # Recheck opt-out/token after collection and before network mutation.
            def still_current():
                return (self.addon.getSetting('diagnostics_github_enabled') == 'true'
                        and self.addon.getSetting('credits_github_token').strip() == token)
            if not still_current():
                return
            if not upload(token, report, identity, still_current=still_current):
                return
            state.update(digest=digest, uploaded=int(time.time()), status='Uploaded to private GitHub')
            store.save(state)
        except Exception:
            try:
                from account import Store
                store = Store(Path(self.profile) / 'diagnostic-export')
                state = store.load()
                state['status'] = 'Export will retry; check private GitHub token access'
                store.save(state)
            except Exception:
                pass
        finally:
            self.busy = False


def report_reference(profile):
    try:
        from account import Store
        data=Store(Path(profile)/'diagnostic-export').load()
        identity=data.get('client')
        if isinstance(identity,str) and re.fullmatch(r'[0-9a-f]{32}',identity):
            return 'Report: '+identity[:8]+(' (uploaded)' if data.get('uploaded') else ' (pending)')
    except Exception:pass
    return 'Diagnostics: Settings > Troubleshooting'
