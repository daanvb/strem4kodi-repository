"""Per-series track preferences; track indices never persist across episodes."""
import hashlib
import re
import time
from pathlib import Path
from account import Store


def series_key(context, file):
    identity = str(context.get('id') or '')
    if context.get('kind') != 'series' or context.get('url_hash') != hashlib.sha256(file.encode()).hexdigest():
        return None
    return identity.split(':')[0] if re.fullmatch(r'tt[0-9]+:[0-9]+:[0-9]+', identity) else None


def signature(track, subtitle=False):
    from subtitles import language
    code = language(track.get('language'))
    if not code or code in ('und','unk','none','off'):
        return None
    result = {'language': code}
    if subtitle:
        result.update(forced=bool(track.get('isforced') or re.search(r'\bforced\b', str(track.get('name') or ''), re.I)),
                      impaired=bool(track.get('isimpaired')))
    else:
        result['codec'] = str(track.get('codec') or '').lower()[:30]
    return result


def match(tracks, preference, subtitle=False):
    if not isinstance(preference, dict):return None
    candidates = [(track, signature(track, subtitle)) for track in tracks if isinstance(track, dict) and isinstance(track.get('index'), int)]
    candidates = [(track, value) for track, value in candidates if value and value['language'] == preference.get('language')]
    if subtitle:
        candidates = [(t,v) for t,v in candidates if v.get('forced') == preference.get('forced') and v.get('impaired') == preference.get('impaired')]
    exact = [t for t,v in candidates if v == preference]
    return (exact or [t for t,v in candidates] or [None])[0]


def manage(profile, player, rpc, picker):
    file = player.getPlayingFile()
    key = series_key(Store(Path(profile)/'playback').load(), file)
    if not key:return picker.ok('Series track preferences', 'Available during a Strem4Kodi episode.')
    choice = picker.select('Series track preferences', ['Remember current audio and subtitles', 'Forget saved preferences'], preselect=-1)
    if choice not in (0,1) or player.getPlayingFile()!=file:return
    store = Store(Path(profile)/'series-tracks')
    rows = store.load().get('series', {})
    if choice == 1:rows.pop(key,None)
    else:
        active = next((p for p in rpc('Player.GetActivePlayers') or [] if p.get('type')=='video'),None)
        if not active:return
        props = rpc('Player.GetProperties', {'playerid':active['playerid'], 'properties':['currentaudiostream','currentsubtitle','subtitleenabled']}) or {}
        if player.getPlayingFile()!=file:return
        rows[key] = {'audio': signature(props.get('currentaudiostream') or {}),
                     'subtitle': signature(props.get('currentsubtitle') or {},True) if props.get('subtitleenabled') else 'off',
                     'updated': int(time.time())}
    rows = dict(sorted(rows.items(),key=lambda pair:pair[1].get('updated',0))[-200:])
    store.save({'series':rows})
    picker.ok('Series track preferences', 'Preferences saved for this series.' if choice==0 else 'Saved preferences removed.')

class Watcher:
    def __init__(self,profile,player,home,rpc):
        self.profile,self.player,self.home,self.rpc=Path(profile),player,home,rpc
        self.file=None;self.session=None;self.started=0;self.done=set()
    def tick(self):
        try:
            file=self.player.getPlayingFile() if self.player.isPlayingVideo() else None
            if not file or file!=getattr(self.player,'_playing_file',None):return
            session=getattr(self.player,'_track_session',None)
            if self.file!=file or self.session!=session:
                self.file=file;self.session=session;self.started=time.monotonic();self.done=set()
            if time.monotonic()-self.started>30:return
            key=series_key(Store(self.profile/'playback').load(),file)
            if not key:return
            pref=Store(self.profile/'series-tracks').load().get('series',{}).get(key)
            if not pref:return
            active=next((p for p in self.rpc('Player.GetActivePlayers') or [] if p.get('type')=='video'),None)
            if not active:return
            props=self.rpc('Player.GetProperties', {'playerid':active['playerid'], 'properties':['audiostreams','subtitles']}) or {}
            digest=hashlib.sha256(file.encode()).hexdigest()
            for kind in ('audio','subtitle'):
                if kind in self.done:continue
                if self.home.getProperty('strem4kodi.'+('audio' if kind=='audio' else 'subtitles')+'.manual')==digest:
                    self.done.add(kind);continue
                value=pref.get(kind)
                track=match(props.get('audiostreams' if kind=='audio' else 'subtitles') or [],value,kind=='subtitle')
                if self.player.getPlayingFile()!=file:return
                if kind=='audio' and track:self.rpc('Player.SetAudioStream',{'playerid':active['playerid'],'stream':track['index']})
                elif kind=='subtitle' and value=='off':
                    # Off keeps the app's automatic forced-subtitle policy active.
                    self.rpc('Player.SetSubtitle',{'playerid':active['playerid'],'subtitle':'off'})
                elif kind=='subtitle' and track:
                    self.rpc('Player.SetSubtitle',{'playerid':active['playerid'],'subtitle':track['index'],'enable':True})
                    self.home.setProperty('strem4kodi.subtitles.manual',digest)
                else:continue
                self.done.add(kind)
        except Exception:pass
