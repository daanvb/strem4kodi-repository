"""Expose Kodi's real buffering controls without changing device defaults."""
import math


def cache_status(value):
    try:
        level = float(value)
        if math.isfinite(level) and 0 <= level <= 100:
            return 'Playback cache: {:g}% reported by Kodi.'.format(level)
    except (TypeError, ValueError):
        pass
    return 'Playback cache: not reported by Kodi.'


def open_settings(dialog, kodi, owner=None):
    message = ('Kodi 21 or newer: Services > Caching. Set the settings level '
               'to Advanced to choose buffering mode and memory size. '
               'These settings apply to all Kodi playback on this device. '
               'Some streams manage their own buffer.')
    if kodi.getCondVisibility('Player.HasVideo'):
        message = cache_status(kodi.getInfoLabel('Player.CacheLevel')) + '\n\n' + message
    dialog.ok('Stream buffering', message)
    if owner is not None:
        owner.close()
    kodi.executebuiltin('ActivateWindow(servicesettings,filecache)')
