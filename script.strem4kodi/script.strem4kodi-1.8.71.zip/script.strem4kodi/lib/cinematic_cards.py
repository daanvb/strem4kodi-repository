"""Clean, consistent poster cards with a quiet frame and clear remote focus."""
import xml.etree.ElementTree as ET

BASE = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/cinematic/'
ACTION_CARD = '[String.IsEqual(ListItem.Property(id),discover:load-more) | String.IsEqual(ListItem.Property(id),discover:more)]'


def control(parent, kind, **values):
    node = ET.SubElement(parent, 'control', type=kind)
    for key, value in values.items():ET.SubElement(node, key).text = str(value)
    return node


def posters(listing, compact=False):
    for tag in ('itemlayout', 'focusedlayout'):
        layout = listing.find(tag)
        if layout is None:continue
        for child in list(layout):layout.remove(child)
        focused = tag == 'focusedlayout'
        control(layout, 'image', left=12, top=12, width=206, height=309,
                texture=BASE+'poster-mask.png', colordiffuse='FF181B20')
        for art, visible in (('poster','!String.IsEmpty(ListItem.Art(poster))'),
                             ('thumb','String.IsEmpty(ListItem.Art(poster))')):
            image = control(layout, 'image', left=12, top=12, width=206, height=309,
                    texture='$INFO[ListItem.Art(%s)]' % art, aspectratio='scale',
                    visible='[' + visible + '] + !' + ACTION_CARD)
            image.find('texture').set('diffuse', BASE+'poster-mask.png')
        # Local covers use native text, keeping names sharp at every TV size.
        list_cover='String.IsEqual(ListItem.Property(list_cover),true)'
        control(layout,'label',left=28,top=35,width=174,height=28,
                label='$INFO[ListItem.Property(list_kind)]',font='font20',
                textcolor='FFC8C4DF',align='center',visible=list_cover)
        control(layout,'textbox',left=28,top=202,width=174,height=92,
                label='$INFO[ListItem.Property(list_title)]',font='font23_title',
                textcolor='FFFFFFFF',align='center',visible=list_cover)
        focus = 'Control.HasFocus({})'.format(listing.get('id'))
        control(layout, 'image', left=12, top=12, width=206, height=309,
                texture=BASE+'poster-outline.png')
        if focused:
            control(layout, 'image', left=12, top=12, width=206, height=309,
                    texture=BASE+'poster-focus.png', visible=focus)
        # Paging actions use the frame, never a missing-film/video placeholder.
        control(layout, 'label', left=24, top=65, width=182, height=80,
                label='+', font='font60', textcolor='FFB5A4E8', align='center',
                visible=ACTION_CARD)
        control(layout, 'textbox', left=24, top=160, width=182, height=78,
                label='$INFO[ListItem.Label]', font='font23_title', textcolor='FFFFFFFF',
                align='center', aligny='center', visible=ACTION_CARD)
        control(layout, 'label', left=24, top=260, width=182, height=32,
                label='Press OK', font='font23', textcolor='FFADACB5', align='center',
                visible=ACTION_CARD)
        from lib.poster_progress import append as append_progress
        append_progress(layout, 19, 310, 192)
        control(layout, 'label', left=171, top=20, width=38, height=30,
                label='✓', font='font23', textcolor='FFFFFFFF', align='center',
                visible='String.IsEqual(ListItem.Property(watched),true)')
        control(layout, 'label', left=16, top=333, width=198, height=32,
                label='$INFO[ListItem.Label]', font='font23_title' if focused else 'font23',
                textcolor='FFFFFFFF' if focused else 'FFBFC4CE', scroll='true' if focused else 'false')
        control(layout, 'label', left=16, top=366, width=198, height=24,
                label='$INFO[ListItem.Property(UnwatchedEpisodes),, episodes left]',
                font='font20', textcolor='FF929AA6', visible='String.IsEmpty(ListItem.Property(release_label))')
        control(layout, 'label', left=16, top=366, width=198, height=24,
                label='$INFO[ListItem.Property(release_label)]', font='font20', textcolor='FFD3C4F6',
                visible='!String.IsEmpty(ListItem.Property(release_label))', scroll='true' if focused else 'false')

    if compact:
        for tag in ('itemlayout', 'focusedlayout'):
            layout = listing.find(tag)
            layout.set('height', '346')
            for node in list(layout):
                if node.findtext('top') == '366':
                    layout.remove(node)
                    continue
                for prop in ('left','top','width','height'):
                    child = node.find(prop)
                    if child is not None:child.text = str(round(float(child.text) * .94))
    # These pages already name the selected title in the hero. Their short
    # viewport shows poster artwork (including its genre), not extra captions.
    for layout in listing:
        if layout.tag not in ('itemlayout', 'focusedlayout'):
            continue
        for node in layout.findall('control'):
            if node.get('type') != 'label' or float(node.findtext('top', '0')) < 320:
                continue
            visible = node.find('visible')
            if visible is None:
                ET.SubElement(node, 'visible').text = '!String.IsEqual(Window.Property(page),Discover) + !String.IsEqual(Window.Property(page),Home) + !String.IsEqual(Window.Property(page),Library)'
            else:
                visible.text = '[' + visible.text + '] + !String.IsEqual(Window.Property(page),Discover) + !String.IsEqual(Window.Property(page),Home) + !String.IsEqual(Window.Property(page),Library)'
