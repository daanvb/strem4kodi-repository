"""Serialize mutations of a Home window's rows and Kodi controls."""
from functools import wraps


def serialized_rows(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        with self._row_update_lock:
            return method(self, *args, **kwargs)
    return guarded
