"""Public MDBList search and paged browsing using the existing device API key."""
import hashlib
import json
import re
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from lib.cache_policy import open_cache, read_policy
from search_match import normalized, relevance


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('Redirected MDBList response')


def get_addon():
    from addon_state import get_addon as configured_addon
    return configured_addon()


def request(key, path, **params):
    url = 'https://api.mdblist.com/' + path + '?' + urlencode(dict(apikey=key, **params))
    try:
        with build_opener(NoRedirect()).open(Request(url, headers={'Accept': 'application/json', 'User-Agent': 'Strem4Kodi'}), timeout=5) as response:
            if urlsplit(response.geturl()).hostname != 'api.mdblist.com':
                raise ValueError('Invalid response host')
            raw = response.read(2*1024*1024+1)
            if len(raw) > 2*1024*1024: raise ValueError('Response too large')
            data = json.loads(raw)
            if not isinstance(data, (dict, list)) or isinstance(data, dict) and data.get('error'):
                raise ValueError('Invalid response')
            more = response.headers.get('X-Has-More', '').lower()
            return data, more == 'true' if more in ('true', 'false') else None
    except Exception:
        # API-key-bearing URLs must never reach notifications or logs.
        raise ValueError('MDBList is unavailable. Check your API key or try again later.') from None


def cached(operation, group, loader):
    key = get_addon().getSetting('mdblist_api_key').strip()
    if not key: raise ValueError('Add your MDBList API key in Settings → API keys to browse public lists.')
    policy = read_policy()
    identity = 'mdblist-lists-v1:'+hashlib.sha256(key.encode()).hexdigest()+':'+operation
    cache = None
    try:
        cache = open_cache(group, policy)
        value = cache.get(identity) if cache else None
    except Exception: value = None
    if value is not None: return value
    value = loader(key)
    if cache:
        try: cache.put(identity, value, policy[group])
        except Exception: pass
    return value


def search(query, limit=12):
    from lib.genre_search import genre
    term = normalized(genre(query) or query)[:200]
    if len(term) < 2: return []
    def load(key):
        data, _ = request(key, 'lists/search', query=term)
        if not isinstance(data, list): raise ValueError('MDBList search is unavailable.')
        ranked, seen = [], set()
        for row in data:
            if not isinstance(row, dict) or row.get('private') or row.get('adult'): continue
            identity = str(row.get('id') or '')
            label = str(row.get('name') or '').strip()[:200]
            score = relevance(term, label)
            if not re.fullmatch(r'[1-9][0-9]{0,11}', identity) or score is None or identity in seen: continue
            seen.add(identity)
            kind = {'movie':'movie', 'show':'series'}.get(row.get('mediatype'), 'all')
            author = str(row.get('user_name') or '')[:100]
            description = str(row.get('description') or '')[:1400]
            spec = dict(id='mdblist:'+identity, _mdblist=identity, _search_collection=True,
                        kind=kind, label=label, addon='MDBList'+(' · '+author if author else ''),
                        url='', extras=[{'name':'skip'}], defaults={})
            card = dict(id='mdblist:'+identity, type='collection', name=label, poster='',
                        genres=['Public list'], description='Public MDBList list'+(' by '+author if author else '')+'. '+description,
                        _catalogue=spec)
            ranked.append((score, len(ranked), card))
        return [r for _, _, r in sorted(ranked, key=lambda r:r[:2])][:12]
    try: return cached('search:'+term, 'search', load)[:limit]
    except Exception: return []


def media(row):
    if not isinstance(row, dict) or row.get('adult'): return None
    kind = {'movie':'movie', 'show':'series', 'series':'series'}.get(row.get('mediatype') or row.get('type'))
    ids = row.get('ids') if isinstance(row.get('ids'), dict) else {}
    imdb = str(row.get('imdb_id') or ids.get('imdb') or '')
    title = str(row.get('title') or row.get('name') or '').strip()
    if not kind or not title or not re.fullmatch(r'tt[0-9]+', imdb): return None
    poster = row.get('poster') or ''
    try:
        if not isinstance(poster, str) or urlsplit(poster).scheme not in ('https', 'http'): poster = ''
    except ValueError: poster = ''
    return dict(id=imdb, type=kind, name=title[:200], poster=poster,
                description=str(row.get('description') or '')[:1600],
                year=str(row.get('release_year') or ''), genres=row.get('genres') if isinstance(row.get('genres'), list) else [])


def items(catalog, extras=None):
    identity = str(catalog.get('_mdblist') or '')
    if not re.fullmatch(r'[1-9][0-9]{0,11}', identity): raise ValueError('Invalid MDBList identity')
    offset = max(0, int((extras or {}).get('skip') or 0))
    def load(key):
        data, more = request(key, 'lists/'+identity+'/items', limit=100, offset=offset,
                             unified='true', sort='rank', order='asc', append_to_response='genres,poster,description')
        if isinstance(data, dict):
            if not isinstance(data.get('movies'), list) or not isinstance(data.get('shows'), list):
                raise ValueError('MDBList items are unavailable.')
            data = [dict(r, mediatype=r.get('mediatype') or kind) for group, kind in (('movies','movie'),('shows','show'))
                    for r in data[group] if isinstance(r, dict)]
            data.sort(key=lambda r: r.get('rank') if type(r.get('rank')) is int else 1000000)
        if not isinstance(data, list): raise ValueError('MDBList items are unavailable.')
        result = [converted for row in data[:100] for converted in [media(row)] if converted]
        return dict(items=result, count=min(100, len(data)), more=more)
    page = cached('items:'+identity+':'+str(offset), 'catalog', load)
    catalog['_page_count'] = page['count']
    catalog['_has_more'] = page['more']
    return page['items']
