"""Bundled list covers: immediate, deterministic and independent of providers."""

BASE='special://home/addons/script.strem4kodi/resources/skins/Main/media/lists/'


def details(row):
    catalog=row.get('_catalogue') or {}
    if not catalog or row.get('type')!='collection':return None
    title=str(row.get('name') or catalog.get('label') or 'Browse titles')
    kind=('COLLECTION' if catalog.get('_tmdb_collection') else
          'GENRE' if catalog.get('_genre') else 'PUBLIC LIST' if catalog.get('_mdblist') else 'CATALOGUE')
    return {'poster':BASE+'curated.png','title':title,'kind':kind}
