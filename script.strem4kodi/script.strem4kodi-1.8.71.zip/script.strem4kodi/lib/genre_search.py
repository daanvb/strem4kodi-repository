"""Genre browse cards alongside title and list search."""
from search_match import normalized

HOME = 'https://v3-cinemeta.strem.io/manifest.json'
GENRES = ('Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime',
          'Documentary', 'Drama', 'Family', 'Fantasy', 'History', 'Horror',
          'Music', 'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Sport', 'Thriller',
          'War', 'Western')
ALIASES = {'spooky': 'Horror', 'scary': 'Horror', 'science fiction': 'Sci-Fi',
           'sci fi': 'Sci-Fi', 'scifi': 'Sci-Fi', 'romantic': 'Romance',
           'documentaries': 'Documentary', 'animated': 'Animation'}


def genre(query):
    term = normalized(query)
    for suffix in (' movies', ' films', ' movie', ' film', ' lists', ' shows', ' series'):
        if term.endswith(suffix):
            term = term[:-len(suffix)].strip()
            break
    return ALIASES.get(term) or next((g for g in GENRES if normalized(g) == term), '')


def matches(query):
    name = genre(query)
    if not name: return []
    kind = 'series' if normalized(query).endswith((' shows', ' series')) else 'movie'
    label = name + (' series' if kind == 'series' else ' movies')
    spec = dict(id='top', kind=kind, label=label, addon='Cinemeta', url=HOME,
                extras=[{'name': 'skip'}], defaults={'genre': name},
                _genre=name, _search_collection=True)
    return [dict(id='genre:'+kind+':'+normalized(name), type='collection', name=label,
                 genres=['Genre'], poster='', _catalogue=spec,
                 description='Browse '+label.lower()+', ordered by popularity.')]
