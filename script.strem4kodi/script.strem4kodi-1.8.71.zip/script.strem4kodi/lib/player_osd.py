"""Idle control-bar cleanup limited to video started by Strem4Kodi."""
import time

# Preserve existing saved enum indices when adding choices.
DELAYS = (None, 5, 10, 15, 3, 7, 12)
HIDDEN = 'strem4kodi.player.idle_hidden'


class PlayerOSD:
    def __init__(self, player, addon, kodi=None, gui=None, clock=time.monotonic):
        if kodi is None:
            import xbmc as kodi
        if gui is None:
            import xbmcgui as gui
        self.player=player;self.addon=addon;self.kodi=kodi;self.gui=gui
        self.clock=clock;self.visible_since=None
        self.session=None

    def reset(self):
        self.visible_since=None
        self.gui.Window(10000).clearProperty(HIDDEN)

    def tick(self):
        try:
            index=int(self.addon.getSetting('playback_controls_hide') or '1')
            delay=DELAYS[index] if 0 <= index < len(DELAYS) else 5
            live_file=getattr(self.player, '_live_file', None)
            file=live_file if isinstance(live_file, str) and live_file else getattr(self.player,'_playing_file',None)
            if delay is None or not file or not self.player.isPlayingVideo() or self.player.getPlayingFile()!=file:
                self.session=None;self.reset();return
            if self.session != file:
                self.session=file;self.reset()
            top=self.gui.getCurrentWindowDialogId()
            # Seek feedback is modeless and may have no current modal dialog.
            # Never close or shift focus while any options/chapter menu is open.
            controls=(top == 12901 or (top in (-1, 0, 10115)
                       and self.kodi.getCondVisibility('Window.IsVisible(videoosd)')))
            feedback=(top in (-1, 0, 10115) and self.kodi.getCondVisibility('Window.IsVisible(seekbar)'))
            if not controls and not feedback:
                self.reset();return
            if self.kodi.getCondVisibility('Player.Paused | Player.Caching | Player.Forwarding | Player.Rewinding'):
                self.reset();return
            now=self.clock()
            idle=self.kodi.getGlobalIdleTime()
            if idle < delay:
                self.gui.Window(10000).clearProperty(HIDDEN)
            # Recent actual seeks extend the timer, rather than treating an
            # indefinitely retained Player.Seeking flag as fresh remote input.
            if self.kodi.getCondVisibility('Player.HasPerformedSeek(2)'):
                self.reset();return
            if self.visible_since is None:self.visible_since=now
            if now-self.visible_since>=delay and idle>=delay:
                if controls:
                    if self.gui.Window(12901).getFocusId() == 9007:
                        self.kodi.executebuiltin('SetFocus(9001)')
                    self.kodi.executebuiltin('Dialog.Close(videoosd)')
                # SeekBar can immediately reopen from retained ShowTime/ShowInfo
                # flags. Suppress only our feedback until input/state changes.
                self.gui.Window(10000).setProperty(HIDDEN, 'true')
                self.visible_since=None
        except Exception:
            self.visible_since=None
