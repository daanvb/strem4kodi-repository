"""Device-local preferences, saved separately from concurrent account sync."""
from pathlib import Path
from account import Store, AccountError


def _load(profile):
    try:
        return Store(Path(profile) / 'providers').load()
    except AccountError:
        return {}  # A damaged preference file must not prevent account playback.


def state(profile, account=None):
    account = Store(profile).load() if account is None else account
    config = _load(profile)
    return dict(account, providerPreferences=config.get('providerPreferences') or {},
                artworkRevision=config.get('artworkRevision', 0))


def choose(profile, role, value):
    from provider_roles import save_preference
    current = state(profile)
    save_preference(current, role, value)
    store = Store(Path(profile) / 'providers')
    config = _load(profile)
    config['providerPreferences'] = current['providerPreferences']
    store.save(config)


def refresh_artwork(profile):
    """Invalidate resolved posters without clearing catalogue/login/progress data."""
    store = Store(Path(profile) / 'providers')
    config = _load(profile)
    config['artworkRevision'] = int(config.get('artworkRevision') or 0) + 1
    store.save(config)
    return config['artworkRevision']


def hostname(provider):
    """Display only a transport hostname, excluding credentials and URL tokens."""
    from urllib.parse import urlsplit
    import re
    try:
        url=urlsplit(str(provider.get('transportUrl') or ''))
        host=url.hostname or ''
        if url.scheme not in ('http','https') or not re.fullmatch(r'[a-zA-Z0-9_.:-]{1,253}',host):
            return 'Host unavailable'
        return host.lower()
    except (ValueError,TypeError):
        return 'Host unavailable'
