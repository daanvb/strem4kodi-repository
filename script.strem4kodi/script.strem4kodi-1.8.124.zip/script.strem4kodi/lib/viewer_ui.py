"""Small viewer-management flow using the existing themed Kodi controls."""
from pathlib import Path
from account import Store,AccountError
from lib import viewer_profiles as profiles


def manage(root):
    import xbmc
    from lib.ui_dialogs import dialog
    ui=dialog()
    if not profiles.account_token(root):
        ui.ok('Viewer profiles','Connect your Stremio account first.')
        return False
    # Do not switch the data owner while the decoder or resolver is active.
    from lib.native_playback import busy
    if xbmc.Player().isPlaying() or busy():
        ui.ok('Viewer profiles','Stop playback and finish or cancel loading before changing profiles.')
        return False
    if not profiles.state(root):
        if not ui.yesno('Viewer profiles','Keep your current data as Main and enable separate viewers? With private saved-list sync enabled, viewer data also syncs between devices. Stremio login, providers and device settings stay shared.'):
            return False
        try:profiles.enable(root)
        except AccountError:
            ui.ok('Viewer profiles','Kodi could not save the profiles. Your existing data was kept.')
            return False
        changed=True
    else:changed=False
    while True:
        data=profiles.state(root);records=data['records'];active=data['active']
        live=sorted((key for key,row in records.items() if not row['deleted']),key=lambda k:records[k]['name'].casefold())
        labels=[records[key]['name']+(' (current)' if key==active else '') for key in live]+['Add profile']
        choice=ui.select('Viewer profiles',labels,preselect=live.index(active))
        if choice<0:return changed
        try:
            if choice==len(live):
                name=ui.input('New profile name')
                if name.strip():profiles.edit(root,'create',name=name)
                continue
            identity=live[choice]
            options=['Switch to this profile','Rename profile','Delete profile']
            from lib.viewer_sync import pending_conflicts,resolve_conflict
            from lib.credits_sync import SyncError
            conflicts=pending_conflicts(root,identity)
            if conflicts:options.append('Review {} sync conflicts'.format(len(conflicts)))
            action=ui.select(records[identity]['name'],options,preselect=-1)
            if action==0:
                # An unsent final checkpoint must remain with the old viewer.
                from lib.progress_outbox import _worker
                pending=Store(profiles.directory(root)/'progress-outbox').load().get('rows') or []
                if pending or _worker is not None and _worker.is_alive():
                    ui.ok('Saving progress','Your last playback update is still being saved. Please try again in a moment.')
                    continue
                profiles.edit(root,'switch',identity)
                return True
            if action==1:
                name=ui.input('Profile name',defaultt=records[identity]['name'])
                if name.strip():profiles.edit(root,'rename',identity,name)
            if action==2 and ui.yesno('Delete profile','Remove '+records[identity]['name']+' from all synced devices? Its local files are retained for recovery; other profiles are kept.'):
                profiles.edit(root,'delete',identity)
                if identity==active:return True
            if action==3 and conflicts:
                keys=sorted(conflicts)
                selected=ui.select('Progress conflicts',[(conflicts[key]['local'].get('name') or key)+' · '+key for key in keys])
                if selected<0:continue
                key=keys[selected];pair=conflicts[key]
                def description(row):
                    state=row.get('state') or {}
                    return '{} · {}s'.format(state.get('lastWatched') or 'Unknown date',
                                             round(float(state.get('timeOffset') or 0)/1000))
                decision=ui.select('Choose progress for '+(pair['local'].get('name') or key),
                    ['Keep this device: '+description(pair['local']),
                     'Use synced version: '+description(pair['remote'])])
                if decision in (0,1):
                    resolve_conflict(root,identity,key,'local' if decision==0 else 'remote')
                    changed=True
                    if identity==active:return True
        except (ValueError,RuntimeError,AccountError,SyncError) as error:
            ui.ok('Viewer profiles',str(error))
