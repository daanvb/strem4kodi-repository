"""Sports kickoffs, UK clock conversion and the user-selected live window."""
from datetime import datetime, timedelta, timezone
import base64
import json
import math
import re
from urllib.parse import unquote, urlsplit
from lib.title_text import plain

SPAN = 3 * 60 * 60
STEP = 30 * 60
PAGE_ROWS = 7
LIVE_WINDOW = 150 * 60
MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def uk_datetime(stamp):
    """UK civil time, including BST, without depending on host timezone/tzdata.

    Modern UK transitions are at 01:00 UTC on the last Sundays of March/October.
    This also works on Kodi's Python 3.8 builds without zoneinfo.
    """
    utc = datetime.fromtimestamp(stamp, timezone.utc)
    transitions = []
    for month in (3, 10):
        last = datetime(utc.year, month, 31, 1, tzinfo=timezone.utc)
        transitions.append(last - timedelta(days=(last.weekday() + 1) % 7))
    summer = transitions[0] <= utc < transitions[1]
    return utc.astimezone(timezone(timedelta(hours=int(summer)), 'BST' if summer else 'GMT'))


def provider_timezone(catalog):
    """Read only the timezone option; never retain decoded provider configuration."""
    zone = catalog.get('timezone') or (catalog.get('defaults') or {}).get('timezone')
    if zone:
        return str(zone)
    if str(catalog.get('addon') or '').casefold() != 'sports streams':
        return ''
    try:
        parts = urlsplit(catalog.get('url') or '').path.split('/')[:-1]
    except ValueError:
        return ''
    for part in reversed(parts):
        if not 4 <= len(part) <= 16384:
            continue
        try:
            data = json.loads(base64.urlsafe_b64decode(unquote(part) + '=' * (-len(unquote(part)) % 4)))
            if isinstance(data, dict) and isinstance(data.get('timezone'), str):
                return data['timezone'][:80]
        except (ValueError, UnicodeError):
            continue
    return ''


def release_start(value, zone=''):
    """Read Sports Streams' dated kickoff label; bare clock times are ambiguous."""
    match = re.fullmatch(r'(\d{1,2}) ([A-Za-z]{3}) (\d{4})\s*[·|,]\s*(\d{1,2}):(\d{2})(?:\s+(GMT|UTC|BST))?', plain(value))
    if not match:
        return None
    try:
        day, month, year, hour, minute, suffix = match.groups()
        date = datetime(int(year), MONTHS.index(month.title()) + 1, int(day), int(hour), int(minute))
        zone = (suffix or zone or 'Europe/London').strip()
        if zone.upper() in ('UTC', 'GMT', 'BST'):
            return date.replace(tzinfo=timezone(timedelta(hours=int(zone.upper() == 'BST')))).timestamp()
        if zone.casefold() in ('europe/london', 'uk'):
            # Test both offsets against the UK calendar. Reject nonexistent
            # spring-forward clock times, choosing the first autumn occurrence.
            base = date.replace(tzinfo=timezone.utc).timestamp()
            return next((stamp for stamp in (base - 3600, base)
                         if uk_datetime(stamp).replace(tzinfo=None) == date), None)
        from zoneinfo import ZoneInfo
        return date.replace(tzinfo=ZoneInfo(zone)).timestamp()
    except (ValueError, OverflowError, OSError, ImportError, KeyError):
        return None


def timestamp(value):
    """Only accept a full timestamp with an explicit timezone (or Unix time)."""
    try:
        if isinstance(value, bool):
            return None
        if isinstance(value, (int, float)):
            stamp = float(value)
            if stamp > 100000000000:
                stamp /= 1000
            return stamp if math.isfinite(stamp) and 0 < stamp < 253402300800 else None
        if not isinstance(value, str) or 'T' not in value:
            return None
        date = datetime.fromisoformat(value.strip().replace('Z', '+00:00'))
        return date.timestamp() if date.tzinfo is not None else None
    except (ValueError, TypeError, OverflowError, OSError):
        return None


def first_time(row, fields):
    for field in fields:
        value = timestamp(row.get(field))
        if value is not None:
            return value
    return None


def entry(row):
    start = first_time(row, ('startTime', 'start_time', 'start', 'released'))
    if start is None:
        # Display labels already use the provider's UK wall clock. Its config
        # can say GMT even during BST; applying that option adds an hour twice.
        # Explicit offsets in structured timestamps/label suffixes still win.
        start = release_start(row.get('releaseInfo'))
    end = first_time(row, ('endTime', 'end_time', 'end'))
    if start is None or end is not None and end <= start:
        end = None
    release = plain(row.get('releaseInfo'))
    description = plain(row.get('description'))
    live = row.get('isLive') is True or bool(re.fullmatch(r'LIVE(?: NOW)?', release, re.I))
    live = live or any(line.strip().upper() == 'LIVE NOW' for line in description.splitlines())
    return dict(row=row, title=plain(row.get('name') or row.get('title')) or 'Sports stream',
                description=description, release=release, live=live, start=start, end=end)


def entries(rows):
    """Retain supplied ordering and identity, omitting catalogue paging actions."""
    return [entry(row) for row in rows if isinstance(row, dict) and row.get('id')
            and not row.get('_discover_load_more') and not row.get('_discover_more')]


def window_start(now):
    return math.floor(now / STEP) * STEP - STEP


def block(value, start, width=1500):
    """Clip a known interval or the explicitly requested 2.5-hour live window."""
    if value['start'] is None:
        return None
    left = max(start, value['start'])
    right = min(start + SPAN, effective_end(value))
    if right <= left:
        return None
    return (left - start) / SPAN * width, (right - left) / SPAN * width


def marker(value, start, width=1500):
    kickoff = value['start']
    if kickoff is None or not start <= kickoff <= start + SPAN:
        return None
    return min(width - 4, (kickoff - start) / SPAN * width)


def effective_end(value):
    if value['start'] is None:
        return None
    return value['end'] if value['end'] is not None else value['start'] + LIVE_WINDOW


def duration_label(value):
    end = effective_end(value)
    if end is None:
        return ''
    minutes = int((end - value['start']) / 60)
    return ('~' if value['end'] is None else '') + str(minutes) + ' min'


def status(value, now):
    if value['start'] is not None:
        if now < value['start']:
            return 'Upcoming'
        end = effective_end(value)
        if now < end or value['end'] is None and value['live']:
            return 'Live'
        return 'Ended'
    return 'Live' if value['live'] else value['release'] or 'Available'


def local_time(stamp, date=False):
    return uk_datetime(stamp).strftime('%a %d %b · %H:%M %Z' if date else '%H:%M')


def clock_label(value):
    if value['start'] is None:
        return 'Live stream' if value['live'] else value['release']
    times = local_time(value['start'])
    times += '–' + ('~' if value['end'] is None else '') + local_time(effective_end(value))
    return times


def caption(value, now):
    if value['start'] is None:
        return status(value, now)
    return clock_label(value) + ' · ' + duration_label(value) + ' · ' + status(value, now)
