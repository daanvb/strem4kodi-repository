"""Source-reported availability, never inferred from artwork or another episode."""
from core.stream_ui import stream_card

AUDIO_ORDER = ('Atmos', 'TrueHD', 'Dolby Digital Plus', 'Dolby Digital', 'DTS-HD MA', 'DTS')


def formats(rows, prepared=None):
    cards = [(prepared.card(row) if prepared is not None else stream_card(row)) for row in rows if isinstance(row, dict)
             and not row.get('_session_failed')]
    qualities = ('4K', '1080p', '720p', '480p', '360p')
    best = next((q for q in qualities if any(c.get('quality') == q for c in cards)), '')
    video = {tag for c in cards for tag in c.get('video_tags', [])}
    audio = {tag.split(' 2.')[0].split(' 5.')[0].split(' 7.')[0]
             for c in cards for tag in c.get('audio_tags', [])}
    formats = [best] if best else []
    if 'Dolby Vision' in video:
        formats.append('Dolby Vision')
    if 'HDR10+' in video:
        formats.append('HDR10+')
    elif 'HDR10' in video:
        formats.append('HDR10')
    elif 'HDR' in video:
        formats.append('HDR')
    sound = next((v for v in AUDIO_ORDER if v in audio), '')
    if sound:
        formats.append(sound)
    return formats


def merge_formats(*groups):
    """Rank cumulative availability without keeping source URLs in memory."""
    tags = {tag for group in groups for tag in group}
    result = [q for q in ('4K','1080p','720p','480p','360p') if q in tags][:1]
    if 'Dolby Vision' in tags:result.append('Dolby Vision')
    result += [v for v in ('HDR10+','HDR10','HDR') if v in tags][:1]
    result += [a for a in AUDIO_ORDER if a in tags][:1]
    return result


ASSETS = {'4K': 'ui/4k-compact', '1080p': 'ui/1080p-compact',
          '720p': 'ui/720p-compact', '480p': 'ui/480p-compact', '360p': 'ui/360p-compact',
          'Dolby Vision': 'ui/dolbyvision-v3', 'HDR10+': 'ui/hdr10plus-compact',
          'HDR10': 'ui/hdr10-compact', 'HDR': 'ui/hdr-compact',
          'Atmos': 'ui/atmos-v3', 'TrueHD': 'ui/truehd-v3',
          'DTS-HD MA': 'ui/dtshd_ma-readable', 'DTS': 'ui/dts-readable',
          'Dolby Digital Plus': 'ui/eac3-v3', 'Dolby Digital': 'ui/ac3-v3'}
ASSETS = {key: path + '-even-v1' for key, path in ASSETS.items()}
ASSETS['4K'] = 'ui/4k-compact-even-v2'
for tag, stem in (('Dolby Vision','dolbyvision'), ('Atmos','atmos'),
                  ('TrueHD','truehd'), ('Dolby Digital Plus','eac3'), ('Dolby Digital','ac3')):
    ASSETS[tag] = 'ui/' + stem + ('-compact-master-v3' if stem in ('atmos','eac3','ac3') else '-compact-master-v2')


# Preserve branded masters for rebuilding; ship prefiltered pixels for the
# current 64x28 GUI controls instead of relying on GPU minification.
HERO_MASTERS = dict(ASSETS)
ASSETS = {tag: path + '-1080-v1' for tag, path in HERO_MASTERS.items()}


def properties(found):
    paths = ['special://home/addons/script.strem4kodi/resources/skins/Main/media/formats/display/hero/' + ASSETS[v] + '.png'
             for v in found if v in ASSETS]
    values = {'available_format_' + str(i): paths[i] if i < len(paths) else '' for i in range(4)}
    values.update({'available_format_' + str(i) + '_tint': 'FFFFFFFF' for i in range(4)})
    return values


def apply(window, rows, prepared=None):
    for key, value in properties(formats(rows,prepared)).items():
        window.setProperty(key, value)


def catalogue_formats(meta):
    """Read explicit technical fields only, with no network or artwork guessing."""
    fields = ('quality', 'resolution', 'height', 'audio', 'audioCodec', 'hdr', 'bitDepth')
    values = {key: meta[key] for key in fields if key in meta}
    for key in ('availableFormats', 'videoFormats', 'audioFormats'):
        value = meta.get(key)
        if isinstance(value, (str, list, tuple)):
            values['label'] = values.get('label', '') + ' ' + (' '.join(str(v) for v in value) if isinstance(value, (list, tuple)) else value)
    return formats([values]) if values else []


FORMAT_GROUPS = (('4K', '1080p', '720p', '480p', '360p'),
                 ('Dolby Vision', 'HDR10+', 'HDR10', 'HDR'), AUDIO_ORDER)


def complete_formats(values):
    """Every displayed technical family is already known."""
    return all(any(tag in values for tag in group) for group in FORMAT_GROUPS)


def fill_gaps(primary, fallback):
    """Secondary title facts cannot upgrade an already known technical family."""
    result = list(primary)
    for group in FORMAT_GROUPS:
        if not any(tag in primary for tag in group):
            result.extend(tag for tag in fallback if tag in group)
    return merge_formats(result)


def display_formats(meta, api, identity=None):
    """Retained source facts lead; PostersPlus fills missing overview families."""
    try:
        found = primary_formats(meta, api, identity)
    except Exception:
        found = catalogue_formats(meta)
    # PostersPlus has title-level facts, never an exact episode/source probe.
    if meta.get('type') == 'series' and (meta.get('_focus_video_id') or identity):
        return found
    return fill_gaps(found, meta.get('_postersplus_quality') or [])


def primary_formats(meta, api, identity=None):
    """Show retained badges immediately; source URL freshness stays separate."""
    # Browsing a future/selected episode still presents the series overview.
    # Keep the original context for playback and on-demand source requests.
    overview = dict(meta)
    if meta.get('type') == 'series':
        overview.pop('_focus_video_id', None)
    summary = api.availability_summary(overview)
    if isinstance(summary, dict) and 'formats' in summary:
        if summary['formats'] or meta.get('type') != 'series':
            return summary['formats']
        # An empty episode lookup cannot erase explicit series-level metadata.
        return catalogue_formats(meta)
    if meta.get('type') == 'series' and not meta.get('_focus_video_id'):
        return catalogue_formats(meta)  # Explicit title metadata; never another episode's cache.
    return for_title(meta, api.stream_cache_state, identity) or catalogue_formats(meta)


def for_title(meta, cache_reader, identity=None):
    if meta.get('type') not in ('movie', 'series'):
        return []
    state = meta.get('state') if isinstance(meta.get('state'), dict) else {}
    target = identity or meta.get('_focus_video_id') or state.get('video_id')
    if meta.get('type') == 'movie':
        target = meta.get('id')
    # A series-level cache must never stand in for a particular episode.
    if not target or (meta.get('type') == 'series' and target == meta.get('id')):
        return []
    cached = cache_reader(meta, target)
    # Last-known technical badges remain useful after playable URLs expire.
    return formats(cached[0]) if cached else []
