"""S4K surfaces for the Sports guide; native EPG controls stay in place."""
import xml.etree.ElementTree as ET


def apply(tree, filename, profile):
    from lib.context_frost import PROPERTY, surface
    controls = tree.getroot().find('controls')
    if filename == 'script-stremio-guide-sidebar.xml':
        drawer = next(c for c in controls if c.find('.//control[@id="9000"]') is not None)
        panel = next(c for c in drawer.findall('control[@type="image"]') if c.findtext('top') == '100')
        slot = list(drawer).index(panel)
        drawer.remove(panel)
        drawer.insert(slot, surface((0, 100, 410, 880), profile, PROPERTY, 'true',
                                    'Sports frosted sidebar', radius=60))
        return True
    # A quiet full-page artwork wash gives the guide its own backdrop; panels
    # use the same artwork with stronger tint so times/markers remain legible.
    for slot, texture, color in ((2, '$INFO[Window.Property(context_frosted)]', 'FFFFFFFF'),
                                 (3, 'special://home/addons/script.strem4kodi/resources/branding/white.png', 'B8000000')):
        image = ET.Element('control', type='image')
        for name, value in (('left', '0'), ('top', '0'), ('width', '1920'), ('height', '1080')):
            ET.SubElement(image, name).text = value
        ET.SubElement(image, 'texture', background='true', colordiffuse=color).text = texture
        controls.insert(slot, image)
    for slot, bounds, label in ((4, (32, 20, 1856, 160), 'Sports frosted header'),
                                (5, (32, 184, 1856, 620), 'Sports frosted timeline'),
                                (6, (32, 808, 1856, 248), 'Sports frosted details')):
        controls.insert(slot, surface(bounds, profile, PROPERTY, 'true', label))
    return True
