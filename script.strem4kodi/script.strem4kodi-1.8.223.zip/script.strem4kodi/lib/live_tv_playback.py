"""Kodi 21 live playback entry; independent of movie/series progress."""
import re

from lib.live_tv_provider import CHANNELS, CHANNEL_IDS


def resolve(channel, handle, kodi, gui, plugin, addon_module):
    item = gui.ListItem()
    try:
        if channel not in CHANNEL_IDS:
            raise ValueError('Unknown channel')
        addon_module.Addon('inputstream.adaptive')
        window = gui.Window(10000)
        window.clearProperty('s4k.live.endpoint')
        window.setProperty('s4k.live.request', 'true')
        monitor = kodi.Monitor()
        endpoint = ''
        for _ in range(40):
            endpoint = window.getProperty('s4k.live.endpoint')
            if endpoint:
                break
            if monitor.waitForAbort(0.1):
                raise ValueError('Cancelled')
        if not re.fullmatch(r'http://127\.0\.0\.1:[0-9]{1,5}/[0-9a-f]{48}/', endpoint):
            raise ValueError('Live service unavailable')
        item.setPath(endpoint + channel + '.mpd')
        item.setLabel(dict(CHANNELS)[channel])
        item.setMimeType('application/dash+xml')
        item.setContentLookup(False)
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('IsPlayable', 'true')
        item.setProperty('StartOffset', '0')
        item.setProperty('script.trakt.exclude', '1')
        item.setProperty('s4k.live', 'true')
        plugin.setResolvedUrl(handle, True, item)
    except Exception:
        plugin.setResolvedUrl(handle, False, gui.ListItem())
        gui.Dialog().notification('Live TV', 'Live TV unavailable. Check InputStream Adaptive and retry.')


def show(kodi, gui, addon_module):
    """Small remote-friendly channel picker for the initial BBC adapter."""
    from lib.ui_dialogs import dialog
    selected = dialog().select('Live TV · BBC preview · HD/UHD only', [name for _, name in CHANNELS])
    if 0 <= selected < len(CHANNELS):
        kodi.executebuiltin('PlayMedia(plugin://script.strem4kodi/?action=play_live&channel='
                            + CHANNELS[selected][0] + ')')
