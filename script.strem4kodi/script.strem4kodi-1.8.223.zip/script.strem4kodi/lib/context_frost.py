"""Artwork frost for app-owned menus, without framebuffer capture or Pillow."""
import math
import os
from pathlib import Path
import struct
import tempfile
import xml.etree.ElementTree as ET
import zlib

from lib.background_artwork import frosted_sidebar

MENUS = frozenset((
    'script-stremio-sports-guide.xml', 'script-stremio-guide-sidebar.xml',
    'script-strem4kodi-loading.xml', 'script-strem4kodi-up-next.xml',
    'script-stremio-dialog-toast.xml', 'script-stremio-dialog-progress.xml',
    'script-stremio-dialog-progress-bg.xml', 'script-stremio-dialog-input.xml',
    'script-stremio-error-report.xml',
    'script-stremio-settings.xml',
    'script-stremio-media-actions.xml', 'script-stremio-select.xml',
    'script-stremio-dialog-select.xml', 'script-stremio-dialog-confirm.xml',
    'script-stremio-dialog-message.xml', 'script-stremio-dialog-text.xml',
    'script-strem4kodi-player-audio.xml', 'script-strem4kodi-player-media.xml',
    'script-strem4kodi-player-timeline.xml', 'script-strem4kodi-player-scrub.xml',
))
PROPERTY = 'context_frosted'
BOUND_WINDOWS = frozenset(('script-strem4kodi-loading.xml', 'script-strem4kodi-up-next.xml',
                          'script-stremio-dialog-toast.xml', 'script-stremio-dialog-progress.xml',
                          'script-stremio-dialog-progress-bg.xml'))


def prepare_bindings(tree, filename):
    """Modeless windows must address their own images, not the current window."""
    if filename not in BOUND_WINDOWS:
        return ()
    identities = []
    for layer in tree.findall(".//control[description='Context frost artwork']"):
        identity = 9880 + len(identities)
        layer.set('id', str(identity))
        layer.find('texture').text = ''
        identities.append(identity)
    return tuple(identities)


def bind(window, artwork=None):
    identities = getattr(window, '_frost_controls', ())
    if not isinstance(identities, (tuple, list)):
        return
    value = getattr(window, '_frost_artwork', '') if artwork is None else artwork
    for identity in identities:
        window.getControl(identity).setImage(value if isinstance(value, str) else '')


def current_artwork():
    """Capture the caller before the new dialog becomes Kodi's current window."""
    try:
        import xbmc
        import xbmcgui
        def artwork(window_id):
            if not window_id or window_id == 9999:
                return ''
            window = xbmcgui.Window(window_id)
            for key in (PROPERTY, 'fanart'):
                value = window.getProperty(key)
                if isinstance(value, str) and value:
                    return frosted_sidebar(value)
            return ''
        result = artwork(xbmcgui.getCurrentWindowDialogId())
        if result:
            return result
        if xbmc.getCondVisibility('Player.HasVideo'):
            value = xbmc.getInfoLabel('Player.Art(fanart)')
            if isinstance(value, str) and value:
                return frosted_sidebar(value)
        return artwork(xbmcgui.getCurrentWindowId())
    except (ImportError, AttributeError, RuntimeError):
        return ''


def media_bounds(count):
    height = min(14, max(1, count)) * 60 + 28
    return 640, max(190, 540 - height // 2), 640, height


def selector_bounds(count, left=50, top=600):
    height = 90 + min(7, max(1, count)) * 64
    return max(40, min(left, 1240)), max(40, min(top, 1040 - height)), 640, height


def _mask(profile, bounds, radius):
    """Cache a tiny compressed full-canvas mask; only corner math is per-row."""
    left, top, width, height = bounds
    directory = Path(profile) / 'context-frost'
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / ('mask-v1-{}-{}-{}-{}-{}.png'.format(*bounds, radius))
    if path.is_file():
        return str(path)
    radius = min(radius, width / 2, height / 2)
    rows = []
    empty = bytes(1920 * 4)
    white = b'\xff\xff\xff\xff'
    for y in range(1080):
        if not top <= y < top + height:
            rows.append(b'\0' + empty)
            continue
        dy = max(radius - (y - top + .5), radius - (top + height - y - .5), 0)
        inset = radius - math.sqrt(max(0, radius * radius - dy * dy)) if radius else 0
        start, end = max(0, left + inset), min(1920, left + width - inset)
        first, last = math.floor(start), math.ceil(end)
        row = bytearray(empty)
        row[first * 4:last * 4] = white * (last - first)
        if last > first:
            row[first * 4 + 3] = round(255 * min(1, first + 1 - start))
            row[(last - 1) * 4 + 3] = round(255 * min(1, end - last + 1))
        rows.append(b'\0' + row)
    def chunk(kind, data):
        return struct.pack('!I', len(data)) + kind + data + struct.pack('!I', zlib.crc32(kind + data) & 0xffffffff)
    png = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('!2I5B', 1920, 1080, 8, 6, 0, 0, 0))
           + chunk(b'IDAT', zlib.compress(b''.join(rows), 6)) + chunk(b'IEND', b''))
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=directory, suffix='.tmp', delete=False) as stream:
            temporary = stream.name
            stream.write(png)
        os.replace(temporary, path)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
    return str(path)


def apply(tree, filename, profile, arguments):
    """Replace only the menu surface; controls, focus and outside content stay."""
    if filename not in MENUS:
        return False
    if filename in ('script-stremio-sports-guide.xml', 'script-stremio-guide-sidebar.xml'):
        from lib.sports_style import apply as sports_style
        return sports_style(tree, filename, profile)
    if filename == 'script-strem4kodi-loading.xml':
        group = tree.find('.//control[@id="300"]')
        panels = group.findall('control[@type="image"]')
        panels[0].find('texture').set('colordiffuse', '30FFFFFF')
        result = _apply_panel(group, panels[1], filename, profile, arguments)
        trivia = tree.find('.//control[@id="310"]')
        panel = trivia.find('control[@id="314"]')
        bounds = tuple(int(panel.findtext(n)) for n in ('left', 'top', 'width', 'height'))
        trivia.insert(list(trivia).index(panel), surface(bounds, profile, PROPERTY, 'true', 'Loading trivia frost'))
        panel.find('texture').set('colordiffuse', '40181720')
        return result
    controls = tree.getroot().find('controls')
    if filename == 'script-stremio-settings.xml':
        panels = [c for c in controls.findall('control[@type="image"]')
                  if c.findtext('description') == 'Settings glass surface']
        results = [_apply_panel(controls, panel, filename, profile, arguments) for panel in panels]
        return bool(results) and all(results)
    panel = next((c for c in controls.findall('control[@type="image"]')
                  if c.findtext('description') == 'Frost surface' or any(part in c.findtext('texture', '') for part in
                         ('local-card-rounded.png', 'player/control-shade.png'))), None)
    if panel is None:
        return False
    return _apply_panel(controls, panel, filename, profile, arguments)


def surface(bounds, profile, artwork_property, visible, description, radius=24):
    """Build a page-owned frost surface using its live artwork property."""
    group = ET.Element('control', type='group')
    ET.SubElement(group, 'description').text = description
    ET.SubElement(group, 'visible').text = visible
    panel = ET.SubElement(group, 'control', type='image')
    for name, value in zip(('left', 'top', 'width', 'height'), bounds):
        ET.SubElement(panel, name).text = str(value)
    ET.SubElement(panel, 'texture', border=str(radius), colordiffuse='FF181720').text = (
        'special://home/addons/script.strem4kodi/resources/skins/Main/media/controls/local-card-rounded.png')
    _apply_panel(group, panel, '', profile, {}, artwork_property)
    return group


def _apply_panel(controls, panel, filename, profile, arguments, artwork_property=PROPERTY):
    bounds = tuple(int(panel.findtext(n)) for n in ('left', 'top', 'width', 'height'))
    if filename == 'script-stremio-media-actions.xml':
        bounds = media_bounds(len(arguments.get('options', [])))
    elif filename == 'script-stremio-select.xml':
        bounds = selector_bounds(len(arguments.get('options', [])), arguments.get('left', 50), arguments.get('top', 600))
    for name, value in zip(('left', 'top', 'width', 'height'), bounds):
        panel.find(name).text = str(value)
    texture = panel.find('texture')
    for color in list(panel.findall('colordiffuse')):
        panel.remove(color)
    texture.set('colordiffuse', 'FF181720')
    radius = int(texture.get('border', '0').split(',')[0])
    try:
        mask = _mask(profile, bounds, radius)
    except OSError:
        return False  # Keep a readable opaque surface if profile storage fails.
    for name, value in zip(('left', 'top', 'width', 'height'), (0, 0, 1920, 1080)):
        panel.find(name).text = str(value)
    texture.attrib.pop('border', None)
    texture.text = mask
    slot = list(controls).index(panel) + 1
    for art in (True, False):
        layer = ET.Element('control', type='image')
        ET.SubElement(layer, 'description').text = 'Context frost artwork' if art else 'Context frost tint'
        for name, value in zip(('left', 'top', 'width', 'height'), (0, 0, 1920, 1080)):
            ET.SubElement(layer, name).text = str(value)
        ET.SubElement(layer, 'aspectratio').text = 'stretch'
        node = ET.SubElement(layer, 'texture')
        if art:
            node.set('background', 'true')
            node.set('diffuse', mask)
            node.text = '$INFO[Window.Property({})]'.format(artwork_property)
        else:
            node.set('colordiffuse', 'A02B3038')
            node.text = mask
        controls.insert(slot, layer)
        slot += 1
    return True
