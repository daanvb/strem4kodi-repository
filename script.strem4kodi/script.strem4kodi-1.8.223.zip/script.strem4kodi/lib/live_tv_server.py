"""Loopback-only, capability-protected live manifest refresh service.

Only built-in channel IDs are accepted. No caller-controlled upstream URL,
registration endpoint, credentials, logs or on-disk stream cache is exposed.
"""
import secrets
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit

from lib.live_tv_manifest import filter_dash
from lib.live_tv_provider import CHANNEL_IDS, read_https, resolve_bbc


class LiveServer:
    def __init__(self, resolve=resolve_bbc, fetch=read_https, clock=time.monotonic):
        self.resolve, self.fetch, self.clock = resolve, fetch, clock
        self.token = secrets.token_hex(24)
        self.cache = {}
        self.closed = False
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                self.connection.settimeout(12)
                parts = urlsplit(self.path)
                prefix = '/' + owner.token + '/'
                if (parts.query or not parts.path.startswith(prefix)
                        or not parts.path.endswith('.mpd')):
                    self.send_error(404)
                    return
                channel = parts.path[len(prefix):-4]
                if channel not in CHANNEL_IDS or owner.closed:
                    self.send_error(404)
                    return
                try:
                    data = owner.manifest(channel)
                except Exception:
                    self.send_error(502, 'HD live stream unavailable')
                    return
                if owner.closed:
                    self.send_error(503)
                    return
                self.send_response(200)
                self.send_header('Content-Type', 'application/dash+xml')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                try:
                    self.wfile.write(data)
                except OSError:
                    pass  # A cancelled player request is normal.

        class Server(HTTPServer):
            def get_request(self):
                connection, address = super().get_request()
                connection.settimeout(12)
                return connection, address

        self.http = Server(('127.0.0.1', 0), Handler)
        self.http.timeout = 0.25
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    @property
    def base_url(self):
        return 'http://127.0.0.1:{}/{}/'.format(self.http.server_port, self.token)

    def _run(self):
        try:
            while not self.closed:
                self.http.handle_request()
        finally:
            self.http.server_close()

    def manifest(self, channel):
        if self.closed or channel not in CHANNEL_IDS:
            raise ValueError('Live session unavailable')
        cached = self.cache.get(channel)
        if not cached or self.clock() - cached[0] >= 300:
            cached = (self.clock(), self.resolve(channel))
            self.cache[channel] = cached
        try:
            data, final_url = self.fetch(cached[1])
            result = filter_dash(data, final_url)
        except Exception:
            self.cache.pop(channel, None)
            raise
        if self.closed:
            raise ValueError('Live session ended')
        return result

    def close(self):
        self.closed = True
        self.cache.clear()
        self.thread.join(timeout=0.5)


class LiveService:
    """Start on demand; the Kodi service owns the server lifetime."""
    def __init__(self, window, player=None, clock=time.monotonic):
        self.window = window
        self.server = None
        self.player = player
        self.clock = clock
        self.started = 0
        self.playing = False
        self.window.clearProperty('s4k.live.endpoint')

    def tick(self):
        if self.window.getProperty('s4k.live.request') != 'true':
            if self.server and self.player:
                try:
                    active = (self.player.isPlayingVideo() and
                              self.player.getPlayingFile().startswith(self.server.base_url))
                except Exception:
                    active = False
                if active:
                    self.playing = True
                elif self.playing or self.clock() - self.started > 60:
                    self.close()
            return
        self.window.clearProperty('s4k.live.request')
        if self.server:
            self.server.close()
        self.window.clearProperty('s4k.live.endpoint')
        self.server = LiveServer()
        self.started = self.clock()
        self.playing = False
        self.window.setProperty('s4k.live.endpoint', self.server.base_url)

    def close(self):
        self.window.clearProperty('s4k.live.endpoint')
        self.window.clearProperty('s4k.live.request')
        if self.server:
            self.server.close()
            self.server = None
