"""Native poster facts from loaded catalogues and local source observations only."""
from datetime import date
import re
from urllib.parse import urlsplit

from lib.catalogue_identity import aliases


def annotate(catalogs, context=()):
    """Recompute membership; retained row flags must not manufacture a chart."""
    catalogs = list(catalogs)
    try:
        context = list(context)
    except TypeError:
        context = []
    trending = set()
    for catalog in catalogs + context:
        label = str(catalog.get('label') or '')
        if re.search(r'\btrending\b', label, re.I) and not catalog.get('_genre'):
            for row in catalog.get('items', []):
                trending.update(aliases(row))
    annotated = []
    for catalog in catalogs:
        items = []
        for row in catalog.get('items', []):
            fresh = dict(row)
            fresh.pop('_poster_trending', None)
            if aliases(row) & trending:
                fresh['_poster_trending'] = True
            items.append(fresh)
        annotated.append(dict(catalog, items=items))
    return annotated


SETTINGS = (('Trending tags', 'ui_poster_trending_tags'),
            ('Quality tags', 'ui_poster_quality_tags'))


def properties(row, summary_reader=None, today=None, get_setting=None):
    values = {'poster_trend': '', 'poster_quality': ''}
    values.update({'poster_quality_' + str(i): '' for i in range(3)})
    if row.get('type') not in ('movie', 'series') or row.get('_catalogue'):
        return values
    try:
        host = (urlsplit(str(row.get('poster') or '')).hostname or '').lower()
    except ValueError:
        host = ''
    # These posters already have provider-controlled tags baked into their pixels.
    if host == 'btttr.cc' or host.endswith('.btttr.cc'):
        return values
    trending_enabled = not get_setting or get_setting('ui_poster_trending_tags') != 'false'
    quality_enabled = not get_setting or get_setting('ui_poster_quality_tags') != 'false'
    labels = ['Trending'] if row.get('_poster_trending') and trending_enabled else []
    released = str(row.get('released') or '')
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}(?:T.*)?', released):
        try:
            age = ((today or date.today()) - date.fromisoformat(released[:10])).days
            if 0 <= age <= 30 and trending_enabled:
                labels.append('New')
        except ValueError:
            pass
    values['poster_trend'] = ' · '.join(labels)
    from lib.available_formats import catalogue_formats
    found = catalogue_formats(row)
    if summary_reader:
        try:
            summary = summary_reader(row)
            # Local availability summaries are source observations. Shared disc
            # hints are intentionally excluded: they do not prove a usable source.
            if isinstance(summary, dict) and summary.get('origin', 'sources') == 'sources':
                found = list(summary.get('formats') or []) or found
        except Exception:
            pass
    values['poster_quality'] = ' · '.join(tag for tag in ('4K', 'Dolby Vision', 'Atmos') if tag in found and quality_enabled)
    for index, tag in enumerate(('4K', 'Dolby Vision', 'Atmos')):
        values['poster_quality_' + str(index)] = tag if tag in found and quality_enabled else ''
    return values


def append(layout):
    """Two quiet native ribbons, clear of the watched mark and progress bar."""
    import xml.etree.ElementTree as ET
    for field, top, width in (('poster_trend', 25, 145),):
        visible = '!String.IsEmpty(ListItem.Property(%s))' % field
        background = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=19, top=top, width=width, height=29,
                               texture='special://home/addons/script.strem4kodi/resources/branding/white.png',
                               colordiffuse='DD15171C', visible=visible).items():
            ET.SubElement(background, key).text = str(value)
        label = ET.SubElement(layout, 'control', type='label')
        for key, value in dict(left=24, top=top, width=width-10, height=29,
                               label='$INFO[ListItem.Property(%s)]' % field,
                               font='font18_title', textcolor='FFFFFFFF',
                               align='center', aligny='center', visible=visible).items():
            ET.SubElement(label, key).text = str(value)
    from lib.available_formats import ASSETS
    for index, (tag, left, width) in enumerate((('4K', 19, 35), ('Dolby Vision', 57, 92), ('Atmos', 152, 59))):
        visible = '!String.IsEmpty(ListItem.Property(poster_quality_%d))' % index
        image = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=left, top=273, width=width, height=29,
                               texture='special://home/addons/script.strem4kodi/resources/branding/white.png',
                               colordiffuse='DD15171C', visible=visible).items():
            ET.SubElement(image, key).text = str(value)
        image = ET.SubElement(layout, 'control', type='image')
        for key, value in dict(left=left+3, top=276, width=width-6, height=23,
                               texture='special://home/addons/script.strem4kodi/resources/skins/Main/media/formats/display/hero/'+ASSETS[tag]+'.png',
                               aspectratio='keep', visible=visible).items():
            ET.SubElement(image, key).text = str(value)
