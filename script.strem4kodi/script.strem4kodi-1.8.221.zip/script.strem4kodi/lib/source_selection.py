"""Bounded technical selection evidence; no names, media IDs, URLs or hashes."""
import math
import time
from pathlib import Path

PROVIDERS=('Any','AIOStreams','Usenet','Pengu','Other')
ENUMS={'provider':PROVIDERS,'video':('P7 / FEL reported','Dolby Vision','HDR10+','HDR10','HDR','SDR','Unknown'),
       'quality':('4K','1080p','720p','480p','360p','AUTO'),
       'release':('Remux','BluRay','WEB-DL','WEBRip','HDTV','Unknown'),
       'audio':('Atmos','TrueHD','DD+','DD','DTS','Other'),
       'excluded_reason':('blacklist-unavailable','blacklisted','reported-wrong-episode','unsupported-disc',
                          'episode-identity','quality-ceiling','picker-filter','failed-or-missing-link',
                          'episode-title','language','early-safety','preferred-provider','provider-health')}
PREFERENCES={'quality':('Any',)+ENUMS['quality'],'maximum':('Any','4K','1080p','720p'),
             'dynamic':('Any','FEL reported')+ENUMS['video'],'source_type':('Any',)+ENUMS['release']}


def load(profile):
    from account import Store
    try:value=Store(Path(profile)/'diagnostic-selection').load()
    except Exception:return {}
    result={}
    for name,allowed in (('priority',('quality','fast')),('preferred_provider',PROVIDERS),('phase',('complete','arrival'))):
        if value.get(name) in allowed:result[name]=value[name]
    for name,limit in (('mode',2),('time',2100000000),('returned',10000),('eligible',10000),('shortlisted',10000)):
        if type(value.get(name)) is int and 0<=value[name]<=limit:result[name]=value[name]
    prefs=value.get('preferences')
    result['preferences']={name:prefs[name] for name,allowed in PREFERENCES.items()
                           if prefs.get(name) in allowed} if isinstance(prefs,dict) else {}
    candidates=[]
    for row in value.get('candidates',[])[:13] if isinstance(value.get('candidates'),list) else []:
        if not isinstance(row,dict):continue
        clean={name:row[name] for name,allowed in ENUMS.items() if row.get(name) in allowed}
        for name in ('selected','eligible','shortlisted','healthy'):
            if type(row.get(name)) is bool:clean[name]=row[name]
        for name,limit in (('bitrate_bps',1e10),('size_bytes',1024**6)):
            number=row.get(name)
            if type(number) in (int,float) and 0<=number<=limit and math.isfinite(number):clean[name]=number
        candidates.append(clean)
    result['candidates']=candidates
    return result


def record(profile,mode,prefs,rows,eligible,shortlist,selected,complete=True,exclusions=None):
    if not isinstance(profile,(str,Path)):return
    from account import Store
    from lib.autoplay_ranking import key,provider_group
    from lib.stream_presenter import line
    from lib.provider_health import penalized
    try:
        if not Path(profile).is_absolute() or not Path(profile).is_dir():return
        eligible_ids={id(row) for row in eligible};short_ids={id(row) for row in shortlist}
        candidates=([selected] if selected is not None else [])+[row for row in eligible if row is not selected][:8]
        candidates += [row for row in rows if id(row) not in eligible_ids][:4]
        safe=[];health={}
        for row in candidates[:13]:
            stages=key(row,prefs)
            label=line((row.get('card') or {}).get('provider') or row.get('provider') or 'Stream',70)
            if label not in health:health[label]=not penalized(row)
            item=dict(provider=provider_group(label) or 'Other',healthy=health[label],
                      selected=row is selected,eligible=id(row) in eligible_ids,shortlisted=id(row) in short_ids,
                      video=ENUMS['video'][stages[0][1]],quality=ENUMS['quality'][stages[1][1]],
                      release=ENUMS['release'][stages[2][1]],audio=ENUMS['audio'][stages[3]],
                      bitrate_bps=max(0,min(1e10,-stages[4])),size_bytes=max(0,min(1024**6,-stages[5])))
            if not item['eligible']:item['excluded_reason']=(exclusions or {}).get(id(row),'early-safety')
            elif not item['shortlisted']:item['excluded_reason']='preferred-provider' if item['healthy'] else 'provider-health'
            safe.append(item)
        Store(Path(profile)/'diagnostic-selection').save(dict(time=int(time.time()),mode=mode,
            priority=prefs['priority'],preferred_provider=prefs.get('provider') or 'Any',
            phase='complete' if complete else 'arrival',returned=min(len(rows),10000),
            eligible=min(len(eligible),10000),shortlisted=min(len(shortlist),10000),
            preferences={name:prefs[name] for name,allowed in PREFERENCES.items() if prefs.get(name) in allowed},candidates=safe))
    except Exception:pass  # Optional evidence cannot stop selection or Cancel.
