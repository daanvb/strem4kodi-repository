"""Per-device, per-content source selection; never bypass the quality ceiling."""
from lib.source_preferences import preferences, limit_quality
from lib.stream_presenter import stream_traits, presentation, filter_rows

PROFILES = ('movie', 'series', 'animation')
FIELDS = {'quality': ('Any', '4K', '1080p', '720p'),
          'dynamic': ('Any', 'Dolby Vision', 'HDR10', 'P7 / FEL reported'),
          'source_type': ('Any', 'Remux', 'BluRay', 'WEB-DL', 'WEBRip', 'HDTV')}



def profile(meta):
    genres = meta.get('genres') or []
    if isinstance(genres, str):genres = [genres]
    if meta.get('type') == 'series' and any(str(g).casefold() == 'animation' for g in genres):return 'animation'
    return 'series' if meta.get('type') == 'series' else 'movie'


def configured(addon, meta):
    scope = profile(meta)
    prefs = preferences(addon)
    # Technical ordering is fixed within the explicit preferred provider.
    prefs.update(sort='highest_bitrate', audio='Any')
    prefs['priority']='fast' if addon.getSetting('auto_'+scope+'_priority')=='1' else 'quality'
    for field, values in FIELDS.items():
        try:index = int(addon.getSetting('auto_' + scope + '_' + field) or '0') - 1
        except (ValueError, TypeError):index = -1
        if 0 <= index < len(values):prefs[field] = values[index]
    for field in ('language',):
        value = addon.getSetting('auto_' + scope + '_' + field)
        if value and value != '__inherit__':prefs[field] = '' if value == '__any__' else value
    try:mode = int(addon.getSetting('auto_' + scope + '_mode') or '0')
    except (ValueError, TypeError):mode = 0
    return mode if mode in (0, 1, 2) else 0, prefs


def matches(row, prefs):
    traits = stream_traits(row)
    from lib.autoplay_ranking import provider_group
    if prefs.get('provider') and provider_group(traits['provider']) != prefs['provider']:return False
    if prefs.get('quality') not in (None, 'Any') and traits['quality'] != prefs['quality']:return False
    from lib.autoplay_ranking import video_matches
    if prefs.get('dynamic') not in (None, 'Any') and not video_matches(traits,prefs['dynamic']):return False
    source_type=prefs.get('source_type')
    if source_type not in (None, '', 'Any') and source_type.casefold() not in {v.casefold() for v in traits.get('source_types',[])}:return False
    audio = presentation(row)['audio']
    if prefs.get('audio') not in (None, 'Any') and prefs['audio'].casefold() not in audio.casefold():return False
    language = prefs.get('language', '').casefold()
    if language and language != 'any':
        from lib.source_languages import matches_language
        if not matches_language(audio.partition(' | Language: ')[2],language):return False
    return True


def eligible_candidates(rows,prefs,meta,filters,identity,profile,exclusions=None):
    """Shared safety gates for speed, quality, arrivals and complete searches."""
    def retain(before,after,reason):
        if exclusions is not None:
            kept={id(row) for row in after}
            for row in before:
                if id(row) not in kept:exclusions[id(row)]=reason
        return after
    if profile:
        from lib.source_failures import blocked
        from lib.playback_recovery import digest
        failures=blocked(profile)
        if failures is None:return retain(rows,[],'blacklist-unavailable')
        rows=retain(rows,[row for row in rows if digest(row.get('url','')) not in failures],'blacklisted')
        from lib.wrong_episode import exclude_reported
        rows = retain(rows,exclude_reported(profile, meta.get('type'), identity, rows, meta.get('name', '')),'reported-wrong-episode')
    from lib.source_identity import eligible as matching_episode
    from source_probe import unsupported_disc
    rows=retain(rows,[r for r in rows if not unsupported_disc(r.get('url',''),r)],'unsupported-disc')
    rows=retain(rows,matching_episode(rows,meta,identity,require_match=True),'episode-identity')
    eligible=retain(rows,limit_quality(rows,prefs['maximum']),'quality-ceiling')
    eligible=retain(eligible,filter_rows(eligible,*filters),'picker-filter')
    eligible=retain(eligible,[r for r in eligible if r.get('url') and not r.get('_session_failed')],'failed-or-missing-link')
    from lib.source_identity import target, title_verified
    if target(meta, identity) is not None:
        titled = [r for r in eligible if title_verified(r, meta, identity)]
        if titled:
            eligible = retain(eligible,titled,'episode-title')
    if prefs.get('language') and prefs['language'].casefold()!='any':
        language_prefs={'language':prefs['language']}
        possible=[r for r in eligible if matches(r,language_prefs) or
                  presentation(r)['audio'].partition(' | Language: ')[2].strip().casefold()
                  in ('','unknown','und','unk','unreported','multi','multilingual')]
        if possible:eligible=retain(eligible,possible,'language')
    return eligible


def preferred_candidates(rows,prefs,mode=2,partial=False):
    """Apply explicit provider preference after episode/language/filter safety."""
    wanted=prefs.get('provider')
    if not wanted:return rows
    from lib.autoplay_ranking import provider_group
    from lib.provider_health import penalized
    healthy=[];preferred=[];health={}
    for row in rows:
        label=stream_traits(row)['provider']
        if label not in health:health[label]=mode!=2 or not penalized(row)
        if health[label]:
            healthy.append(row)
            if provider_group(label)==wanted:preferred.append(row)
    # Partial replies cannot prove the preferred provider has no usable result.
    return preferred if preferred or partial else healthy or rows


def select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None, identity=None, profile=None):
    mode, prefs = configured(addon, meta)
    if mode == 0:return mode, None, False
    exclusions={} if profile else None
    eligible=eligible_candidates(rows,prefs,meta,filters,identity,profile,exclusions)
    from lib.last_source import match, load, recent_success
    from lib.autoplay_ranking import rank, key
    from lib.provider_health import rank as health_rank, penalized
    all_eligible=list(eligible) if prefs['priority']=='fast' else rank(eligible,prefs)
    eligible=preferred_candidates(all_eligible,prefs,mode)
    ranked=list(eligible)
    if mode == 2:
        ranked = health_rank(ranked)
        if prefs['priority']!='fast':
            # Provider-wide failures must not lower the requested technical
            # quality of another eligible release. Stable sorting preserves
            # health order within a technical tie, ahead of provider preference.
            ranked = sorted(ranked,key=lambda row:key(row,prefs)[:-1])
    selected = (ranked or [None])[0]
    if prefs['priority']=='fast':
        if remembered is None and profile and eligible:
            remembered=load(profile,meta.get('type'),identity)
        if not recent_success(remembered):remembered=None
    previous = match(eligible, remembered)
    # Best quality reuses success only for a complete technical tie. Fastest
    # start may reuse any eligible, healthy release without a quality wait.
    if (selected is not None and previous is not None and
            (prefs['priority']=='fast' or key(previous,prefs)==key(selected,prefs)) and
            (mode != 2 or not penalized(previous))):
        selected = previous
    from lib.source_selection import record
    record(profile,mode,prefs,rows,all_eligible,eligible,selected,exclusions=exclusions)
    return mode, selected, bool(selected and prefs['priority']!='fast' and not matches(selected,prefs))


def early_select(rows, addon, meta, filters=('All', 'All', 'All'), remembered=None, identity=None, profile=None):
    """Fast priority may start early; quality priority needs the full search."""
    mode,prefs=configured(addon,meta)
    if mode!=2 or prefs['priority']!='fast':return None
    exclusions={} if profile else None
    eligible=eligible_candidates(rows,prefs,meta,filters,identity,profile,exclusions)
    from lib.source_identity import target,comparable_title,title_verified
    if target(meta,identity) is not None and comparable_title(meta,identity):
        # Do not take a number-only file while a verifiable title can arrive.
        eligible=[row for row in eligible if title_verified(row,meta,identity)]
    if prefs.get('language') and prefs['language'].casefold()!='any':
        # Unlike a completed search, a partial foreign-only batch is not
        # evidence that English/unknown alternatives are unavailable.
        eligible=[row for row in eligible if matches(row,{'language':prefs['language']}) or
                  presentation(row)['audio'].partition(' | Language: ')[2].strip().casefold()
                  in ('','unknown','und','unk','unreported','multi','multilingual')]
    from lib.provider_health import penalized
    eligible=[row for row in eligible if not penalized(row)]
    all_eligible=list(eligible)
    eligible=preferred_candidates(eligible,prefs,mode,partial=True)
    from lib.last_source import match, load, recent_success
    if remembered is None and profile and eligible:
        remembered=load(profile,meta.get('type'),identity)
    selected=(match(eligible,remembered) if recent_success(remembered) else None) or (eligible or [None])[0]
    if selected is not None:
        from lib.source_selection import record
        record(profile,mode,prefs,rows,all_eligible,eligible,selected,complete=False,exclusions=exclusions)
    return selected


def selection_details(row, addon, meta, identity):
    """Explain observed autoplay rules, without claiming provider truth."""
    from lib.source_identity import status, target, title_verified
    _, prefs = configured(addon, meta)
    details = (['Fastest start: eligible success within 36 hours or first suitable source; no quality wait']
               if prefs['priority']=='fast' else
               ['Best available quality: video format > resolution > source type > audio > bitrate > file size; AIOStreams breaks complete ties'])
    if target(meta, identity) is not None:
        verdict = status(row, meta, identity)
        details.append(('Filename title matches the requested episode' if title_verified(row, meta, identity)
                        else 'Episode number matches; filename title is unconfirmed') if verdict == 'match'
                       else 'Episode identity not confirmed by source labels')
    traits=stream_traits(row)
    if prefs.get('provider'):
        from lib.autoplay_ranking import provider_group
        details.append('Preferred provider: '+prefs['provider']+(
            ' — eligible sources tried first' if provider_group(traits['provider'])==prefs['provider']
            else ' — no eligible healthy sources; using a fallback'))
    details.append('Reported quality: ' + traits['quality'])
    if traits.get('source_types'):details.append('Reported source type: ' + ' / '.join(traits['source_types']))
    bitrate=(row.get('card') or {}).get('bitrate')
    if not bitrate:
        from core.stream_ui import stream_card
        bitrate=stream_card(row).get('bitrate')
    if bitrate:details.append('Reported bitrate: ' + str(bitrate))
    if prefs['priority']!='fast':details.append('Source preferences matched' if matches(row, prefs) else 'Closest available match to source preferences')
    return details
