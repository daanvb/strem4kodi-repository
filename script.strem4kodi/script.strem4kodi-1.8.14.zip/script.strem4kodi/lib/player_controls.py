"""Readable audio/subtitle pickers and a compact playback settings menu."""
from lib.player_audio import audio_description


def online_chapters(player, profile, kodi, picker):
    import hashlib
    from account import Store
    from chapters_db import lookup, identity
    from lib.ui_dialogs import progress_bg
    file = player.getPlayingFile()
    context = Store(profile / 'playback').load()
    if context.get('url_hash') != hashlib.sha256(file.encode()).hexdigest():
        return
    if not identity(context.get('kind'), context.get('id')):
        picker.ok('Chapters', 'This title has no supported IMDb identity for chapter lookup.')
        return
    progress = progress_bg()
    try:
        progress.create('Chapters', 'Looking for chapter lists on ChaptersDB…')
        try:
            editions = lookup(profile, context['kind'], context['id'], player.getTotalTime())
        except Exception:
            editions = None
    finally:
        progress.close()
    def matches():
        return player.isPlayingVideo() and player.getPlayingFile() == file
    if not matches():
        return
    if editions is None:
        picker.ok('Chapters', 'ChaptersDB could not be reached. Try again later; playback is unaffected.')
        return
    if not editions:
        picker.ok('Chapters', 'No compatible chapter list was found. Availability depends on the title and release.')
        return
    edition = picker.select('ChaptersDB — choose your edition',
                            [row['note'] + ' | {} chapters; timings may differ between releases'.format(len(row['chapters']))
                             for row in editions], preselect=-1)
    if edition < 0 or edition >= len(editions) or not matches():
        return
    chapters = editions[edition]['chapters']
    position = player.getTime()
    current = max((i for i, row in enumerate(chapters) if row['start'] <= position), default=0)
    choice = picker.select('Chapters', [row['name'] + ' | ' + row['time'] for row in chapters], preselect=current)
    if 0 <= choice < len(chapters) and matches() and kodi.getCondVisibility('Player.SeekEnabled'):
        player.seekTime(chapters[choice]['start'])


def choose_audio(rpc, dialog, language_name, playing_file):
    file = playing_file()
    players = rpc('Player.GetActivePlayers') or []
    video = next((p for p in players if p.get('type') == 'video'), None)
    if not video:
        return
    player_id = video['playerid']
    properties = rpc('Player.GetProperties', {
        'playerid': player_id, 'properties': ['audiostreams', 'currentaudiostream']})
    tracks = properties.get('audiostreams') or []
    if not tracks:
        dialog.ok('Audio', 'Kodi has not reported any audio tracks yet.')
        return
    current = (properties.get('currentaudiostream') or {}).get('index')
    selected = next((i for i, track in enumerate(tracks) if track.get('index') == current), 0)
    choice = dialog.select('Audio track', [audio_description(t, language_name) for t in tracks], preselect=selected)
    if choice < 0 or choice >= len(tracks) or playing_file() != file:
        return
    latest = rpc('Player.GetActivePlayers') or []
    if not any(p.get('type') == 'video' and p.get('playerid') == player_id for p in latest):
        return
    rpc('Player.SetAudioStream', {'playerid': player_id, 'stream': tracks[choice]['index']})


def choose_subtitles(rpc, dialog, language_name, playing_file, open_window):
    file = playing_file()
    players = rpc('Player.GetActivePlayers') or []
    video = next((p for p in players if p.get('type') == 'video'), None)
    if not video:
        return
    player_id = video['playerid']
    properties = rpc('Player.GetProperties', {
        'playerid': player_id, 'properties': ['subtitles', 'currentsubtitle', 'subtitleenabled']})
    tracks = properties.get('subtitles') or []
    labels = ['Off | Hide subtitles']
    for track in tracks:
        code = track.get('language') or ''
        language = language_name(code) if code else ''
        details = [track.get('name') or 'Subtitle track']
        if track.get('isforced'):
            details.append('Forced')
        if track.get('isimpaired'):
            details.append('Hearing impaired')
        labels.append((language or code or 'Unknown language') + ' | ' + ' / '.join(details))
    labels.extend(['Download subtitles | Find subtitles with your installed services',
                   'Subtitle settings | Timing, position and appearance'])
    current = (properties.get('currentsubtitle') or {}).get('index')
    selected = next((i + 1 for i, t in enumerate(tracks) if t.get('index') == current), 0)
    if not properties.get('subtitleenabled'):
        selected = 0
    choice = dialog.select('Subtitles', labels, preselect=selected)
    if choice < 0 or choice >= len(labels) or playing_file() != file:
        return
    latest = rpc('Player.GetActivePlayers') or []
    if not any(p.get('type') == 'video' and p.get('playerid') == player_id for p in latest):
        return
    if choice == 0:
        rpc('Player.SetSubtitle', {'playerid': player_id, 'subtitle': 'off'})
    elif choice <= len(tracks):
        rpc('Player.SetSubtitle', {'playerid': player_id,
                                 'subtitle': tracks[choice - 1]['index'], 'enable': True})
    else:
        open_window('ActivateWindow(subtitlesearch)' if choice == len(tracks) + 1
                    else 'ActivateWindow(osdsubtitlesettings)')


def choose_settings(dialog, playing_file, execute, has_chapters=False):
    file = playing_file()
    labels = ['Audio adjustments | Volume, amplification and audio delay',
              'Subtitle settings | Timing, position and appearance',
              'Picture settings | Aspect ratio, zoom and video processing',
              'Stop playback | Return to browsing']
    actions = ['ActivateWindow(osdaudiosettings)', 'ActivateWindow(osdsubtitlesettings)',
               'ActivateWindow(osdvideosettings)', 'PlayerControl(Stop)']
    if has_chapters:
        labels.insert(0, 'Chapters | Jump to a chapter in this video')
        actions.insert(0, 'ActivateWindow(videobookmarks)')
    choice = dialog.select('Playback settings', labels, preselect=-1)
    if 0 <= choice < len(actions) and playing_file() == file:
        execute(actions[choice])


def run(action):
    import xbmc
    from setup_profile import rpc
    from lib.ui_dialogs import dialog
    try:
        if action == 'audio':
            choose_audio(rpc, AudioDialog(), lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME),
                         xbmc.Player().getPlayingFile)
        elif action == 'subtitles':
            # A manual subtitle menu takes priority over automatic selection.
            import hashlib
            import xbmcgui
            xbmcgui.Window(10000).setProperty('strem4kodi.subtitles.manual',
                hashlib.sha256(xbmc.Player().getPlayingFile().encode()).hexdigest())
            choose_subtitles(rpc, AudioDialog('Choose a subtitle language, or turn subtitles off.'),
                             lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME),
                             xbmc.Player().getPlayingFile, xbmc.executebuiltin)
        elif action == 'settings':
            from pathlib import Path
            import xbmcvfs
            from account import Store
            from addon_state import get_addon
            from chapters_db import identity
            import hashlib
            player = xbmc.Player()
            profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
            context = Store(profile / 'playback').load()
            native = xbmc.getCondVisibility('Integer.IsGreater(Player.ChapterCount,0) + Player.SeekEnabled')
            fallback = (get_addon().getSetting('chaptersdb_enabled') != 'false'
                        and xbmc.getCondVisibility('Player.SeekEnabled')
                        and context.get('url_hash') == hashlib.sha256(player.getPlayingFile().encode()).hexdigest()
                        and identity(context.get('kind'), context.get('id')))
            def execute(command):
                if command == 'ActivateWindow(videobookmarks)' and not native:
                    online_chapters(player, profile, xbmc,
                                    AudioDialog('ChaptersDB timings depend on the release. Choose the matching edition.'))
                else:
                    xbmc.executebuiltin(command)
            choose_settings(AudioDialog('Adjust playback, or return to browsing.'),
                            player.getPlayingFile, execute, native or bool(fallback))
    except Exception:
        dialog().ok('Playback', 'These controls are unavailable. Try again after playback starts.')


class AudioDialog:
    def __init__(self, help_text='Choose a language and format. Track names are supplied by the file.'):
        self.help_text = help_text

    def ok(self, title, message):
        from lib.ui_dialogs import dialog
        return dialog().ok(title, message)

    def select(self, title, labels, preselect=0):
        import xbmcgui
        from lib.theme import window
        from addon_state import get_addon
        help_text = self.help_text

        class AudioWindow(xbmcgui.WindowXMLDialog):
            def onInit(self):
                self.result = -1
                self.setProperty('dialog_title', title)
                self.setProperty('dialog_help', help_text)
                listing = self.getControl(600)
                items = []
                for index, label in enumerate(labels):
                    language, _, details = label.partition(' | ')
                    item = xbmcgui.ListItem(label=language, label2=details)
                    item.setProperty('active', 'true' if index == preselect else '')
                    items.append(item)
                listing.addItems(items)
                listing.selectItem(max(0, preselect))
                self.setFocusId(600)

            def onClick(self, control):
                if control == 600:
                    self.result = self.getControl(600).getSelectedPosition()
                    self.close()

            def onAction(self, action):
                if action.getId() in (10, 92, 216, 247):
                    self.close()

        picker = window(AudioWindow, 'script-strem4kodi-player-audio.xml', get_addon().getAddonInfo('path'))
        picker.result = -1
        picker.doModal()
        result = picker.result
        del picker
        return result
