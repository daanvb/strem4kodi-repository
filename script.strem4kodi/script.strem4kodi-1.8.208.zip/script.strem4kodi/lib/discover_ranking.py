"""Promote service results using supplied Popular and Trending chart positions."""
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from lib.catalogue_identity import identity
from lib.discovery_groups import genre_label

_cache = {}
_lock = threading.Lock()


def promote(rows, catalog, extras, choices, fetch_page):
    genre = (extras or {}).get('genre')
    if catalog.get('family') != 'Streaming services' or not genre:
        return rows
    charts = [c for name in ('Popular', 'Trending') for c in choices
              if c.get('kind') == catalog.get('kind') and c.get('family') == 'Highlights'
              and c.get('label') == name][:2]
    if not charts:
        return rows
    signature = tuple((c['id'], tuple((m.get('url'), m.get('id'),
                                     repr(m.get('defaults'))) for m in c.get('members', []))) for c in charts)
    key = (catalog.get('kind'), str(genre), signature)

    def load(chart):
        options = next((e.get('options') or [] for e in chart.get('extras', [])
                        if e.get('name') == 'genre'), [])
        value = next((v for v in options if
                      (genre_label(v) or str(v).strip()).casefold() ==
                      (genre_label(genre) or str(genre).strip()).casefold()), None)
        try:
            # A global chart is still useful ranking evidence when it cannot
            # filter by genre: only already-filtered service titles are moved.
            return fetch_page(dict(chart), {'genre': value} if value is not None else {}) or []
        except Exception:
            return []

    # Cache bookkeeping never holds the global lock during provider I/O.
    with _lock:
        cached = _cache.get(key)
    if cached and cached[0] > time.monotonic():
        ranking = cached[1]
    else:
        with ThreadPoolExecutor(max_workers=2) as pool:
            pages = list(pool.map(load, charts))
        ranking = {}
        for position in range(max((len(p) for p in pages), default=0)):
            for page in pages:
                if position < len(page):
                    target = identity(page[position])
                    if target is not None:ranking.setdefault(target, len(ranking))
        with _lock:
            if len(_cache) >= 32:_cache.clear()
            _cache[key] = (time.monotonic() + (300 if ranking else 30), ranking)
    return sorted(rows, key=lambda row: ranking.get(identity(row), len(ranking)))
