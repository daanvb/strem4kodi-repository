"""Conservative grouping: exact release filename and technical metadata or URL."""
import re
from core.stream_ui import stream_card
from lib.playback_recovery import digest
from lib.fel_catalog import badge
from core.source_service import service_id

def group_rows(rows,prepared=None):
    groups={};result=[]
    for row in rows:
        card=prepared.card(row) if prepared is not None else stream_card(row);name=card.get('filename','')
        if re.search(r'\.(?:mkv|mp4|m2ts|avi|ts)$',name,re.I):
            key=('file',name.casefold(),card.get('quality'),card.get('size'),card.get('tech'),card.get('languages'),badge(row))
        elif row.get('url'):key=('url',digest(row['url']))
        else:key=('unique',len(result))
        key=(key,service_id(row))
        if key not in groups:
            group=dict(row);group['_alternatives']=[];groups[key]=group;result.append(group)
            if prepared is not None:prepared.alias(group,row)
        groups[key]['_alternatives'].append(row)
    for group in result:
        group['_session_failed']=all(r.get('_session_failed') for r in group['_alternatives'])
    return result
