"""Discover choices and library views derived from account data."""
def discover_catalogs(addons):
    result = []
    for addon in addons:
        if not addon.get('account'):
            continue
        manifest = addon.get('manifest') or {}
        catalogs = manifest.get('catalogs', [])
        for catalog in catalogs if isinstance(catalogs, list) else []:
            if not isinstance(catalog, dict) or not catalog.get('id') or not catalog.get('type'):
                continue
            extra = catalog.get('extra', [])
            required_names = catalog.get('extraRequired') or []
            if not isinstance(extra, list) or not isinstance(required_names, list) or any(
                    not isinstance(name, str) for name in required_names):
                continue
            extras = [e for e in extra if isinstance(e, dict) and isinstance(e.get('name'), str) and e['name']]
            # Search-only and special context catalogs do not belong in Discover.
            required = set(required_names) | {e['name'] for e in extras if e.get('isRequired')}
            options = {e['name']: e for e in extras if isinstance(e.get('options'), list) and e['options']}
            if any(name not in options for name in required):
                continue
            defaults = {name: str(options[name]['options'][0]) for name in required}
            result.append({'label': str(catalog.get('name') or catalog['id']),
                           'kind': catalog['type'], 'id': catalog['id'],
                           'addon': manifest.get('name') or 'Addon',
                           'url': addon['transportUrl'], 'extras': extras, 'defaults': defaults})
    from lib.poster_enhancement import consolidate
    return consolidate(result)


def library_sections(entries, kind='all', order='recent'):
    items = [dict(e, id=e.get('_id') or e.get('id')) for e in entries
             if isinstance(e, dict) and (e.get('_id') or e.get('id'))
             and (e.get('type') is None or isinstance(e['type'], str))
             and not e.get('removed') and not e.get('temp')
             and (kind == 'all' or e.get('type') == kind)]
    if order == 'name':
        items.sort(key=lambda e: str(e.get('name') or '').casefold())
    elif order == 'watched':
        items.sort(key=lambda e: str((e.get('state') or {}).get('lastWatched') or ''), reverse=True)
    else:
        items.sort(key=lambda e: str(e.get('_ctime') or e.get('ctime') or e.get('_mtime') or ''), reverse=True)
    types = list(dict.fromkeys(['movie', 'series'] + [e.get('type') or 'other' for e in items]))
    labels = {'movie': 'Movies', 'series': 'Series', 'collection': 'Collections'}
    return [{'label': labels.get(t, t.title()), 'items': [e for e in items if (e.get('type') or 'other') == t]}
            for t in types if any((e.get('type') or 'other') == t for e in items)]


def library_kinds(entries):
    """Offer only types with visible, saved library items, never sync tombstones."""
    sections = library_sections(entries)
    return ['all'] + list(dict.fromkeys(item['type'] for section in sections
                                      for item in section['items'] if item.get('type')))
