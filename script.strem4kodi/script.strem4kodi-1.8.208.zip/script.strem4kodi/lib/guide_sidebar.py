"""Nimbus sidebar displayed over the still-open Sports guide."""
import xbmcgui

from lib.sidebar_nav import ENTRIES, menu_action, menu_items
from lib.theme import window as themed_window


class GuideSidebar(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.result = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        listing = self.getControl(9000)
        listing.reset()
        listing.addItems(menu_items(xbmcgui))
        sports = next(i for i, entry in enumerate(ENTRIES) if entry[1] == 207)
        listing.selectItem(sports)
        self.setFocusId(9000)

    def onAction(self, action):
        if action.getId() in (2, 10, 92, 216, 247):
            self.close()

    def onClick(self, control):
        if control == 9000:
            self.result = menu_action(self.getControl(9000).getSelectedPosition())
            self.close()
        elif control == 209:
            self.result = 209
            self.close()


def show(path):
    window = themed_window(GuideSidebar, 'script-stremio-guide-sidebar.xml', path, 'Main', '1080i')
    try:
        window.doModal()
        return window.result
    finally:
        window.close()
