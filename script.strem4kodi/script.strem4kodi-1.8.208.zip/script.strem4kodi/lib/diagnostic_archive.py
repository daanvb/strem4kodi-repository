"""Bounded, redacted technical logs retained across Kodi restarts.

This is deliberately separate from the strict, fixed-field JSON summary.
Free-form error text is scrubbed, not guaranteed anonymous. Ordinary unknown
INFO/DEBUG messages and structured payloads are excluded.
"""
import gzip
import hashlib
import os
import re
import subprocess
import tempfile
import time
from pathlib import Path

READ_LIMIT = 1024 * 1024
TEXT_LIMIT = 256 * 1024
COMPRESSED_LIMIT = 256 * 1024
KEEP = 6
_SECRET = re.compile(r'(?i)(?:auth|token|password|passwd|secret|api[_-]?key|access[_-]?key|cookie)')


def scrub(text, secrets=()):
    """Keep decoder/GUI/OS error detail while removing common private values."""
    text = str(text)[:4096]
    for secret in secrets:
        if isinstance(secret, str) and len(secret) >= 4:
            text = text.replace(secret, '[credential]')
    text = re.sub(r'(?i)\b(?:[a-z][a-z0-9+.-]*://|www\.)[^\s<>\x00]+', '[url]', text)
    # Serialized config/response bodies are not useful native crash evidence.
    text = re.sub(r'[\[{].*[\]}]', '[payload]', text)
    text = re.sub(r'(?i)\b(?:authorization|proxy-authorization|cookie|set-cookie)\s*[:=].*', '[auth header]', text)
    text = re.sub(r'''(?ix)\b(?:auth\w*|\w*token\w*|password|passwd|\w*secret\w*|api[_-]?key|access[_-]?key|username|email|filename|title|query)\s*[:=]\s*(?:"[^"\n]*"|'[^'\n]*'|[^\s,;]+)''', '[private value]', text)
    text = re.sub(r'(?i)\bBearer\s+\S+', 'Bearer [credential]', text)
    text = re.sub(r'''(?:[A-Za-z]:[\\/]|(?<!\w)/)(?:[^\s<>"']+[\\/])*[^\s<>"']*''', '[path]', text)
    text = re.sub(r'\b(?:\d{1,3}\.){3}\d{1,3}(?::\d{1,5})?\b', '[address]', text)
    text = re.sub(r'(?i)(?<!\w)(?:[0-9a-f]{0,4}:){2,}[0-9a-f]{0,4}(?:%\w+)?(?!\w)', '[address]', text)
    text = re.sub(r'\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b', '[email]', text)
    text = re.sub(r'''["'][^"'\n]*["']''', '[quoted]', text)
    text = re.sub(r'\b[A-Za-z0-9_+./=-]{32,}\b', '[opaque value]', text)
    text = re.sub(r'(?i)\b[^\s]+\.(?:mkv|mp4|m3u8|avi|mov|strm)\b', '[media file]', text)
    return ''.join(c for c in text if c == '\t' or ord(c) >= 32)[:1500]


def configured_secrets(profile, addon):
    result = []
    for key in ('credits_github_token', 'tmdb_api_key', 'mdblist_api_key', 'live_football_api_key'):
        value = addon.getSetting(key)
        if isinstance(value, str) and len(value) >= 4:
            result.append(value)
    # The account store contains the Stremio auth key and configured addon URLs.
    from account import Store
    def visit(value, sensitive=False):
        if isinstance(value, dict):
            for key, child in value.items():
                visit(child, sensitive or bool(_SECRET.search(str(key))))
        elif isinstance(value, list):
            for child in value[:200]:visit(child, sensitive)
        elif sensitive and isinstance(value, str) and len(value) >= 4:
            result.append(value)
    visit(Store(profile).load())
    return tuple(sorted(set(result), key=len, reverse=True))


def technical_text(text, secrets=(), android=False):
    from lib.diagnostic_logs import _HEADER, _technical_message
    from collections import OrderedDict
    rows = []
    cached = OrderedDict()
    groups = OrderedDict()
    repeat = 0
    previous = None
    last_prefix = ''
    def flush():
        nonlocal repeat
        if repeat:
            rows.append('{} [previous message repeated {} times]\n'.format(last_prefix, repeat))
            repeat = 0
    for line in text.splitlines():
        line = line[:4096]
        header = _HEADER.match(line)
        body = header['message'] if header else line
        level = header['level'].lower() if header else ''
        prefix = '{} T:{} {} '.format(header['time'], header['thread'], level) if header else ''
        # Android decoder floods alternate several messages, so adjacent-only
        # deduplication still scrubbed thousands of identical bodies per minute.
        key = (level, body)
        if key not in cached:
            known = _technical_message(body)
            keep = (known or android or level in ('warning', 'error', 'fatal') or
                    re.search(r'(?i)\b(?:error|fatal|exception|signal|backtrace|abort message)\b', body))
            cached[key] = scrub(body, secrets) if keep else ''
            if len(cached) > 256:cached.popitem(last=False)
        message = cached[key]
        if not message.strip():continue
        if level in ('warning', 'error', 'fatal'):
            group_key = (header['thread'], level, message)
            if group_key in groups:
                groups[group_key][0] += 1
                groups[group_key][1] = prefix
                continue
            groups[group_key] = [0, prefix]
            if len(groups) > 128:
                old, (count, last) = groups.popitem(last=False)
                if count:rows.append('{}{} [message repeated {} times]\n'.format(last,old[2],count))
        if message == previous:
            repeat += 1
            last_prefix = prefix
            continue
        flush()
        rows.append(prefix + message + '\n')
        previous = message
        last_prefix = prefix
    flush()
    for key, (count, last) in groups.items():
        if count:rows.append('{}{} [message repeated {} times]\n'.format(last,key[2],count))
    raw = ''.join(rows).encode('utf-8')
    if len(raw) > TEXT_LIMIT:
        # Retain first faults and the final handoff rather than only the flood.
        head = raw[:TEXT_LIMIT // 4].rsplit(b'\n', 1)[0]
        tail = raw[-TEXT_LIMIT * 3 // 4:].partition(b'\n')[2]
        raw = head + b'\n[technical log truncated]\n' + tail
    return raw


def read_log(path):
    if Path(path).is_symlink():raise OSError('Linked logs are excluded')
    with Path(path).open('rb') as stream:
        stream.seek(0, 2)
        size = stream.tell()
        stream.seek(0)
        if size <= READ_LIMIT:
            raw = stream.read(READ_LIMIT)
        else:
            head = stream.read(64 * 1024).rsplit(b'\n', 1)[0]
            stream.seek(size - (READ_LIMIT - 64 * 1024))
            raw = head + b'\n[input log truncated: middle omitted]\n' + stream.read(READ_LIMIT - 64 * 1024).partition(b'\n')[2]
    return raw.decode('utf-8', 'replace'), size, size > READ_LIMIT


def android_crash():
    """Only this app UID's accessible crash buffer; never root or other apps."""
    binary = Path('/system/bin/logcat')
    if not binary.is_file() or not hasattr(os, 'getuid'):
        return 'unavailable', ''
    try:
        with tempfile.TemporaryFile() as output:
            result = subprocess.run([str(binary), '-b', 'crash', '-d', '-t', '200',
                                     '--uid={}'.format(os.getuid())],
                                    stdout=output, stderr=subprocess.DEVNULL,
                                    timeout=3, check=False)
            if result.returncode:
                return 'permission-denied-or-unsupported', ''
            output.seek(0)
            text = output.read(READ_LIMIT).decode('utf-8', 'replace')
        if not text.strip() or not any(line and not line.startswith('---------') for line in text.splitlines()):
            return 'no-accessible-entries', ''
        return 'captured', text
    except subprocess.TimeoutExpired:
        return 'timed-out', ''
    except OSError:
        return 'unavailable', ''


def capture(profile, addon, logs, include_android=False):
    """Caller holds the export lock; run on the diagnostic worker, never GUI."""
    from account import Store
    root = Path(profile) / 'diagnostic-export' / 'logs'
    root.mkdir(parents=True, exist_ok=True)
    store = Store(root)
    try:state = store.load()
    except Exception:state = {}
    rows = [r for r in state.get('snapshots', []) if isinstance(r, dict) and
            re.fullmatch(r'[0-5]\.log\.gz', str(r.get('file', ''))) and
            re.fullmatch(r'[0-9a-f]{64}', str(r.get('sha256', ''))) and (root / r['file']).is_file()][-KEEP:]
    # Recover a slot replaced just before an interrupted manifest save.
    rows = [r for r in rows if not (root/r['file']).is_symlink() and
            (root/r['file']).stat().st_size <= COMPRESSED_LIMIT and
            hashlib.sha256((root/r['file']).read_bytes()).hexdigest() == r['sha256']]
    secrets = configured_secrets(profile, addon)
    inputs, status = [], dict(state.get('sources', {}))
    fingerprints = dict(state.get('fingerprints', {}))
    for name in ('kodi.old.log', 'kodi.log'):
        try:
            path = Path(logs) / name
            stat = path.stat()
            signature = [stat.st_size, stat.st_mtime_ns, stat.st_ino]
            old = fingerprints.get(name, {})
            if (old.get('signature') == signature and (not old.get('sha256') or
                    any(r['sha256'] == old['sha256'] for r in rows))):
                status[name] = 'captured'
                continue
            text, size, truncated = read_log(path)
            inputs.append((name, text, size, truncated, False))
            fingerprints[name] = dict(signature=signature, sha256='')
            status[name] = 'captured'
        except OSError:
            status[name] = 'unavailable'
    if include_android:
        status['android-crash'], text = android_crash()
        if text:inputs.append(('android-crash', text, len(text.encode()), False, True))
    for name, text, size, truncated, android in inputs:
        raw = technical_text(text, secrets, android=android)
        if truncated:raw = b'[input log truncated: middle omitted]\n' + raw
        if not raw:continue
        data = gzip.compress(raw, mtime=0)
        if len(data) > COMPRESSED_LIMIT:raise ValueError('Diagnostic attachment too large')
        digest = hashlib.sha256(data).hexdigest()
        if name in fingerprints:fingerprints[name]['sha256'] = digest
        if any(r['sha256'] == digest for r in rows):continue
        used = {r['file'] for r in rows}
        # Replacing the current log must not evict the only old/crash log in
        # this very capture. A later capture would repair it, but a completed
        # playback report needs all available sources immediately.
        latest = {r['source']:r['sha256'] for r in rows if r['source'] != name}
        expendable = [r for r in rows if r['sha256'] not in latest.values()]
        replacement = (expendable or rows)[0]['file'] if rows else '0.log.gz'
        slot = next((str(i)+'.log.gz' for i in range(KEEP) if str(i)+'.log.gz' not in used), replacement)
        rows = [r for r in rows if r['file'] != slot]
        fd, temp = tempfile.mkstemp(dir=root, prefix='.capture-')
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(data);stream.flush();os.fsync(stream.fileno())
            os.replace(temp, root / slot)
        finally:
            if os.path.exists(temp):os.unlink(temp)
        rows.append(dict(file=slot, source=name, sha256=digest, captured=int(time.time()),
                         input_bytes=size, input_truncated=truncated, bytes=len(data), text_bytes=len(raw)))
    saved = dict(snapshots=rows, sources=status, fingerprints=fingerprints)
    if saved != state:store.save(saved)
    return dict(snapshots=rows, sources=status)


def attachments(profile, snapshot):
    root = Path(profile) / 'diagnostic-export' / 'logs'
    return [(row, (root / row['file']).read_bytes()) for row in snapshot['snapshots']]
