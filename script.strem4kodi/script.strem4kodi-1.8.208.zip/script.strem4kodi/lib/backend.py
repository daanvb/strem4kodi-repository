"""Program-window adapter to the existing Strem4Kodi backend.

No video-plugin navigation and no global skin settings are used here.
"""
import sys
import time
import uuid
from urllib.parse import urlencode

import xbmc
import xbmcaddon
from addon_state import get_addon
import xbmcvfs

CORE = get_addon()
CORE_PATH = xbmcvfs.translatePath(CORE.getAddonInfo('path'))
if CORE_PATH not in sys.path:
    sys.path.append(CORE_PATH)

from account import Store, library_rows
from addons_core import active_addons
from metadata_bridge import details, seasons, episodes, search as metadata_search, trailer_rows
from lib.title_metadata import people, recommendations
from protocol import fetch, resource_url
from sources import collect
from continue_playback import next_series_episode, resume_seconds
from stream_ui import stream_card
from library_actions import member, change

from lib.viewer_profiles import ViewerAccount
STORE = ViewerAccount(xbmcvfs.translatePath(CORE.getAddonInfo('profile')))
HOME = 'https://v3-cinemeta.strem.io/manifest.json'


def providers(role=None):
    from provider_roles import ordered, selected, artwork_providers, key
    from lib.provider_config import state as provider_state
    state = provider_state(STORE.directory, STORE.load())
    result = ordered(state, role) if role else list(active_addons(state))
    from lib.provider_diagnostics import configure
    configure(STORE.directory, active_addons(state))
    if role == 'metadata':
        artwork = artwork_providers(state)
        rating = selected(state, 'ratings')
        preferred = {'artwork': key(artwork[0]) if artwork else '',
                     'ratings': key(rating) if rating else ''}
        result = [dict(p, _preferred_roles=[r for r, value in preferred.items() if value == key(p)])
                  for p in result]
    return list(result)


def search_catalogues(query, limit=8):
    from lib.browse import discover_catalogs
    from lib.catalogue_search import matches
    return matches(query, discover_catalogs(providers()), limit)


def search_titles(query, limit=60):
    from concurrent.futures import ThreadPoolExecutor
    from lib.movie_collections import search as collection_search
    from lib.mdblist_lists import search as list_search
    from lib.genre_search import matches as genre_matches
    catalogues = genre_matches(query) + search_catalogues(query)
    def titles():
        try:
            return metadata_search(query, providers('search'), limit=limit, provider_first=True, fallback_only=True)
        except Exception:
            return []
    try:
        with ThreadPoolExecutor(max_workers=3) as pool:
            collections_future = pool.submit(collection_search, query)
            lists_future = pool.submit(list_search, query)
            result = titles()
            collections = collections_future.result()
            lists = lists_future.result()
    except RuntimeError:
        # Low-resource Kodi devices may be unable to start another worker.
        result = titles()
        collections = collection_search(query)
        lists = list_search(query)
    from lib.diagnostic_export import record_search
    record_search(STORE.directory, query, {'titles': len(result), 'collections': len(collections),
                                         'lists': len(lists), 'catalogues': len(catalogues)})
    from lib.catalog_poster import configured
    return collections + catalogues + lists + configured(STORE.load()).cached([{'items': result}])[0]['items']


def suggestions(query):
    from lib.movie_collections import search as collection_search
    from lib.genre_search import matches as genre_matches
    catalogues = collection_search(query, limit=8, cached_only=True) + genre_matches(query) + search_catalogues(query, limit=8)
    try:
        return catalogues + _title_suggestions(query)
    except Exception:
        return catalogues


def suggestion_collections(query):
    """Discover cold collections independently of the fast title response."""
    from lib.movie_collections import search as collection_search
    return collection_search(query, limit=8)


def _title_suggestions(query):
    from provider_roles import selected, ordered, is_aiometadata
    from lib.title_suggestions import lookup
    from lib.provider_config import state as provider_state
    state = provider_state(STORE.directory, STORE.load())
    primary = selected(state, 'search')
    if primary is None:
        primary = next((p for p in ordered(state, 'search') if is_aiometadata(p)), None)
    if primary:
        # Autocomplete and full search share the same supplier and ranking.
        from lib.title_suggestions import ranked
        matches = ranked(query, metadata_search(query, [primary], limit=40, provider_first=True,
                         fetcher=lambda url: fetch(url, timeout=3), fallback_only=True))
    else:
        matches = lookup(query)
    from lib.catalog_poster import configured
    return configured(state).cached([{'items': matches}])[0]['items']


def catalog(kind, genre=''):
    payload = fetch(resource_url(HOME, 'catalog', kind, 'top', {'genre': genre} if genre else None))
    return [r for r in payload.get('metas', []) if isinstance(r, dict) and r.get('id')][:40]


def metadata(row, quality=True):
    _request_fel_catalog()
    result = dict(row)
    full = details(row['type'], row['id'], providers=providers('metadata'))
    result.update(result.pop('_fallback_artwork', {}))
    result['_artwork_pending'] = False
    result.update({k: v for k, v in full.items() if v not in ('', None, [], {})})
    from lib.poster_enhancement import decorate
    result = decorate([result], STORE.load())[0]
    from lib.catalog_poster import configured
    result['_metadata_checked_signature'] = configured(STORE.load()).signature
    return metadata_quality(result) if quality else result


def metadata_quality(result):
    """Supplement source facts without making the title's ready path wait."""
    from lib.available_formats import complete_formats, primary_formats
    # Complete local/shared source facts require no secondary service lookup.
    if result.get('type') == 'series' and result.get('_focus_video_id'):
        return result
    try:
        if complete_formats(primary_formats(result, sys.modules[__name__])):
            return result
    except Exception:
        pass  # A local optional-format cache must never block title metadata.
    from lib.postersplus_quality import enrich
    return enrich(result)


def poster_quality(row):
    from lib.postersplus_quality import enrich
    return enrich(row)


def availability_metadata(row):
    from metadata_bridge import availability_episodes
    return availability_episodes(row.get('type'), row.get('id'), providers('metadata'))


def library():
    from lib.progress_outbox import projected_library
    return [dict(r, id=r.get('_id') or r.get('id')) for r in library_rows(projected_library(STORE))]


def saved(meta):
    from lib.progress_outbox import projected_library
    return next((r for r in projected_library(STORE)
                 if r.get('_id') == meta['id'] and r.get('type') == meta['type']), {})


def in_library(meta):
    return member(STORE.load().get('library', []), meta['id'], meta['type'])


def toggle_library(meta):
    return toggle_saved_list(meta, 'watchlist')


def saved_list_roles(meta):
    from lib.saved_lists import SavedLists
    state = STORE.load()
    return SavedLists(STORE.directory, state.get('token')).roles(meta, True if meta.get('type') == 'collection' else in_library(meta))


def saved_list_entries(entries, role):
    from lib.saved_lists import SavedLists
    return SavedLists(STORE.directory, STORE.load().get('token')).entries(entries, role)


def toggle_saved_list(meta, role):
    return update_saved_lists(meta, {role: not saved_list_roles(meta)[role]})


def move_saved_list(meta, role):
    from lib.saved_lists import ROLES
    if role not in ROLES:
        raise ValueError('Unknown saved list')
    return update_saved_lists(meta, {name: name == role for name in ROLES})


def update_saved_lists(meta, values):
    from lib.saved_lists import SavedLists, ROLES, clean
    if not values or any(role not in ROLES for role in values):
        raise ValueError('Unknown saved list')
    state = STORE.load()
    if not state.get('token'):
        raise ValueError('Connect your Stremio account in Settings first.')
    memory = SavedLists(STORE.directory, state['token'])
    if not clean({memory.key(meta): {role:{'value':bool(value),'updated':0} for role,value in values.items()}}):
        raise ValueError('Favourites and Watch Later support movies, series and movie collections.')
    if meta.get('type') == 'collection':
        memory.set_roles(meta, values, False)
        return True
    saved_before = member(state.get('library', []), meta['id'], meta['type'])
    roles = memory.roles(meta, saved_before)
    roles.update(values)
    viewer_options={'store':STORE} if getattr(state,'viewer_id',None) else {}
    state['library'] = change(state['token'], meta['id'], meta['type'],
                              meta.get('name', ''), meta.get('poster', ''), any(roles.values()), **viewer_options)
    STORE.save(state)
    memory.set_roles(meta, values, saved_before)
    return True


def mark_episodes_through(meta, target_id, watched=True):
    from episode_actions import sync_through
    remote, selected = sync_through(STORE, meta, target_id, watched)
    return remote, selected


def mark_episode(meta, target_id, watched=True):
    from episode_actions import sync_single
    remote, selected = sync_single(STORE, meta, target_id, watched)
    return remote, selected


def mark_movie(meta, watched=True):
    from media_actions import sync_movie_watched
    return sync_movie_watched(STORE, meta, watched)


def remove_continue(meta):
    from media_actions import sync_remove_continue
    result = sync_remove_continue(STORE, meta)
    from lib.continue_index import suppress
    item = next((row for row in result if row.get('_id') == meta.get('id')
                 and row.get('type') == meta.get('type')), meta)
    suppress(STORE.directory, item)
    from lib.home_state import HomeState
    HomeState(STORE.directory, STORE.load().get('token')).suppress(item)
    return result


def languages(meta):
    raw = (meta.get('languages') or meta.get('spokenLanguages') or
           meta.get('audioLanguages') or meta.get('language') or [])
    if isinstance(raw, (str, dict)):
        raw = [raw]
    rows = []
    for value in raw if isinstance(raw, list) else []:
        if isinstance(value, dict):
            code = value.get('iso_639_1') or value.get('code') or ''
            name = value.get('english_name') or value.get('name') or code
        else:
            name = str(value).strip()
            code = name if len(name) in (2, 3) else ''
        if code:
            name = xbmc.convertLanguage(str(code), xbmc.ENGLISH_NAME) or name
        row = {'name': str(name), 'code': str(code).upper() or str(name)[:2].upper()}
        if name and row not in rows:
            rows.append(row)
    return rows


def _stream_provider_signature():
    from lib.stream_index import provider_signature
    return provider_signature(providers('streams'))

def stream_cache_state(meta, identity):
    from lib.stream_index import get
    return get(STORE.directory, meta['type'], identity, _stream_provider_signature())


def availability_summary(meta):
    from lib.availability_index import get, scope
    context = scope(meta, saved(meta) if meta.get('type') == 'series' and not meta.get('_focus_video_id') else None)
    local = get(STORE.directory, meta, context)
    from lib.format_database import Database
    target = meta.get('id') if meta.get('type') == 'movie' else meta.get('_focus_video_id')
    if not target and local:
        target = local.get('target')
    if not target and meta.get('type') == 'series' and meta.get('videos'):
        video, _ = next_series_episode(meta['videos'], meta['id'], saved(meta))
        target = video.get('id') if video else None
    database = Database(STORE.directory)
    from lib.catalog_poster import identity as title_identity
    title = title_identity(meta)
    imdb = title[1] if title else ''
    if meta.get('type') == 'series' and not meta.get('_focus_video_id'):
        overview = database.series_formats(imdb)
        if overview:
            return dict(overview, scope=context, target=None)
    shared = database.get(meta.get('type'), imdb if meta.get('type') == 'movie' else target)
    if not shared and not local and meta.get('type') == 'series':
        shared = database.series_formats(imdb)
    # A source observation outranks a disc-release hint. Between source records
    # use the newest timestamp, including a downgrade or empty format result.
    if shared and (not local or shared['origin'] == 'sources' and shared['updated'] > local.get('updated', 0)):
        return dict(shared, scope=context, target=target)
    return local or dict(scope=context)


def remember_availability(meta, target, rows, context=None, complete=True, now=None):
    from lib.availability_index import put, scope
    from lib.available_formats import formats
    if not rows:
        return  # Failed lookups must not erase last-known availability.
    context = context or availability_summary(meta)['scope']
    found = formats(rows)
    put(STORE.directory, meta, context, target, found, now=now, complete=complete, rows=rows)
    # The same episode may subsequently be opened explicitly in details.
    put(STORE.directory, meta, scope(dict(meta, _focus_video_id=target)), target, found, now=now, complete=complete, rows=rows)

def background_formats_allowed():
    # Only the configured private AIOStreams addon may warm visible titles.
    return focused_formats_allowed()


def focused_formats_allowed():
    """Allow badge warming only for a configured non-public AIOStreams addon."""
    from lib.availability_requests import background_safe
    from provider_roles import name

    return any(background_safe(p) and
               'aiostreams' in ''.join(c for c in name(p).lower() if c.isalnum())
               for p in providers('streams'))


def prefetch_availability(meta, identity):
    """Query all selected addons without making one slow addon block a title worker."""
    from lib.availability_requests import _requests
    from lib.availability_index import put, scope
    from lib.available_formats import merge_formats, formats
    from sources import embedded_sources
    context = meta.get('_availability_scope') or availability_summary(meta)['scope']
    retained = availability_summary(meta).get('formats') or []
    profile = STORE.directory
    def changed(found, complete):
        if not found:return
        visible = found if complete else merge_formats(retained,found)
        put(profile,meta,context,identity,visible,complete=complete)
        put(profile,meta,scope(dict(meta,_focus_video_id=identity)),identity,visible,complete=complete)
    embedded = embedded_sources(meta, identity)
    if embedded is not None:
        found = formats(embedded[0])
        changed(found,True)
        return {'formats':found,'complete':True,'done':True}
    from lib.availability_requests import background_safe
    from lib.availability_requests import aio_provider
    active = [p for p in providers('streams') if background_safe(p)]
    selected = aio_provider(active, meta['type'], identity)
    return _requests.request(str(STORE.directory), [selected] if selected else [], meta['type'], identity,
                             changed, subscriber=context)


def _request_fel_catalog():
    if CORE.getSetting("fel_labels") != "false" and not xbmc.Player().isPlayingVideo():
        from lib.fel_catalog import request
        request(STORE.directory)

def _fel_row(row, meta):
    row["_fel_movie_id"] = str(meta.get("imdb_id") or meta.get("id") or "") if meta.get("type") == "movie" else ""
    row["_fel_labels"] = CORE.getSetting("fel_labels") != "false"
    return row

def cached_source_rows(meta, identity):
    from sources import embedded_sources
    embedded = embedded_sources(meta, identity)
    if embedded is not None:
        for row in embedded[0]:
            row['card'] = stream_card(row)
            _fel_row(row, meta)
        try:remember_availability(meta, identity, embedded[0])
        except Exception:pass  # Optional badges cannot discard embedded sources.
        return embedded
    cached=stream_cache_state(meta, identity)
    if not cached:return None
    rows,skipped,failed,updated,_,_=cached
    # Old/fresh playable caches can show badges in details without having been
    # recorded in the shared database. Repair that gap locally, preserving age.
    try:
        from lib.availability_index import get, scope
        context = scope(dict(meta, _focus_video_id=identity))
        known = get(STORE.directory, meta, context)
        if not known or known.get('updated', 0) < updated:
            remember_availability(meta, identity, rows, context=context, complete=not failed, now=updated)
    except Exception:
        pass  # Optional badge repair must not discard usable cached streams.
    _request_fel_catalog()
    from core.source_service import service_id
    for row in rows:
        row['card']=stream_card(row)
        row['service_id']=service_id(row)
        _fel_row(row, meta)
    return rows,skipped,failed

def source_rows(meta, identity, on_formats=None, on_status=None, on_progress=None,
                on_observations=None, cancelled=None):
    profile = STORE.directory
    def stopped():
        return str(STORE.directory) != str(profile) or (cancelled is not None and cancelled())
    from lib.stream_index import put
    from sources import embedded_sources
    embedded = embedded_sources(meta, identity)
    if embedded is not None:
        for row in embedded[0]:
            row['card'] = stream_card(row)
            _fel_row(row, meta)
        try:remember_availability(meta, identity, embedded[0])
        except Exception:pass  # Optional badges cannot discard embedded sources.
        return embedded
    _request_fel_catalog()
    active = providers('streams')
    context = meta.get('_availability_scope') or str(identity)
    retained = availability_summary(meta).get('formats')
    def early_badges(rows):
        if on_formats:
            on_formats(rows)
        if not retained:
            try:remember_availability(meta, identity, rows, context=context, complete=False)
            except Exception:pass
    from lib.source_requests import requests
    from lib.stream_index import provider_signature
    def load(arriving, progress, abandoned):
        from lib.format_budget import foreground, cooldown
        foreground(profile, cost=len(active))
        timing = []
        observations = {}
        result = collect(active, meta['type'], identity, timing=timing,
                         on_results=arriving, on_progress=progress, observations=observations,
                         cancelled=abandoned)
        foreground(profile, cost=observations.get('requests', len(active)))
        if any(t.get('rate_limited') for t in timing):
            cooldown(profile)
        try:
            from lib.perf_report import record_stream_providers
            record_stream_providers(profile, timing)
        except Exception:
            pass
        return result, timing, observations
    (rows, skipped, failed), timing, observations = requests.request(
        (str(profile), meta['type'], identity, provider_signature(active)),
        load, early_badges, on_progress, cancelled=stopped)
    if stopped() or observations.get('cancelled'):
        return None
    if on_status:
        reasons = {t.get('reason') for t in timing if t.get('failed')}
        if any(t.get('rate_limited') for t in timing):reasons.add('rate_limited')
        on_status(next((r for r in ('rate_limited','timed_out','denied','connection_failed','server_error','invalid_response')
                        if r in reasons), 'unavailable' if failed else ''))
    if on_observations:
        on_observations(observations)
    for row in rows:
        row['card'] = stream_card(row)
        _fel_row(row, meta)
    result=(rows,skipped,failed)
    if rows:
        try:put(profile,meta['type'],identity,result,provider_signature(active))
        except Exception:pass
    try:remember_availability(meta, identity, rows, context=context, complete=not failed)
    except Exception:pass
    return result


def play(meta, identity, stream, resume_ms=0):
    if meta.get('type') == 'series':
        from episode_identity import conflict
        episode = next((v for v in meta.get('videos') or [] if v.get('id') == identity), {})
        if conflict(episode or {'id':identity}, str(meta.get('id') or '')):
            raise ValueError('Episode identity disagrees with its numbering. Refresh metadata before playback.')
    from lib.playback_loading import cancelled
    if cancelled(stream.get('_playback_attempt')):return
    # Reuse the core resolver, subtitles and playback observer rather than
    # introducing a second playback implementation in the program addon.
    key = uuid.uuid4().hex
    from lib.playback_timing import mark
    from lib.playback_payload import write, prune
    from lib.resume_rewind import prepare
    from lib.viewer_profiles import current as current_viewer
    resume = prepare(meta, stream, resume_ms, CORE)
    mark(stream.get('_playback_attempt'),'cache_begin')
    write(STORE.directory, key, dict(stream, meta=meta, kind=meta['type'], id=identity,
          _viewer_id=current_viewer(STORE.directory), **resume))
    mark(stream.get('_playback_attempt'),'cache_written')
    url = 'plugin://script.strem4kodi/?' + urlencode({'action': 'play', 'key': key})
    from lib.prerolls import select, PROPERTY
    import xbmcgui
    session = xbmcgui.Window(10000)
    if cancelled(stream.get('_playback_attempt')):return
    preroll=select(meta, stream, resume_ms, CORE, rotate=False)
    if cancelled(stream.get('_playback_attempt')):return
    mark(stream.get('_playback_attempt'),'dispatch')
    if preroll:
        session.setProperty(PROPERTY, key)
        xbmc.executebuiltin('RunScript(special://home/addons/script.strem4kodi/preroll_player.py,' + key + ')')
    else:
        session.clearProperty(PROPERTY)
        xbmc.executebuiltin('PlayMedia(' + url + ')')
    # Cleanup cannot delay dispatch or fail a successfully dispatched request.
    try:
        import threading
        threading.Thread(target=prune,args=(STORE.directory,),daemon=True).start()
    except RuntimeError:pass


def _continue_rows(state, catalogs=(), allow_network=False):
    from lib import continue_index
    import sqlite3
    library = state.get('library', [])
    try:
        # The optional local index must never hide the account's other Home rows.
        continue_index.seed(STORE.directory, library)
        if allow_network:
            from continue_playback import continue_series_target
            for media_id, row in continue_index.unresolved_series(STORE.directory, 8):
                try:
                    full = metadata(row)
                    target, resume_ms = continue_series_target(full.get('videos') or [], row)
                except Exception:
                    continue
                projected = dict(row)
                projected.update({key: value for key, value in full.items()
                                  if value not in ('', None, [], {})})
                projected['id'] = media_id
                series_status=str(full.get('status') or '').strip().lower()
                confirmed_finished = target is None and series_status in ('ended','canceled','cancelled')
                continue_index.resolve_series(STORE.directory, media_id, projected, target, resume_ms, confirmed_finished)
        continuing, forgotten = continue_index.retained_rows(STORE.directory, 100)
    except (sqlite3.Error, OSError):
        return None
    if continuing or forgotten:
        from lib.hero_metadata import prepare
        continuing = prepare(continuing, catalogs, None)
        return {'label': 'Continue Watching', 'items': continuing, 'failed': False,
                '_retention_reminders': forgotten}
    return None


def account_home_capacity():
    """Reserve Home rows including both airing sections after async refresh."""
    state = STORE.load()
    from lib import continue_index
    import sqlite3
    try:
        continue_index.seed(STORE.directory, state.get('library', []))
    except (sqlite3.Error, OSError):
        pass
    return 10


def _progress_sections(continuing):
    """Keep recent series on Continue Watching with their next episode focus."""
    if not continuing:
        return []
    watching = []
    for row in continuing.get('items', []):
        episode = row.get('_next_episode')
        if episode and row.get('type') == 'series':
            card = dict(row, _continue_watching=True, _focus_video_id=episode['id'])
            card['name'] = '{} - S{:02d}E{:02d}'.format(row.get('name', ''), int(episode.get('season') or 0), int(episode.get('episode') or episode.get('number') or 0))
            card['description'] = episode.get('description') or episode.get('overview') or row.get('description', '')
            watching.append(card)
        else:
            watching.append(row)
    return [dict(continuing, items=watching)] if watching else []


def account_home(refresh=True):
    from lib.perf_trace import now as perf_now, log as perf_log
    total_started = perf_now()
    """Return Home without blocking startup when refresh=False.

    Both modes read local playback state. Catalogue browsing belongs in Discover
    and Sports; metadata and account sync remain in the background service.
    """
    from lib.home_snapshot import load as load_snapshot, save as save_snapshot
    state = STORE.load()
    if not state.get('token'):
        return []

    from lib.progress_outbox import projected_library
    state['library'] = projected_library(STORE, state)

    if not refresh:
        stage_started = perf_now()
        from lib.home_snapshot import active_rows
        rows = active_rows(load_snapshot(STORE.directory),
                           [a for a in active_addons(state) if a.get('account') is True])
        continuing = _continue_rows(state, rows, False)
        result = _progress_sections(continuing) + _upcoming_sections(state, continuing) + _recommendation_sections(state)
        from lib.catalog_poster import configured
        result = configured(state).cached(result)
        perf_log('home.cached', stage_started, profile=STORE.directory, rows=len(result),
                 items=sum(len(row.get('items') or []) for row in result))
        perf_log('home.cached.total', total_started, profile=STORE.directory)
        return result

    # Account/provider sync runs in the periodic service worker.
    addons_started = perf_now()
    perf_log('home.refresh.account.local', addons_started, profile=STORE.directory)
    from lib.provider_diagnostics import configure
    configure(STORE.directory, active_addons(state))
    catalogs_started = perf_now()
    catalog_rows = []
    perf_log('home.refresh.catalogs', catalogs_started, profile=STORE.directory, rows=len(catalog_rows),
             items=sum(len(row.get('items') or []) for row in catalog_rows))
    # Clear legacy catalogue snapshots after migrating to the focused Home.
    save_snapshot(STORE.directory, catalog_rows)

    # Library/CW network sync and series resolution run in the 15-minute service
    # worker. Home only reads the latest local SQLite state, avoiding a 2-3s
    # 4k+ library pull plus metadata fan-out on every window open.
    library_started = perf_now()
    continuing = _continue_rows(state, catalog_rows, False)
    perf_log('home.refresh.library.local', library_started, profile=STORE.directory)
    result = _progress_sections(continuing) + _upcoming_sections(state, continuing) + _recommendation_sections(state)
    from lib.catalog_poster import configured
    result = configured(state).cached(result)
    perf_log('home.refresh.total', total_started, profile=STORE.directory, rows=len(result),
             items=sum(len(row.get('items') or []) for row in result))
    return result


def _upcoming_sections(state=None, continuing=None):
    import sqlite3
    if state is not None:
        from lib.home_upcoming import sections
        try:
            return sections(STORE.directory, state, (continuing or {}).get('items') or [], metadata,
                            reminder_items=(continuing or {}).get('_retention_reminders'))
        except (sqlite3.Error, OSError):
            return []
    from lib.continue_index import upcoming
    try:
        rows = upcoming(STORE.directory)
    except (sqlite3.Error, OSError):
        return []
    return [{'label': 'Upcoming Episodes', 'items': rows, 'failed': False}] if rows else []


def collection_progress(rows, unwatched=False):
    from lib.catalogue_search import with_progress
    from lib.continue_index import resolved_series
    from lib.discovery_groups import item_key
    known = {item_key(r): r.get('videos') for r in resolved_series(STORE.directory)}
    library = [dict(r, videos=known.get(item_key(dict(r, id=r.get('_id') or r.get('id'))), r.get('videos') or []))
               for r in account_library(False) if isinstance(r, dict)]
    return with_progress(rows, library, unwatched)


def discover_choices(sports=False):
    from lib.browse import discover_catalogs
    from lib.discovery_groups import groups
    return groups(discover_catalogs(providers()), sports=sports)


def rank_discover(catalog, rows, extras):
    from lib.discover_ranking import promote
    try:
        return promote(rows, catalog, extras, discover_choices(), discover_items)
    except Exception:
        return rows


def refresh_sports_schedule(rows, cancelled=None):
    """Refresh fixture metadata while preserving catalogue rows on failure."""
    from lib.live_football_schedule import enrich
    core = globals().get('CORE')
    return enrich(rows, core.getSetting('live_football_api_key').strip() if core else '', cancelled=cancelled)


def discover_items(catalog, extras=None, cancelled=None):
    if cancelled and cancelled():
        return None
    if catalog.get('_mdblist'):
        from lib.mdblist_lists import items
        return items(catalog, extras)
    if catalog.get('_genre'):
        from lib.genre_search import GENRES, HOME
        if catalog['_genre'] not in GENRES or catalog.get('kind') not in ('movie', 'series'):
            return []
        values = {'genre': catalog['_genre']}
        if (extras or {}).get('skip'): values['skip'] = str(max(0, int(extras['skip'])))
        data = fetch(resource_url(HOME, 'catalog', catalog['kind'], 'top', values))
        return [dict(r, type=r.get('type') or catalog['kind']) for r in data.get('metas', [])
                if isinstance(r, dict) and r.get('id')][:100]
    if catalog.get('_tmdb_collection'):
        from lib.movie_collections import movies
        return movies(catalog['_tmdb_collection'])
    if catalog.get('members'):
        from lib.discovery_groups import merge_pages
        fetch_page = discover_items if cancelled is None else lambda member, values: discover_items(member, values, cancelled)
        rows = merge_pages(catalog, fetch_page, extras)
        if cancelled and cancelled():
            return None
        if catalog.get('kind') in ('sport', 'sports'):
            from lib.sports_epg import annotate_rows
            rows = annotate_rows(rows, catalog)
            from lib.live_football_schedule import enrich
            core = globals().get('CORE')
            rows = enrich(rows, core.getSetting('live_football_api_key').strip() if core else '', cancelled=cancelled)
        return rows
    if not any(p.get('transportUrl') == catalog.get('url') for p in providers()):
        return []
    values = dict(catalog['defaults'])
    values.update(extras or {})
    data = fetch(resource_url(catalog['url'], 'catalog', catalog['kind'], catalog['id'], values))
    if cancelled and cancelled():
        return None
    sports = catalog['kind'] in ('sport', 'sports') or str(catalog.get('addon') or '').casefold() == 'sports streams'
    metas = data.get('metas', [])
    if sports and (data.get('error') or 'metas' not in data or not isinstance(metas, list)):
        raise ValueError('Sports catalogue response is unusable')
    rows = [dict(row, type=row.get('type') or catalog['kind']) for row in metas
            if isinstance(row, dict) and row.get('id')][:100]
    if sports:
        from lib.sports_epg import annotate_rows, provider_timezone
        zone = provider_timezone(catalog)
        if zone:
            rows = [dict(row, _sports_timezone=zone) for row in rows]
        rows = annotate_rows(rows, catalog)
        from lib.live_football_schedule import enrich
        core = globals().get('CORE')
        rows = enrich(rows, core.getSetting('live_football_api_key').strip() if core else '', cancelled=cancelled)
    return rows


def account_library(refresh=True):
    from account import pull_library
    state = STORE.load()
    if refresh and state.get('token') and not getattr(state,'viewer_id',None):
        remote = pull_library(state['token'])
        STORE.update_library(state['token'], state.get('library', []), remote)
        state = STORE.load()
    return state.get('library', [])



def _recommendation_sections(state):
    from lib.home_recommendations import sections
    return sections(STORE.directory, state)
