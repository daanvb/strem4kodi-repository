"""Small, truthful loading summaries from completed add-on requests."""
from lib.stream_presenter import line


def failure_label(reason):
    return {'rate_limited': 'Provider rate limit', 'timed_out': 'Source request timed out',
            'connection_failed': 'Source connection failed', 'server_error': 'Provider server error',
            'denied': 'Provider access denied', 'invalid_response': 'Invalid provider response'}.get(reason, 'Source request failed')


def properties(status, elapsed=0):
    total = max(0, int(status.get('total') or 0))
    completed = min(total, max(0, int(status.get('completed') or 0)))
    count = max(0, int(status.get('rows') or 0))
    failed = max(0, int(status.get('failed') or 0))
    limited = max(0, int(status.get('rate_limited') or 0))
    pending = [line(name, 40) for name in status.get('pending', []) if line(name, 40)]
    done = completed == total
    seconds = max(0, int(elapsed))
    heading = ('Search incomplete' if done and failed else 'Search complete' if done else 'Searching add-ons') + ' · {} / {} checked'.format(completed, total)
    if count:
        heading += ' · {} sources found'.format(count)
    if seconds:
        heading += ' · {}s'.format(seconds)
    if done and failed:
        labels = {'rate_limited': 'rate limited', 'timed_out': 'timed out', 'connection_failed': 'connection failed',
                  'server_error': 'server error', 'denied': 'access denied',
                  'invalid_response': 'invalid response', 'request_failed': 'request failed'}
        reasons = status.get('failure_reasons') or {}
        detail = ' · '.join('{} {}'.format(reasons[key], value) for key, value in labels.items() if reasons.get(key))
        detail = detail or '{} add-on requests failed'.format(failed)
    elif status.get('retrying'):
        detail = 'Retrying ' + ', '.join(line(name, 40) for name in status['retrying'][:2])
    elif limited:
        detail = '{} add-on{} rate limited'.format(limited, '' if limited == 1 else 's')
    elif pending:
        detail = 'Waiting for ' + ', '.join(pending[:2]) + (' and others' if len(pending) > 2 else '')
    else:
        detail = ''
    if not done and count:
        detail += (' · ' if detail else '') + 'You can choose a source now'
    elif not done and seconds >= 10:
        detail += (' · ' if detail else '') + 'Some add-ons are taking longer'
    return {'streams_search_status': heading, 'streams_search_detail': detail}
