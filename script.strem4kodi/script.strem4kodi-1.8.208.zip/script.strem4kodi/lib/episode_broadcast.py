"""Optional television broadcast listings for future series episodes."""
from datetime import datetime, timedelta, timezone
import json
import re
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from lib.episode_availability import air_date
from lib.sports_epg import uk_datetime

_CACHE = {}
_LOCK = threading.Lock()


def _json(url):
    request = Request(url, headers={'Accept': 'application/json', 'User-Agent': 'Strem4Kodi/1'})
    with urlopen(request, timeout=4) as response:
        payload = response.read(2 * 1024 * 1024 + 1)
    if len(payload) > 2 * 1024 * 1024:
        raise ValueError('TV listing response too large')
    return json.loads(payload.decode('utf-8'))


def listings(meta, fetcher=None, now=None):
    """Match network episodes by IMDb ID, season, number and nearby air date."""
    identity = str(meta.get('imdb_id') or meta.get('id') or '')
    if not re.fullmatch(r'tt\d{5,12}', identity):
        return {}
    now = now or datetime.now(timezone.utc)
    today = uk_datetime(now.timestamp()).date()
    targets = {}
    for row in meta.get('videos') or []:
        if not isinstance(row, dict):
            continue
        try:
            season, number = int(row.get('season')), int(row.get('episode', row.get('number')))
            date = str(row.get('released') or row.get('firstAired') or '')[:10]
            parsed, _ = air_date(row)
            if (parsed is not None and today <= parsed.date() <= today + timedelta(days=365)
                    and season >= 0 and number > 0
                    and re.fullmatch(r'\d{4}-\d{2}-\d{2}', date)):
                targets[(season, number, date)] = str(row.get('id') or '')
        except (TypeError, ValueError):
            continue
    if not targets:
        return {}
    if fetcher is None:
        with _LOCK:
            cached = _CACHE.get(identity)
            if cached and cached[0] > time.monotonic():
                return {key: value for key, value in cached[1].items() if key in targets.values()}
        fetcher = _json
        save = True
    else:
        save = False
    result = {}
    try:
        show = fetcher('https://api.tvmaze.com/lookup/shows?imdb=' + identity)
        network = show.get('network') or show.get('webChannel') or {}
        country = network.get('country') or {}
        if (str((show.get('externals') or {}).get('imdb') or '') != identity
                or not isinstance(network.get('name'), str)):
            return {}
        show_id = int(show['id'])
        if not 0 < show_id < 100000000:
            return {}
        episodes = fetcher('https://api.tvmaze.com/shows/{}/episodes'.format(show_id))
        for episode in episodes if isinstance(episodes, list) else []:
            if not isinstance(episode, dict):
                continue
            airdate = episode.get('airdate')
            if not isinstance(airdate, str) or not isinstance(episode.get('airstamp'), str):
                continue
            stamp = datetime.fromisoformat(episode['airstamp'].replace('Z', '+00:00'))
            if stamp.tzinfo is None:
                continue
            try:
                listed_date = datetime.fromisoformat(airdate).date()
            except ValueError:
                continue
            if abs((stamp.date() - listed_date).days) > 1:
                continue
            airtime = episode.get('airtime')
            if not isinstance(airtime, str) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d', airtime):
                continue
            if country.get('timezone') == 'Europe/London':
                uk = uk_datetime(stamp.timestamp())
                if uk.date() != listed_date or uk.strftime('%H:%M') != airtime:
                    continue
            if episode.get('airtime') == '00:00' and not show.get('network'):
                continue  # Streaming catalogues often use midnight as a placeholder.
            target_id = next((identity for (season, number, date), identity in targets.items()
                              if season == episode.get('season') and number == episode.get('number')
                              and abs((datetime.fromisoformat(date).date() - listed_date).days) <= 1), None)
            if not target_id:
                continue
            result[target_id] = {'_broadcast_start': episode['airstamp'],
                                 '_broadcast_network': network['name'][:20]}
    except (HTTPError, URLError, ValueError, TypeError, KeyError, OSError, json.JSONDecodeError):
        return {}
    if save:
        with _LOCK:
            if len(_CACHE) >= 32:
                _CACHE.pop(next(iter(_CACHE)))
            _CACHE[identity] = (time.monotonic() + 3600, result)
    return result
