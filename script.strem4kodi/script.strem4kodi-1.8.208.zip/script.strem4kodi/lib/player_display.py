"""Publish bounded, local playback labels for the optional companion skin."""
from datetime import datetime
import time

from lib.player_audio import FinishEstimate, audio_description

PREFIX = 'strem4kodi.player.'
KEYS = ('active', 'audio', 'ends', 'chapter', 'live')


class PlayerDisplay:
    def __init__(self, player, kodi=None, window=None, rpc=None, clock=time.time):
        if kodi is None:
            import xbmc as kodi
        if window is None:
            import xbmcgui
            window = xbmcgui.Window(10000)
        if rpc is None:
            from setup_profile import rpc
        self.player = player
        self.kodi = kodi
        self.window = window
        self.rpc = rpc
        self.clock = clock
        self.file = None
        self.estimate = FinishEstimate()
        self.transition_since = None

    def close(self):
        for key in KEYS:
            self.window.clearProperty(PREFIX + key)
        self.file = None
        self.estimate = FinishEstimate()
        self.transition_since = None

    def tick(self):
        try:
            live_file = getattr(self.player, '_live_file', None)
            live = isinstance(live_file, str) and bool(live_file)
            file = live_file if live else getattr(self.player, '_playing_file', None)
            if not file:
                self.close()
                return
            playing = self.player.isPlayingVideo()
            actual = self.player.getPlayingFile() if playing else ''
            if not playing or not actual:
                # Owned transitions have a short grace; Stop clears the
                # observer's owned file immediately and bypasses this path.
                if self.transition_since is None:self.transition_since = self.clock()
                if self.clock()-self.transition_since >= 2:self.close()
                return
            if actual != file:
                stream_for_key = getattr(self.player, '_stream_for_key', None)
                key = getattr(self.player, '_live_key' if live else '_key', None)
                from lib.playback_recovery import owns_stream
                stream = stream_for_key(key) if callable(stream_for_key) else None
                if not stream or not owns_stream(self.player, stream, actual):
                    self.close()
                    return
                file = actual
            self.transition_since = None
            if self.file != file:
                self.close()
                self.file = file
            self.window.setProperty(PREFIX + 'active', 'true')
            self.window.setProperty(PREFIX + 'live', 'true' if live else '')
            from lib.chapter_labels import label
            try:
                number = int(self.kodi.getInfoLabel('Player.Chapter') or 0)
                count = int(self.kodi.getInfoLabel('Player.ChapterCount') or 0)
            except (TypeError, ValueError):
                number = count = 0
            self.window.setProperty(PREFIX + 'chapter',
                label(self.kodi.getInfoLabel('Player.ChapterName'), number, count) if number > 0 and not live else '')
            speed = 2 if self.kodi.getCondVisibility('Player.Forwarding | Player.Rewinding') else 1
            end = None if live else self.estimate.update(self.clock(), self.player.getTotalTime(), self.player.getTime(), speed)
            if live:
                self.window.setProperty(PREFIX + 'ends', 'Live · delay unavailable')
            elif end is None:
                self.window.clearProperty(PREFIX + 'ends')
            else:
                self.window.setProperty(PREFIX + 'ends', 'Ends at ' + datetime.fromtimestamp(end).strftime('%H:%M'))
            # The service samples only while our player bar is visible. Kodi's
            # native labels continue to work when the service is not running.
            if not self.kodi.getCondVisibility('Window.IsVisible(videoosd)'):
                return
            players = self.rpc('Player.GetActivePlayers') or []
            video = next((p for p in players if p.get('type') == 'video'), None)
            if not video:
                self.window.clearProperty(PREFIX + 'audio')
                return
            properties = self.rpc('Player.GetProperties', {
                'playerid': video['playerid'], 'properties': ['currentaudiostream', 'speed']})
            # Validate again after the request: a next episode may have started.
            if self.player.getPlayingFile() != file:
                self.window.clearProperty(PREFIX + 'audio')
                return
            self.window.setProperty(PREFIX + 'audio', audio_description(
                properties.get('currentaudiostream'),
                lambda code: self.kodi.convertLanguage(code, self.kodi.ENGLISH_NAME),
                self.kodi.getInfoLabel('VideoPlayer.AudioCodec')))
        except Exception:
            # Never leave audio or finish-time data from a previous track.
            self.window.clearProperty(PREFIX + 'audio')
            self.window.clearProperty(PREFIX + 'ends')
