"""Durable account-bound progress updates with retry and pre-write snapshots."""
from datetime import datetime, timezone
import hashlib
import threading
import time
import uuid
import re
from copy import deepcopy
from pathlib import Path
from account import Store
from lib.viewer_profiles import storage_directory

_lock=threading.RLock()
_worker=None
_next=0
_processing=set()

def failure_label(error):
    message=str(error)
    match=re.fullmatch(r'Stremio service returned HTTP (\d{3})\. Please retry shortly\.',message)
    if match:return 'Stremio HTTP '+match.group(1)
    return {
        'Could not reach the Stremio service. Check your connection and retry.':'Stremio unreachable - retrying',
        'Stremio returned an unexpected response. Please retry shortly.':'Unexpected Stremio response - retrying',
        'Unable to read the Stremio library. Existing local data was kept.':'Unable to read Stremio library - retrying',
        'Stremio rejected the watch-progress update.':'Stremio rejected progress - retrying',
        'Stremio did not confirm the watch-progress update.':'Awaiting Stremio confirmation - retrying',
        'Account changed during sync.':'Account changed - waiting for retry',
    }.get(message,'Progress upload failed - retrying')

def owner(token):return hashlib.sha256(str(token).encode()).hexdigest()


def _snapshot_directory(store, snapshot):
    from lib.viewer_profiles import ViewerAccount
    folder = Path(store.directory)
    if isinstance(store, ViewerAccount):
        identity = getattr(snapshot, 'viewer_id', None)
        if identity:folder = folder/'viewers'/owner(snapshot.get('token'))/identity
    return folder


def projected_library(store, snapshot=None):
    """Display durable local intent without acknowledging or uploading it.

    The transport library stays untouched, especially for viewer conflict
    comparisons. Outbox folders and account hashes bound every projection.
    """
    snapshot = store.load() if snapshot is None else snapshot
    library = list(snapshot.get('library') or [])
    token = snapshot.get('token')
    if not token:return library
    # Do not resolve account ownership again after a UI profile/account switch.
    folder = _snapshot_directory(store, snapshot)
    with _lock:
        queue = Store(folder/'progress-outbox')
        if queue.directory != folder/'progress-outbox':return library
        rows = queue.load().get('rows') or []
    for row in rows:
        if row.get('owner') != owner(token):continue
        item = row.get('local_item') or row.get('prepared')
        if not isinstance(item, dict):
            # Older durable events predate local projection snapshots.
            from core.playback_progress import apply_progress, _released
            context = row.get('context') or {}
            stamp = _released(row.get('captured_at'))
            if context.get('kind') not in ('movie', 'series') or not stamp:continue
            item = apply_progress(library, context, row.get('position_ms'), row.get('duration_ms'),
                row.get('watched_ms'), ended=row.get('ended',False), checkpoint=row.get('checkpoint',False),
                credits_watched=row.get('credits_watched',False), now=stamp)
        key = item.get('_id'), item.get('type')
        library = [r for r in library if (r.get('_id'),r.get('type')) != key] + [deepcopy(item)]
    return library

def reconcile_library(store, token, local, remote):
    """Keep pending local snapshots until Stremio catches up or supersedes them."""
    from core.playback_progress import _released
    with _lock:
        rows=Store(storage_directory(store)/'progress-outbox').load().get('rows') or []
    pending={}
    for row in rows:
        context=row.get('context') or {}
        stamp=_released(row.get('captured_at'))
        key=(context.get('meta_id'),context.get('kind'))
        if row.get('owner')==owner(token) and stamp:
            pending[key]=max(stamp,pending.get(key,stamp))
    result=list(remote)
    for item in local or []:
        key=(item.get('_id'),item.get('type'))
        if key not in pending:continue
        index=next((i for i,r in enumerate(result) if (r.get('_id'),r.get('type'))==key),None)
        stamp=_released(result[index].get('_mtime')) if index is not None else None
        if stamp and stamp>=pending[key]:continue
        local_stamp=_released(item.get('_mtime'))
        if stamp and (not local_stamp or stamp>=local_stamp):continue
        if index is None:result.append(item)
        else:result[index]=item
    return result

def enqueue(store,pending):
    if (pending.get('context') or {}).get('kind') not in ('movie','series'):return False
    from lib.viewer_profiles import ViewerAccount
    if isinstance(store, ViewerAccount):store = store.freeze()
    snapshot=store.load()
    token=snapshot.get('token')
    if not token:return False
    folder = _snapshot_directory(store, snapshot)
    queue=Store(folder/'progress-outbox')
    if queue.directory != folder/'progress-outbox':return False
    with _lock:
        data=queue.load();rows=data.get('rows') or []
        row=dict(pending,owner=owner(token),captured_at=datetime.now(timezone.utc).isoformat(timespec='milliseconds'),event_id=uuid.uuid4().hex)
        from core.playback_progress import apply_progress
        row['local_item'] = apply_progress(projected_library(store, snapshot), pending['context'],
            pending['position_ms'], pending['duration_ms'], pending['watched_ms'],
            ended=pending['ended'], checkpoint=pending.get('checkpoint', False),
            credits_watched=pending.get('credits_watched', False))
        from lib.viewer_profiles import ViewerAccount
        if isinstance(store,ViewerAccount) and getattr(snapshot,'viewer_id',None):
            context=pending['context']
            prior_item=next((r for r in snapshot.get('library',[]) if isinstance(r,dict)
                             and (r.get('_id'),r.get('type'))==(context.get('meta_id'),context.get('kind'))),None)
            from lib.viewer_sync import clean_library
            row['observed_item']=(clean_library([prior_item]) or [None])[0]
        prior=next((r for r in reversed(rows) if row.get('session') and r.get('owner')==row['owner'] and r.get('session')==row.get('session')
                    and all((r.get('context') or {}).get(k)==row['context'].get(k) for k in ('kind','meta_id','video_id'))
                    and not r.get('prepared') and not r.get('in_flight')),None)
        if prior:
            if 'observed_item' in prior:row['observed_item']=prior['observed_item']
            row['watched_ms']+=prior.get('watched_ms',0)
            row['credits_watched']=bool(row.get('credits_watched') or prior.get('credits_watched'))
            rows.remove(prior)
        rows.append(row);queue.save({'rows':rows})
    from lib.playback_refresh import refresh_continue_index
    from lib.progress_signal import publish
    try:
        refresh_continue_index(store, pending['context'], row['local_item'], projected=True)
        publish(pending['context'])
    except (OSError, RuntimeError, ValueError):
        pass  # Durable enqueue succeeded; a derived UI index can be rebuilt.
    return True

def process_one(store,syncer=None):
    from lib.viewer_profiles import ViewerAccount
    if isinstance(store, ViewerAccount):store = store.freeze()
    key = str(storage_directory(store))
    with _lock:
        if key in _processing:return False
        _processing.add(key)
    try:return _process_one(store, syncer)
    finally:
        with _lock:_processing.discard(key)


def _process_one(store,syncer=None):
    from core.playback_progress import sync_progress
    syncer=syncer or sync_progress
    snapshot=store.load()
    token=snapshot.get('token')
    if not token:return False
    folder = _snapshot_directory(store, snapshot)
    queue=Store(folder/'progress-outbox')
    if queue.directory != folder/'progress-outbox':return False
    with _lock:
        rows=queue.load().get('rows') or []
        unsupported=[r for r in rows if r.get('owner')==owner(token) and (r.get('context') or {}).get('kind') not in ('movie','series')]
        if unsupported:
            archive=Store(folder/'progress-outbox-unsupported')
            archive.save({'rows':(archive.load().get('rows') or [])+unsupported})
            rows=[r for r in rows if r not in unsupported]
            queue.save({'rows':rows})
        pending=next((r for r in rows if r.get('owner')==owner(token)),None)
        if pending is None:return False
        pending['in_flight']=True
        queue.save({'rows':rows})
        pending=dict(pending)
    def prepare(item):
        with _lock:
            rows=queue.load().get('rows') or []
            for r in rows:
                if r['event_id']==pending['event_id']:r['prepared']=item
            queue.save({'rows':rows})
    credits_args = {'credits_watched': True} if pending.get('credits_watched') else {}
    remote=syncer(store,pending['context'],pending['position_ms'],pending['duration_ms'],pending['watched_ms'],
        ended=pending['ended'],checkpoint=pending.get('checkpoint',False),captured_at=pending['captured_at'],
        prepared_item=pending.get('prepared'),prepare_func=prepare,expected_owner=pending['owner'],
        observed_item=pending.get('observed_item'),observed_known='observed_item' in pending,**credits_args)
    if remote is None:return False
    with _lock:
        rows=queue.load().get('rows') or []
        # A checkpoint captured while this write was in flight observed our
        # predecessor. Rebase only that same session/title/account lineage.
        from lib.viewer_sync import clean_library
        ancestor = clean_library([pending.get('observed_item')])
        saved_pending = next((r for r in rows if r.get('event_id') == pending['event_id']), {})
        prepared = saved_pending.get('prepared')
        confirmed_own = isinstance(prepared, dict) and clean_library([remote]) == clean_library([prepared])
        for row in rows:
            if (confirmed_own and pending.get('session') and row.get('session') == pending['session']
                    and row.get('owner') == pending['owner']
                    and row.get('event_id') != pending['event_id']
                    and row.get('context', {}).get('meta_id') == pending['context']['meta_id']
                    and row.get('context', {}).get('kind') == pending['context']['kind']
                    and 'observed_item' in row and clean_library([row.get('observed_item')]) == ancestor):
                row['observed_item'] = (clean_library([remote]) or [None])[0]
        queue.save({'rows':[r for r in rows if r['event_id']!=pending['event_id']]})
    Store(folder/'sync-status').save({'updated':time.time()})
    Store(folder/'progress-sync-status').save({'updated':time.time()})
    from lib.playback_refresh import refresh_continue_index
    from lib.progress_signal import publish
    refresh_continue_index(store,pending['context'],remote,projected=True)
    publish(pending['context'])
    return True

def summary(profile,token):
    if not token:return 'Connect Stremio first'
    try:
        rows=Store(profile/'progress-outbox').load().get('rows') or []
        count=sum(r.get('owner')==owner(token) for r in rows)
        if count:return '{} progress uploads pending'.format(count)
        stamp=Store(profile/'sync-status').load().get('updated')
        return 'Synced '+time.strftime('%H:%M',time.localtime(stamp)) if stamp else 'Ready'
    except Exception:return 'Sync status unavailable'

def tick(store):
    global _worker,_next
    if time.monotonic()<_next:return
    with _lock:
        if _worker is not None and _worker.is_alive():return
        from lib.viewer_profiles import ViewerAccount
        if isinstance(store,ViewerAccount):store=store.freeze()
        targets=[store]
        if isinstance(store,ViewerAccount) and store.identity:
            from lib.viewer_profiles import state
            targets=[ViewerAccount(store.directory,identity) for identity,row in state(store.directory).get('records',{}).items() if not row['deleted']]
        _next=time.monotonic()+5
        def run():
            global _next
            try:
                for target in targets:
                    while process_one(target):pass
            except Exception as error:
                Store(storage_directory(store)/'progress-sync-status').save({'error':failure_label(error),'attempt':time.time()})
                _next=time.monotonic()+60
        _worker=threading.Thread(target=run,daemon=True)
        try:_worker.start()
        except RuntimeError:
            _worker=None
            _next=time.monotonic()+5

def retry_now():
    global _next
    _next=0
