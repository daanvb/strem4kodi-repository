"""Pure state-aware action lists for long-press media menus."""


def episode_options(watched=False, prefix_watched=False, resume=False):
    return [
        {'action':'play', 'label':'Resume' if resume else 'Play', 'icon':'play'},
        {'action':'restart', 'label':'Play from Beginning', 'icon':'restart'},
        {'action':'manual-source', 'label':'Choose Source Manually', 'icon':'play'},
        {'action':'mark-watched', 'label':'Mark this episode watched', 'icon':'watched'},
        {'action':'mark-unwatched', 'label':'Mark this episode unwatched', 'icon':'unwatched'},
        {'action':'through-unwatched' if prefix_watched else 'through-watched',
         'label':'Mark all episodes unwatched to here' if prefix_watched else 'Mark all episodes watched to here',
         'icon':'through-unwatch' if prefix_watched else 'through-watch'},
    ]


def continue_options(kind, watched=False, partial=False):
    rows = [
        {'action':'restart', 'label':'Watch from Beginning', 'icon':'restart'},
        {'action':'mark-watched', 'label':'Mark as Watched', 'icon':'watched'},
        {'action':'mark-unwatched', 'label':'Mark as Unwatched', 'icon':'unwatched'},
        {'action':'remove-continue', 'label':'Remove from Continue Watching', 'icon':'remove'},
    ]
    return rows
