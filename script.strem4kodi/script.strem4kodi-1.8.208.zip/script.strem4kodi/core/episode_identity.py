"""Reconcile IMDb episode identities without rewriting watched history."""
import re

VERSION = 1


def coordinates(row):
    try:
        for value in (row.get('season'), row.get('episode', row.get('number'))):
            if isinstance(value, bool) or isinstance(value, float) and not value.is_integer():
                return None
        season = int(row['season'])
        episode = int(row.get('episode', row.get('number')))
        if season >= 0 and episode > 0:
            return season, episode
    except (KeyError, TypeError, ValueError, OverflowError):
        pass
    return None


def conflict(row, series_id=''):
    if row.get('_identity_conflict'):
        return True
    identity = str(row.get('id') or '')
    match = re.fullmatch(r'(tt\d+):(\d+):(\d+)', identity)
    if match:
        expected = int(match[2]), int(match[3])
        if re.fullmatch(r'tt\d+', series_id) and match[1] != series_id:return True
        for field, wanted in (('season', expected[0]), ('episode', expected[1]), ('number', expected[1])):
            if row.get(field) is None:continue
            try:
                if isinstance(row[field], bool) or float(row[field]) != wanted:return True
            except (TypeError, ValueError, OverflowError):return True
    return False


def reconcile(primary, reference, series_id):
    """Reference owns identity/text; preferred suppliers may still own artwork.

    Unmatched primary episodes remain available unless internally contradictory.
    Missing reference titles do not invent evidence or remove number fallbacks.
    """
    trusted = {}
    for row in reference:
        key = coordinates(row)
        if key is not None and not conflict(row, series_id) and row.get('id'):
            if key in trusted:
                trusted[key] = None  # An ambiguous reference cannot settle it.
            else:
                trusted[key] = row
    output, seen = [], set()
    for row in primary:
        copy = dict(row)
        parsed = re.fullmatch(re.escape(series_id) + r':(\d+):(\d+)', str(row.get('id') or ''))
        if parsed and not conflict(row, series_id):
            copy.setdefault('season', int(parsed[1]))
            if copy.get('episode', copy.get('number')) is None:copy['episode'] = int(parsed[2])
            row = copy
        key = coordinates(row)
        ref = trusted.get(key)
        if ref:
            # Numeric fields cannot override a contradictory canonical ID.
            match = re.fullmatch(re.escape(series_id) + r':(\d+):(\d+)', str(row.get('id') or ''))
            if match and (int(match[1]), int(match[2])) != key:
                continue  # The reference row below supplies this identity.
            for field in ('id', 'season', 'episode', 'number'):
                if field in ref:copy[field] = ref[field]
            if 'number' in copy:copy['number'] = ref.get('episode', ref.get('number'))
            title = str(ref.get('title') or ref.get('name') or '').strip()
            if title:
                changed = title != str(row.get('title') or row.get('name') or '').strip()
                copy['title'] = copy['name'] = title
                copy['_identity_reference'] = 'Cinemeta'
                if changed:
                    copy['_identity_reconciled'] = True
                    for field in ('overview', 'description', 'released', 'firstAired'):
                        copy.pop(field, None)
                        if ref.get(field):copy[field] = ref[field]
        elif conflict(copy, series_id):
            copy['_identity_conflict'] = True
        if copy.get('id') in seen:
            continue
        seen.add(copy.get('id'))
        output.append(copy)
    for ref in reference:
        if ref.get('id') not in seen and trusted.get(coordinates(ref)) is ref:
            output.append(dict(ref))
            seen.add(ref.get('id'))
    return output
