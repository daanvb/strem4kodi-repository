"""Manual watched and Continue Watching actions for media cards."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json

from account import AccountError, pull_library, request
from lib.progress_values import integer


def _stamp():
    return datetime.now(timezone.utc).isoformat(
        timespec='milliseconds').replace('+00:00', 'Z')


def _item(entries, meta):
    old = next((row for row in entries if isinstance(row, dict)
                and row.get('_id') == meta.get('id')
                and row.get('type') == meta.get('type')), None)
    if old:
        return deepcopy(old)
    stamp = _stamp()
    return {
        '_id': meta['id'], 'type': meta['type'],
        'name': meta.get('name') or meta['id'], 'poster': meta.get('poster'),
        'posterShape': meta.get('posterShape') or 'poster',
        'removed': True, 'temp': True, '_ctime': stamp, 'behaviorHints': {},
        'state': {'timeWatched': 0, 'timeOffset': 0, 'overallTimeWatched': 0,
                  'timesWatched': 0, 'flaggedWatched': 0, 'duration': 0}}


def apply_movie_watched(entries, meta, watched=True):
    if meta.get('type') != 'movie' or not meta.get('id'):
        raise AccountError('Movie watched state requires a movie.')
    item = _item(entries, meta)
    state = item.setdefault('state', {})
    state['timeOffset'] = 0
    state['timeWatched'] = 0
    state['flaggedWatched'] = 1 if watched else 0
    times = integer(state.get('timesWatched'))
    state['timesWatched'] = max(1, times) if watched else max(0, times - 1)
    state['lastWatched'] = _stamp()
    item['_mtime'] = state['lastWatched']
    return item


def apply_remove_continue(entries, meta):
    if not meta.get('id') or meta.get('type') not in ('movie', 'series'):
        raise AccountError('Continue Watching action requires a movie or series.')
    item = _item(entries, meta)
    state = item.setdefault('state', {})
    state['timeOffset'] = 0
    state['timeWatched'] = 0
    item['_mtime'] = _stamp()
    return item


def _sync(store, meta, mutate, request_func=None, pull_func=None, operation='remove-continue'):
    from lib.viewer_profiles import library_transport, ViewerAccount
    if isinstance(store, ViewerAccount):store = store.freeze()
    transport=library_transport(store)
    if transport:request_func,pull_func=transport
    request_func = request_func or request
    pull_func = pull_func or pull_library
    local = store.load()
    token = local.get('token')
    if not token:
        raise AccountError('Connect your Stremio account in Settings first.')
    latest = pull_func(token)
    from account import Store
    from lib.progress_outbox import owner
    from lib.viewer_profiles import storage_directory
    journal = Store(storage_directory(store)/'media-action-intent')
    rows = journal.load().get('rows') or {}
    key = hashlib.sha256(json.dumps([owner(token), meta['type'], meta['id']]).encode()).hexdigest()
    intent = rows.get(key) or {}
    item = intent.get('item') if intent.get('operation') == operation else None
    if not isinstance(item, dict):item = mutate(latest, meta)
    rows[key] = {'operation':operation, 'item':item}
    journal.save({'rows':rows})
    if store.load().get('token') != token:
        raise AccountError('Account changed during sync.')
    response = request_func('https://api.strem.io/api/datastorePut', {
        'authKey': token, 'collection': 'libraryItem', 'changes': [item]})
    if not isinstance(response, dict) or response.get('error'):
        raise AccountError('Stremio rejected the media action.')
    verified = pull_func(token)
    remote = next((r for r in verified if isinstance(r, dict) and
                   (r.get('_id'), r.get('type')) == (meta['id'], meta['type'])), None)
    if remote is None or remote.get('state') != item.get('state'):
        raise AccountError('Stremio did not confirm the media action. Please retry.')
    local = store.load()
    if local.get('token') != token:
        raise AccountError('Account changed during sync.')
    local['library'] = verified
    store.save(local)
    rows = journal.load().get('rows') or {}
    if rows.get(key) == {'operation':operation, 'item':item}:
        rows.pop(key, None)
        journal.save({'rows':rows})
    return verified


def sync_movie_watched(store, meta, watched=True):
    return _sync(store, meta, lambda rows, value: apply_movie_watched(rows, value, watched),
                 operation='movie-watched:' + str(bool(watched)))


def sync_remove_continue(store, meta):
    return _sync(store, meta, apply_remove_continue)
