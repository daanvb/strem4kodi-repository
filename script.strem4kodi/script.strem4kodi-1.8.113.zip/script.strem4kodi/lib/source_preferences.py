"""Local ranking preferences: soft priorities, never hardware compatibility claims."""
import re
from lib.stream_presenter import presentation, stream_traits, line

def preferences(addon):
    def choice(key,values):
        try:
            index=int(addon.getSetting(key) or '0')
            return values[index] if 0<=index<len(values) else values[0]
        except (ValueError,TypeError,IndexError):return values[0]
    return {'sort':choice('source_sort',('recommended','provider','smallest','largest','highest_bitrate')),
            'quality':choice('source_quality',('Any','4K','1080p','720p')),
            'maximum':choice('source_max_quality',('Any','4K','1080p','720p')),
            'dynamic':choice('source_dynamic',('Any','Dolby Vision','HDR10','FEL reported')),
            'provider':line(addon.getSetting('source_provider'),70),
            'source_type':choice('source_type',('Any','Remux','BluRay','WEB-DL','WEBRip')),
            'audio':choice('source_audio',('Any','Atmos','TrueHD','Dolby Digital Plus','AAC')),
            'language':line(addon.getSetting('source_language') or 'English',40)}

def rank_rows(rows,prefs):
    def score(row):
        traits=stream_traits(row);view=presentation(row)
        score=0
        if prefs.get('provider') and traits['provider'].casefold()==prefs['provider'].casefold():score+=32
        language=view['audio'].partition(' | Language: ')[2]
        wanted = prefs.get('language', '').casefold()
        tokens = set(re.findall(r'[a-z]+', language.casefold()))
        aliases = {'english', 'eng', 'en'} if wanted in ('english', 'eng', 'en') else {wanted}
        if wanted and tokens & aliases:score+=16
        if prefs.get('quality') not in (None,'Any') and traits['quality']==prefs['quality']:score+=8
        if prefs.get('dynamic') not in (None,'Any') and prefs['dynamic'] in traits['dynamic']:score+=4
        if prefs.get('audio') not in (None,'Any') and prefs['audio'].casefold() in view['audio'].casefold():score+=2
        wanted_source=prefs.get('source_type')
        if wanted_source not in (None,'','Any') and wanted_source.casefold() in {v.casefold() for v in traits.get('source_types',[])}:score+=16
        if row.get('_session_failed'):score-=128
        return score
    order=prefs.get('sort','recommended')
    if order=='provider':return sorted(rows,key=lambda r:bool(r.get('_session_failed')))
    if order in ('smallest','largest'):
        def size(row):
            match=re.fullmatch(r'(\d+(?:\.\d+)?)\s*(TiB|GiB|MiB|KiB|TB|GB|MB|KB|B)',stream_traits_size(row),re.I)
            if not match:return (bool(row.get('_session_failed')),True,0)
            value=float(match[1])*{'TB':1024*1024,'TIB':1024*1024,'GB':1024,'GIB':1024,'MB':1,'MIB':1,'KB':1/1024,'KIB':1/1024,'B':1/(1024*1024)}[match[2].upper()]
            return (bool(row.get('_session_failed')),False,value if order=='smallest' else -value)
        return sorted(rows,key=size)
    if order=='highest_bitrate':
        def bitrate(row):
            value=(row.get('card') or {}).get('bitrate') or stream_card_value(row).get('bitrate','')
            match=re.search(r'(?i)(\d+(?:[.,]\d+)?)\s*(Mbps|Mbit/s|kbps|bps)',str(value))
            if match:
                amount=float(match[1].replace(',','.'))
                unit=match[2].lower()
                mbps=amount if unit in ('mbps','mbit/s') else amount/1000 if unit=='kbps' else amount/1_000_000
            else:
                # Some integrations store the provider's raw bps number in
                # the normalized card instead of a display string.
                try:
                    raw=float(str(value).replace(',','.'))
                    mbps=raw/1_000_000 if 0<raw<1e10 else 0
                except (TypeError,ValueError,OverflowError):mbps=0
                if not mbps:return (bool(row.get('_session_failed')),True,0)
            return (bool(row.get('_session_failed')),False,-mbps)
        return sorted(rows,key=bitrate)
    return sorted(rows,key=score,reverse=True)

def stream_card_value(row):
    from core.stream_ui import stream_card
    return stream_card(row)

def stream_traits_size(row):
    from core.stream_ui import stream_card
    return (row.get('card') or {}).get('size') or stream_card(row).get('size','')

def limit_quality(rows,maximum='Any'):
    resolutions={'4K':2160,'1080p':1080,'720p':720,'480p':480,'360p':360}
    ceiling=resolutions.get(maximum)
    if ceiling is None:return list(rows)
    return [row for row in rows if resolutions.get(presentation(row)['quality'],0)<=ceiling]

def load_filters(addon):
    if addon.getSetting('source_remember_filters')!='true':return ('All','All','All')
    provider=addon.getSetting('source_filter_provider') or 'All'
    codec=addon.getSetting('source_filter_codec') or 'All'
    dynamic=addon.getSetting('source_filter_dynamic') or 'All'
    if codec not in ('All','HEVC / H.265','H.264 / AVC','AV1'):codec='All'
    if dynamic not in ('All','Dolby Vision','HDR10','HDR','FEL reported','P7 FEL reported','Profile 7 reported'):dynamic='All'
    return provider,codec,dynamic

def save_filters(addon,provider,codec,dynamic):
    if addon.getSetting('source_remember_filters')=='true':
        for key,value in (('provider',provider),('codec',codec),('dynamic',dynamic)):
            addon.setSetting('source_filter_'+key,value)


def picker_filters(addon):
    provider, _, dynamic = load_filters(addon)
    if addon.getSetting('source_remember_filters') != 'true':return provider,'All',dynamic,'All','All'
    return provider,'All',dynamic,addon.getSetting('source_filter_audio') or 'All',addon.getSetting('source_filter_quality') or 'All'
