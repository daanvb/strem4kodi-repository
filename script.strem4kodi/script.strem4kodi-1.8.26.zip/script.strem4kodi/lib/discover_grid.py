"""Catalogue rows with Home-sized artwork and two-axis browsing."""
import xml.etree.ElementTree as ET
from lib.cinematic_cards import posters, control

ROW_IDS = tuple(range(9500, 9564))
ROW_ITEMS = 12


def split(items, capacity=len(ROW_IDS)):
    """Keep every title; the final row may extend for very large lists."""
    rows = [items[i:i + ROW_ITEMS] for i in range(0, len(items), ROW_ITEMS)]
    if len(rows) > capacity:
        rows = rows[:capacity - 1] + [items[(capacity - 1) * ROW_ITEMS:]]
    return rows


def build(tree):
    controls = tree.getroot().find('controls')
    rows = tree.find('.//control[@id="2000"]')
    ET.SubElement(rows, 'visible').text = '!String.IsEqual(Window.Property(discover_grid),true)'
    group = ET.SubElement(controls, 'control', type='grouplist', id='9600')
    for tag, value in {'left':50, 'top':660, 'width':1800, 'height':420,
                       'orientation':'vertical', 'itemgap':0, 'scrolltime':180,
                       'usecontrolcoords':'true',
                       'visible':'String.IsEqual(Window.Property(discover_grid),true)'}.items():
        ET.SubElement(group, tag).text = str(value)
    for cid in ROW_IDS:
        listing = ET.SubElement(group, 'control', type='list', id=str(cid))
        for tag, value in {'width':1800, 'height':333, 'orientation':'horizontal',
                           'scrolltime':180, 'onup':9200 if cid == ROW_IDS[0] else cid-1,
                           'ondown':cid+1 if cid != ROW_IDS[-1] else cid,
                           'onleft':9000, 'onright':cid,
                           'visible':'String.IsEqual(Window.Property(has%s),true)' % cid}.items():
            ET.SubElement(listing, tag).text = str(value)
        for tag in ('itemlayout', 'focusedlayout'):
            ET.SubElement(listing, tag, width='230', height='333')
        posters(listing)
        for layout in (listing.find('itemlayout'), listing.find('focusedlayout')):
            for node in list(layout):
                if node.get('type') == 'label' and float(node.findtext('top', '0')) >= 320:
                    layout.remove(node)
            control(layout, 'textbox', left=24, top=100, width=182, height=110,
                    label='$INFO[ListItem.Label]', font='font23', textcolor='FFFFFFFF',
                    align='center', aligny='center',
                    visible='String.IsEqual(ListItem.Property(id),discover:load-more)')
