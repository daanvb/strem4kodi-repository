"""Persistent service: startup shell and watch-progress sync."""
import sys
import threading
import time
from pathlib import Path

_CORE = Path(__file__).resolve().parent / "core"
if str(_CORE) not in sys.path:
    sys.path.insert(0, str(_CORE))

import xbmc
import xbmcgui
import xbmcvfs

from account import Store
from addon_state import get_addon
from lib.playback_observer import ProgressPlayer, flush_pending
from lib.skip_segments import SkipSegmentWatcher
from lib.up_next import UpNextWatcher

ADDON = get_addon()
PROFILE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")))
SESSION_WINDOW_ID = 10000
STARTUP_LAUNCHED = "stremioforkodi.startup.launched"
APP_RUNNING = "stremioforkodi.running"
PROGRESS_READY = "stremioforkodi.progress.ready"
DELAYS = (0, 1, 2, 3, 5)


def configured_delay():
    try:
        index = int(ADDON.getSetting("startup_delay") or "0")
    except (TypeError, ValueError):
        index = 0
    return DELAYS[index] if 0 <= index < len(DELAYS) else 0


class ContinueIndexSync:
    INTERVAL = 60
    def __init__(self):
        self._next = 0
        self._maintenance_next = 0
        self._worker = None
        self._lock = threading.Lock()
    def tick(self):
        window=xbmcgui.Window(SESSION_WINDOW_ID)
        if window.getProperty("strem4kodi.sync.request"):
            window.clearProperty("strem4kodi.sync.request");self._next=0
            if window.getProperty("strem4kodi.sync.manual"):
                window.clearProperty("strem4kodi.sync.manual");self._maintenance_next=0
            from lib.progress_outbox import retry_now
            retry_now()
        now = time.time()
        if now < self._next:
            return
        with self._lock:
            if self._worker is not None and self._worker.is_alive():
                return
            self._next = now + self.INTERVAL
            try:
                self._worker = threading.Thread(target=self._run, daemon=True)
                self._worker.start()
            except RuntimeError:
                self._worker = None
    def _run(self):
        try:
            # Periodic account/CW sync is maintenance work; never compete with
            # active playback or overwrite progress while the watcher is writing it.
            if xbmc.Player().isPlayingVideo():
                return
            store = Store(PROFILE)
            state = store.load()
            token = state.get("token")
            if not token:
                return
            from account import AccountConflict, pull_library, pull_addons
            from addons_core import merge_account
            from lib import continue_index
            maintenance = time.time()>=self._maintenance_next
            if maintenance:
                try:
                    remote, _ = pull_addons(token)
                    state["addons"] = merge_account(state, remote)
                except Exception:
                    pass
            remote_library = pull_library(token)
            # Re-read after network I/O so unrelated concurrent state writes are
            # preserved. Merge only fields owned by this maintenance worker.
            latest = store.load()
            if latest.get("token")!=token or xbmc.Player().isPlayingVideo():return
            # A progress write completed during the pull: retry instead of replacing it.
            if latest.get("library") != state.get("library"):self._next=0;return
            from lib.progress_outbox import reconcile_library
            remote_library = reconcile_library(store, token, latest.get("library"), remote_library)
            changed=latest.get("library")!=remote_library
            state["library"] = remote_library
            try:
                # Save against the pre-fetch snapshot. Only our changed fields
                # merge; edits or disconnects during either network call win.
                store.save(state)
            except AccountConflict:
                self._next = 0
                return
            continue_index.seed(PROFILE, remote_library)
            if changed:
                from lib.progress_signal import publish
                publish({"meta_id":"*","video_id":""})
            Store(PROFILE/'sync-status').save({'updated':time.time()})
            # Resolve completed/sentinel series in this daemon worker, not Home.
            from continue_playback import continue_series_target
            from lib import backend as home_api
            for media_id, row in continue_index.unresolved_series(PROFILE, 8):
                try:
                    full = home_api.metadata(row)
                    target, resume_ms = continue_series_target(full.get("videos") or [], row)
                    projected = dict(row)
                    projected.update({k:v for k,v in full.items() if v not in ("",None,[],{})})
                    projected["id"] = media_id
                    status = str(full.get("status") or "").strip().lower()
                    confirmed = target is None and status in ("ended","canceled","cancelled")
                    continue_index.resolve_series(PROFILE, media_id, projected, target, resume_ms, confirmed)
                except Exception:
                    continue
            if changed:
                from lib.progress_signal import publish
                publish({"meta_id":"*","video_id":""})
            if not maintenance:return
            self._maintenance_next=time.time()+900
            # Source lookups belong to explicit title/source opening. Shared
            # format facts are refreshed by FormatSync without provider scans.
        except Exception:
            return


def maybe_autostart(monitor):
    if ADDON.getSetting("startup_autostart") != "true":
        return
    session = xbmcgui.Window(SESSION_WINDOW_ID)
    if session.getProperty(STARTUP_LAUNCHED) == "true":
        return
    session.setProperty(STARTUP_LAUNCHED, "true")
    delay = configured_delay()
    if delay and monitor.waitForAbort(delay):
        return
    if not monitor.abortRequested() and session.getProperty(APP_RUNNING) != "true":
        xbmc.executebuiltin("RunScript(script.strem4kodi,startup)")


def main():
    monitor = xbmc.Monitor()

    # Unit tests may execute main() with only the historical startup symbols.
    if "ProgressPlayer" not in globals():
        maybe_autostart(monitor)
        return

    from lib.diagnostic_events import install
    install(PROFILE)
    player = ProgressPlayer()
    from lib.service_guard import ServiceGuard
    guard = ServiceGuard(lambda message: xbmc.log(message, xbmc.LOGWARNING), profile=PROFILE)
    from lib.player_osd import PlayerOSD
    player_osd = PlayerOSD(player, ADDON)
    from lib.player_display import PlayerDisplay
    player_display = PlayerDisplay(player)
    from lib.forced_subtitles import ForcedSubtitleWatcher
    from setup_profile import rpc
    forced_subtitles = ForcedSubtitleWatcher(PROFILE, ADDON, player, xbmc,
                                            xbmcgui.Window(SESSION_WINDOW_ID), rpc)
    from lib.diagnostic_export import Reporter
    diagnostic_reporter = Reporter(PROFILE, ADDON, xbmcvfs.translatePath('special://logpath/'),
                                   idle=lambda: not xbmc.Player().isPlayingVideo(), player=player)
    from lib.series_tracks import Watcher as SeriesTracks
    series_tracks = SeriesTracks(PROFILE, player, xbmcgui.Window(SESSION_WINDOW_ID), rpc)
    continue_sync = ContinueIndexSync()
    skip_watcher = SkipSegmentWatcher(PROFILE)
    up_next = UpNextWatcher(PROFILE, player)
    from lib.credits_sync import CreditsSync
    credits_sync = CreditsSync(PROFILE,ADDON)
    from lib.saved_lists_sync import SavedListsSync
    saved_lists_sync = SavedListsSync(PROFILE, ADDON)
    from lib.home_state_sync import HomeStateSync
    home_state_sync = HomeStateSync(PROFILE, ADDON)
    from lib.preroll_catalog import Watcher as PreRollCatalogue
    preroll_catalogue = PreRollCatalogue(PROFILE, ADDON)
    from lib.format_sync import FormatSync
    format_sync = FormatSync(PROFILE, ADDON)
    from lib.fel_catalog import request as request_disc_formats
    guard.run('disc formats', request_disc_formats, PROFILE)
    session = xbmcgui.Window(SESSION_WINDOW_ID)
    session.setProperty(PROGRESS_READY, "true")
    try:
        guard.run('autostart', maybe_autostart, monitor)
        # Service updates can restart while a video is already playing.
        startup_tasks=(('account sync',continue_sync.tick),('credits sync',credits_sync.tick),
                       ('saved lists',saved_lists_sync.tick),('home sync',home_state_sync.tick),
                       ('format sync',format_sync.tick),('prerolls',preroll_catalogue.tick),
                       ('up next',up_next.tick),('skip segments',skip_watcher.tick))
        for name,callback in startup_tasks:guard.run(name,callback)
        tasks=(('diagnostics',diagnostic_reporter.tick),)+startup_tasks[:6]+(
            ('progress',player.tick),('series tracks',series_tracks.tick),
            ('forced subtitles',forced_subtitles.tick),('player display',player_display.tick),
            ('player controls',player_osd.tick))+startup_tasks[6:]
        from lib.progress_outbox import tick as outbox_tick
        progress_store=Store(PROFILE)
        while not monitor.waitForAbort(1):
            for name,callback in tasks:guard.run(name,callback)
            while guard.run('progress queue',flush_pending,player):
                pass
            guard.run('progress upload',outbox_tick,progress_store)
        guard.run('final progress',player._finish,False)
        while guard.run('progress queue',flush_pending,player):
            pass
    finally:
        recovery = getattr(player, '_live_recovery', None)
        if recovery:
            guard.run('live cancel',recovery.cancel)
            guard.run('live cleanup',recovery.finish_covers)
        guard.run('display cleanup',player_display.close)
        guard.run('up next cleanup',up_next.close)
        guard.run('skip cleanup',skip_watcher.close)
        guard.run('service marker cleanup',session.clearProperty,PROGRESS_READY)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        from lib.diagnostic_events import record
        record('service', error, PROFILE)
        raise
