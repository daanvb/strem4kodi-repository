"""Session-only recovery for explicitly selected sources; no URL logging/storage."""
import hashlib
import threading
import time

def digest(url):
    return hashlib.sha256(str(url).encode('utf-8')).hexdigest()

class RecoveryTracker:
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.lock=threading.RLock();self.pending=None;self.event=None
    def arm(self,url,identity,resume_ms,window):
        with self.lock:
            self.event=None
            self.pending={'hash':digest(url),'identity':identity,'resume':resume_ms,
                          'window':window,'created':self.clock(),'started':False}
    def started(self,url):
        with self.lock:
            if self.pending:
                if digest(url)!=self.pending['hash']:self.pending=None
                else:self.pending['started']=True
    def position(self,url,seconds):
        with self.lock:
            if self.pending and digest(url)==self.pending['hash']:
                self.pending['resume']=max(0,int(seconds*1000))
    def failed(self):
        with self.lock:
            if self.pending and (self.pending['started'] or self.clock()-self.pending['created']<120):
                self.event=dict(self.pending)
            self.pending=None
    def stopped(self):
        with self.lock:self.pending=None
    def take(self):
        with self.lock:
            event=self.event;self.event=None;return event
    def clear(self):
        with self.lock:self.pending=None;self.event=None

def player(tracker):
    import xbmc
    class RecoveryPlayer(xbmc.Player):
        def onAVStarted(self):
            try:tracker.started(self.getPlayingFile())
            except Exception:tracker.stopped()
        def onPlayBackError(self):tracker.failed()
        def onPlayBackStopped(self):tracker.stopped()
        def onPlayBackEnded(self):tracker.stopped()
    return RecoveryPlayer()
