"""Optional cached TMDB enrichment; Stremio metadata remains usable offline."""
import hashlib
from addon_state import get_addon
from lib.cache_policy import open_cache, read_policy


def lookup(meta, operation):
    key = get_addon().getSetting('tmdb_api_key').strip()
    if not key:
        return None
    policy = read_policy()
    cache = open_cache('metadata', policy)
    cache_key = 'tmdb-v1:' + hashlib.sha256(key.encode()).hexdigest() + ':' + operation + ':' + str(meta.get('type')) + ':' + str(meta.get('id'))
    try:
        cached = cache.get(cache_key) if cache else None
        if cached is not None:
            return cached
        from tmdb_metadata import credits, recommendations
        result = recommendations(meta, key) if operation == 'recommendations' else credits(meta, key, operation)
        if cache:
            cache.put(cache_key, result, policy['metadata'])
        return result
    except Exception:
        return None


def people(meta, role='cast'):
    from metadata_bridge import people as provider_people, _merge_people
    base = provider_people(meta, role)
    extra = lookup(meta, role) or []
    # Keep provider order and supplement missing portraits and specific jobs.
    return _merge_people(base + extra)


def recommendations(meta, providers=()):
    from metadata_bridge import recommendations as catalog_recommendations
    rows = lookup(meta, 'recommendations')
    return rows if rows else catalog_recommendations(meta, providers)
