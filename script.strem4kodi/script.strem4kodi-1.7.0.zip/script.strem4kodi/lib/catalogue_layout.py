"""Device-local catalogue artwork choices, keyed without storing provider URLs."""
import hashlib
from pathlib import Path
from account import Store


def key(catalog):
    parts = (catalog.get('url') or '', catalog.get('kind') or '',
             catalog.get('catalog_id') or catalog.get('id') or '')
    return hashlib.sha256('\n'.join(str(p) for p in parts).encode()).hexdigest()


def load(profile, catalog):
    return (Store(Path(profile)/'catalogue-layouts').load().get('layouts') or {}).get(key(catalog), 'posters')


def save(profile, catalog, value):
    if value not in ('posters', 'wide'):raise ValueError('Unknown catalogue layout')
    store=Store(Path(profile)/'catalogue-layouts')
    values=store.load().get('layouts') or {}
    values[key(catalog)]=value
    store.save({'layouts':values})


def wide_art(row):
    return row.get('landscape') or row.get('thumbnail') or row.get('background') or row.get('poster') or ''


def add_layouts(listing, cid):
    import xml.etree.ElementTree as ET
    base='special://home/addons/script.strem4kodi/resources/skins/Main/media/'
    for tag in ('itemlayout','focusedlayout'):
        existing=listing.find(tag)
        if existing is None:continue
        existing.set('condition', '!String.IsEqual(Window.Property(layout%d),wide)' % cid)
        wide=ET.Element(tag, width='380', height=existing.get('height','393'),
                        condition='String.IsEqual(Window.Property(layout%d),wide)' % cid)
        def control(kind, x,y,w,h,values):
            c=ET.SubElement(wide,'control',type=kind)
            for name,value in dict(left=x,top=y,width=w,height=h,**values).items():ET.SubElement(c,name).text=str(value)
            return c
        control('image',10,18,356,200,{'texture':base+'episode-card-local/mask.png','colordiffuse':'FF15171C'})
        control('image',10,18,356,200,{'texture':'$INFO[ListItem.Property(wide_art)]','aspectratio':'keep'})
        control('label',18,232,340,42,{'font':'font23_title' if tag=='focusedlayout' else 'font23','textcolor':'FFFFFFFF','label':'$INFO[ListItem.Label]','scroll':'true'})
        if tag=='focusedlayout':control('image',10,216,356,4,{'texture':base+'solid.png','colordiffuse':'FF6EC3FF'})
        listing.insert(list(listing).index(existing),wide)
