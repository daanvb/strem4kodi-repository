"""Remote-friendly channel/event guide over the already-loaded sports catalogue."""
import time
import threading
import xbmcgui

from lib import sports_epg as epg
from lib.theme import PALETTES, index, window as themed_window
from addon_state import get_addon

WHITE = 'special://home/addons/script.strem4kodi/resources/branding/white.png'
TRANSPARENT = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/progress-local/transparent.png'
GRID_LEFT, GRID_WIDTH = 360, 1500
ROWS_TOP, ROW_PITCH, ROW_HEIGHT = 246, 74, 64
IDLE_REFRESH = 199
TOOLBAR = (101, 103, 104, 105, 106)


class SidebarAction:
    def __init__(self, control, cover=None):
        self.control = control
        self.cover = cover


class SportsGuide(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        from lib.window_lifetime import Lifetime
        self._lifetime = Lifetime()
        self._idle_lock = threading.Lock()
        self._idle_owner = None
        self._refresh_pending = False
        self._modal_depth = 0
        self.on_ready = kwargs.pop('on_ready', None)
        self._owner_window = kwargs.pop('owner_window_id', None)
        rows = kwargs.pop('rows')
        self.state = kwargs.pop('state', None)
        self.closed = False
        self.rows = rows
        self.role = epg.catalogue_role(kwargs.pop('catalogue_role', '') or kwargs.get('heading'))
        self.entries = epg.entries(rows, time.time(), self.role)
        self.more_row = next((row for row in rows if isinstance(row, dict) and row.get('_discover_load_more')), None)
        self.heading = epg.plain(kwargs.pop('heading'))
        self.path = kwargs.pop('path', '')
        self.catalogues = kwargs.pop('catalogues', [])
        self.catalogue_id = kwargs.pop('catalogue_id', None)
        self.load_catalogue = kwargs.pop('load_catalogue', None)
        self.competition = (self.state or {}).get('competition', '')
        self.competition_options = epg.competition_options(rows)
        self.competitions = [option['key'] for option in self.competition_options]
        position = kwargs.pop('position', 0)
        target = rows[position] if type(position) is int and 0 <= position < len(rows) else None
        self.selected = next((i for i, value in enumerate(self.entries)
                              if isinstance(target, dict) and
                              (value['row'].get('type'), value['row'].get('id')) ==
                              (target.get('type'), target.get('id'))), 0)
        self.start = (self.state or {}).get('start', epg.window_start(time.time()))
        self.result = None
        self.dynamic = []
        self.row_buttons = []
        self._rendering = False
        self.cells = {}
        self.highlights = {}
        self.palette = PALETTES[index(get_addon())]
        super().__init__(*args, **kwargs)

    def close(self):
        with self._lifetime.lock:
            if self.closed:
                return
            self.closed = True
        with self._idle_lock:
            self._refresh_pending = False
        if isinstance(self.state, dict):
            self.state.update(start=self.start, competition=self.competition)
        self._lifetime.retire(super().close)

    def setProperty(self, key, value):
        return self._lifetime.publish(super().setProperty, key, value)

    def setFocusId(self, identity):
        return self._lifetime.publish(super().setFocusId, identity)

    def setFocus(self, control):
        return self._lifetime.publish(super().setFocus, control)

    def getFocusId(self):
        return self._lifetime.call(super().getFocusId)

    def onInit(self):
        if self.closed:
            return
        self.setProperty('guide_heading', 'Sports guide · ' + self.heading)
        self.setProperty('guide_catalogue', self.heading)
        self.setProperty('guide_more', 'true' if self.more_row is not None else '')
        self.update_competition_properties()
        self.render()
        try:
            window = self._owner_window if self._owner_window is not None else xbmcgui.getCurrentWindowId()
            owner = window, xbmcgui.getCurrentWindowDialogId()
            if (all(type(value) is int and value > 9999 for value in owner)
                    and owner[0] != 12005):
                self._idle_owner = owner
        except (AttributeError, RuntimeError):
            pass  # Unknown native ownership disables idle publications.
        if self.on_ready is not None and not self.closed:
            self.on_ready(self)

    def _visible(self):
        if self.closed or self._idle_owner is None or self._modal_depth:
            return False
        try:
            return self._idle_owner == (xbmcgui.getCurrentWindowId(), xbmcgui.getCurrentWindowDialogId())
        except (AttributeError, RuntimeError):
            return False

    def queue_refresh(self, post, now=None):
        """Existing browse tick posts one click; only the GUI callback renders."""
        minute = int((time.time() if now is None else now) // 60)
        if self.closed or self._rendering or self._modal_depth or minute == getattr(self, '_rendered_minute', None):
            return False
        with self._idle_lock:
            if self._refresh_pending:
                return False
        if not self._visible():
            return False
        with self._idle_lock:
            if self.closed or self._refresh_pending or self._rendering or self._modal_depth:
                return False
            self._refresh_pending = True
        try:
            post(self._idle_owner[1], IDLE_REFRESH)
        except Exception:
            with self._idle_lock:
                self._refresh_pending = False
            raise
        return True

    def _refresh_idle(self):
        with self._idle_lock:
            pending, self._refresh_pending = self._refresh_pending, False
        if (not pending or not self._visible() or self._rendering
                or int(time.time() // 60) == self._rendered_minute):
            return
        focus = self.getFocusId()
        self.render(toolbar=focus if focus in TOOLBAR else None)

    def _with_modal(self, callback):
        self._modal_depth += 1
        try:
            return callback()
        finally:
            self._modal_depth -= 1

    def update_competition_properties(self):
        if self.competition not in self.competitions:
            self.competition = ''
        label = next((option['label'] for option in self.competition_options
                      if option['key'] == self.competition), '')
        self.setProperty('guide_competition', label or 'All competitions')
        self.setProperty('guide_competitions', 'true' if self.competitions else '')

    def label(self, x, y, width, height, text, color='FFE5E5E7', font='Strem4Kodi21'):
        control = xbmcgui.ControlLabel(x, y, width, height, text, font=font, textColor=color)
        self.dynamic.append(control)
        return control

    def image(self, x, y, width, height, color):
        control = xbmcgui.ControlImage(int(x), y, max(1, int(width)), height, WHITE, colorDiffuse=color)
        self.dynamic.append(control)
        return control

    def render(self, toolbar=None):
        if self.closed:
            return
        self._rendering = True
        with self._idle_lock:
            self._refresh_pending = False
        try:
            self._lifetime.publish(self._render, toolbar)
        finally:
            self._rendering = False

    def _render(self, toolbar=None):
        # Keep native focus targets alive across scrolling. Removing a focused
        # dynamic button lets Kodi fall back to the sport selector mid-gesture.
        if not self.row_buttons:
            self.row_buttons = [xbmcgui.ControlButton(50, ROWS_TOP + i * ROW_PITCH, 1810, ROW_HEIGHT, '',
                focusTexture=TRANSPARENT, noFocusTexture=TRANSPARENT, font='Strem4Kodi21')
                for i in range(epg.PAGE_ROWS)]
            self.addControls(self.row_buttons)
            for button in self.row_buttons:
                button.setNavigation(button, button, button, button)
        if self.dynamic:
            self.removeControls(self.dynamic)
        self.dynamic = []
        self.cells = {}
        self.highlights = {}
        now = time.time()
        selected = self.entries[self.selected]['row'] if self.entries else None
        identity = (selected.get('type'), selected.get('id')) if selected else None
        self.entries = epg.entries(epg.competition_rows(self.rows, self.competition), now, self.role)
        if identity:
            self.selected = next((i for i, value in enumerate(self.entries)
                                  if (value['row'].get('type'), value['row'].get('id')) == identity), self.selected)
        self.selected = min(self.selected, max(0, len(self.entries) - 1))
        self._rendered_minute = int(now // 60)
        self.setProperty('guide_date', epg.local_time(self.start, date=True))
        page = self.selected // epg.PAGE_ROWS * epg.PAGE_ROWS
        self.setProperty('guide_count', '{}–{} of {} listings · UK time'.format(
            page + 1 if self.entries else 0, min(page + epg.PAGE_ROWS, len(self.entries)), len(self.entries)))
        for tick in range(7):
            x = GRID_LEFT + tick * 250
            self.label(min(x, 1760), 202, 100, 32, epg.local_time(self.start + tick * epg.STEP))
        now_x = min(GRID_LEFT + int((now - self.start) / epg.SPAN * GRID_WIDTH), 1856) if self.start <= now < self.start + epg.SPAN else None
        if now_x is not None:
            badge_x = max(GRID_LEFT, min(now_x - 70, GRID_LEFT + GRID_WIDTH - 150))
            self.image(badge_x, 182, 150, 48, self.palette[5])
            self.label(badge_x + 8, 188, 138, 32, 'NOW ' + epg.local_time(now), self.palette[0], 'Strem4Kodi20Bold')
            self.image(now_x, 230, 4, 530, self.palette[5])
        else:
            before = now < self.start
            x = GRID_LEFT if before else GRID_LEFT + GRID_WIDTH - 180
            self.image(x, 182, 180, 48, self.palette[5])
            self.label(x + 8, 188, 164, 32, ('← NOW ' if before else 'NOW ') + epg.local_time(now) + ('' if before else ' →'), self.palette[0])
        for i, button in enumerate(self.row_buttons):
            button.setVisible(i < len(self.entries[page:page + epg.PAGE_ROWS]))
        for offset, value in enumerate(self.entries[page:page + epg.PAGE_ROWS]):
            position = page + offset
            y = ROWS_TOP + offset * ROW_PITCH
            self.highlights[position] = self.image(50, y, 1810, ROW_HEIGHT, self.palette[0])
            self.image(GRID_LEFT, y, GRID_WIDTH, ROW_HEIGHT, self.palette[2])
            self.label(64, y + 2, 275, 32, value['title'])
            live = epg.status(value, now) == 'Live'
            self.label(64, y + 35, 275, 26, '● LIVE' if live else epg.status(value, now),
                       'FF83CEA1' if live else 'FFADACB5')
            geometry = epg.block(value, self.start)
            if geometry is not None:
                x, width = geometry
                self.image(GRID_LEFT + x, y + 4, width, ROW_HEIGHT - 8, 'FF21583E' if live else self.palette[3])
                if live:
                    self.image(GRID_LEFT + x, y + 4, width, 3, 'FF83CEA1')
                    self.image(GRID_LEFT + x, y + ROW_HEIGHT - 7, width, 3, 'FF83CEA1')
            elif live and value['continuous']:
                # A full-width interval is truthful only for 24-hour feeds.
                # Untimed events remain visibly LIVE without suggesting that
                # their start/end covers the entire displayed guide window.
                self.image(GRID_LEFT, y + 4, GRID_WIDTH, ROW_HEIGHT - 8, 'FF21583E')
            if now_x is not None:
                self.image(now_x, y, 4, ROW_HEIGHT, self.palette[5])
            # Transparent focus targets keep start markers readable on selection.
            button = self.row_buttons[offset]
            self.cells[position] = button
            kickoff = epg.marker(value, self.start)
            text = epg.clock_label(value)
            if kickoff is not None:
                x = GRID_LEFT + kickoff
                self.image(x, y + 6, 4, ROW_HEIGHT - 12, 'FFFFBB55')
                self.image(x - 2, y + 4, 8, 8, 'FFFFBB55')
                label_x = x + 14 if x + 14 + 470 <= GRID_LEFT + GRID_WIDTH else max(GRID_LEFT, x - 482)
                label_width = min(470, x - label_x - 12) if label_x < x else 470
            else:
                label_x = GRID_LEFT + 18
                label_width = 570
                if value['start'] is not None and not epg.fixture_status(value):
                    text = ('← ' if value['start'] < self.start else '→ ') + text
            end = epg.effective_end(value)
            if end is not None and self.start <= end <= self.start + epg.SPAN:
                end_x = min(GRID_LEFT + GRID_WIDTH - 4, GRID_LEFT + int((end - self.start) / epg.SPAN * GRID_WIDTH))
                self.image(end_x, y + 6, 4, ROW_HEIGHT - 12, 'FF83CEA1')
                self.image(end_x - 2, y + ROW_HEIGHT - 12, 8, 8, 'FF83CEA1')
            duration = epg.duration_label(value)
            if duration:
                text += ' · ' + duration
            self.label(int(label_x), y + 17, int(min(label_width, GRID_LEFT + GRID_WIDTH - int(label_x) - 10)), 32, text)
        if not self.entries:
            self.label(360, 300, 1450, 60, 'No loaded sports listings. Choose a sports list first.')
        self.addControls(self.dynamic)
        if toolbar is not None:
            self.setFocusId(toolbar)
        elif self.selected in self.cells:
            self.setFocus(self.cells[self.selected])
        else:
            self.setFocusId(105)
        self.update_details()

    def update_details(self):
        return self._lifetime.publish(self._update_details)

    def _update_details(self):
        focus = self.getFocusId()
        for position, background in self.highlights.items():
            background.setColorDiffuse(self.palette[4] if self.cells[position].getId() == focus else self.palette[0])
        if not self.entries:
            self.setProperty('guide_title', '')
            self.setProperty('guide_description', '')
            return
        value = self.entries[self.selected]
        self.setProperty('guide_title', value['title'] + ' · ' + epg.caption(value, time.time()))
        self.setProperty('guide_description', value['description'] or 'No description supplied.')

    def onFocus(self, control):
        if not self.closed:
            self._lifetime.publish(self._onFocus, control)

    def _onFocus(self, control):
        if self._rendering or control != self.getFocusId():
            return
        for position, button in self.cells.items():
            if button.getId() == control:
                self.selected = position
                break
        self.update_details()

    def open_sidebar(self):
        from lib.guide_sidebar import show
        focus = self.getFocusId()
        selected = show(self.path)
        if self.closed:
            return
        if selected in (None, 207):
            self.setFocusId(focus)
            return
        from lib.navigation_cover import Cover
        from lib.sidebar_nav import ENTRIES
        title = next((entry[0] for entry in ENTRIES if entry[1] == selected), 'Strem4Kodi')
        cover = Cover()
        self.result = SidebarAction(selected, cover)
        try:
            cover.show('Opening ' + title + '…', self.close)
        except Exception:
            self.result.cover = None
            self.close()

    def onAction(self, action):
        if self.closed:
            return
        aid = action.getId()
        if aid in (10, 92, 216, 247):
            self._with_modal(self.open_sidebar)
            return
        self._lifetime.publish(self._navigate, aid)

    def _navigate(self, aid):
        focus = self.getFocusId()
        if getattr(self, '_rendered_minute', None) != int(time.time() // 60):
            self.render(toolbar=focus if focus in TOOLBAR else None)
            focus = self.getFocusId()
        if focus in TOOLBAR:
            if aid == 4 and self.cells:
                self.setFocus(self.cells[self.selected])
            return
        if aid in (1, 2):
            self.start += -epg.STEP if aid == 1 else epg.STEP
            self.render()
        elif aid in (3, 4, 5, 6):
            delta = {3: -1, 4: 1, 5: -epg.PAGE_ROWS, 6: epg.PAGE_ROWS}[aid]
            target = self.selected + delta
            if target < 0 and aid == 3:
                self.setFocusId(105)
                return
            self.selected = max(0, min(max(0, len(self.entries) - 1), target))
            if self.selected in self.cells:
                self.setFocus(self.cells[self.selected])
                self.update_details()
            else:
                self.render()

    def onClick(self, control):
        if self.closed:
            return
        if control == IDLE_REFRESH:
            self._lifetime.publish(self._refresh_idle)
        elif control == 103:
            self._with_modal(self.open_sidebar)
        elif control == 104 and self.more_row is not None:
            self.result = self.more_row
            self.close()
        elif control == 105:
            self._with_modal(self.choose_catalogue)
        elif control == 106:
            self._with_modal(self.choose_competition)
        elif control == 101:
            self.start = epg.window_start(time.time())
            self.render(toolbar=control)
        else:
            self._lifetime.publish(self._choose_row, control)

    def _choose_row(self, control):
        for position, button in self.cells.items():
            if button.getId() == control:
                self.result = self.entries[position]['row']
                self.close()
                break

    def choose_catalogue(self):
        if not self.catalogues or self.load_catalogue is None:
            return
        from lib.nimbus_select import Dialog
        current = next((i for i, c in enumerate(self.catalogues) if c['id'] == self.catalogue_id), -1)
        # A nested modal leaves this guide visible underneath the list picker.
        selected = Dialog(self.path, left=50, top=190).select(
            'Sports list', [c['label'] for c in self.catalogues], preselect=current)
        if self.closed:
            return
        self.setFocusId(105)
        self.update_details()
        if selected < 0 or selected >= len(self.catalogues) or selected == current:
            return
        catalogue = self.catalogues[selected]
        rows = self.load_catalogue(catalogue)
        if self.closed:
            return
        if rows is None:  # Cancelled/failed loads keep the current guide intact.
            self.setProperty('guide_count', 'Unable to load sports list. Choose the list again to retry.')
            return
        self.rows = rows
        self.role = epg.catalogue_role(catalogue)
        self.entries = epg.entries(rows, time.time(), self.role)
        self.more_row = next((row for row in rows if isinstance(row, dict) and row.get('_discover_load_more')), None)
        self.catalogue_id = catalogue['id']
        self.heading = epg.plain(catalogue['label'])
        self.competition = ''
        self.competition_options = epg.competition_options(rows)
        self.competitions = [option['key'] for option in self.competition_options]
        self.selected = 0
        self.setProperty('guide_heading', 'Sports guide · ' + self.heading)
        self.setProperty('guide_catalogue', self.heading)
        self.setProperty('guide_more', 'true' if self.more_row is not None else '')
        self.update_competition_properties()
        self.render(toolbar=105)

    def choose_competition(self):
        if not self.competitions:
            return
        from lib.nimbus_select import Dialog
        options = ['All competitions'] + [option['label'] for option in self.competition_options]
        current = self.competitions.index(self.competition) + 1 if self.competition in self.competitions else 0
        selected = Dialog(self.path, left=362, top=190).select(
            'Competition', options, preselect=current)
        if self.closed:
            return
        self.setFocusId(106)
        self.update_details()
        if selected < 0 or selected >= len(options) or selected == current:
            return
        self.competition = '' if selected == 0 else self.competitions[selected - 1]
        self.selected = 0
        self.update_competition_properties()
        self.render(toolbar=106)


def show(path, rows, heading, position=0, **options):
    guide = themed_window(SportsGuide, 'script-stremio-sports-guide.xml', path, 'Main', '1080i',
                          rows=rows, heading=heading, position=position, path=path, **options)
    try:
        guide.doModal()
        return guide.result
    finally:
        guide.close()
