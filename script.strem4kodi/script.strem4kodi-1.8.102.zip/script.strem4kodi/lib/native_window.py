"""Retire a full Kodi window before releasing its reusable native ID."""


def wait_retired(window_id, kodi, gui):
    if type(window_id) is not int or not 13000 <= window_id < 13200:
        return True
    for _ in range(40):
        if (gui.getCurrentWindowId() != window_id
                and kodi.getCondVisibility('Window.IsVisible({})'.format(window_id)) is not True):
            return True
        kodi.sleep(50)
    return False
