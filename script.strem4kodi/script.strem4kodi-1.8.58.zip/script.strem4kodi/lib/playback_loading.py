"""Attempt-bound playback loading screen; never stores stream URLs."""
import json
import threading
import time
import uuid
from lib.stream_presenter import line

CANCEL_KEY='strem4kodi.playback.cancelled'
ACTIVE_KEY='strem4kodi.loading.active'
_visibility_lock=threading.RLock()


def _busy_owner(token, clear=False):
    """Suppress only the companion skin's duplicate busy artwork, not Kodi's work."""
    try:
        import xbmcgui
        with _visibility_lock:
            home=xbmcgui.Window(10000)
            if clear:
                if home.getProperty(ACTIVE_KEY)==token:home.clearProperty(ACTIVE_KEY)
            else:home.setProperty(ACTIVE_KEY,token)
    except (ImportError,AttributeError,RuntimeError):pass

def _initial_layout(tree,title,detail,art):
    """Populate the very first frame, before Kodi queues Python onInit."""
    art=dict(art or {})
    for cid,value in ((301,art.get('stage') or 'Starting playback'),(302,title),
                      (303,art.get('hint') or 'Opening your selected source'),
                      (304,detail),(311,art.get('trivia_label') or ''),(312,art.get('trivia') or '')):
        tree.find('.//control[@id="{}"]/label'.format(cid)).text=value
    for cid,key in ((305,'poster'),(307,'background')):
        tree.find('.//control[@id="{}"]/texture'.format(cid)).text=art.get(key) or ''
    # Keep the optional frame absent even before the first callback arrives.
    if not art.get('trivia'):
        group=tree.find('.//control[@id="310"]')
        for child in list(group):
            if child.get('type')=='image':group.remove(child)
    if art.get('poster'):
        tree.find('.//control[@id="306"]/texture').text=''

def cancelled(attempt):
    if not attempt:return False
    import xbmcgui
    try:return attempt in json.loads(xbmcgui.Window(10000).getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):return False

def signal_cancel(attempt):
    if not attempt:return
    import xbmcgui
    window=xbmcgui.Window(10000)
    try:rows=json.loads(window.getProperty(CANCEL_KEY) or '[]')
    except (ValueError,TypeError):rows=[]
    if not isinstance(rows,list):rows=[]
    window.setProperty(CANCEL_KEY,json.dumps((rows+[attempt])[-16:]))

def _make_window(title,detail,on_cancel,art=None):
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window as themed_window
    class LoadingWindow(xbmcgui.WindowXMLDialog):
        initialized=False
        dismissed=False
        def update(self,title,detail='',art=None):
            self.content=(title,detail,dict(art or {}))
            if not self.initialized or self.dismissed:return
            # Modeless dialog Window.Property can resolve against the underlying
            # media window. Address this dialog's own controls for every field.
            title,detail,art=self.content
            self.getControl(301).setLabel(art.get('stage') or 'Starting playback')
            self.getControl(302).setText(title)
            self.getControl(303).setText(art.get('hint') or 'Opening your selected source')
            self.getControl(304).setText(detail)
            for cid,name in ((305,'poster'),(307,'background')):
                self.getControl(cid).setImage(art.get(name) or '')
                self.getControl(cid).setVisible(bool(art.get(name)))
            self.getControl(306).setVisible(not bool(art.get('poster')))
            self.getControl(310).setVisible(bool(art.get('trivia')))
            self.getControl(311).setLabel(art.get('trivia_label') or '')
            self.getControl(312).setText(art.get('trivia') or '')
        def hint(self,text):
            title,detail,art=self.content
            art['hint']=text
            self.content=(title,detail,art)
            if self.initialized:self.getControl(303).setText(text)
        def fact(self,label,text):
            title,detail,art=self.content
            self.content=(title,detail,dict(art,trivia_label=label,trivia=text))
            if self.initialized and not self.dismissed:
                self.getControl(311).setLabel(label)
                self.getControl(312).setText(text)
        def onInit(self):
            if self.dismissed:
                self.close()
                return
            self.initialized=True
            self.update(*self.content)
            self.setFocusId(201)
        def onAction(self,action):
            if action.getId() in (10,13,92,216,247):on_cancel()
        def onClick(self,control_id):
            if control_id==201:on_cancel()
    window=themed_window(LoadingWindow,'script-strem4kodi-loading.xml',
                         get_addon().getAddonInfo('path'),'Main','1080i',
                         layout_transform=lambda tree:_initial_layout(tree,title,detail,art))
    window.update(title,detail,art)
    return window

class LoadingSession:
    def __init__(self,on_cancel,factory=_make_window,state=None,ready=None,clock=time.monotonic,
                 thread_factory=threading.Thread):
        self.on_cancel=on_cancel;self.factory=factory
        self.lock=threading.RLock();self.attempt='';self.window=None
        self.state=state;self.ready=ready;self.clock=clock
        self.created=0;self.elapsed=-1;self.wake=threading.Event()
        self.lifetime=None;self.content=None;self.ui_thread=None
        self.visibility_token=''
        self.rotation_wake=threading.Event();self.rotation_due=0
        self.thread_factory=thread_factory
        self.cancel_done=threading.Event();self.cancel_done.set()
    def begin(self,attempt,title,detail='',art=None):
        self.finish()
        with self.lock:
            self.attempt=attempt
            self.created=self.clock();self.elapsed=-1;self.wake=threading.Event()
            self.content=(line(title,110),line(detail,140),dict(art or {}))
            self.rotation_wake=threading.Event();self.rotation_due=self.clock()+10
            lifetime=self.lifetime=object()
            self.visibility_token=uuid.uuid4().hex
            _busy_owner(self.visibility_token)
            self.ui_thread=self.thread_factory(target=self._run_dialog,args=(lifetime,),daemon=True)
            self.ui_thread.start()
            if len(self.content[2].get('trivia_choices') or [])>1:
                self.thread_factory(target=self._rotate_facts,args=(lifetime,self.rotation_wake),daemon=True).start()
            if self.state is not None:
                threading.Thread(target=self._watch,args=(attempt,self.wake),daemon=True).start()
    def _run_dialog(self,lifetime):
        """Create AND pump on the same live thread; never nest in a media callback.

        Kodi binds callbacks to the Python thread that constructs the window.
        A parent callback must return so provider updates can acquire its native
        window lock. Calling doModal inside that callback stalls those updates.
        """
        window=None
        try:
            with self.lock:
                if self.lifetime is not lifetime:return
                title,detail,art=self.content
            arguments=(title,detail,lambda:self._cancel_window(window))
            window=self.factory(*arguments,art) if art else self.factory(*arguments)
            with self.lock:
                if self.lifetime is not lifetime:
                    window.dismissed=True
                    return
                self.window=window
                content=self.content
            window.update(*content)
            window.doModal()
        except Exception:
            pass  # Native GUI failures must not print a private source/title.
        finally:
            self.finish(lifetime=lifetime)
    def _cancel_window(self,window):
        self.cancel(window=window)
    def advance(self,attempt,title,detail='',art=None,on_cancel=None,state=None,ready=None):
        """Transfer search to playback without closing or allocating a dialog."""
        with self.lock:
            if not self.attempt:return False
            self.wake.set()
            self.attempt=attempt
            self.on_cancel=on_cancel or self.on_cancel
            self.state,self.ready=state,ready
            self.created=self.clock();self.elapsed=-1;self.wake=threading.Event()
            next_art=dict(art or {})
            # Handover retains both the current fact and the ten-second cadence.
            previous=self.content[2] if self.content else {}
            for key in ('trivia','trivia_label','trivia_choices'):
                if key in previous:next_art[key]=previous[key]
            self.content=(line(title,110),line(detail,140),next_art)
            window=self.window
            content=self.content
            if state is not None:
                threading.Thread(target=self._watch,args=(attempt,self.wake),daemon=True).start()
        if window:window.update(*content)
        return True
    def hint(self,text):
        with self.lock:
            if not self.content:return
            title,detail,art=self.content
            self.content=(title,detail,dict(art,hint=text))
            window=self.window
        if window:window.hint(text)
    def _rotate_facts(self,lifetime,wake):
        while not wake.wait(.2):
            try:self.rotate_fact(lifetime)
            except Exception:pass  # Optional facts never interrupt playback or Cancel.
    def rotate_fact(self,lifetime):
        with self.lock:
            if self.lifetime is not lifetime or self.clock()<self.rotation_due or not self.content:return
            title,detail,art=self.content
            choices=art.get('trivia_choices') or []
            if len(choices)<2:return
            current=(art.get('trivia_label'),art.get('trivia'))
            position=next((i for i,row in enumerate(choices) if tuple(row)==current),-1)
            label,text=choices[(position+1)%len(choices)]
            self.content=(title,detail,dict(art,trivia_label=label,trivia=text))
            self.rotation_due=self.clock()+10
            window=self.window
        if window:window.fact(label,text)
    def _watch(self,attempt,wake):
        """Keep overlay cleanup independent of the media-details refresh thread."""
        while not wake.wait(.2):
            try:
                pending=self.state()
                ready=bool(self.ready and self.ready())
                self.check(attempt,pending,ready)
            except Exception:
                # Even unavailable player/state queries cannot strand the dialog.
                self.check(attempt,{'attempt':attempt,'started':False})
    def check(self,attempt,pending,ready=False):
        text=None
        with self.lock:
            if self.attempt!=attempt:return
            done=ready or self.clock()-self.created>=50
            if not done:
                elapsed = int(max(0, self.clock() - self.created))
                if elapsed != self.elapsed:
                    self.elapsed = elapsed
                    text='This source is taking longer. You can cancel and choose another.' if elapsed >= 15 else 'Opening your selected source'
        if done:self.finish(attempt)
        else:
            if text:self.hint(text)
            self.observe(pending,ready=ready,attempt=attempt)
    def cancel(self,attempt=None,window=None):
        with self.lock:
            if window is not None:
                if window is not self.window:return
                attempt=self.attempt
            if not attempt:return
            if self.attempt!=attempt:return
            signal_cancel(attempt)
            callback=self.on_cancel
            self.cancel_done.clear()
            # Consume ownership atomically with the token. A simultaneous
            # search-to-playback advance cannot retarget a cancelled dialog.
            window=self._detach()
        from lib.playback_timing import mark
        mark(attempt,'cancelled')
        self._close(window)
        # Return from Kodi's onAction immediately. It holds this dialog's native
        # object lock; a provider can hold the parent lock while updating it.
        # Closing first, then cleaning up off-callback, prevents that lock cycle.
        def cleanup():
            try:callback()
            except Exception:pass
            finally:self.cancel_done.set()
        self.thread_factory(target=cleanup,daemon=True).start()
    def observe(self,pending,ready=None,attempt=None):
        # Native queries must run outside our lock, as they can pump GUI callbacks.
        started=pending and pending.get('started')
        if ready is None:
            ready=bool(started and (self.ready is None or self.ready()))
        with self.lock:
            if attempt is not None and self.attempt!=attempt:return
            attempt=self.attempt
            # AVStarted precedes the first fullscreen frame on some players.
            done=attempt and (not pending or pending.get('attempt')!=attempt or (started and ready))
        if done:self.finish(attempt)
    def finish(self,attempt=None,lifetime=None):
        with self.lock:
            if attempt is not None and self.attempt!=attempt:return
            if lifetime is not None and self.lifetime is not lifetime:return
            window=self._detach()
        self._close(window)
    def _detach(self):
        window=self.window;token=self.visibility_token
        self.window=None;self.attempt='';self.lifetime=None;self.visibility_token=''
        self.wake.set()
        self.rotation_wake.set()
        return window,token
    @staticmethod
    def _close(owned):
        window,token=owned
        if window:
            window.dismissed=True
            try:window.close()
            except Exception:pass
        if token:_busy_owner(token,clear=True)
