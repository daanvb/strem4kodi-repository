"""Session-only recovery for explicitly selected sources; no URL logging/storage."""
import hashlib
import threading
import time
import uuid

def digest(url):
    return hashlib.sha256(str(url).encode('utf-8')).hexdigest()

def playing_attempt(player):
    try:
        value=player.getPlayingItem().getProperty('Strem4KodiPlaybackAttempt')
        return value if isinstance(value,str) else ''
    except (AttributeError,RuntimeError):return ''

class RecoveryTracker:
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.lock=threading.RLock();self.pending=None;self.event=None
    def arm(self,url,identity,resume_ms,window):
        with self.lock:
            self.event=None
            self.pending={'hash':digest(url),'identity':identity,'resume':resume_ms,
                          'window':window,'created':self.clock(),'started':False,'attempt':uuid.uuid4().hex}
            return self.pending['attempt']
    def poll_failure(self, profile):
        from pathlib import Path
        if not isinstance(profile, (str, Path)):return
        with self.lock:
            if not self.pending:return
            from account import Store
            try:row = Store(Path(profile)/'source-failure').load()
            except Exception:return
            if row.get('hash') == self.pending['hash'] and row.get('attempt') == self.pending['attempt']:
                self.event = dict(self.pending)
                self.pending = None
    def startup_timeout(self):
        with self.lock:
            if self.pending and not self.pending.get('preroll') and not self.pending['started'] and self.clock()-self.pending['created']>45:
                self.event=dict(self.pending)
                self.pending=None
    def preroll(self, active):
        with self.lock:
            if self.pending:
                self.pending['preroll']=bool(active)
                if not active:self.pending['created']=self.clock()
    def started(self,url,attempt=''):
        with self.lock:
            if self.pending:
                if attempt and attempt!=self.pending['attempt']:return
                current=self.pending['attempt']
                # Kodi may report the redirected URL instead of the selected URL.
                # The resolver's attempt property identifies that same playback.
                if not attempt and digest(url)!=self.pending['hash']:self.pending=None
                else:self.pending['started']=True
                return current
    def snapshot(self):
        with self.lock:
            return dict(self.pending) if self.pending else None
    def position(self,url,seconds):
        with self.lock:
            if self.pending and digest(url)==self.pending['hash']:
                self.pending['resume']=max(0,int(seconds*1000))
    def failed(self):
        with self.lock:
            if self.pending and (self.pending['started'] or self.clock()-self.pending['created']<120):
                self.event=dict(self.pending)
            self.pending=None
    def stopped(self):
        with self.lock:self.pending=None
    def take(self):
        with self.lock:
            event=self.event;self.event=None;return event
    def clear(self):
        with self.lock:self.pending=None;self.event=None

def player(tracker, profile=None, on_started=None):
    import xbmc
    class RecoveryPlayer(xbmc.Player):
        _preroll = False
        _preroll_error = False
        _active_hash = None
        def onAVStarted(self):
            try:
                self._active_hash=digest(self.getPlayingFile())
                from lib.prerolls import phase, clear_phase
                current_phase=phase()
                if current_phase and not current_phase.startswith('handoff:'):
                    self._preroll=True
                    tracker.preroll(True)
                    # The loading overlay must not cover the introduction.
                    pending=tracker.snapshot()
                    if pending and on_started:on_started(pending['attempt'])
                    return
                self._preroll=False
                self._preroll_error=False
                tracker.preroll(False)
                if current_phase.startswith('handoff:'):clear_phase(current_phase)
                from source_probe import error_video
                if error_video(self.getPlayingFile()):
                    tracker.failed();self.stop()
                else:
                    attempt=tracker.started(self.getPlayingFile(),playing_attempt(self))
                    if attempt and on_started:on_started(attempt)
            except Exception:tracker.stopped()
        def onPlayBackError(self):
            from lib.prerolls import phase
            if self._preroll or (phase() and not phase().startswith('handoff:')):
                self._preroll_error=True
                tracker.preroll(False)
            else:tracker.failed()
        def onPlayBackStopped(self):
            from lib.prerolls import phase
            if phase() and (self._preroll_error or (self._preroll and phase().startswith('handoff:'))):
                self._preroll=False
                self._preroll_error=False
                tracker.preroll(False)
                return
            tracker.poll_failure(profile)
            self._finish_current()
        def _finish_current(self):
            pending=tracker.snapshot()
            # A lasting listener also sees the trailer/previous video's queued
            # Stop/End. That event must not clear a newly armed source attempt.
            if (pending and not pending['started'] and self._active_hash
                    and pending['hash']!=self._active_hash and not self._preroll):return
            tracker.stopped()
        def onPlayBackEnded(self):
            if self._preroll:
                self._preroll=False
                tracker.preroll(False)
            else:self._finish_current()
    return RecoveryPlayer()
