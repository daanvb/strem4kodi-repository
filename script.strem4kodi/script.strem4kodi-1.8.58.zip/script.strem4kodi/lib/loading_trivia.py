"""Sourced trivia for the exact title; no playback network work or cast filler."""
from collections import OrderedDict
from functools import lru_cache
import json
from pathlib import Path
import random
import re
import threading
from lib.stream_presenter import line

_previous = OrderedDict()
_lock = threading.Lock()


@lru_cache(maxsize=1)
def catalogue():
    try:
        rows = json.loads((Path(__file__).resolve().parents[1] / 'resources/trivia.json').read_text(encoding='utf-8'))
        return rows if isinstance(rows, dict) else {}
    except (OSError, ValueError):return {}


def identity(meta):
    kind = meta.get('type')
    imdb = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
    if kind not in ('movie', 'series') or not re.fullmatch(r'tt\d+', imdb):return ''
    return kind + ':' + imdb


def _sourced(rows):
    return [row for row in rows if isinstance(row,dict) and isinstance(row.get('text'),str)
            and isinstance(row.get('source'),str) and row['source'].startswith('https://')]


def facts(meta):
    rows=_sourced(catalogue().get(identity(meta),[]))
    if rows:return 'Did you know?',list(dict.fromkeys(line(row['text'],190) for row in rows))
    return 'Did you know?',[]


def choose(meta):
    """Avoid consecutive repeats during this app session, with bounded history."""
    label, rows = facts(meta)
    if not rows:return {}
    key = identity(meta) or (str(meta.get('type')), str(meta.get('id')))
    with _lock:
        previous = _previous.pop(key, '')
        selected = random.choice([row for row in rows if row != previous] or rows)
        _previous[key] = selected
        while len(_previous) > 512:_previous.popitem(last=False)
    choices = [(label, row) for row in rows]
    return {'trivia_label': label, 'trivia': selected, 'trivia_choices': choices}
