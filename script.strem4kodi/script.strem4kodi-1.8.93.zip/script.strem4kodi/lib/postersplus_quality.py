"""Optional title-quality facts from configured PostersPlus artwork.

Only compact facts are cached. Credentials, URLs and the raw debug response are
never stored or logged here. Playback/source details remain authoritative.
"""
import hashlib
import json
import threading
import time
from collections import OrderedDict
from urllib.parse import parse_qs, urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen
from weakref import WeakValueDictionary

from lib.catalogue_identity import aliases

TTL = 3600
RETRY = 300
MAX_BYTES = 128 * 1024
TOKENS = {'4K': '4K', '1080P': '1080p', '720P': '720p', '480P': '480p',
          'DV': 'Dolby Vision', 'DOLBY VISION': 'Dolby Vision',
          'HDR10+': 'HDR10+', 'HDR10': 'HDR10', 'HDR': 'HDR',
          'ATMOS': 'Atmos', 'TRUEHD': 'TrueHD', 'DTS-HD MA': 'DTS-HD MA',
          'DTSHDMA': 'DTS-HD MA', 'DTS': 'DTS', 'DD+': 'Dolby Digital Plus',
          'DDP': 'Dolby Digital Plus', 'EAC3': 'Dolby Digital Plus',
          'DD': 'Dolby Digital', 'AC3': 'Dolby Digital'}


def endpoint(row):
    if row.get('type') not in ('movie', 'series') or row.get('_catalogue'):
        return ''
    value = row.get('poster')
    if not isinstance(value, str) or len(value) > 16384:
        return ''
    try:
        parsed = urlsplit(value)
        # AIOMetadata keeps the configured upstream in its signed image URL.
        if '/poster-cache/proxy/' in parsed.path:
            values = parse_qs(parsed.query)
            value = values.get('url', [''])[0]
            parsed = urlsplit(value)
        if (parsed.scheme != 'https' or not parsed.hostname or parsed.username
                or parsed.password or parsed.path != '/poster'):
            return ''
        values = parse_qs(parsed.query)
        kind = values.get('type', [''])[0]
        if kind != row['type']:
            return ''
        source = dict(type=kind, id=values.get('stremio_id', [''])[0],
                      imdb_id=values.get('imdb_id', [''])[0],
                      tmdb_id=values.get('tmdb_id', [''])[0])
        known, declared = aliases(row), aliases(source)
        if not known & declared:
            return ''
        # A conflicting explicit IMDb id must not be rescued by a TMDB alias.
        imdb_known = {key for key in known if key[1].startswith('tt')}
        imdb_source = {key for key in declared if key[1].startswith('tt')}
        if imdb_known and imdb_source and imdb_known != imdb_source:
            return ''
        values['debug'] = ['1']
        values.pop('nocache', None)
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path,
                           urlencode(values, doseq=True), ''))
    except (ValueError, TypeError):
        return ''


def facts(payload, row):
    if not isinstance(payload, dict) or payload.get('type') != row.get('type'):
        return None
    returned = dict(type=payload['type'],
                    imdb_id=payload.get('effective_imdb_id') or payload.get('imdb_id'),
                    tmdb_id=payload.get('tmdb_id'))
    known, received = aliases(row), aliases(returned)
    if not received & known:
        return None
    imdb_known = {key for key in known if key[1].startswith('tt')}
    imdb_received = {key for key in received if key[1].startswith('tt')}
    if imdb_known and imdb_received and imdb_known != imdb_received:
        return None
    tokens = payload.get('quality_tokens')
    if not isinstance(tokens, list) or len(tokens) > 64:
        return None
    from lib.available_formats import merge_formats
    return merge_formats([TOKENS[token.strip().upper()] for token in tokens
                          if isinstance(token, str) and token.strip().upper() in TOKENS])


def fetch(url):
    request = Request(url, headers={'Accept': 'application/json',
                                   'User-Agent': 'Strem4Kodi/PostersPlusQuality'})
    with urlopen(request, timeout=3) as response:
        if response.headers.get_content_type() != 'application/json':
            raise ValueError('Quality response is not JSON')
        raw = response.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise ValueError('Quality response is too large')
    return json.loads(raw)


class Quality:
    def __init__(self, cache=None, fetcher=fetch, clock=time.time):
        self.cache, self.fetcher, self.clock = cache, fetcher, clock
        self.memory = OrderedDict()
        self.guard = threading.Lock()
        self.locks = WeakValueDictionary()

    def enrich(self, row):
        url = endpoint(row)
        if not url:
            return row
        result = dict(row, _postersplus_active=True)
        key = 'postersplus-quality-v1:' + hashlib.sha256(url.encode()).hexdigest()
        with self.guard:
            lock = self.locks.get(key)
            if lock is None:
                lock = threading.Lock()
                self.locks[key] = lock
        with lock:
            record = self.memory.get(key)
            if record is None and self.cache is not None:
                try:
                    record = self.cache.get(key)
                except Exception:
                    pass
            if (not isinstance(record, dict) or type(record.get('expires')) not in (int, float)
                    or not self.clock() < record['expires'] < self.clock() + TTL + 1
                    or not isinstance(record.get('formats'), list)):
                try:
                    found = facts(self.fetcher(url), row)
                except Exception:
                    found = None  # Optional quality must never prevent browsing/playback.
                ttl = TTL if found else RETRY
                record = {'formats': found or [], 'expires': self.clock() + ttl}
                if self.cache is not None:
                    try:
                        self.cache.put(key, record, ttl)
                    except Exception:
                        pass
            with self.guard:
                self.memory[key] = record
                self.memory.move_to_end(key)
                while len(self.memory) > 256:
                    self.memory.popitem(last=False)
            result['_postersplus_quality'] = list(record.get('formats') or [])
        return result


_QUALITY = None
_GUARD = threading.Lock()


def enrich(row):
    global _QUALITY
    # Avoid opening any cache when the configured artwork is another provider.
    if not endpoint(row):
        return row
    with _GUARD:
        if _QUALITY is None:
            try:
                from lib.cache_policy import open_cache
                cache = open_cache('metadata')
            except Exception:
                cache = None
            _QUALITY = Quality(cache=cache)
    try:
        return _QUALITY.enrich(row)
    except Exception:
        return dict(row, _postersplus_active=True, _postersplus_quality=[])
