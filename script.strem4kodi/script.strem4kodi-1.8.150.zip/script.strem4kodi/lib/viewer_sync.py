"""Private repository sync of viewer roster and isolated watch/list state."""
import base64
from copy import deepcopy
import json
import gzip
import zlib
from pathlib import Path
import re
import threading
import time

from account import Store, storage_lock
from lib.credits_sync import request, SyncError, LIMIT
from lib import viewer_profiles as profiles

ROSTER = '/contents/viewers.json'
DATA_LIMIT=8*1024*1024


def clean_library(rows):
    """Share title IDs/state only; artwork is rehydrated through configured providers."""
    result = {}
    if not isinstance(rows, list):return []
    for row in rows:
        if not isinstance(row, dict) or row.get('type') not in ('movie', 'series'):continue
        if row.get('state') is not None and not isinstance(row['state'],dict):continue
        identity = row.get('_id')
        if not isinstance(identity, str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,200}',identity):continue
        item = dict(_id=identity, type=row['type'], removed=row.get('removed') is True, temp=row.get('temp') is True)
        for key,limit in (('name',200),('_mtime',64),('_ctime',64),('posterShape',20)):
            if isinstance(row.get(key), str):item[key]=row[key][:limit]
        state={}
        for key in ('timeWatched','timeOffset','overallTimeWatched','timesWatched','flaggedWatched','duration'):
            value=(row.get('state') or {}).get(key)
            if type(value) in (int,float) and 0 <= value <= 1e15:state[key]=value
        for key,limit in (('video_id',200),('lastWatched',64),('watched',100000)):
            value=(row.get('state') or {}).get(key)
            if isinstance(value,str):state[key]=value[:limit]
        item['state']=state
        result[(row['type'],identity)]=item
    return [result[key] for key in sorted(result)]


def merge_library(left, right):
    result={}
    for row in clean_library(left)+clean_library(right):
        key=(row['type'],row['_id']);old=result.get(key)
        if old is None or profiles.library_order(row)>profiles.library_order(old):result[key]=row
    return [result[key] for key in sorted(result)]


def reconcile_library(local, remote, base=None, pending=None):
    """Compare both devices with the last synced state, independent of clocks.

    A competing edit stays local and the remote copy stays remote until the
    viewer chooses one. Both sanitized versions are kept in a local journal.
    """
    def index(rows):return {(row['type'],row['_id']):row for row in clean_library(rows)}
    here,there,ancestor=index(local),index(remote),index(base or [])
    pending=pending or {}
    exported={};applied={};conflicts={}
    for key in sorted(here.keys()|there.keys()):
        own,other,old=here.get(key),there.get(key),ancestor.get(key)
        label=':'.join(key)
        if label in pending:
            # A queued playback update can conflict with the local library
            # even when local and remote later match. Keep it for review.
            conflicts[label]=pending[label]
            if other is not None:exported[key]=other
            if own is not None:applied[key]=own
            continue
        if own==other:
            chosen=own
        elif own is None:
            chosen=other
        elif other is None:
            chosen=own
        elif old is None or own!=old and other!=old:
            conflicts[label]=dict(local=own,remote=other)
            exported[key]=other
            applied[key]=own
            continue
        elif own==old:
            chosen=other
        else:
            chosen=own
        if chosen is not None:
            exported[key]=chosen
            applied[key]=chosen
    return ([exported[key] for key in sorted(exported)],
            [applied[key] for key in sorted(applied)],conflicts)


def pending_conflicts(root, identity):
    rows=Store(profiles.directory(root,identity)/'viewer-sync-conflicts').load().get('rows') or {}
    if not isinstance(rows,dict):return {}
    return {key:value for key,value in rows.items() if isinstance(key,str)
            and isinstance(value,dict) and all(clean_library([value.get(side)])==[value.get(side)]
                                                   for side in ('local','remote'))}


def record_progress_conflict(root, identity, local, remote):
    own=clean_library([local]);other=clean_library([remote])
    if not own or not other:return False
    key='{}:{}'.format(own[0]['type'],own[0]['_id'])
    if (other[0]['type'],other[0]['_id'])!=(own[0]['type'],own[0]['_id']):return False
    target=Store(profiles.directory(root,identity)/'viewer-sync-conflicts')
    with storage_lock(Path(root)/'viewer-control'):
        rows=target.load().get('rows') or {}
        rows[key]=dict(local=own[0],remote=other[0])
        target.save(dict(rows=rows))
    return True


def resolve_conflict(root, identity, key, choice):
    if choice not in ('local','remote'):raise ValueError('Unknown conflict choice')
    rows=pending_conflicts(root,identity)
    if key not in rows:raise SyncError('That conflict is no longer available')
    with storage_lock(Path(root)/'viewer-control'),storage_lock(Path(root)):
        data=profiles.state(root)
        if identity not in data.get('records',{}) or data['records'][identity]['deleted']:
            raise SyncError('That viewer is no longer available')
        journal=Store(profiles.directory(root,identity)/'viewer-sync-conflicts')
        latest=journal.load().get('rows') or {}
        if latest.get(key)!=rows[key]:raise SyncError('Viewer progress changed; review the conflict again')
        pair=rows[key];selected=pair[choice]
        if key!='{}:{}'.format(selected['type'],selected['_id']):
            raise SyncError('Invalid viewer progress conflict')
        library_store=profiles._library_store(root,identity)
        snapshot=library_store.load()
        current=snapshot.get('library',[])
        prior=next((row for row in current if isinstance(row,dict) and
                    (row.get('type'),row.get('_id'))==(selected['type'],selected['_id'])),None)
        # A checkpoint upload can detect a competing Stremio version before
        # the viewer sync has imported that version into the local library.
        # In that case the current row may still be the baseline (or absent),
        # while the journal correctly holds both choices. Permit the recorded
        # pair to be resolved without silently accepting unrelated edits.
        base=clean_library(Store(profiles.directory(root,identity)/'viewer-sync-base').load().get('library') or [])
        baseline=next((row for row in base if (row.get('type'),row.get('_id'))==(selected['type'],selected['_id'])),None)
        current_clean=clean_library([prior])
        allowed=[[pair['local']],[pair['remote']]]
        if baseline is not None:allowed.append([baseline])
        if current_clean not in allowed:
            raise SyncError('Viewer progress changed; review the conflict again')
        replacement=prior if choice=='local' and clean_library([prior])==[selected] else selected
        snapshot['library']=[row for row in current if not isinstance(row,dict) or
                             (row.get('type'),row.get('_id'))!=(selected['type'],selected['_id'])]+[replacement]
        library_store.save(snapshot)
        latest.pop(key)
        journal.save(dict(rows=latest))


def decode(response):
    if response is None:return None,None
    try:
        raw=base64.b64decode(response['content'],validate=False)
        if len(raw)>LIMIT:raise ValueError()
        if raw.startswith(b'\x1f\x8b'):
            decoder=zlib.decompressobj(16+zlib.MAX_WBITS)
            raw=decoder.decompress(raw,DATA_LIMIT+1)
            if len(raw)>DATA_LIMIT or not decoder.eof or decoder.unused_data:raise ValueError()
        value=json.loads(raw)
        if response.get('encoding')!='base64' or not isinstance(response.get('sha'),str) or len(raw)>DATA_LIMIT or value.get('version')!=1:raise ValueError()
        return value,response['sha']
    except Exception:raise SyncError('Invalid viewer sync file; data was kept') from None


def upload(token,path,data,sha,transport):
    raw=json.dumps(dict(data,version=1),sort_keys=True,separators=(',',':')).encode()
    if len(raw)>DATA_LIMIT:raise SyncError('Viewer data is too large; local data was kept')
    if path.endswith('.gz'):raw=gzip.compress(raw,mtime=0)
    if len(raw)>LIMIT//2:raise SyncError('Viewer data is too large; local data was kept')
    payload=dict(message='Merge viewer profiles',content=base64.b64encode(raw).decode())
    if sha:payload['sha']=sha
    transport(token,path,payload)


def synchronize_roster(root, token, transport=request):
    account=profiles._token(root)
    def valid():return profiles._token(root)==account
    if transport(token).get('private') is not True:raise SyncError('Viewer sync requires a private repository')
    for _ in range(3):
        if not valid():return False
        remote,sha=decode(transport(token,ROSTER))
        if not valid():return False
        if remote is not None and (not isinstance(remote.get('records'),dict) or profiles.clean(remote['records'])!=remote['records']):
            raise SyncError('Invalid viewer roster; local profiles were kept')
        local=profiles.state(root)
        if not local and remote is None:return False
        if not local:local=profiles.enable(root)
        records=profiles.merge(local.get('records',{}), (remote or {}).get('records',{}))
        if not records or not any(not r['deleted'] for r in records.values()):raise SyncError('Viewer roster has no available profiles; local data was kept')
        with storage_lock(Path(root)/'viewer-control'),storage_lock(Path(root)):
            if not valid():return False
            latest=profiles.state(root)
            records=profiles.merge(records,latest.get('records',{}))
            active=latest.get('active')
            if active not in records or records[active]['deleted']:active=next(k for k in sorted(records) if not records[k]['deleted'])
            # Active selection is deliberately local to this device.
            profiles.registry(root).save(dict(owner=profiles._owner(profiles._token(root)),records=records,active=active))
        if remote is not None and profiles.clean(remote.get('records'))==records:return True
        if not valid():return False
        try:upload(token,ROSTER,dict(records=records),sha,transport)
        except SyncError:continue
        verified,_=decode(transport(token,ROSTER))
        if verified and profiles.merge(verified.get('records'),records)==profiles.clean(verified.get('records')):return True
    raise SyncError('Viewer roster sync will retry; local profiles were kept')


def synchronize_viewer(root, identity, token, transport=request):
    if transport(token).get('private') is not True:raise SyncError('Viewer sync requires a private repository')
    from lib.saved_lists import SavedLists,clean as clean_tags,merge as merge_tags
    from lib.home_state import HomeState,clean as clean_home,merge as merge_home
    path='/contents/viewers/'+identity+'.json.gz'
    # Capture the directory once; switching during HTTP must not retarget data.
    directory=profiles.directory(root,identity)
    account_token=profiles._token(root)
    lists=SavedLists(root,account_token,viewer_id=identity)
    home=HomeState(root,account_token,viewer_id=identity)
    raw_before=profiles.read_library(root,identity)
    before=(clean_library(raw_before),lists.snapshot(),home.snapshot())
    base_store=Store(directory/'viewer-sync-base')
    conflicts_store=Store(directory/'viewer-sync-conflicts')
    def valid():
        data=profiles.state(root)
        return (profiles._token(root)==account_token and
                identity in data.get('records',{}) and not data['records'][identity]['deleted'])
    for _ in range(3):
        if not valid():return False
        remote,sha=decode(transport(token,path));remote=remote or {}
        if not valid():return False
        if remote and (not isinstance(remote.get('library'),list) or not isinstance(remote.get('tags'),dict) or not isinstance(remote.get('home'),dict)):
            raise SyncError('Invalid viewer state; local progress was kept')
        if remote and (clean_library(remote['library'])!=remote['library'] or clean_tags(remote['tags'])!=remote['tags'] or clean_home(remote['home'])!=remote['home']):
            raise SyncError('Invalid viewer state; local progress was kept')
        raw_local=profiles.read_library(root,identity)
        base_data=base_store.load()
        with storage_lock(Path(root)/'viewer-control'):
            pending=conflicts_store.load().get('rows') or {}
            library,applied,conflicts=reconcile_library(raw_local,remote.get('library',[]),
                base_data.get('library') if 'library' in base_data else None,pending)
            if conflicts!=pending:conflicts_store.save(dict(rows=conflicts))
        tags=merge_tags(lists.snapshot(),remote.get('tags',{}))
        records=merge_home(home.snapshot(),remote.get('home',{}))
        data=dict(library=library,tags=tags,home=records)
        normalized=dict(library=clean_library(remote.get('library',[])),tags=clean_tags(remote.get('tags',{})),home=clean_home(remote.get('home',{})))
        if data!=normalized:
            if not valid():return False
            try:upload(token,path,data,sha,transport)
            except SyncError:continue
            verified,_=decode(transport(token,path))
            if not verified or (clean_library(verified.get('library',[]))!=library
                    or merge_tags(verified.get('tags',{}),tags)!=clean_tags(verified.get('tags',{}))
                    or merge_home(verified.get('home',{}),records)!=clean_home(verified.get('home',{}))):continue
            remote=verified
        if not valid():return False
        # Do not apply a network snapshot over an action made during HTTP.
        latest=profiles.read_library(root,identity)
        if latest!=raw_local:continue
        original={(row.get('type'),row.get('_id')):row for row in latest if isinstance(row,dict)}
        applied_raw=[]
        for row in applied:
            prior=original.get((row['type'],row['_id']))
            applied_raw.append(prior if prior is not None and clean_library([prior])==[row] else row)
        if not profiles.replace_library_if_unchanged(root,identity,latest,applied_raw):continue
        base_store.save(dict(library=clean_library(remote.get('library',[]))))
        lists.merge(remote.get('tags',{}));home.merge(remote.get('home',{}))
        return before!=(clean_library(profiles.read_library(root,identity)),lists.snapshot(),home.snapshot())
    raise SyncError('Viewer sync will retry; local progress was kept')


class ViewerSync:
    def __init__(self,root,addon):
        self.root,self.addon=Path(root),addon
        self.busy=False;self.next_check=0

    def tick(self):
        if self.busy or time.monotonic()<self.next_check:return
        try:
            import xbmc
            from lib.native_playback import busy
            if xbmc.Player().isPlayingVideo() or busy():return
        except (ImportError,AttributeError,RuntimeError):pass
        if self.addon.getSetting('lists_github_enabled')!='true':return
        token=self.addon.getSetting('credits_github_token').strip()
        account=profiles._token(self.root)
        if not token or not account:return
        self.busy=True;self.next_check=time.monotonic()+60
        def run():
            try:
                if synchronize_roster(self.root,token):
                    data=profiles.state(self.root)
                    changed=False
                    # Include inactive dirty profiles so a switch never strands
                    # a final progress update on the previous viewer.
                    for identity,row in data['records'].items():
                        if profiles._token(self.root)!=account:return
                        if not row['deleted']:changed=synchronize_viewer(self.root,identity,token) or changed
                    conflicts=sum(len(pending_conflicts(self.root,identity)) for identity,row in data['records'].items()
                                  if not row['deleted'])
                    label=('{} viewer title conflicts need review in Viewer profiles'.format(conflicts)
                           if conflicts else 'Synced with private GitHub')
                    Store(self.root/'viewer-sync-status').save(dict(status=label,updated=time.time()))
                    if changed:
                        import xbmcgui
                        xbmcgui.Window(10000).setProperty('strem4kodi.saved_lists.revision',str(time.time_ns()))
                        xbmcgui.Window(10000).setProperty('strem4kodi.home.recommendations.revision',str(time.time_ns()))
                        from lib.progress_signal import publish
                        publish(dict(meta_id='*',video_id=''))
            except Exception:
                Store(self.root/'viewer-sync-status').save(dict(status='Sync will retry; local viewer data was kept'))
            finally:self.busy=False
        try:threading.Thread(target=run,daemon=True).start()
        except RuntimeError:self.busy=False
