"""Reversible addon-only CoreELEC preset; never changes Kodi decoder settings."""
from functools import lru_cache
from pathlib import Path

@lru_cache(maxsize=1)
def detected():
    try:
        return 'coreelec' in Path('/etc/os-release').read_text(encoding='utf-8').lower()
    except OSError:
        return False

def enabled(addon):
    value=addon.getSetting('coreelec_preset')
    return value=='1' or (value not in ('1','2') and detected())

def trailer_quality(addon):
    value=addon.getSetting('trailers_quality')
    return '1' if enabled(addon) and value in ('','0') else value
