"""Visible, catalogue-supplied filters for a selected streaming service."""


def options(catalog):
    if (not isinstance(catalog, dict) or catalog.get('family') != 'Streaming services'
            or catalog.get('_search_collection') or catalog.get('_tmdb_collection')):
        return []
    return [e for e in catalog.get('extras', [])
            if e.get('name') not in ('skip', 'search') and e.get('options')]


def label(catalog, values, overview=False):
    available = options(catalog) if not overview else []
    if not available:
        return ''
    values = dict(catalog.get('defaults') or {}, **(values or {}))
    if len(available) == 1:
        extra = available[0]
        required = extra.get('isRequired') or any(extra['name'] in m.get('defaults', {}) or
                       any(e.get('name') == extra['name'] and e.get('isRequired') for e in m.get('extras', []))
                       for m in catalog.get('members', []))
        return extra['name'].replace('_', ' ').title() + ': ' + str(values.get(extra['name'], 'Default' if required else 'All'))
    active = [str(values[e['name']]) for e in available if e['name'] in values]
    return 'Filters: ' + (' · '.join(active) if active else 'All')


def edit(window, path):
    available = options(window.discover_catalog)
    if window.getProperty('page') != 'Discover' or window.discover_overview or not available:
        return
    index = 0
    if len(available) > 1:
        from lib.nimbus_select import Dialog
        index = Dialog(path, left=950, top=660).select(
            'Service filters', [e['name'].replace('_', ' ').title() for e in available])
        if index < 0:
            return
    # Reuse the existing option editor, including required values, clearing,
    # remembering and resetting each supplier's pagination cursor.
    window.edit_filters(3 + index)
    if window.getProperty('discover_service_filter'):
        window.setFocusId(9204)
