"""Map provider metadata to Nimbus FlixInfoIcon labels."""
import re
import math
from datetime import datetime, timedelta


def measured_episode_seconds(video_id, state):
    """Use the synced file duration only for its exact episode (stored in ms)."""
    if not video_id or not isinstance(state, dict) or video_id != state.get('video_id'):
        return 0
    value = state.get('duration')
    if isinstance(value, bool):
        return 0
    try:
        seconds = float(value) / 1000
    except (TypeError, ValueError, OverflowError):
        return 0
    return seconds if math.isfinite(seconds) and 0 < seconds <= 86400 else 0


def finish_time(row, now=None, saved=None):
    """Finish the relevant movie/episode from its saved resume position."""
    from continue_playback import next_series_episode, resume_seconds
    kind = row.get('type')
    if kind not in ('movie', 'series'):
        return ''
    state = (saved or row).get('state') or {}
    target = row.get('_focus_video_id') or (row.get('id') if kind == 'movie' else '')
    episode = row.get('_finish_episode') or {}
    if kind == 'series' and not target and row.get('videos'):
        video, _ = next_series_episode(row['videos'], row.get('id'), saved or row)
        episode = video or {}
        target = episode.get('id')
    if kind == 'series' and target and not episode:
        episode = next((v for v in row.get('videos', []) if v.get('id') == target), {})
    if kind == 'series' and not target and resume_seconds(state.get('timeOffset')):
        target = state.get('video_id')
    matching = kind == 'movie' or bool(target and target == state.get('video_id'))
    offset = resume_seconds(state.get('timeOffset')) if matching else 0
    raw_runtime = episode.get('runtime') or row.get('runtime')
    if not episode.get('runtime') and episode.get('duration'):
        value = episode['duration']
        if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
            raw_runtime = str(round(value / 60000 if value > 10000 else value / 60 if value > 300 else value))
        else:
            raw_runtime = value
    runtime = str(raw_runtime or '').strip().lower()
    iso = re.fullmatch(r'pt(?:(\d+)h)?(?:(\d+)m)?', runtime)
    if iso and (iso[1] or iso[2]):
        runtime = str(int(iso[1] or 0)*60 + int(iso[2] or 0))
    plain = re.fullmatch(r'(\d+)\s*(?:m|min|mins|minutes)?', runtime)
    hours = re.fullmatch(r'(\d+)\s*h(?:ours?)?\s*(?:(\d+)\s*m(?:in(?:utes?)?)?)?', runtime)
    minutes = int(plain[1]) if plain else int(hours[1])*60 + int(hours[2] or 0) if hours else 0
    seconds = minutes * 60 if 0 < minutes <= 1440 else 0
    measured_episode = measured_episode_seconds(target, state) if kind == 'series' else 0
    if measured_episode:
        seconds = measured_episode
    elif offset and kind == 'movie':
        try:
            measured = float(state.get('duration') or 0) / 1000
            if offset < measured <= 86400:
                seconds = measured
        except (TypeError, ValueError):
            pass
    if not seconds:
        return ''
    # Completed/invalid offsets are replay estimates, never a negative runtime.
    remaining = seconds - offset if 0 < offset < seconds else seconds
    return ((now or datetime.now()) + timedelta(seconds=remaining)).strftime('%H:%M')


def upcoming_preview(full, preview):
    """Keep episode presentation separate from cached series metadata."""
    result = dict(full)
    for key in ('_focus_video_id', 'state'):
        if key in preview:
            result[key] = preview[key]
    if preview.get('_upcoming_episode'):
        result.update({key: preview[key] for key in
                       ('name', 'description', '_release_label', '_upcoming_episode') if key in preview})
    return result


def credits(row):
    """Format available provider credits without requesting more metadata."""
    def names(*fields):
        for field in fields:
            value = row.get(field)
            if isinstance(value, str):
                value = [value]
            if not isinstance(value, (list, tuple)):
                continue
            result = []
            for person in value:
                name = person.get('name') if isinstance(person, dict) else person
                if isinstance(name, str) and name.strip() and name.strip() not in result:
                    result.append(name.strip())
                if len(result) == 3:
                    break
            if result:
                return ', '.join(result)
        return ''
    return {'hero_cast': names('castPeople', 'cast'),
            'hero_director': names('directorPeople', 'director')}


def tags(row):
    date = str(row.get('released') or row.get('releaseInfo') or row.get('year') or '')
    match_year = re.match(r'^(\d{4})',date)
    date = match_year.group(0) if match_year else ''
    runtime = str(row.get('runtime') or '')
    match = re.fullmatch(r'(\d+)\s*(?:min|mins|minutes)?', runtime.strip(), re.I)
    if match:
        minutes = int(match[1])
        runtime = ('{}h'.format(minutes // 60) + (' {}m'.format(minutes % 60) if minutes % 60 else '')) if minutes >= 60 else '{}m'.format(minutes)
    value = str(row.get('certificate_gb') or '')
    if not value and row.get('certificate_country') == 'GB':
        value = str(row.get('certification') or row.get('mpaa') or '')
    value = value.upper().strip()
    if value not in ('U', 'PG', '12', '12A', '15', '18', 'R18'):value = ''
    return {'premiered': date, 'certificate': 'UK ' + value if value else '',
            'genre_tag':' · '.join((row.get('genres') or [])[:2]), 'runtime_tag':runtime}


def credit_lines(value, max_width=380):
    """Put each credited person on their own line."""
    names = [part.strip() for part in value.split(',') if part.strip()]
    return (names + ['', '', ''])[:3]
