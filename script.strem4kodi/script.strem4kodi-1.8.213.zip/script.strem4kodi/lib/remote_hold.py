"""Recognise a raw CEC/IR OK burst without native repeated selections."""
import threading
import time

RELEASE_GAP = .32
FIRST_REPEAT_GAP = .75
HOLD_SECONDS = .65
OPEN_HOLD_SECONDS = 1.0
_CONTEXT_GUARD_UNTIL = 0
LONG_PRESS = 0x01000000


class SelectBurst:
    def __init__(self, clock=time.monotonic):
        self.clock = clock
        self.first = self.last = None
        self.focus = None
        self.count = 0
        self.max_gap = 0
        self.native_hold = False

    def cancel(self):
        self.first = self.last = self.focus = None
        self.count = 0
        self.max_gap = 0
        self.native_hold = False

    def press(self, focus, native_hold=False):
        now = self.clock()
        if self.first is None or focus != self.focus:
            self.cancel()
            self.first, self.focus = now, focus
        elif self.last is not None:
            self.max_gap = max(self.max_gap, now-self.last)
        self.count += 1
        self.native_hold |= native_hold
        self.last = now

    def released(self):
        # A CEC remote can wait ~500 ms before its first repeat. Treating
        # 320 ms of silence as release selected the title before that repeat.
        # Subsequent repeats use the shorter quiet gap. Three events avoid
        # turning a double tap into a context menu.
        gap = FIRST_REPEAT_GAP if self.count == 1 and not self.native_hold else RELEASE_GAP
        if self.last is None or self.clock() - self.last < gap:
            return None
        result = (self.focus, self.native_hold or self.count >= 3 and self.last - self.first >= HOLD_SECONDS)
        self.cancel()
        return result



def take_context_guard():
    """Hand the menu a short guard when it opened while OK was still held."""
    global _CONTEXT_GUARD_UNTIL
    active = time.monotonic() < _CONTEXT_GUARD_UNTIL
    _CONTEXT_GUARD_UNTIL = 0
    return active

def _focus(window):
    cid = window.getFocusId()
    try: position = window.getControl(cid).getSelectedPosition()
    except (AttributeError, RuntimeError): position = None
    return cid, position


class RemoteSelect:
    def __init__(self, window):
        self.window = window
        self.burst = SelectBurst()
        self.lock = threading.Lock()
        self.running = False
        self.delivered_focus = None
        self.delivered_last = None

    def cancel(self):
        with self.lock:self.burst.cancel()

    def press(self, native_hold=False):
        from lib.input_guard import note_input
        note_input(self.window)
        focus = _focus(self.window)
        with self.lock:
            now = self.burst.clock()
            if (focus == self.delivered_focus and self.delivered_last is not None
                    and 0 <= now-self.delivered_last < FIRST_REPEAT_GAP):
                # A late first repeat after a dispatched short OK belongs to
                # that gesture. Consume its tail, including native long flags.
                self.delivered_last = now
                return
            self.burst.press(focus, native_hold)
            if self.running:return
            self.running = True
        try:
            threading.Thread(target=self.watch, daemon=True).start()
        except RuntimeError:
            with self.lock:
                self.running = False
                self.burst.cancel()
            raise

    def watch(self):
        import xbmc
        import xbmcgui
        from lib.hero_preview import NO_DIALOG
        try:
            while True:
                time.sleep(.04)
                with self.lock:
                    if self.burst.first is None:
                        self.running = False
                        return
                    count=self.burst.count
                    duration=self.burst.last-self.burst.first
                    gap=self.burst.max_gap
                    now = self.burst.clock()
                    held_now = (self.burst.count >= 3 and now - self.burst.first >= OPEN_HOLD_SECONDS
                                and now - self.burst.last < RELEASE_GAP)
                    result = (self.burst.focus, True) if held_now else self.burst.released()
                    if result is None:continue
                    if held_now:self.burst.cancel()
                    self.running = False
                    self.delivered_focus = result[0]
                    self.delivered_last = self.burst.clock()
                focus, held = result
                owner = getattr(self.window, '_context_window_id', None)
                if (getattr(self.window, 'closed', False) is True or
                        xbmcgui.getCurrentWindowId() != owner or
                        xbmcgui.getCurrentWindowDialogId() not in (*NO_DIALOG, owner) or
                        _focus(self.window) != focus):return
                # The destination menu guards repeats when opened mid-hold.
                # SendClick omits ACTION_SELECT_ITEM and Kodi ignores that
                # message on list containers. A real Select action supports
                # both poster lists and buttons through their native handlers.
                if held_now:
                    global _CONTEXT_GUARD_UNTIL
                    _CONTEXT_GUARD_UNTIL = time.monotonic() + 2.0
                command = 'Action({},{})'.format('ContextMenu' if held else 'Select', owner)
                xbmc.executebuiltin(command)
                # One fixed-field summary per completed gesture, never each
                # repeat, typed keys, title names or UI contents.
                try:
                    xbmc.log('Strem4Kodi REMOTE | OK events={} duration_ms={} max_gap_ms={} context={}'.format(
                        min(count,1000), min(round(duration*1000),60000),
                        min(round(gap*1000),60000), int(held)), xbmc.LOGINFO)
                except (AttributeError,RuntimeError):pass
                return
        except (AttributeError, RuntimeError):
            with self.lock:
                self.burst.cancel()
                self.running = False


def handle(window, action):
    guard = getattr(window, '_remote_select', None)
    try:
        code=action.getButtonCode()
        selected = action.getId() == 58 and type(code) is int and code & ~LONG_PRESS == 11
    except (AttributeError, RuntimeError): selected = False
    if not selected:
        if isinstance(guard, RemoteSelect):guard.cancel()
        return False
    if not isinstance(guard, RemoteSelect):
        guard = window._remote_select = RemoteSelect(window)
    guard.press(bool(code & LONG_PRESS))
    return True
