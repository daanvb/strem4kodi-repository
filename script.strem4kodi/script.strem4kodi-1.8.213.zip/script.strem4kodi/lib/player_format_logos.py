"""Shared P3i player artwork. Callers supply reported or detected formats."""

ROOT = 'special://home/addons/skin.strem4kodi/media/codecs/'


def logo(name):
    return ROOT + 'b_' + name + '.png' if name else ''


REPORTED_LOGOS = {
    'Dolby Vision': 'dolby_vision', 'HDR10': 'hdr10', 'HDR10+': 'hdr10plus',
    'TrueHD': 'truehd', 'Dolby Digital Plus': 'eac3', 'Dolby Digital': 'ac3',
    'DTS-HD MA': 'dtshd_ma', 'DTS': 'dca',
}

AUDIO_LOGOS = {
    'ac3': 'ac3', 'eac3': 'eac3', 'truehd': 'truehd',
    'truehd_atmos': 'truehd_atmos', 'eac3_ddp_atmos': 'eac3_ddp_atmos',
    'dca': 'dca', 'dts': 'dca', 'dts_es': 'dca', 'dts_96_24': 'dca',
    'dts_express': 'dca', 'dtshd_ma': 'dtshd_ma', 'dtshd_hra': 'dtshd_hra',
    'dtshd_ma_x': 'dtshd_ma_x', 'dtshd_ma_x_imax': 'dtshd_ma_x_imax',
    'dtshd_ma_auro3d': 'dtshd_ma_auro3d',
    'aac': 'aac', 'aac_lc': 'aac', 'aac_latm': 'aac', 'he_aac': 'aac',
    'he_aac_v2': 'aac', 'flac': 'flac', 'mp2': 'mp2', 'mp3': 'mp3',
    'opus': 'opus', 'pcm': 'pcm',
}


def video_logo(hdr, runtime):
    """Follow CoreELEC output mode when supplied; otherwise use Kodi HDR type."""
    mode = runtime.get('amlogic.vs10.mode', '')
    source = runtime.get('video.source.hdr.type.raw', '')
    if mode == 'SDR':
        return logo('sdr_vs')
    if mode == 'HDR10':
        return logo('hdr10_vs')
    if mode == 'Dolby Vision':
        if source == '2':
            return logo('dolby_vision_conv')
        if source in ('0', '1', '4'):
            return logo('dolby_vision_vs')
        hdr = 'Dolby Vision'
    if hdr == 'Dolby Vision':
        return logo('dolby_vision_fel' if runtime.get('video.dovi.el.type') == 'full'
                    else 'dolby_vision')
    if hdr == 'SDR' and runtime.get('video.bit.depth') in ('8', '10'):
        return logo('sdr' + runtime['video.bit.depth'])
    return logo({'HDR10': 'hdr10', 'HDR10+': 'hdr10plus', 'HLG': 'hlg'}.get(hdr, ''))
