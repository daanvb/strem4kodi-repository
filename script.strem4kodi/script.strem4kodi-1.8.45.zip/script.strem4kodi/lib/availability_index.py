"""Small persistent badge summaries, independent of playable source URLs."""
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from contextlib import closing

REFRESH = 60 * 60
PARTIAL_REFRESH = 120
MAX_AGE = 7 * 24 * 60 * 60


def scope(meta, saved=None):
    if meta.get('type') == 'movie':
        return str(meta.get('id') or '')
    if meta.get('_focus_video_id'):
        return str(meta['_focus_video_id'])
    state = (saved or {}).get('state') or {}
    try:
        offset = float(state.get('timeOffset') or 0)
    except (TypeError, ValueError):
        offset = 0
    # Resume movement within an episode does not invalidate its formats. A
    # completion or next-episode pointer does change the target context.
    mode = 'pointer' if offset == 1 else 'resume' if offset >= 1000 else 'next'
    key = [state.get('video_id') or '', mode]
    return 'next:' + hashlib.sha256(json.dumps(key).encode()).hexdigest()


def _connect(profile):
    path = Path(profile) / 'cache'
    path.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path / 'availability.sqlite', timeout=2)
    db.execute('CREATE TABLE IF NOT EXISTS badges (kind TEXT, title TEXT, scope TEXT, target TEXT, formats TEXT, updated REAL, PRIMARY KEY(kind,title,scope))')
    return db


def get(profile, meta, context, now=None):
    now = time.time() if now is None else now
    try:
        with closing(_connect(profile)) as db:
            row = db.execute('SELECT target,formats,updated FROM badges WHERE kind=? AND title=? AND scope=?',
                (meta['type'], meta['id'], context)).fetchone()
        if not row or now - row[2] > MAX_AGE:
            return None
        payload = json.loads(row[1])
        complete = payload.get('complete', True) if isinstance(payload, dict) else True
        found = payload.get('formats', []) if isinstance(payload, dict) else payload
        return dict(target=row[0], formats=found, complete=complete,
                    updated=row[2], stale=now-row[2]>(REFRESH if complete else PARTIAL_REFRESH), scope=context)
    except (sqlite3.Error, OSError, ValueError, KeyError):
        return None


def put(profile, meta, context, target, formats, now=None, complete=True, rows=None):
    now = time.time() if now is None else now
    try:
        with closing(_connect(profile)) as db, db:
            db.execute('INSERT OR REPLACE INTO badges VALUES (?,?,?,?,?,?)',
                (meta['type'], meta['id'], context, target, json.dumps({'formats':formats,'complete':bool(complete)}), now))
            db.execute('DELETE FROM badges WHERE updated<?', (now-MAX_AGE,))
        from lib.format_database import Database, source_sets
        Database(profile).remember(meta['type'], target, formats, now=now, complete=complete, sources=source_sets(rows) if rows is not None else None)
    except (sqlite3.Error, OSError, ValueError, KeyError):
        pass
