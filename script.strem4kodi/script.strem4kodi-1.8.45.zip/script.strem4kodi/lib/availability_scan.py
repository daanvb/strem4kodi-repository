"""Local-only progress for format availability scans; never uploaded."""
import json
import re
import threading
import time
from pathlib import Path

_latest = None


class Scan:
    def __init__(self, profile, page):
        global _latest
        try:self.path = Path(profile) / 'diagnostics' / 'logo-scan.json'
        except TypeError:self.path = None
        self.page = str(page)
        self.started = time.monotonic()
        self.lock = threading.RLock()
        self.total = 0
        self.active = {}
        self.results = {}
        self.next_save = 0
        _latest = self

    def queued(self, total):
        with self.lock:self.total = total

    def start(self, key, row):
        with self.lock:
            title = re.sub(r'https?://\S+', '[link]', str(row.get('name') or row.get('id') or 'Title'))
            self.active[key] = {'title': ' '.join(title.split())[:80], 'phase':'Checking cache', 'started':time.monotonic()}
            self.save()

    def phase(self, key, value):
        with self.lock:
            if key in self.active:
                self.active[key]['phase'] = {'cached':'Cached', 'metadata':'Finding episode', 'sources':'Waiting for source addons'}.get(value,'Checking cache')
                self.save()

    def finish(self, key, status):
        with self.lock:
            self.active.pop(key, None)
            self.results[key] = status
            self.save()

    def snapshot(self):
        with self.lock:
            now = time.monotonic()
            active = [dict(title=v['title'],phase=v['phase'],seconds=round(now-v['started'])) for v in self.active.values()]
            return {'page':self.page,'total':self.total,'checked':len(self.results),
                    'with_logos':sum(v=='logos' for v in self.results.values()),
                    'no_formats':sum(v=='unknown' for v in self.results.values()),
                    'failed':sum(v=='failed' for v in self.results.values()),
                    'pending':sum(v=='pending' for v in self.results.values()),
                    'seconds':round(now-self.started),'active':active,'recorded':time.time()}

    def save(self):
        if _latest is not self or self.path is None or time.monotonic() < self.next_save:
            return
        self.next_save = time.monotonic() + 2
        try:
            self.path.parent.mkdir(parents=True,exist_ok=True)
            self.path.write_bytes(json.dumps(self.snapshot()).encode('utf-8'))
        except OSError:
            pass


def snapshot(profile):
    try:path = Path(profile) / 'diagnostics' / 'logo-scan.json'
    except TypeError:return {}
    if _latest is not None and _latest.path == path:
        return _latest.snapshot()
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        return value if isinstance(value,dict) else {}
    except (OSError, ValueError):
        return {}


def describe(value):
    if not value:return 'No scan recorded'
    lines = ['Page: '+str(value.get('page','')), 'Checked: {} of {}'.format(value.get('checked',0),value.get('total',0)),
             'With logos: {} | No format details: {} | No result/retrying: {}'.format(value.get('with_logos',0),value.get('no_formats',0),value.get('failed',0)),
             'Waiting for addons: {}'.format(value.get('pending',0)),
             'Elapsed: {} seconds'.format(value.get('seconds',0))]
    for row in value.get('active',[]):
        lines.append('{} â€” {} ({} seconds)'.format(row['title'],row['phase'],row['seconds']))
    return '\n'.join(lines)
