"""Native UK live adapters; Widevine licences remain handled by the device CDM.

Protocol research: EasyPlayTV (Scottrix, GPL-2.0),
https://codeberg.org/scottrix/EasyPlayTV (resources/lib/{itvx,my5}.py).
No upstream account store, code execution, media keys or relay feeds are used.
"""
import base64
import hashlib
import hmac
import json
import re
import time
from dataclasses import dataclass, field
from urllib.parse import unquote

from lib.live_tv_http import json_request, request, secure_url
from lib.live_tv_quality import HDUnavailable

CHANNELS = (
    ('itv1', 'ITV1'), ('itv2', 'ITV2'), ('itv3', 'ITV3'), ('itv4', 'ITV4'),
    ('itv_quiz', 'ITV Quiz'),
    ('c4', 'Channel 4'), ('e4', 'E4'), ('more4', 'More4'), ('film4', 'Film4'), ('4seven', '4seven'),
    ('c5', 'Channel 5'), ('5star', '5STAR'), ('5usa', '5USA'), ('5action', '5ACTION'), ('5select', '5SELECT'),
)
C5_IDS = {'c5': 'C5', '5star': 'C6', '5usa': 'C7', '5action': 'C0', '5select': 'C8'}
ITV_IDS = {'itv1': 'ITV1', 'itv2': 'ITV2', 'itv3': 'ITV3', 'itv4': 'ITV4', 'itv_quiz': 'ITVBe'}


@dataclass(repr=False)
class LiveStream:
    url: str
    license_url: str = ''
    license_headers: dict = field(default_factory=dict)
    provider: str = ''
    license_token: str = ''

    def __post_init__(self):
        secure_url(self.url)
        if self.license_url:
            secure_url(self.license_url)


def aes_unwrap(ciphertext, key, iv):
    # This unwraps broadcaster API metadata, never Widevine media keys.
    try:
        from Cryptodome.Cipher import AES
        from Cryptodome.Util.Padding import unpad
    except ImportError:
        from Crypto.Cipher import AES
        from Crypto.Util.Padding import unpad
    return unpad(AES.new(key, AES.MODE_CBC, iv).decrypt(ciphertext), 16)


def resolve_itv(channel, account=None, fetch=json_request):
    if channel not in ITV_IDS:
        raise HDUnavailable('Unknown ITV channel.')
    if account is None:
        from lib.live_tv_accounts import ITVAccount
        account = ITVAccount()
    token = account.token()
    payload = {
        'client': {'id': 'browser', 'service': 'itv.x', 'supportsAdPods': False, 'version': '4.1'},
        'device': {'manufacturer': 'Firefox', 'model': '131.0',
                   'os': {'name': 'Linux', 'type': 'desktop', 'version': 'x86_64'}},
        'user': {'token': token},
        'variantAvailability': {'drm': {'maxSupported': 'L3', 'system': 'widevine'},
                                'featureset': {'min': ['mpeg-dash', 'widevine'],
                                               'max': ['hd', 'mpeg-dash', 'widevine', 'inband-webvtt']},
                                'platformTag': 'dotcom', 'player': 'dash'}}
    data = fetch('https://simulcast.itv.com/playlist/itvonline/' + ITV_IDS[channel], payload,
                 {'Accept': 'application/vnd.itv.online.playlist.sim.v3+json',
                  'Authorization': 'Bearer ' + token,
                  'Origin': 'https://www.itv.com', 'Referer': 'https://www.itv.com/'})
    location = data['Playlist']['Video']['VideoLocations'][0]
    return LiveStream(location['Url'], location.get('KeyServiceUrl', ''),
                      {'Referer': 'https://www.itv.com/', 'Content-Type': ''}, provider='itv')


def c5_metadata_keys(script):
    """Read the public player's API envelope configuration without executing JS."""
    match = re.search(r'''\}\)\(['"]([^'"]{6})['"]\)''', script)
    blob = re.search(r'''\(\s*\)\s*\{\s*return\s+(["'])(.{3000,}?)\1;\s*\}''', script)
    if not match or not blob:
        raise HDUnavailable('Channel 5 player has changed. An S4K update is needed.')
    xor = match.group(1)
    encoded = unquote(blob.group(2))
    decoded = ''.join(chr(ord(c) ^ ord(xor[i % len(xor)])) for i, c in enumerate(encoded))
    candidates = re.findall(r'(?<![A-Za-z0-9+/])([A-Za-z0-9+/]{22}={1,2})(?![A-Za-z0-9+/])', decoded)
    keys = [base64.b64decode(c + '=' * (-len(c) % 4)) for c in candidates]
    if len(keys) < 2 or any(len(k) != 16 for k in keys[:2]):
        raise HDUnavailable('Channel 5 metadata configuration is unavailable.')
    return keys[:2]


def resolve_c5(channel, fetch=request, clock=time.time):
    if channel not in C5_IDS:
        raise HDUnavailable('Unknown Channel 5 channel.')
    script = fetch('https://player.akamaized.net/html5player/core/html5-c5-player.js').decode('utf-8')
    keys = c5_metadata_keys(script)
    # The player has swapped the two metadata key roles between releases.
    for aes_key, signing_key in (keys, keys[::-1]):
        try:
            url = ('https://cassie.channel5.com/api/v2/live_media/my5desktopng/'
                   + C5_IDS[channel] + '.json?timestamp=' + str(int(clock())))
            signature = base64.urlsafe_b64encode(hmac.new(signing_key, url.encode(), hashlib.sha256).digest()).decode().rstrip('=')
            raw = json.loads(fetch(url + '&auth=' + signature,
                                   headers={'Origin': 'https://www.channel5.com', 'Referer': 'https://www.channel5.com/'}))
            decode = lambda value: base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
            data = json.loads(aes_unwrap(decode(raw['data']), aes_key, decode(raw['iv'])))
            for asset in data.get('assets', []):
                if asset.get('drm') == 'widevine' and asset.get('keyserver'):
                    return LiveStream(asset['renditions'][0]['url'], asset['keyserver'],
                                      {'Referer': 'https://www.channel5.com/', 'Content-Type': 'application/octet-stream'},
                                      provider='c5')
        except Exception:
            continue
    raise HDUnavailable('Channel 5 is unavailable in HD. Please retry later.')


def resolve_commercial(channel):
    try:
        if channel in ITV_IDS:
            return resolve_itv(channel)
        if channel in C5_IDS:
            return resolve_c5(channel)
        if channel in ('c4', 'e4', 'more4', 'film4', '4seven'):
            from lib.live_tv_c4 import resolve_c4
            return resolve_c4(channel)
        raise HDUnavailable('Unknown live channel.')
    except HDUnavailable:
        raise
    except Exception:
        raise HDUnavailable('Broadcaster response is unsupported. Please retry later.') from None


def license_response(stream, challenge, fetch=request):
    if not stream.license_url or not challenge or len(challenge) > 1024 * 1024:
        raise HDUnavailable('Invalid licence request.')
    if stream.provider == 'c4':
        from lib.live_tv_c4 import c4_license_response
        return c4_license_response(stream, challenge, fetch)
    return fetch(stream.license_url, data=challenge, headers=stream.license_headers, limit=1024 * 1024)
