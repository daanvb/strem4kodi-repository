"""Bounded diagnostic summaries uploaded only to the private sync repository."""
import base64
import hashlib
import json
import os
import re
import threading
import time
import uuid
from pathlib import Path
from contextlib import contextmanager
from collections import deque

_LOCK = threading.Lock()
_UPLOAD_LOCK = threading.Lock()
MANUAL_REQUEST = 'strem4kodi.diagnostics.send'
SOURCE_UPLOAD_UNKNOWN = 'Source-search upload failed; retry or send a diagnostic report'
SOURCE_UPLOAD_ERRORS = {
    'access':'Source-search upload failed; check private reporting access',
    'conflict':'Source-search upload failed; concurrent GitHub write, try again',
    'connection':'Source-search upload failed; could not connect to GitHub',
    'unavailable':'Source-search upload failed; GitHub temporarily unavailable',
    'backoff':'Source-search upload failed; GitHub requested a delay, try later',
    'verification':'Source-search upload verification failed; try again',
    'private':'Source-search upload blocked; repository must be private',
    'size':'Source-search upload failed; report exceeds the size limit',
    'response':'Source-search upload failed; unexpected GitHub response',
    'redirect':'Source-search upload blocked; repository redirected',
}


@contextmanager
def upload_guard(profile):
    """Serialize service/player interpreters without locking other profile writes."""
    directory = Path(profile) / 'diagnostic-export'
    directory.mkdir(parents=True, exist_ok=True)
    with _UPLOAD_LOCK, (directory / '.upload.lock').open('a+b') as stream:
        if os.name == 'nt':
            import msvcrt
            stream.seek(0, 2)
            if not stream.tell():
                stream.write(b'0'); stream.flush()
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if os.name == 'nt':
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def player_summary(label, visibility):
    """Only numeric Kodi measurements and fixed units leave the player."""
    def visible(name):
        try:return bool(visibility(name))
        except Exception:return False
    result = {'playing': visible('Player.HasVideo'),
              'caching': visible('Player.Caching'),
              'paused': visible('Player.Paused')}
    for field, name in (('cache', 'Player.CacheLevel'),
                        ('fps', 'Player.Process(VideoFPS)'),
                        ('width', 'Player.Process(VideoWidth)'),
                        ('height', 'Player.Process(VideoHeight)'),
                        ('video_bitrate', 'Player.Process(videolivebitrate)'),
                        ('audio_bitrate', 'Player.Process(audiolivebitrate)'),
                        ('queue', 'Player.Process(videoqueuelevel)'),
                        ('queue_data', 'Player.Process(videoqueuedatalevel)')):
        try:value = str(label(name) or '').strip()
        except Exception:continue
        if re.fullmatch(r'[0-9]{1,9}(?:\.[0-9]{1,6})?\s*(?:%|fps|[kKmMgG]?[bB](?:it)?/s|[kKmMgG]?[bB]|[kKmMgG]bps)?', value):
            result[field] = value
    return result
PATTERNS = {
    'errors': r'\bERROR\b', 'fatal': r'\bFATAL\b',
    'python_tracebacks': r'Traceback \(most recent call last\)',
    'stream_failure': r'error opening|failed to open|error loading stream|couldn.t start this stream',
    'no_matching_file': r'no matching file', 'torrent_pending': r'torrent.*download',
    'disc_failure': r'VIDEO_TS|UDF.*fail', 'native_crash': r'SIGSEGV|SIGABRT|SIGBUS|segmentation fault|fatal signal',
    'memory_failure': r'bad_alloc|out of memory|MemoryError|low memory',
    'gui_control_failure': r'non-existent control|control.{0,80}(?:does not exist|not found)|window.{0,80}does not exist',
    'texture_failure': r'(?:failed|unable) to load (?:texture|image)',
    'ui_xml_failure': r'(?:error|failed|unable).{0,60}(?:parsing xml|load skin|loading window)',
}

def log_summary(path):
    """Classify a bounded tail and export allowlisted technical excerpts."""
    try:
        from lib.diagnostic_logs import read_tail, excerpts
        text, tail_only = read_tail(path)
        return {'available': True, 'tail_only': tail_only,
                'counts': {key: len(re.findall(pattern, text, re.I)) for key, pattern in PATTERNS.items()},
                'excerpts': excerpts(text)}
    except OSError:
        return {'available': False}

def record_search(profile, query, counts, failed=False):
    try:
        from account import Store
        with _LOCK:
            store = Store(Path(profile) / 'diagnostic-search')
            rows = store.load().get('events', [])
            # No search text or deterministic query hash: avoid reconstructing viewing interests.
            rows.append({'time': int(time.time()), 'query_length': min(len(str(query)), 200),
                         'failed': bool(failed), 'results': {k: min(max(int(v), 0), 10000)
                         for k, v in counts.items() if k in ('titles', 'collections', 'lists', 'catalogues')}})
            store.save({'events': rows[-30:]})
    except Exception:
        pass

def record_source(profile, identity, row):
    try:
        from account import Store
        target = str(identity)
        target = target if re.fullmatch(r'tt[0-9]+(?::[0-9]+:[0-9]+)?', target) else 'unknown'
        hints = row.get('behaviorHints') if isinstance(row.get('behaviorHints'), dict) else {}
        data = row.get('streamData') if isinstance(row.get('streamData'), dict) else {}
        evidence = ' '.join(str(v) for v in (row.get('filename'), hints.get('filename'), data.get('filename'), row.get('description')) if v)
        episode_tags = sorted(set(re.findall(r'\bS[0-9]{1,3}E[0-9]{1,3}\b', evidence, re.I)))[:10]
        event = {'time': int(time.time()), 'requested_id': target,
                 'episode_tags': [v.upper() for v in episode_tags],
                 'fields_present': sorted(k for k in row if k in ('behaviorHints','streamData','filename','description','season','episode')),
                 'formats': [label for label, pattern in (('Atmos', r'\batmos\b'), ('TrueHD', r'\btrue[ .-]?hd\b'),
                    ('DTS', r'\bdts\b'), ('Dolby Vision', r'\bdolby vision\b'), ('HDR', r'\bhdr\b')) if re.search(pattern, evidence, re.I)]}
        with _LOCK:
            store = Store(Path(profile) / 'diagnostic-source')
            events = store.load().get('events', [])
            store.save({'events': (events + [event])[-30:]})
    except Exception:
        pass

def build(profile, addon, log_directory):
    from account import Store
    from lib.provider_diagnostics import rows
    from lib.playback_timing import load as timing
    from lib.perf_report import load as performance
    from lib.error_report import _environment
    report = {'version': 2, 'environment': _environment(),
              'logs': {name: log_summary(Path(log_directory) / name) for name in ('kodi.log', 'kodi.old.log')},
              'search': Store(Path(profile) / 'diagnostic-search').load().get('events', [])[-30:]}
    # Only fixed numeric timing fields; attempt identifiers and arbitrary properties are excluded.
    report['playback_ms'] = {k: v for k, v in timing().get('stages', {}).items()
                            if k in ('selected','dispatch','resolver','metadata','subtitles','resolved','playing','cancelled')
                            and isinstance(v, int) and 0 <= v <= 1800000}
    from lib.perf_report import STAGES
    report['performance'] = {k: {'ms': v.get('ms')} for k, v in performance(profile).items()
                             if k in STAGES and isinstance(v, dict) and isinstance(v.get('ms'), (int, float))}
    report['requests'] = [{k: r[k] for k in ('resource','status','ms','timeout') if k in r} for r in rows(profile)]
    report['sources'] = Store(Path(profile) / 'diagnostic-source').load().get('events', [])[-30:]
    from lib.runtime_trace import load as runtime_events
    report['runtime'] = runtime_events(profile)
    from lib.seek_diagnostics import load as seek_events
    report['seek_recovery'] = seek_events(profile)
    from lib.diagnostic_events import load as failures
    from lib.startup_trace import load as startups
    report['failures'] = failures(profile)
    report['startup'] = startups(profile)
    from lib.ui_crash import snapshot
    report['app_session'] = snapshot(profile)
    try:
        from setup_profile import get_setting
        report['display'] = {k: get_setting(k) for k in ('videoplayer.adjustrefreshrate', 'videoplayer.usedisplayasclock')}
    except Exception:
        report['display'] = {}
    report['options'] = {key: addon.getSetting(key) == 'true' for key in
                         ('prerolls_enabled','up_next_enabled','ui_animations','unpause_rewind_enabled')}
    return report

def upload(token, report, identity, transport=None, still_current=lambda: True, attachments=(), source_only=False):
    from lib.credits_sync import request, SyncError
    transport = transport or request
    if transport(token).get('private') is not True:
        raise SyncError('Diagnostic export requires a private repository','private')
    if not isinstance(identity, str) or not re.fullmatch(r'[0-9a-f]{32}', identity):
        raise SyncError('Invalid diagnostic client identity')
    # Six stable slots bound the repository footprint. The summary records
    # content hashes; Git history also retains earlier versions of each slot.
    for descriptor, data in attachments:
        name = descriptor.get('file', '')
        if (not re.fullmatch(r'[0-5]\.log\.gz', name) or len(data) > 256 * 1024 or
                hashlib.sha256(data).hexdigest() != descriptor.get('sha256')):
            raise SyncError('Invalid diagnostic attachment')
        if not still_current():return False
        target = '/contents/diagnostic-logs/' + identity + '/' + name
        prior = transport(token, target)
        if prior and base64.b64decode(prior.get('content', '')) == data:continue
        if not still_current():return False
        payload = {'message':'Update redacted private Kodi log', 'content':base64.b64encode(data).decode()}
        if prior:payload['sha'] = prior['sha']
        transport(token, target, payload)
        verified = transport(token, target)
        if not verified or base64.b64decode(verified.get('content', '')) != data:
            raise SyncError('Diagnostic log upload could not be verified')
    path = '/contents/' + ('diagnostics-source/' if source_only else 'diagnostics/') + identity + '.json'
    previous = transport(token, path)
    if not still_current():
        return False
    raw = json.dumps(report, sort_keys=True, separators=(',', ':')).encode()
    if len(raw) > 128 * 1024:
        raise SyncError('Diagnostic report exceeds the size limit','size')
    payload = {'message': 'Update private client diagnostic summary', 'content': base64.b64encode(raw).decode()}
    if previous:
        payload['sha'] = previous['sha']
    transport(token, path, payload)
    verified = transport(token, path)
    if not verified or base64.b64decode(verified.get('content', '')) != raw:
        raise SyncError('Diagnostic upload could not be verified','verification')
    return True

class Reporter:
    def __init__(self, profile, addon, log_directory, idle=lambda: True, player=None):
        self.profile, self.addon, self.logs, self.idle = profile, addon, log_directory, idle
        self.next_check, self.next_upload, self.busy = 0, 0, False
        self.captured_android = False
        self.player = player
        self.playback_ends = deque(maxlen=10)
        self.history_pending = True
        self.history_retry = 0
        self.worker_retry = 0

    def tick(self):
        if self.busy:
            return
        pop = getattr(type(self.player), 'pop_diagnostic_ends', None)
        if pop:self.playback_ends.extend(pop(self.player))
        enabled = self.addon.getSetting('diagnostics_github_enabled') == 'true'
        if not enabled:
            self.playback_ends.clear()
            return
        try:
            import xbmcgui
            session = xbmcgui.Window(10000)
            mode = session.getProperty(MANUAL_REQUEST)
            force = mode in ('true', 'source_search')
            source_only = mode == 'source_search'
        except Exception:
            session, force, source_only = None, False, False
        now = time.monotonic()
        if (not force or source_only) and now < self.worker_retry:return
        history_due = self.history_pending and now >= self.history_retry and self.idle()
        if not force and not self.playback_ends and not history_due and now < self.next_check:
            return
        if force:
            session.clearProperty(MANUAL_REQUEST)
        self.next_check = time.monotonic() + 60
        token = self.addon.getSetting('credits_github_token').strip()
        if not token:
            return
        self.busy = True
        try:
            # Preserve old.log immediately after restart, even during playback.
            # Network uploads still wait for idle or an explicit manual report.
            collect_only = not force and (not self.idle() or now < self.history_retry or
                (now < self.next_upload and not self.playback_ends and not history_due))
            options = {'force':force, 'collect_only':collect_only}
            if source_only:options['source_only'] = True
            threading.Thread(target=self.run, args=(token,), kwargs=options, daemon=True).start()
        except RuntimeError:
            self.busy = False
            self.next_check = now + 60
            self.worker_retry = now + 60
            if source_only and session is not None:
                session.setProperty(MANUAL_REQUEST, 'source_search')

    def run(self, token, live=None, force=False, collect_only=False, source_only=False):
        try:
            with upload_guard(self.profile):
                if source_only:return self._run_source(token)
                return self._run(token, live, force, collect_only)
        except OSError:
            self.worker_retry = time.monotonic() + 60
            return None
        finally:
            self.busy = False

    def _run_source(self, token):
        """Explicit timing-only export: never collect logs or playback history."""
        from account import Store
        from lib.perf_report import build_payload
        from lib.credits_sync import SyncError
        store = Store(Path(self.profile) / 'diagnostic-export')
        def current():
            return (self.addon.getSetting('diagnostics_github_enabled') == 'true'
                    and self.addon.getSetting('credits_github_token').strip() == token)
        def status(message):
            state = store.load()
            state['source_status'] = message
            store.save(state)
        try:
            if not current():
                status('Source-search upload cancelled')
                return
            report = build_payload(self.profile, source_only=True)
            if not report:
                status('No source-search measurements to upload')
                return
            state = store.load()
            identity = state.get('client')
            if not isinstance(identity, str) or not re.fullmatch(r'[0-9a-f]{32}', identity):
                identity = uuid.uuid4().hex
                state['client'] = identity
                store.save(state)
            # A different sync worker can advance the repository while this
            # report is being written. Refresh the SHA and verify once more;
            # never retry denied access or a server-requested delay.
            for attempt in range(2):
                if not current():
                    status('Source-search upload cancelled')
                    return
                try:
                    completed=upload(token, report, identity, still_current=current, source_only=True)
                except SyncError as error:
                    if attempt==0 and error.code in ('conflict','connection','unavailable','verification'):continue
                    raise
                if completed:
                    status('Source-search report uploaded and verified')
                    return identity[:8]
                status('Source-search upload cancelled')
                return
        except Exception as error:
            from lib.diagnostic_events import record
            record('diagnostics.source',error,self.profile)
            try:
                message=SOURCE_UPLOAD_ERRORS.get(getattr(error,'code',None),SOURCE_UPLOAD_UNKNOWN)
                status(message if current() else 'Source-search upload cancelled')
            except Exception:pass  # A storage failure cannot terminate the service.

    def _run(self, token, live=None, force=False, collect_only=False):
        try:
            from account import Store
            def still_current():
                return (self.addon.getSetting('diagnostics_github_enabled') == 'true'
                        and self.addon.getSetting('credits_github_token').strip() == token)
            if not still_current():return
            store = Store(Path(self.profile) / 'diagnostic-export')
            state = store.load()
            identity = state.get('client')
            if not isinstance(identity, str) or not re.fullmatch(r'[0-9a-f]{32}', identity):
                identity = uuid.uuid4().hex
                state['client'] = identity
                store.save(state)
            from lib.diagnostic_archive import capture, attachments
            try:
                snapshot = capture(self.profile, self.addon, self.logs,
                                   include_android=force or not self.captured_android)
                self.captured_android = True
            except Exception as error:
                snapshot = {'snapshots':[], 'sources':{'capture':'failed'}}
                from lib.diagnostic_events import record
                record('service', error, self.profile)
            if not still_current():return
            from lib import diagnostic_playback as history
            report = None
            files = attachments(self.profile, snapshot)
            if self.playback_ends:
                report = build(self.profile, self.addon, self.logs)
                report['version'] = 3
                report['log_capture'] = snapshot
                while self.playback_ends:
                    if not still_current():return
                    history.save(self.profile, report, files, self.playback_ends[0])
                    self.playback_ends.popleft()
            self.history_pending = history.pending(self.profile)
            if collect_only:return
            # Autoplay may have started while the report was being prepared.
            # Recheck before every remote write, without touching playback.
            def can_upload():
                return still_current() and (force or self.idle())
            if not can_upload():return
            if self.history_pending:
                if not history.upload(self.profile, token, identity, still_current=can_upload):return
                self.history_pending = False
            if report is None:report = build(self.profile, self.addon, self.logs)
            report['version'] = 3
            report['log_capture'] = snapshot
            if live is not None:
                report['player'] = live
            digest = hashlib.sha256(json.dumps(report, sort_keys=True).encode()).hexdigest()
            if not force and state.get('digest') == digest:
                self.next_upload = time.monotonic() + 900
                return
            # Recheck opt-out/token after collection and before network mutation.
            if not still_current():
                return
            if not upload(token, report, identity, still_current=can_upload,
                          attachments=files):
                return
            state.update(digest=digest, uploaded=int(time.time()), status='Uploaded to private GitHub')
            store.save(state)
            self.next_upload = time.monotonic() + 900
            return identity[:8]
        except Exception:
            self.history_retry = time.monotonic() + 60
            if self.playback_ends:self.worker_retry = self.history_retry
            try:
                from account import Store
                store = Store(Path(self.profile) / 'diagnostic-export')
                state = store.load()
                state['status'] = 'Export will retry; check private GitHub token access'
                store.save(state)
            except Exception:
                pass
        finally:
            self.busy = False


def report_reference(profile):
    try:
        from account import Store
        data=Store(Path(profile)/'diagnostic-export').load()
        identity=data.get('client')
        if isinstance(identity,str) and re.fullmatch(r'[0-9a-f]{32}',identity):
            return 'Report: '+identity[:8]+(' (uploaded)' if data.get('uploaded') else ' (pending)')
    except Exception:pass
    return 'Diagnostics: Settings > Troubleshooting'
