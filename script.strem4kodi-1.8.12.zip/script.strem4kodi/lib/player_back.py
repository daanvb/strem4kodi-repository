"""Short-lived fullscreen Back handler; no media/account requests."""
import hashlib
import json
import time

PROPERTY = 'strem4kodi.player.back'
WINDOW_SECONDS = 3.0


def decide(raw, identity, now):
    try:
        previous = json.loads(raw)
        elapsed = now - float(previous['time'])
        if previous.get('identity') == identity and 0 <= elapsed <= WINDOW_SECONDS:
            return True, ''
    except (ValueError, TypeError, KeyError):
        pass
    return False, json.dumps({'identity': identity, 'time': now}, separators=(',', ':'))


def run(kodi=None, gui=None, clock=time.monotonic):
    if kodi is None:
        import xbmc as kodi
    if gui is None:
        import xbmcgui as gui
    window = gui.Window(10000)
    player = kodi.Player()
    if not player.isPlayingVideo() or not kodi.getCondVisibility('Window.IsActive(fullscreenvideo)'):
        window.clearProperty(PROPERTY)
        return
    identity = hashlib.sha256(player.getPlayingFile().encode('utf-8')).hexdigest()
    stop, state = decide(window.getProperty(PROPERTY), identity, clock())
    if stop:
        window.clearProperty(PROPERTY)
        player.stop()
    else:
        window.setProperty(PROPERTY, state)
        gui.Dialog().notification('Strem4Kodi', 'Press Back again to stop playback',
                                  time=3000, sound=False)
