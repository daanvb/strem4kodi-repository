"""Addon-owned, reversible fullscreen Back keymap."""
from pathlib import Path

KEYMAP = '''<keymap>
  <FullscreenVideo>
    <keyboard><escape>Stop</escape><backspace>Stop</backspace><browser_back>Stop</browser_back></keyboard>
    <remote><back>Stop</back></remote>
    <joystick profile="game.controller.default"><b>Stop</b></joystick>
  </FullscreenVideo>
</keymap>
'''


DOUBLE_KEYMAP = KEYMAP.replace('Stop', 'RunScript(special://home/addons/script.strem4kodi/player_back.py)')


def back_mode(addon):
    if addon.getSetting('playback_back_migrated') != 'true':
        if addon.getSetting('playback_back_stops') == 'false':
            addon.setSetting('playback_back_action', '0')
        addon.setSetting('playback_back_migrated', 'true')
    try:
        value = int(addon.getSetting('playback_back_action') or '2')
        return value if value in (0, 1, 2) else 2
    except (ValueError, TypeError):
        return 2


def write_keymap(directory, enabled, double=False):
    target = Path(directory) / 'zz-strem4kodi-back.xml'
    legacy = Path(directory) / 'zz-stremio-for-kodi-back.xml'
    migrated = False
    if legacy.exists() and legacy.read_text(encoding='utf-8') in (KEYMAP, DOUBLE_KEYMAP):
        legacy.unlink()
        migrated = True
    content = DOUBLE_KEYMAP if double else KEYMAP
    if enabled:
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and target.read_text(encoding='utf-8') == content:
            return migrated
        target.write_text(content, encoding='utf-8', newline='\n')
        return True
    if target.exists():
        target.unlink()
        return True
    return migrated


def apply():
    import xbmc
    import xbmcvfs
    try:
        from addon_state import get_addon
    except ModuleNotFoundError:
        # Report/repository entry points can import this helper without default.py
        # having first inserted core/ on sys.path. Keep startup independent.
        from core.addon_state import get_addon
    mode = back_mode(get_addon())
    if write_keymap(xbmcvfs.translatePath('special://profile/keymaps/'),
                    mode != 0, double=mode == 2):
        xbmc.executebuiltin('Action(ReloadKeymaps)')
