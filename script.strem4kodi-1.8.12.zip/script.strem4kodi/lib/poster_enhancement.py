"""Treat installed BetterPosters as artwork, rather than duplicate catalogue rows."""
import re
from urllib.parse import urlsplit


def _host(value):
    try:return urlsplit(str(value or '')).hostname or ''
    except ValueError:return ''


def enabled(addons):
    return any(is_provider(a) for a in addons)


def is_provider(addon):
    manifest = addon.get('manifest') or {}
    name = re.sub(r'\W', '', str(manifest.get('name') or manifest.get('id') or '')).casefold()
    return 'betterposters' in name


def template(rows):
    for row in rows:
        poster=str(row.get('poster') or '')
        host=_host(poster)
        if host=='btttr.cc' or host.endswith('.btttr.cc'):
            if re.search(r'tt\d+',poster):return re.sub(r'tt\d+','{imdb}',poster,count=1)
    return 'https://btttr.cc/poster/imdb/poster-default/{imdb}.jpg'


def decorate(rows, addons, pattern=None):
    if not enabled(addons):return list(rows)
    pattern=pattern or template(rows)
    result=[]
    for row in rows:
        copy=dict(row)
        identity=str(copy.get('imdb_id') or copy.get('imdbId') or copy.get('id') or '').partition(':')[0]
        if re.fullmatch(r'tt\d+',identity) and copy.get('type') in ('movie','series'):
            # Keep artwork already supplied by the user's configured style.
            host=_host(copy.get('poster'))
            if host!='btttr.cc' and not host.endswith('.btttr.cc'):
                copy['poster']=pattern.replace('{imdb}',identity)
        result.append(copy)
    return result


def consolidate(specs):
    """Use the artwork wrapper when it duplicates an installed catalogue."""
    def key(row):
        label=re.sub(r'(?i)better\s*posters?', '',row.get('label',''))
        label=re.sub(r'\W+',' ',label).strip().casefold()
        return row.get('kind'),label
    decorated={key(s):s for s in specs if 'betterposters' in re.sub(r'\W','',str(s.get('addon') or '')).casefold()}
    result=[];seen=set()
    for spec in specs:
        identity=key(spec)
        chosen=decorated.get(identity,spec)
        if identity in decorated:
            if identity in seen:continue
            seen.add(identity)
            chosen=dict(chosen)
            chosen['label']=re.sub(r'(?i)\s*[-|:]?\s*better\s*posters?\s*[-|:]?\s*','',chosen['label']).strip() or spec['label']
        result.append(chosen)
    return result
