"""Local, session-bound media details. Source claims never become detections."""
import hashlib
import math
import re
from lib.player_audio import audio_description, detected_codec


def safe(value, limit=150):
    from lib.stream_presenter import line
    return line(value, limit).replace('[', '').replace(']', '')


def number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) and value > 0 else 0
    except (ValueError, TypeError):
        return 0


def dv_detail(value):
    match = re.fullmatch(r'\s*([578])(?:\.([0-9]))?\s*(FEL|MEL|EL)?\s*', str(value or ''), re.I)
    if not match:
        return ''
    profile = match[1] + ('.' + match[2] if match[2] else '')
    return 'Profile ' + profile + (' · ' + match[3].upper() if match[3] else '')


def source_details(stream):
    from lib.stream_presenter import presentation
    from lib.fel_catalog import badge
    view = presentation(stream)
    profile = stream.get('dolbyVisionProfile') or stream.get('dvProfile')
    layer = str(stream.get('enhancementLayer') or stream.get('dvEnhancementLayer') or '').upper()
    detail = dv_detail(str(profile or '') + (' ' + layer if layer in ('FEL', 'MEL', 'EL') else ''))
    if not detail:
        detail = badge(stream)
    return {key: safe(value) for key, value in {
        'source': view['title'], 'video': view['detail'], 'audio': view['audio'],
        'dv': detail}.items() if value}


def resolution_format(width, height):
    width, height = number(width), number(height)
    if not width or not height:
        return '', ''
    if width >= 7680 or height >= 4320:
        return '8k', '8K UHD'
    if width >= 3840 or height >= 2160:
        return '4k', '4K UHD'
    if width <= 2048 and height <= 1080 and (width >= 1920 or height >= 1080):
        return '1080p', '1080p Full HD'
    if width <= 1366 and height <= 768 and (width >= 1280 or height >= 720):
        return '720p', '720p HD'
    return '', ''


def format_icons(hdr, codec, audio, active_codec='', width=0, height=0):
    # Only local known assets; track titles and source claims cannot set badges.
    audio = audio if isinstance(audio, dict) else {}
    base = detected_codec(audio, active_codec)
    audio_icon = {'ac3': 'ac3', 'eac3': 'eac3', 'truehd': 'truehd',
                  'eac3_ddp_atmos': 'atmos', 'truehd_atmos': 'atmos', 'atmos':'atmos',
                  'dca': 'dts', 'dts': 'dts', 'dtshd_ma': 'dtshd_ma',
                  'dtshd_hra': 'dtshd_hra', 'dtshd_ma_x':'dtshd_ma', 'dtshd_ma_x_imax':'dtshd_ma',
                  'aac': 'aac', 'aac_lc':'aac', 'he_aac':'aac', 'he_aac_v2':'aac', 'flac': 'flac'}.get(base, '')
    names = {'hdr': {'Dolby Vision': 'dolbyvision', 'HDR10': 'ui/hdr10', 'HDR10+': 'ui/hdr10plus', 'HDR': 'ui/hdr', 'HLG': 'ui/hlg'}.get(hdr, ''),
             'video': '', 'audio': audio_icon,
             'audio_base': {'truehd_atmos':'truehd', 'eac3_ddp_atmos':'eac3'}.get(base, ''),
             'resolution': ('ui/' + resolution_format(width, height)[0]) if resolution_format(width, height)[0] else ''}
    return {key: ('special://home/addons/script.strem4kodi/resources/skins/Main/media/formats/' + name + '.png') if name else ''
            for key, name in names.items()}


def snapshot(rpc, label, playing_file, context=None, language_name=None):
    file = playing_file()
    players = rpc('Player.GetActivePlayers') or []
    player = next((p for p in players if p.get('type') == 'video'), None)
    if not file or not player:
        return None
    props = rpc('Player.GetProperties', {'playerid': player['playerid'],
                'properties': ['currentvideostream', 'currentaudiostream', 'currentsubtitle', 'subtitleenabled']}) or {}
    def info(name):
        try:
            return safe(label(name))
        except Exception:
            return ''
    video = props.get('currentvideostream') or {}
    audio = props.get('currentaudiostream') or {}
    width = number(video.get('width')) or number(info('Player.Process(VideoWidth)'))
    height = number(video.get('height')) or number(info('Player.Process(VideoHeight)'))
    codec = info('VideoPlayer.VideoCodec') or safe(video.get('codec'))
    codec = {'hevc': 'HEVC / H.265', 'h265': 'HEVC / H.265', 'h264': 'AVC / H.264', 'av1': 'AV1'}.get(codec.lower(), codec.upper())
    hdr = info('VideoPlayer.HdrType') or safe(video.get('hdrtype'))
    hdr = {'dolbyvision': 'Dolby Vision', 'hdr10': 'HDR10', 'hdr10plus': 'HDR10+', 'hlg': 'HLG', 'sdr': 'SDR'}.get(hdr.lower(), hdr)
    fps = number(info('Player.Process(VideoFPS)'))
    detail = dv_detail(info('VideoPlayer.HdrDetail')) if hdr == 'Dolby Vision' else ''
    resolution_name = resolution_format(width, height)[1]
    detected = [('Resolution', (resolution_name + ' | ' if resolution_name else '') + '{} × {}'.format(int(width), int(height)) if width and height else 'Not reported'),
                ('Video codec', codec or 'Not reported'),
                ('Frame rate', ('{:.3f}'.format(fps).rstrip('0').rstrip('.') + ' fps') if fps else 'Not reported'),
                ('Dynamic range', hdr or 'Not reported'),
                ('Dolby Vision', detail or ('Profile not reported by Kodi' if hdr == 'Dolby Vision' else 'Not reported')),
                ('Pixel format', info('Player.Process(PixFormat)') or 'Not reported'),
                ('Video decoder', info('Player.Process(VideoDecoder)') or 'Not reported'),
                ('Audio', audio_description(audio, language_name, info('VideoPlayer.AudioCodec'))),
                ('Audio sample rate', info('Player.Process(AudioSamplerate)') or 'Not reported'),
                ('Subtitles', safe((props.get('currentsubtitle') or {}).get('name') or 'Enabled') if props.get('subtitleenabled') else 'Off')]
    context = context or {}
    reported = context.get('media_info') if context.get('url_hash') == hashlib.sha256(file.encode()).hexdigest() else {}
    reported = reported if isinstance(reported, dict) else {}
    claims = [(title, safe(reported.get(key))) for key, title in
              (('source', 'Source'), ('video', 'Video'), ('audio', 'Audio'), ('dv', 'Dolby Vision')) if reported.get(key)]
    icons = format_icons(hdr, codec, audio, info('VideoPlayer.AudioCodec'), width, height)
    title = info('VideoPlayer.Title') or 'Current video'
    if playing_file() != file:
        return None
    return {'file': file, 'title': title, 'detected': detected,
            'reported': claims, 'icons': icons, 'note': 'Source-reported details are unverified. A FEL label does not confirm enhancement-layer processing.'}


def show():
    import threading
    import xbmc
    import xbmcgui
    import xbmcvfs
    from pathlib import Path
    from account import Store
    from setup_profile import rpc
    from addon_state import get_addon
    from lib.theme import window
    from lib.player_controls import menu_session_active
    player = xbmc.Player()
    profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
    context = Store(profile / 'playback').load()
    data = snapshot(rpc, xbmc.getInfoLabel, player.getPlayingFile, context,
                    lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME))
    if not data:
        return
    def text(rows):
        return '[CR][CR]'.join('[B]' + key + '[/B][CR]' + safe(value) for key, value in rows)
    class MediaWindow(xbmcgui.WindowXMLDialog):
        def onInit(self):
            self.closed = False
            if not menu_session_active(player, data['file']):
                self.close()
                return
            self.refresh(data)
            self.setFocusId(600)
            def watch():
                monitor = xbmc.Monitor()
                while not self.closed and not monitor.waitForAbort(1):
                    if not menu_session_active(player, data['file']):
                        self.close()
                        return
                    try:
                        fresh = snapshot(rpc, xbmc.getInfoLabel, player.getPlayingFile, context,
                                         lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME))
                        if fresh and not self.closed:
                            self.refresh(fresh)
                    except Exception:
                        pass
            threading.Thread(target=watch, daemon=True).start()
        def refresh(self, data):
            if getattr(self, 'last_data', None) == data:
                return
            self.last_data = data
            self.setProperty('media_title', data['title'])
            self.setProperty('media_detected', text(data['detected']))
            self.setProperty('media_reported', text(data['reported']) if data['reported'] else 'No source details supplied for this playback.')
            self.setProperty('media_note', data['note'])
            for key, value in data['icons'].items():
                self.setProperty('media_' + key + '_icon', value)
            self.setProperty('media_atmos', 'true' if data['icons']['audio'].endswith('/atmos.png') else '')
            self.setProperty('media_hdr_logo', 'true' if data['icons']['hdr'].endswith('/dolbyvision.png') else '')
            self.setProperty('media_hdr_tint', 'FFFFFFFF' if data['icons']['hdr'].endswith('/hdr10plus.png') else 'FF101A29')
            self.setProperty('media_audio_tint', 'FFFFFFFF' if data['icons']['audio'].endswith(('/dts.png', '/dtshd_ma.png')) else 'FF101A29')
            self.setProperty('media_audio_logo', 'true' if any(data['icons'][key].endswith('/' + name + '.png') for key in ('audio', 'audio_base') for name in ('truehd', 'eac3')) else '')
        def close(self):
            self.closed = True
            super().close()
        def onClick(self, cid):
            if cid == 602:
                self.close()
        def onAction(self, action):
            if action.getId() in (10, 92, 216, 247):
                self.close()
    dialog = window(MediaWindow, 'script-strem4kodi-player-media.xml', get_addon().getAddonInfo('path'), 'Main', '1080i')
    dialog.doModal()
