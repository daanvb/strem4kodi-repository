"""Display-only stream rows. Never change resolver data or expose stream URLs."""
import re
from core.stream_ui import stream_card


def line(value, limit=350):
    text = re.sub(r'<[^>]*>', '', str(value or ''))
    text = re.sub(r'\[/?(?:B|I|CR|TAB|LIGHT|COLOR[^\]]*|UPPERCASE|LOWERCASE)\]', '', text, flags=re.I)
    text = re.sub(r'(?:https?|plugin|magnet)://\S+', '[source]', text, flags=re.I)
    text = ''.join(' ' if ord(ch) < 32 or ord(ch) == 127 else ch for ch in text)
    return ' '.join(text.split())[:limit]


def presentation(row):
    raw = row.get('card')
    source = dict(row)
    if isinstance(raw, dict):
        source['detail'] = str(row.get('detail') or '') + ' ' + str(raw.get('tech') or '')
    parsed = stream_card(source)
    card = dict(parsed)
    if isinstance(raw, dict):
        card.update({k:v for k,v in raw.items() if v not in (None, '', [], {})})
        if raw.get('quality')=='AUTO' and parsed.get('quality')!='AUTO':card['quality']=parsed['quality']
    quality = line(card.get('quality') or 'AUTO', 24)
    provider = line(card.get('provider') or row.get('provider') or 'Unreported', 70)
    size = line(card.get('size') or '', 24)
    from urllib.parse import urlsplit
    live=row.get('isLive') is True or urlsplit(str(row.get('url') or '')).path.lower().endswith('.m3u8')
    title = ' | '.join([quality if quality != 'AUTO' else 'Quality unreported',
                        size or ('Live stream' if live else 'Size unreported'), provider])
    tags = card.get('video_tags') or []
    formats = [t for t in tags if t in ('Dolby Vision', 'HDR10', 'HDR')]
    codecs = [t for t in tags if t in ('AV1', 'H.265', 'H.264', '10bit')]
    release = [t for t in tags if t in ('REMUX', 'BluRay', 'WEB-DL', 'WEBRip')]
    source = line(card.get('source') or ' / '.join(release) or 'Unreported', 70)
    from lib.fel_catalog import badge
    fel = badge(row) if row.get('_fel_labels', True) else ''
    video = (fel + ' | ' if fel else '') + 'Video: ' + (' / '.join(formats) or 'HDR unreported')
    if codecs: video += ' | Codec: ' + ' / '.join(codecs)
    video += ' | Source: ' + source
    if live and not formats and not codecs and source=='Unreported':video='Live stream'
    if card.get('bitrate'):video+=' | Bitrate: '+line(card['bitrate'],30)
    audio = 'Audio: ' + (' / '.join(card.get('audio_tags') or []) or 'Unreported')
    languages = line(card.get('languages'), 70)
    if languages: audio += ' | Language: ' + languages
    return {'title': line(title, 180), 'detail': line(video, 220),
            'audio': line(audio, 220), 'quality': quality}


def stream_traits(row):
    view = presentation(row)
    text = ' '.join((view.get('title',''), view.get('detail',''),view.get('audio',''))).upper()
    provider = line((row.get('card') or {}).get('provider') or row.get('provider') or 'Stream',70)
    codecs=[]
    if 'H.265' in text or 'HEVC' in text: codecs.append('HEVC / H.265')
    if 'H.264' in text or 'AVC' in text: codecs.append('H.264 / AVC')
    if 'AV1' in text: codecs.append('AV1')
    dynamic=[]
    if 'DOLBY VISION' in text or re.search(r'\bDV\b',text): dynamic.append('Dolby Vision')
    if 'HDR10' in text: dynamic.append('HDR10')
    elif re.search(r'\bHDR\b(?! UNREPORTED)',text): dynamic.append('HDR')
    if row.get('_fel_labels', True):
        from lib.fel_catalog import badge
        if badge(row) in ('FEL reported', 'P7 FEL reported'):dynamic.append('FEL reported')
        if badge(row) == 'P7 FEL reported':dynamic.append('P7 FEL reported')
    return {'provider':provider,'codecs':codecs,'dynamic':dynamic,'quality':view.get('quality','AUTO')}

def provider_choices(rows):
    return ['All'] + sorted({stream_traits(row)['provider'] for row in rows if stream_traits(row)['provider']})

def filter_rows(rows, provider='All', codec='All', dynamic='All', audio='All', quality='All'):
    out=[]
    for row in rows:
        t=stream_traits(row)
        if provider!='All' and t['provider']!=provider: continue
        if codec!='All' and codec not in t['codecs']: continue
        if dynamic!='All' and dynamic not in t['dynamic']: continue
        if quality!='All' and t['quality']!=quality:continue
        if audio!='All' and audio.casefold() not in presentation(row)['audio'].casefold():continue
        out.append(row)
    return out

def quality_choices(rows):
    values = {presentation(row)['quality'] for row in rows}
    order = ('4K', '1080p', '720p', '480p', '360p', 'AUTO')
    return ['All'] + sorted(values, key=lambda q: (order.index(q) if q in order else 99, q))


def target_label(meta, identity):
    if meta.get('type') != 'series':
        return line(meta.get('name') or meta.get('title'), 110)
    video = next((v for v in meta.get('videos', []) if v.get('id') == identity), {})
    season, episode = video.get('season'), video.get('episode')
    code = 'S{:02d}E{:02d}'.format(season, episode) if type(season) is int and type(episode) is int else ''
    return line(' · '.join(v for v in (code, video.get('name') or video.get('title') or meta.get('name')) if v), 110)


def playback_meta(meta, identity):
    result = dict(meta)
    if meta.get('type') == 'series':
        result['_stremio_meta_id'] = meta.get('_stremio_meta_id') or meta.get('id')
        video = next((v for v in meta.get('videos', []) if v.get('id') == identity), {})
        result.update(id=identity, name=video.get('name') or video.get('title') or meta.get('name'),
                      season=video.get('season'), episode=video.get('episode'),
                      tvshowtitle=meta.get('name'), _media_type='episode')
    return result
