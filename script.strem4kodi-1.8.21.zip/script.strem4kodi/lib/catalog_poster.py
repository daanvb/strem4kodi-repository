"""Resolve preferred posters independently of catalogue membership."""
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor

from addons_core import active_addons
from protocol import fetch, resource_url
from sources import supports
from provider_roles import artwork_providers, name, selected


def identity(row):
    kind = row.get('type')
    if kind not in ('movie', 'series'):
        return None
    value = str(row.get('imdb_id') or row.get('imdbId') or row.get('id') or row.get('_id') or '')
    imdb = re.fullmatch(r'(?:imdb:)?(tt\d+)(?::\d+:\d+)?', value)
    return (kind, imdb[1] if imdb else value) if value else None


class Posters:
    def __init__(self, state, cache=None, fetcher=None):
        self.providers = artwork_providers(state)
        self.explicit = selected(state, 'artwork') is not None
        self.trust_catalog = not state.get('artworkRevision')
        self.signature = hashlib.sha256(repr(([p.get('transportUrl') for p in self.providers],
                                               state.get('artworkRevision', 0))).encode()).hexdigest()
        self.cache = cache
        # Configured metadata may need to resolve IDs and generate custom art.
        # This runs off the UI thread; use the normal metadata request budget.
        self.fetcher = fetcher or (lambda url: fetch(url, timeout=15, use_cache=False))

    def key(self, title):
        return 'configured-poster-v1:' + self.signature + ':' + title[0] + ':' + title[1]

    def known(self, catalogs, include_catalog=True):
        result = {}
        if not self.providers:
            return result
        names = {name(p) for p in self.providers}
        urls = {p.get('transportUrl') for p in self.providers}
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                owner = catalog.get('addon') or ''
                current = (catalog.get('url') in urls if catalog.get('url') else
                           not self.explicit and len(self.providers) == 1 and owner in names)
                if include_catalog and title and row.get('poster') and current and self.trust_catalog:
                    result.setdefault(title, {'poster': row['poster'], '_poster_provider': owner,
                                              '_poster_preferred': True})
        if self.cache is not None:
            keys = {self.key(identity(row)) for catalog in catalogs for row in catalog.get('items', [])
                    if identity(row)}
            try:
                bulk = self.cache.get_many(keys) if hasattr(self.cache, 'get_many') else None
            except Exception:
                bulk = {}
            checked = set()
            for catalog in catalogs:
                for row in catalog.get('items', []):
                    title = identity(row)
                    if title and title not in checked:
                        checked.add(title)
                        try:
                            cached = bulk.get(self.key(title)) if bulk is not None else self.cache.get(self.key(title))
                            if isinstance(cached, dict) and cached.get('expires', 0) > time.time():
                                artwork = cached.get('artwork') or {}
                                if artwork or not include_catalog:
                                    result[title] = artwork
                        except Exception:
                            pass
        return result

    @staticmethod
    def apply(catalogs, known):
        return [dict(catalog, items=[dict(row, **known.get(identity(row), {}))
                                     for row in catalog.get('items', [])]) for catalog in catalogs]

    def cached(self, catalogs):
        return self.apply(catalogs, self.known(catalogs))

    def refresh(self, catalogs, cancelled=lambda: False):
        # Catalogue/snapshot images are immediate placeholders. They must not
        # permanently prevent checking the configured metadata artwork endpoint.
        known = self.known(catalogs, include_catalog=False)
        pending = []
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                if title and title not in known and title not in pending:
                    pending.append(title)
        if not self.providers:
            return

        def lookup(title):
            if cancelled():
                return title, {}
            kind, media_id = title
            for provider in self.providers:
                if not supports(provider.get('manifest') or {}, kind, media_id, 'meta'):
                    continue
                try:
                    payload = self.fetcher(resource_url(provider['transportUrl'], 'meta', kind, media_id))
                    meta = payload.get('meta') if isinstance(payload, dict) else None
                    poster = meta.get('poster') if isinstance(meta, dict) else None
                    if (isinstance(meta, dict) and meta.get('type', kind) == kind
                            and identity(dict(meta, type=kind)) == title and isinstance(poster, str)
                            and poster.startswith(('https://', 'http://'))):
                        return title, {'poster': poster, '_poster_provider': name(provider), '_poster_preferred': True}
                except Exception:
                    # URLs may contain private configuration: never log them.
                    continue
            return title, {}

        for offset in range(0, len(pending), 8):
            if cancelled():
                return
            with ThreadPoolExecutor(max_workers=4) as pool:
                results = list(pool.map(lookup, pending[offset:offset + 8]))
            if cancelled():
                return
            changed = False
            for title, artwork in results:
                if self.cache is not None:
                    ttl = 900 if artwork else 60
                    try:
                        self.cache.put(self.key(title), {'artwork': artwork, 'expires': time.time() + ttl}, ttl)
                    except Exception:
                        pass
                if artwork:
                    known[title] = artwork
                    changed = True
            if changed:
                yield self.apply(catalogs, known)


def configured(state):
    from lib.cache_policy import open_cache, read_policy
    try:
        from addon_state import get_addon
        import xbmcvfs
        from lib.provider_config import state as provider_state
        state = provider_state(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')), state)
    except (ImportError, AttributeError):
        pass
    posters = Posters(state)
    if posters.providers:
        posters.cache = open_cache('metadata', read_policy())
    return posters
