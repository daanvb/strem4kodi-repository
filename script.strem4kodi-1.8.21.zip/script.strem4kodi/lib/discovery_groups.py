"""Group account catalogues without changing their provider configuration."""
import re
from concurrent.futures import ThreadPoolExecutor


def item_key(row):
    from lib.catalog_poster import identity
    ids = row.get('ids') if isinstance(row.get('ids'), dict) else {}
    imdb = row.get('_imdbId') or ids.get('imdb') or ids.get('imdb_id')
    return identity(dict(row, imdb_id=imdb or row.get('imdb_id'))) or (row.get('type'), row.get('id'))


def clean_label(value):
    value = re.sub(r'(?i)\b(?:aiometadata|trakt|simkl|tmdb|thetvdb|tvdb|imdb|mdblist|cinemeta)\b\s*[-|:]?\s*', '', value)
    value = re.sub(r'(?i)\s*\((?:movies?|shows?|series)\)\s*$', '', value)
    return value.strip(' -|:')


def category(spec):
    # User-visible list names determine categories; opaque provider IDs don't.
    display_label = clean_label(spec['label']) or spec['label']
    text = re.sub(r'[^a-z0-9]+', ' ', display_label.lower())
    if re.search(r'\bcollection\b', text):
        return display_label
    for label, pattern in (
        ('Star Wars', r'\bstar\s*wars\b'), ('Marvel', r'\bmarvel\b'),
        ('DC', r'\bdc\b'), ('Trending', r'\btrending\b'),
        ('Popular', r'\bpopular\b'),
        ('All-time Greats', r'\b(all time|top rated|highest rated|best rated|greatest|top 250)\b'),
        ('New Releases', r'\b(new releases|recently released|latest releases)\b'),
        ('Hidden Gems', r'\bhidden gems\b'), ('Most Watched', r'\bmost watched\b'),
        ('Binge-Worthy', r'\bbinge worthy\b'), ('Quick Watches', r'\bquick watches\b'),
        ('Box Office Hits', r'\bbox office\b'), ('Recommendations', r'\brecommendations?\b'),
        ('Most Anticipated', r'\banticipated\b'), ('Community Favourites', r'\bmost (favorited|favourited|favorites|favourites)\b'),
        ('Favourites', r'\b(favorites|favourites)\b'), ('Watchlist', r'\bwatchlist\b'),
        ('Watch History', r'\b(history|watched history)\b'), ('Genres', r'\bgenres\b')):
        if re.search(pattern, text):
            return label
    # Preserve custom lists rather than guessing their meaning.
    return display_label


def family(spec):
    if re.search(r'(?i)\bcollection\b', spec['label']):
        return 'Collections'
    if category(spec) in ('Netflix', 'Netflix Kids', 'HBO Max', 'Disney+', 'Prime Video', 'Apple TV',
                          'BBC iPlayer', 'Channel 4', 'Discovery+', 'ITVX', 'Paramount Plus'):
        return 'Streaming services'
    return ''


def groups(specs, sports=False):
    buckets = {}
    for spec in specs:
        kind = str(spec['kind']).lower()
        is_sport = kind in ('sport', 'sports') or bool(re.search(r'\bsports?\b', spec.get('addon', '').lower()))
        if is_sport != sports:
            continue
        if sports:
            section = 'sport'
        elif kind in ('movie', 'series'):
            section = kind
        elif kind == 'all':
            # Mixed lists must be requested with their original type. Each
            # Discover section then filters the returned movie/series records.
            for section in ('movie', 'series'):
                projected = dict(spec, kind=section, _request_kind='all')
                # Feed the projected descriptor through normal grouping below.
                for group in groups([projected]):
                    key = (group['kind'], group['label'].casefold())
                    buckets.setdefault(key, dict(group, members=[], extras=[]))['members'].extend(group['members'])
            continue
        elif kind in ('marvel', 'dc', 'starwars', 'star wars'):
            section = 'movie'
        else:
            continue
        label = category(spec)
        key = (section, label.casefold())
        buckets.setdefault(key, {'label': label, 'kind': section, 'id': 'group:' + section + ':' + label.casefold(),
                                 'members': [], 'defaults': {}, 'extras': [], 'family': family(spec)})['members'].append(spec)
    order = {'Popular': 0, 'Trending': 1, 'All-time Greats': 2, 'New Releases': 3}
    result = list(buckets.values())
    for group in result:
        members = group['members']
        if any(any(e['name'] == 'skip' for e in m['extras']) for m in members):
            group['extras'].append({'name': 'skip'})
        # Only offer genres understood by every merged supplier.
        genres = [next((e.get('options', []) for e in m['extras'] if e['name'] == 'genre'), []) for m in members]
        common = [g for g in genres[0] if all(g in values for values in genres)] if genres else []
        if common:
            group['extras'].append({'name': 'genre', 'options': common})
    return sorted(result, key=lambda g: (0 if g['kind'] == 'series' else 1, bool(g.get('family')), order.get(g['label'], 10), g['label'].casefold()))


def merge_pages(group, fetch_page, extras=None):
    values = dict(extras or {})
    cursors = values.pop('_source_cursors', {})
    values.pop('skip', None)
    def load(pair):
        index, member = pair
        page_values = dict(values)
        cursor = cursors.get(str(index), 0)
        pageable = any(e['name'] == 'skip' for e in member['extras'])
        if cursors and not pageable:
            return [], cursor
        if cursor:
            page_values['skip'] = str(cursor)
        try:
            request = dict(member, kind=member.get('_request_kind', member['kind']))
            raw = fetch_page(request, page_values)
            rows = [row for row in raw if row.get('type') == group['kind']] if member.get('_request_kind') == 'all' else raw
            return rows, cursor + len(raw)
        except Exception:
            return [], cursor
    with ThreadPoolExecutor(max_workers=min(4, max(1, len(group['members'])))) as pool:
        pages = list(pool.map(load, enumerate(group['members'])))
    group['_next_cursors'] = {str(i): cursor for i, (_, cursor) in enumerate(pages)}
    seen, result = set(), []
    # Interleave supplier rankings so one provider cannot crowd out the rest.
    for index in range(max((len(rows) for rows, _ in pages), default=0)):
        for rows, _ in pages:
            if index >= len(rows):
                continue
            row = rows[index]
            key = item_key(row)
            if key not in seen:
                seen.add(key)
                result.append(row)
    return result
