"""Local provider preferences, independent of Kodi and private transport URLs."""
import re
from addons_core import active_addons, descriptor_id

ROLES = ('metadata', 'artwork', 'ratings', 'search', 'streams', 'subtitles')
RESOURCES = {'metadata': 'meta', 'artwork': 'meta', 'ratings': 'meta',
             'search': 'catalog', 'streams': 'stream', 'subtitles': 'subtitles'}


def key(provider):
    return descriptor_id(str(provider.get('transportUrl') or ''))


def name(provider):
    """Display names only; never display a configured URL as a fallback."""
    value = str((provider.get('manifest') or {}).get('name') or 'Unnamed add-on')
    value = re.sub(r'https?://\S+', '[link hidden]', value)
    return ' '.join(value.split())[:80]


def eligible(provider, role):
    manifest = provider.get('manifest') or {}
    resources = {r if isinstance(r, str) else r.get('name')
                 for r in manifest.get('resources', []) if isinstance(r, (str, dict))}
    if RESOURCES.get(role) not in resources:
        return False
    if role == 'search':
        label = re.sub(r'\W', '', name(provider)).casefold()
        if any(value in label for value in ('morecontentlikethis', 'contentdeepdive')):
            return False
        return any(isinstance(c, dict) and c.get('type') in ('movie', 'series')
                   and c.get('id') and any(isinstance(e, dict) and e.get('name') == 'search'
                                          for e in c.get('extra', []))
                   and not (set(c.get('extraRequired') or []) |
                            {e.get('name') for e in c.get('extra', [])
                             if isinstance(e, dict) and e.get('isRequired')}) - {'search'}
                   for c in manifest.get('catalogs', []))
    return True


def preference(state, role):
    preferences = state.get('providerPreferences')
    return preferences.get(role, '') if isinstance(preferences, dict) else ''


def selected(state, role):
    return next((p for p in active_addons(state)
                 if eligible(p, role) and key(p) == preference(state, role)), None)


def ordered(state, role):
    """Metadata/search use ordered fallbacks; stream/subtitle choices restrict suppliers."""
    providers = [p for p in active_addons(state) if eligible(p, role)]
    primary = selected(state, role)
    if primary:
        return ([primary] if role in ('streams', 'subtitles') else
                [primary] + [p for p in providers if key(p) != key(primary)])
    return providers


def artwork_providers(state):
    primary = selected(state, 'artwork')
    if primary:
        return [primary]  # Keep original catalogue art when this supplier has no poster.
    return [p for p in ordered(state, 'artwork')
            if 'aiometadata' in re.sub(r'\W', '', name(p)).casefold()]


def choices(state, role):
    providers = [p for p in active_addons(state) if eligible(p, role)]
    automatic = 'All enabled add-ons' if role in ('streams', 'subtitles') else 'Automatic'
    labels, values = [automatic], ['']
    counts = {}
    for p in providers:
        label = name(p)
        counts[label] = counts.get(label, 0) + 1
        labels.append(label + (' ({})'.format(counts[label]) if counts[label] > 1 else ''))
        values.append(key(p))
    value = preference(state, role)
    return labels, values, values.index(value) if value in values else 0


def save_preference(state, role, value):
    if role not in ROLES or value not in choices(state, role)[1]:
        raise ValueError('Choose an enabled provider for this role.')
    state['providerPreferences'] = dict(state.get('providerPreferences') or {}, **{role: value})


def overlaps(state):
    """Describe real overlaps, without treating complementary add-ons as conflicts."""
    rows = []
    for role in ROLES:
        providers = [p for p in active_addons(state) if eligible(p, role)]
        if len(providers) > 1:
            primary = selected(state, role)
            rows.append((role, ', '.join(name(p) for p in providers),
                         name(primary) if primary else 'Automatic'))
    return rows
