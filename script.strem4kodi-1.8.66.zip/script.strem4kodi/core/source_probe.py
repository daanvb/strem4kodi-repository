"""Recognise provider error slates before treating them as playable titles."""
import json
from urllib.parse import urlsplit, unquote
from urllib.request import Request, urlopen
from urllib.error import HTTPError


def error_video(url):
    try:
        parsed = urlsplit(str(url))
        return parsed.hostname == 'slate.elfhosted.com'
    except ValueError:return False

def unsupported_disc(url, row=None):
    """Only reject explicitly identified disc images, never opaque media URLs."""
    row=row if isinstance(row,dict) else {}
    names=[row.get('filename'), (row.get('card') or {}).get('filename')]
    candidates=row.get('filename_candidates')
    if isinstance(candidates,(list,tuple)):names.extend(candidates)
    try:names.append(unquote(urlsplit(str(url)).path))
    except ValueError:pass
    return any(isinstance(name,str) and name.lower().endswith(('.iso','.img','.nrg','.ifo')) for name in names)

def startup_failure(url,owned=False,live=False,opener=urlopen,row=None):
    """Owned playback uses Kodi/recovery, without connecting to the file twice."""
    if error_video(url):return 'provider-error-video'
    if unsupported_disc(url,row):return 'unsupported-disc-image'
    if owned:return ''
    return unavailable(url,opener=opener,live=live)


def unavailable(url, opener=urlopen, live=False):
    if error_video(url):return 'provider-error-video'
    if unsupported_disc(url):return 'unsupported-disc-image'
    # A range probe can consume a one-use live session or be rejected even
    # though the player can open it. Let Kodi establish the live connection.
    if live:return ''
    try:
        # Small bounded GET follows the same redirects as playback. HEAD may lie
        # or be unsupported; file size / short duration alone never imply failure.
        # This is a best-effort error-slate check, not player buffering. A slow
        # proxy must not hold playback behind a second eight-second connection.
        response = opener(Request(url, headers={'Range':'bytes=0-4095'}), timeout=3)
        try:
            if error_video(response.geturl()):return 'provider-error-video'
            if unsupported_disc(response.geturl()):return 'unsupported-disc-image'
            kind = response.headers.get('Content-Type', '').split(';')[0].lower()
            if kind in ('application/x-iso9660-image','application/x-cd-image'):
                return 'unsupported-disc-image'
            if kind == 'application/json':
                try:payload = json.loads(response.read(4096))
                except (ValueError, UnicodeError):return ''
                if isinstance(payload, dict) and (payload.get('error') or payload.get('errorCode')):
                    return 'provider-error-response'
        finally:response.close()
    except HTTPError as error:
        code = error.code
        error.close()
        if code not in (405, 416):return 'http-unavailable'
    except Exception:
        # Unknown transport / range failures are left to Kodi, not guessed.
        pass
    return ''
