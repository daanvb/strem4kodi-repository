"""Floating, manual next-episode prompt for Strem4Kodi playback only."""
import hashlib
import threading
import time
from pathlib import Path
from datetime import datetime, timezone
import xbmc
import xbmcgui
from account import Store
from addon_state import get_addon
from lib.theme import window as themed_window
ROOT = str(Path(__file__).resolve().parents[1])
VISIBLE = 'strem4kodi.up_next.visible'


def card_visible(value):
    try:
        session = xbmcgui.Window(10000)
        if value:
            session.setProperty(VISIBLE, 'true')
        else:
            session.clearProperty(VISIBLE)
    except Exception:
        pass

def following_episode(videos, current_id, now=None):
    rows=[]
    for row in videos or []:
        try:
            season=int(row.get('season'));episode=int(row.get('episode',row.get('number')))
            if season>0 and episode>0 and row.get('id'):rows.append((season,episode,row))
        except (TypeError,ValueError,AttributeError):pass
    rows.sort(key=lambda r:r[:2])
    index=next((i for i,r in enumerate(rows) if r[2]['id']==current_id),None)
    if index is None or index+1==len(rows):return None
    candidate=rows[index+1][2]
    released=candidate.get('released') or candidate.get('firstAired')
    if not released:return None
    try:
        date=datetime.fromisoformat(str(released).replace('Z','+00:00'))
        if date.tzinfo is None:date=date.replace(tzinfo=timezone.utc)
        if date>(now or datetime.now(timezone.utc)):return None
    except (TypeError,ValueError):return None
    return candidate

def prompt_due(position,duration,lead=60,credits=None):
    if duration<=120:return False
    threshold=max(duration/2,duration-lead)
    if isinstance(credits,dict):
        try:
            start=float(credits['start']);end=float(credits['end'])
            if duration/2<=start<end<=duration+10:threshold=start
        except (TypeError,ValueError,KeyError):pass
    return threshold<=position<duration

class UpNextWindow(xbmcgui.WindowXMLDialog):
    def __init__(self,*args,**kwargs):
        self.episode=kwargs.pop('episode');self.meta=kwargs.pop('meta');self.accept=kwargs.pop('accept');self.dismiss=kwargs.pop('dismiss')
        self.loading = False
        super().__init__(*args,**kwargs)
    def onInit(self):
        row=self.episode
        self.setProperty('next_title',str(row.get('title') or row.get('name') or 'Next episode'))
        self.setProperty('next_series',str(self.meta.get('name') or ''))
        self.setProperty('next_number','S{:02d} · E{:02d}'.format(int(row['season']),int(row.get('episode',row.get('number')))))
        self.setProperty('next_art',str(row.get('thumbnail') or self.meta.get('background') or self.meta.get('poster') or ''))
        from lib.auto_source import select
        mode, _, _ = select([], get_addon(), self.meta)
        self.action_label = 'Play Next' if mode == 2 else 'Choose Source'
        self.set_loading(False)
        self.setFocusId(201)
    def set_loading(self, loading):
        self.loading = loading
        self.setProperty('next_loading', 'true' if loading else '')
        self.setProperty('next_action', 'Loading…' if loading else self.action_label)
    def onClick(self,cid):
        if cid == 201:
            if self.loading:
                return
            self.set_loading(True)
            self.accept()
        elif cid == 202:
            self.dismiss()
    def onAction(self,action):
        if action.getId() in (10,92,216,247):self.dismiss()
        elif action.getId() == 13:
            self.dismiss()
            xbmc.Player().stop()

class UpNextWatcher:
    def __init__(self,profile):
        self.profile=Path(profile);self.player=xbmc.Player();self.digest=None;self.ready=None;self.window=None;self.dismissed=False;self.lock=threading.Lock()
        self.pending = None
        from lib.playback_recovery import RecoveryTracker
        self.recovery=RecoveryTracker()
        self.recovery_player=None
        card_visible(False)
        from lib.smart_credits import CreditsMemory
        self.credits_memory=CreditsMemory(profile);self.credits_recorded=False
    def close(self):
        self.recovery.clear()
        if self.pending and self.pending.get('early_timer'):
            self.pending['early_timer'].cancel()
        self.pending = None
        if self.window:
            try:self.window.close()
            except Exception:pass
        self.window=None
        card_visible(False)
    def current_digest(self):
        try:
            if not self.player.isPlayingVideo():return None
            from source_probe import error_video
            if error_video(self.player.getPlayingFile()):return None
            return hashlib.sha256(self.player.getPlayingFile().encode()).hexdigest() if self.player.isPlayingVideo() else None
        except Exception:return None
    def load(self,digest):
        try:
            # Resolve only a playback entry belonging to this addon and this URL.
            stream={}
            for attempt in range(5):
                if self.current_digest()!=digest:return
                key=Store(self.profile/'playback-context').load().get('key')
                from lib.playback_payload import load
                stream=(load(self.profile,key).get('urls') or {}).get(key) or {}
                if hashlib.sha256(str(stream.get('url','')).encode()).hexdigest()==digest:break
                time.sleep(0.25)
            if stream.get('kind')!='series' or hashlib.sha256(str(stream.get('url','')).encode()).hexdigest()!=digest:return
            from lib import backend as api
            meta=api.metadata(stream.get('meta') or {})
            from lib.skip_segments import fetch_segments
            credits=next((x for x in fetch_segments(self.profile,'series',stream.get('id')) if x.get('type')=='outro'),None)
            row=following_episode(meta.get('videos'),stream.get('id'))
            with self.lock:
                if self.digest==digest and row:self.ready=(meta,row,credits,stream.get('id'))
        except Exception:pass
    def hide(self):self.dismissed=True;self.close()
    def play(self,digest,meta,row):
        if self.pending is not None:
            return
        # Construct the callback listener on the lasting service thread, not
        # the source-search worker whose callback pump ends after dispatch.
        if self.recovery_player is None:
            from lib.playback_recovery import player
            self.recovery_player=player(self.recovery,self.profile)
        request = dict(digest=digest, stage='searching', deadline=time.monotonic() + 120,
                       early_lock=threading.RLock(), early_done=threading.Event(), search_done=False,
                       failed=set(), attempts=0)
        request['early_done'].set()
        self.pending = request
        self.dismissed = True
        if self.window:
            self.window.set_loading(True)
        def current():
            if self.pending is not request:return False
            if self.current_digest() in (digest,None,request.get('failed_hash')):return True
            from lib.playback_recovery import playing_attempt
            return bool(request.get('attempt') and playing_attempt(self.player)==request['attempt'])
        def retry(message=None):
            if self.pending is not request:
                return
            self.pending = None
            self.dismissed = False
            if self.window:
                self.window.set_loading(False)
            if message:
                from lib.ui_dialogs import dialog
                dialog().notification('Up Next', message)
        def start(api, source, validate=True):
            if not current():
                return
            request.update(stage='starting', deadline=time.monotonic() + 60)
            attempt=self.recovery.arm(source['url'],row['id'],0,0)
            request['attempt']=attempt
            request['attempts']+=1
            request['failed'].add(source['url'])
            if request.get('automatic') and validate:
                from source_probe import unavailable
                if unavailable(source['url'],live=bool(source.get('isLive') or '.m3u8' in source['url'])):
                    self.recovery.failed()
                    return
            if current():api.play(meta, row['id'], dict(source,_playback_attempt=attempt))
        def choose():
            try:
                if not current():return
                from lib import backend as api
                from lib.ui_dialogs import dialog
                cached = api.stream_cache_state(meta, row['id'])
                result = api.cached_source_rows(meta, row['id']) if cached and not cached[4] else None
                early_failed = request['failed']
                try:limit=(3,5,10,25)[int(get_addon().getSetting('auto_source_attempts') or '1')]
                except (ValueError,IndexError):limit=5
                def early_match():
                    from lib.auto_source import early_select
                    from lib.source_preferences import picker_filters
                    candidates = [dict(source, _session_failed=source.get('url') in early_failed)
                                  for source in request.get('early_rows', [])]
                    return early_select(candidates, get_addon(), meta, picker_filters(get_addon()),identity=row['id'])
                def settled():
                    with request['early_lock']:
                        if not current() or request['search_done'] or request['stage'] != 'searching':return
                        best = early_match()
                        if best is None:return
                        request['stage'] = 'checking'
                        request['early_done'].clear()
                    try:
                        from source_probe import unavailable
                        if unavailable(best['url']):
                            early_failed.add(best['url'])
                            request['stage'] = 'searching'
                        elif current():
                            request['automatic']=True
                            start(api, best,validate=False)
                    except Exception:
                        retry('Could not start the next episode. Please try again.')
                    finally:
                        with request['early_lock']:
                            request['early_timer'] = None
                            request['early_done'].set()
                def arriving(found):
                    with request['early_lock']:
                        if not current() or request['search_done']:return
                        request['early_rows'] = found
                        if (request['stage'] == 'searching' and len(early_failed) < limit
                                and request.get('early_timer') is None and early_match() is not None):
                            timer = threading.Timer(0.0, settled)
                            timer.daemon = True
                            request['early_timer'] = timer
                            try:timer.start()
                            except RuntimeError:request['early_timer'] = None
                rows,_,_ = result if result is not None else api.source_rows(meta,row['id'],on_formats=arriving)
                with request['early_lock']:
                    request['search_done'] = True
                    if request.get('early_timer'):request['early_timer'].cancel()
                request['early_done'].wait()
                request['rows']=rows
                for source in rows:
                    if source.get('url') in early_failed:source['_session_failed'] = True
                if not current():return
                from lib.source_preferences import preferences,rank_rows,limit_quality,picker_filters
                from lib.stream_presenter import filter_rows
                prefs=preferences(get_addon())
                rows=filter_rows(rank_rows(limit_quality(rows,prefs['maximum']),prefs),*picker_filters(get_addon()))
                if not rows:
                    retry('No sources match your device preferences and filters.')
                    return
                from lib.stream_presenter import presentation
                request['rows']=rows
                from lib.auto_source import select
                mode, best, _ = select(rows, get_addon(), meta,identity=row['id'])
                request['automatic']=mode==2
                def advance():
                    if self.pending is not request:return
                    candidates=[dict(source,_session_failed=source.get('url') in request['failed']) for source in request['rows']]
                    _, candidate, _=select(candidates,get_addon(),meta,identity=row['id'])
                    if candidate is None or len(request['failed'])>=limit:
                        retry('Automatic sources were unavailable. Choose a source manually from the episode page.')
                        return
                    request['stage']='searching'
                    start(api,candidate)
                request['advance']=advance
                if request['stage'] != 'searching':return
                if mode == 2:
                    from source_probe import unavailable
                    try:limit=(3,5,10,25)[int(get_addon().getSetting('auto_source_attempts') or '1')]
                    except (ValueError,IndexError):limit=5
                    for _ in range(max(0, limit - len(early_failed))):
                        if best is None or not current():break
                        if not unavailable(best['url']):
                            start(api, best,validate=False)
                            return
                        failed_url=best['url']
                        for source in rows:
                            if source.get('url')==failed_url:source['_session_failed']=True
                        _, best, _ = select(rows, get_addon(), meta,identity=row['id'])
                    retry('Automatic sources were unavailable. Choose a source manually from the episode page.')
                    return
                preselect = rows.index(best) if best in rows else 0
                request['stage'] = 'picking'
                index = dialog().select('Next episode - choose a source',[presentation(r)['title'] for r in rows], preselect=preselect)
                if index>=0 and current():start(api, rows[index])
                else:retry()
            except Exception:
                retry('Could not load the next episode. Please try again.')
        try:
            threading.Thread(target=choose,daemon=True).start()
        except RuntimeError:
            retry('Could not start loading. Please try again.')
    def tick(self):
        if get_addon().getSetting('up_next_enabled')=='false':self.close();return
        digest=self.current_digest()
        if self.pending is not None:
            request = self.pending
            self.recovery.poll_failure(self.profile)
            self.recovery.startup_timeout()
            failure=self.recovery.take()
            if failure and failure.get('attempt')==request.get('attempt'):
                request['failure']=failure
                request['failed_hash']=failure['hash']
            if request.get('failure'):
                failure=request['failure']
                from lib.playback_recovery import stop_failed
                state=stop_failed(self.player,failure)
                if state=='waiting':return
                if state in ('blocked','unrelated'):
                    self.close()
                    if state=='blocked':
                        from lib.ui_dialogs import dialog
                        dialog().notification('Up Next','Kodi is still busy with the failed stream. Automatic retries have stopped.')
                    return
                if request.get('automatic') and request.get('advance'):
                    request.pop('failure')
                    threading.Thread(target=request['advance'],daemon=True).start()
                elif request.get('search_done'):
                    self.recovery.clear()
                    self.pending=None;self.dismissed=False
                    if self.window:self.window.set_loading(False)
                return
            if digest and digest != request['digest']:
                state=self.recovery.snapshot()
                if state and state.get('checking'):return
                try:
                    if self.player.getTime() <= 0.25:return
                except Exception:
                    return
                self.close()  # The next video has actually started.
            elif request['stage'] != 'picking' and time.monotonic() >= request['deadline']:
                self.recovery.clear()
                self.pending = None
                self.dismissed = False
                if self.window:self.window.set_loading(False)
                from lib.ui_dialogs import dialog
                dialog().notification('Up Next','The next episode took too long to load. Please try again.')
            else:
                return  # Keep the card visible through searching and hand-off.
        if digest!=self.digest:
            self.close();self.digest=digest;self.ready=None;self.dismissed=False;self.credits_recorded=False
            if digest:threading.Thread(target=self.load,args=(digest,),daemon=True).start()
        if not digest or self.dismissed or not self.ready:return
        try:
            position=self.player.getTime();duration=self.player.getTotalTime()
        except Exception:return
        meta,row,credits,identity=self.ready
        try:lead=(60,120,180,300)[int(get_addon().getSetting('up_next_lead') or '0')]
        except (ValueError,IndexError):lead=60
        from lib.smart_credits import marker_start
        start=marker_start(credits,duration)
        smart=get_addon().getSetting('up_next_smart')!='false'
        if smart and not self.credits_recorded and start is not None and position>=start:
            try:self.credits_memory.observe(identity,duration,credits,position)
            except Exception:pass
            self.credits_recorded=True
        threshold,_=self.credits_memory.timing(identity,duration,credits,lead,smart)
        if duration<=120 or not threshold<=position<duration:self.close();return
        if self.window:return
        try:
            self.window=themed_window(UpNextWindow,'script-strem4kodi-up-next.xml',ROOT,'Main','1080i',meta=meta,episode=row,accept=lambda:self.play(digest,meta,row),dismiss=self.hide)
            self.window.show()
            card_visible(True)
            from lib.credits_watched import signal
            signal(self.profile, self.player, expected_hash=digest, expected_id=identity)
        except Exception:
            self.dismissed=True;self.close()
