"""Observe Kodi's native startup wait without closing or hiding its dialogs."""


def busy():
    try:
        import xbmc
        # Artwork can be hidden by the skin while the native modal is active.
        return xbmc.getCondVisibility(
            'Window.IsActive(busydialog) | Window.IsActive(busydialognocancel)') is True
    except (ImportError, AttributeError, RuntimeError):
        return False
