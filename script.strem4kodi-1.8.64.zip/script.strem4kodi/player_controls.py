"""Companion-skin action entry point; independent of the browsing window."""
from pathlib import Path
import sys

CORE = str(Path(__file__).resolve().parent / 'core')
if CORE not in sys.path:
    sys.path.insert(0, CORE)

if __name__ == '__main__':
    from lib.player_controls import run
    run(sys.argv[1] if len(sys.argv) > 1 else 'audio')
