"""Fullscreen Up key entry point; the custom player opens with OK."""
from lib.player_up import run

if __name__ == '__main__':
    run()
