# Strem4Kodi branding

Original cyan geometric wordmark and matching play-symbol icon, generated with the built-in image tool from the owner's typography reference.
Unofficial community addon; not endorsed by Stremio or Kodi.
Software copyright and GPL notices remain preserved.

The in-app wordmark and icon use transparent PNG backgrounds. The black matte was removed directly from the original pixels, preserving the cyan shapes and canvas dimensions.
