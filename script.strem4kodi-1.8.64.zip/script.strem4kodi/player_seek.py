"""Remote horizontal seek entry point."""
import sys
from pathlib import Path
CORE = str(Path(__file__).resolve().parent / 'core')
if CORE not in sys.path:
    sys.path.insert(0, CORE)
from lib.player_seek import run

if __name__ == '__main__':
    run({'left': -1, 'right': 1, 'down': 0}.get(sys.argv[-1], 0))
