"""Device-provided choices for Strem4Kodi settings."""
from decimal import Decimal

COLORS = [('White', 'FFFFFFFF'), ('Yellow', 'FFFFFF00'), ('Light gray', 'FFCCCCCC'),
          ('Black', 'FF000000'), ('Cyan', 'FF00FFFF'), ('Green', 'FF00FF00'),
          ('Red', 'FFFF0000'), ('Blue', 'FF0000FF'), ('Orange', 'FFFFA500'),
          ('Pink', 'FFFFC0CB'), ('Magenta', 'FFFF00FF')]

def setting_options(setting):
    """Use device-provided choices, including list and numeric definitions."""
    options = setting.get('options') or setting.get('definition', {}).get('options', [])
    if options:
        return options
    if setting.get('id') in ('subtitles.colorpick', 'subtitles.bordercolorpick', 'subtitles.bgcolorpick', 'subtitles.shadowcolor'):
        return [{'label': label, 'value': value} for label, value in COLORS]
    if isinstance(setting.get('value'), (int, float)) and not isinstance(setting.get('value'), bool):
        if all(key in setting for key in ('minimum', 'maximum', 'step')):
            low, high, step = [Decimal(str(setting[k])) for k in ('minimum', 'maximum', 'step')]
            if step > 0 and high >= low and (high - low) / step <= 500:
                values = [low + step * i for i in range(int((high - low) / step) + 1)]
                return [{'label': format(v.normalize(), 'f'), 'value': int(v) if isinstance(setting['value'], int) else float(v)} for v in values]
    return []
