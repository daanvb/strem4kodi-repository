"""Shared punctuation-insensitive title matching for search and suggestions."""
import re
import unicodedata
from difflib import SequenceMatcher
from urllib.parse import urlsplit


def title_identity(row):
    value = str(row.get('imdb_id') or row.get('imdbId') or row.get('id') or '')
    match = re.fullmatch(r'(?:imdb:)?(tt\d+)', value)
    return row.get('type'), match[1] if match else value


def search_artwork(row):
    """Use declared artwork without adding a network request for every result."""
    for field in ('poster', 'background', 'landscape'):
        value = row.get(field)
        if not isinstance(value, str):
            continue
        value = value.strip()
        try:
            url = urlsplit(value)
            if url.scheme in ('http', 'https') and url.hostname and not any(c.isspace() for c in value):
                return value
        except ValueError:
            pass
    return ''


def searchable_title(row, kind=None):
    """Reject incomplete and explicitly non-title records in search only."""
    if not isinstance(row, dict) or row.get('type', kind) not in ('movie', 'series'):
        return False
    identity, name = row.get('id'), row.get('name')
    if not isinstance(identity, str) or not identity.strip():
        return False
    if re.fullmatch(r'nm\d+|tt\d+:\d+:\d+', identity.strip()):
        return False
    if not isinstance(name, str) or normalized(name) in ('', 'unknown', 'untitled', 'no title', 'unnamed'):
        return False
    if row.get('qid') and row['qid'] not in ('movie', 'tvMovie', 'tvSeries', 'tvMiniSeries'):
        return False
    return bool(search_artwork(row))


def normalized(value):
    text = unicodedata.normalize('NFKD', str(value or '').casefold())
    text = ''.join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"['’‘ʼ`\u02bc]", '', text)
    return ' '.join(re.sub(r'[^\w\s]|_', ' ', text).split())


def relevance(query, title):
    key, text = normalized(query), normalized(title)
    if not key or not text:
        return None
    if key == text:
        return 0
    if text.startswith(key):
        return 1
    # Match at word boundaries: 'it' must not match 'Titanic'.
    if any(text[start:].startswith(key) for start in
           (m.end() for m in re.finditer(' ', text))):
        return 2
    words, terms = text.split(), key.split()
    if all(any(word.startswith(term) for word in words) for term in terms):
        return 3
    # Every term must match; tolerate a small typo only in longer words.
    if all(any(word.startswith(term) or
               (len(term) >= 5 and SequenceMatcher(None, term,
                 word[:len(term)]).ratio() >= .82)
               for word in words) for term in terms):
        return 4
    return None


def query_variants(query):
    """Try a plain title first; retry punctuation-sensitive providers if needed."""
    original = str(query or '').strip()[:200]
    plain = normalized(original)
    words = plain.split()
    for index, word in enumerate(words):
        if len(word) >= 4 and word.endswith('s'):
            words[index] = word[:-1] + "'s"
            break
    possessive = ' '.join(words)
    return list(dict.fromkeys(v for v in (plain, original, possessive) if v))


def title_relevance(query, row):
    key = normalized(query)
    if key and key == normalized(row.get('name')):
        return 0
    terms = key.split()
    # Only treat a trailing year as a qualifier when a title precedes it.
    if len(terms) > 1 and re.fullmatch(r'(?:19|20)\d{2}', terms[-1]):
        year = re.search(r'(?:19|20)\d{2}', str(row.get('year') or row.get('releaseInfo') or ''))
        if not year or year.group() != terms[-1]:
            return None
        key = ' '.join(terms[:-1])
    return relevance(key, row.get('name'))
