"""Presentation helpers for the Strem4Kodi TV stream picker."""
import os
import re


QUALITY_RE = re.compile(r'(?i)(2160p|1080p|720p|480p|360p|4k)')
SIZE_RE = re.compile(r'(?i)(\d+(?:[.,]\d+)?\s*(?:TiB|GiB|MiB|KiB|TB|GB|MB|KB))\b')
SEED_RE = re.compile(r'👤\s*(\d+)')
SOURCE_RE = re.compile(r'⚙️\s*([^\r\n]+)')
FLAG_RE = re.compile(r'[\U0001F1E6-\U0001F1FF]{2}')


def _clean(value):
    return re.sub(r'[\u200b-\u200f\u2060\ufeff]', '', str(value or '')).strip()


def _contains(text, *needles):
    low = text.lower()
    return any(needle.lower() in low for needle in needles)


def _audio_text(value, depth=0):
    """Read bounded provider audio fields, including multiple track codecs."""
    if depth > 3:return ''
    if isinstance(value, str):return value[:1024]
    if isinstance(value, (list, tuple)):
        return ' / '.join(_audio_text(v, depth+1) for v in value[:32])[:4096]
    if isinstance(value, dict):
        return ' '.join(_audio_text(value.get(k), depth+1)
                        for k in ('codec', 'audioCodec', 'format', 'name', 'title'))
    return ''


def stream_card(stream):
    """Return normalized, display-only properties for one stream."""
    label = _clean(stream.get('label'))
    provider = _clean(stream.get('provider'))
    detail = _clean(stream.get('detail'))

    if not provider and ' · ' in label:
        provider = label.split(' · ', 1)[0].strip()
    if not detail and ' · ' in label:
        detail = label.split(' · ', 1)[1].strip()
    provider = provider or 'Stream'

    filename = _clean(stream.get('filename'))
    if filename:
        filename = os.path.basename(filename.replace('\\', '/'))
    if not filename:
        candidates = [line.strip() for line in detail.splitlines()
                      if re.search(r'(?i)\.(mkv|mp4|avi|m2ts|ts)\b', line)]
        filename = os.path.basename(candidates[-1]) if candidates else detail.splitlines()[0] if detail else 'Stream'

    corpus = '\n'.join(v for v in (detail, filename, label, _clean(stream.get('name')), _clean(stream.get('title'))) if v)
    quality_match = QUALITY_RE.search(corpus)
    quality = quality_match.group(1).upper().replace('2160P', '4K') if quality_match else 'AUTO'
    quality = quality.replace('1080P', '1080p').replace('720P', '720p').replace('480P', '480p').replace('360P', '360p')
    structured = ' '.join(str(stream.get(k) or '') for k in ('quality', 'resolution', 'height', 'source', 'videoCodec', 'hdr', 'bitDepth'))
    structured += ' ' + ' / '.join(_audio_text(stream.get(k)) for k in
                                    ('audio', 'audioCodec', 'audioCodecs', 'audioTracks', 'audioStreams'))
    corpus += '\n' + structured
    if quality == 'AUTO':
        token = QUALITY_RE.search(structured)
        if token:
            quality = {'2160p':'4K','4k':'4K'}.get(token.group(1).lower(),token.group(1).lower())
        else:
            alias = re.search(r'(?i)(?<!DTS-)(?<!DTS )\b(UHD|FHD|HD)\b',corpus)
            if alias:quality={'UHD':'4K','FHD':'1080p','HD':'720p'}[alias.group(1).upper()]
        if quality == 'AUTO':
            height = stream.get('height')
            if type(height) is int:quality = {2160:'4K',1080:'1080p',720:'720p',480:'480p',360:'360p'}.get(height,'AUTO')
    if quality == 'AUTO':
        dimensions=re.search(r'(?i)\b(\d{3,4})\s*[x×]\s*(\d{3,4})\b',corpus)
        if dimensions:
            height=int(dimensions.group(2))
            quality={2160:'4K',1080:'1080p',720:'720p',480:'480p',360:'360p'}.get(height,'AUTO')
    bitrate_match=re.search(r'(?i)\b(?:~\s*)?(\d+(?:[.,]\d+)?)\s*(Mbps|Mbit/s|kbps)\b',corpus)
    bitrate=(bitrate_match.group(1).replace(',','.')+' '+bitrate_match.group(2)) if bitrate_match else ''
    if not bitrate:
        try:
            bps=float(stream.get('bitrate') or 0)
            if 0<bps<1e10:bitrate=f'{bps/1e6:.1f} Mbps'
        except (TypeError,ValueError):pass

    size_match = SIZE_RE.search(corpus)
    size = size_match.group(1).replace(',', '.') if size_match else ''
    if not size:
        hints = stream.get('behaviorHints') or {}
        value = stream.get('videoSize') or (hints.get('videoSize') if isinstance(hints, dict) else None)
        try:
            amount = float(value) if not isinstance(value, bool) else 0
            if 0 < amount < 1024 ** 6:
                for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
                    if amount < 1024 or unit == 'TB':break
                    amount /= 1024
                size = ('{:.2f}'.format(amount).rstrip('0').rstrip('.') + ' ' + unit)
        except (TypeError, ValueError, OverflowError):pass
    seed_match = SEED_RE.search(corpus)
    seeders = seed_match.group(1) if seed_match else ''
    source_match = SOURCE_RE.search(corpus)
    source = source_match.group(1).strip() if source_match else ''
    if not source and isinstance(stream.get('source'),str):source=_clean(stream['source'])

    language_codes = []
    for line in corpus.splitlines():
        for flag in FLAG_RE.findall(line):
            code = ''.join(chr(ord(ch) - 0x1F1E6 + ord('A')) for ch in flag)
            if code and code not in language_codes:
                language_codes.append(code)
    reported_languages=stream.get('languages')
    if isinstance(reported_languages,list):language_codes.extend(str(v) for v in reported_languages if isinstance(v,str))
    elif isinstance(reported_languages,str):language_codes.append(reported_languages)
    languages = ' / '.join(dict.fromkeys(language_codes))

    tech = []
    def add(value):
        if value and value not in tech:
            tech.append(value)

    if _contains(corpus, 'remux'):
        add('REMUX')
    if _contains(corpus, 'blu-ray', 'bluray', 'bdrip'):
        add('BluRay')
    elif _contains(corpus, 'web-dl', 'webdl'):
        add('WEB-DL')
    elif _contains(corpus, 'webrip', 'web-rip'):
        add('WEBRip')

    if _contains(corpus, 'dolby vision', ' dv ', '.dv.', 'dovi'):
        add('Dolby Vision')
    if _contains(corpus, 'hdr10+', 'hdr10plus', 'hdr10 plus'):
        add('HDR10+')
    elif _contains(corpus, 'hdr10'):
        add('HDR10')
    elif _contains(corpus, 'hdr'):
        add('HDR')

    if _contains(corpus, 'av1'):
        add('AV1')
    elif _contains(corpus, 'hevc', 'h265', 'h.265', 'x265'):
        add('H.265')
    elif _contains(corpus, 'avc', 'h264', 'h.264', 'x264'):
        add('H.264')

    if _contains(corpus, '10bit', '10-bit') or stream.get('bitDepth') in (10,'10'):
        add('10bit')

    video_tags = list(tech)
    plus_pattern = r'(?i)(?<![a-z0-9])(?:e[ ._-]*ac[ ._-]*3|ec[ ._-]*3|ddp|dd[ ._-]*\+|dolby[ ._-]+digital[ ._-]+plus)(?![a-z])(?:[ ._-]*([257]\.\d))?'
    # A Plus token contains AC3/DD text, but does not establish a second AC3
    # track. Mask only those spans; independent Dolby/DTS tracks remain intact.
    basic_audio = re.sub(plus_pattern, lambda m: ' ' * len(m[0]), corpus)
    audio_patterns = (
        (plus_pattern, 'Dolby Digital Plus'),
        (r'(?i)(?<![a-z0-9])(?:ac[ ._-]*3|dd|dolby[ ._-]+digital)(?![a-z])(?:[ ._-]*([257]\.\d))?', 'Dolby Digital'),
        (r'(?i)aac[ .]?([257]\.\d)?', 'AAC'),
        (r'(?i)flac[ .]?([257]\.\d)?', 'FLAC'),
        (r'(?i)dts[- .]?hd(?:[ .]?ma)?(?:[ .]?(\d\.\d))?', 'DTS-HD MA'),
        (r'(?i)(?<![a-z0-9])true[ ._-]*hd(?:[ ._-]?(\d\.\d))?', 'TrueHD'),
        (r'(?i)(?<![a-z0-9])atmos(?![a-z0-9])', 'Atmos'),
        (r'(?i)dts[- .:_]?x', 'DTS-X'),
        (r'(?i)\bdts\b(?![- .:_]?(?:hd|x))', 'DTS'),
        (r'(?i)aac\s*([257]\.\d)', 'AAC'),
    )
    for pattern, name in audio_patterns:
        match = re.search(pattern, basic_audio if name == 'Dolby Digital' else corpus)
        if match:
            channels = match.group(1) if match.lastindex else ''
            add(name + ((' ' + channels) if channels else ''))
    reported_channels=str(stream.get('channels') or '')
    channel_name={'2':'Stereo','6':'5.1 channels','8':'7.1 channels'}.get(reported_channels,reported_channels+' channels' if reported_channels in ('2.0','5.1','7.1') else '')
    if channel_name:add(channel_name)
    if re.search(r'(?i)\bstereo\b',corpus):add('Stereo')
    elif re.search(r'(?i)\bmono\b',corpus):add('Mono')
    channels = re.search(r'(?i)\b(2\.0|5\.1|7\.1)\b',corpus)
    if channels and not any(channels.group(1) in tag for tag in tech):add(channels.group(1)+' channels')

    meta = []
    if size:
        meta.append(size)
    if source:
        meta.append(source)
    if seeders:
        meta.append(seeders + ' seeders')
    if languages:
        meta.append(languages)

    return {
        'video_tags': video_tags,
        'audio_tags': [tag for tag in tech if tag not in video_tags],
        'provider': provider,
        'quality': quality,
        'headline': '{} · {}'.format(provider, quality),
        'filename': filename,
        'tech': ' • '.join(tech),
        'meta': ' • '.join(meta),
        'size': size,
        'source': source,
        'seeders': seeders,
        'languages': languages,
        'bitrate': bitrate,
        'frame_rate': str(stream.get('frameRate') or ''),
    }
