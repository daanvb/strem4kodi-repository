"""Internal Strem4Kodi runtime modules.

Kodi entry points stay at repository/add-on root; implementation modules live here.
"""
