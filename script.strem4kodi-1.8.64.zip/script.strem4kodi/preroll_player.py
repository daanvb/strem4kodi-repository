"""Separate script lifetime for a pre-roll and its movie handoff."""
import sys
from pathlib import Path
CORE = str(Path(__file__).resolve().parent / 'core')
if CORE not in sys.path:sys.path.insert(0,CORE)

if __name__ == '__main__':
    from lib.preroll_player import run
    run(sys.argv[-1])
