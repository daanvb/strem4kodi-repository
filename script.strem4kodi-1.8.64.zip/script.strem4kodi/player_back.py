"""Kodi keymap entry point, separate from the long-running app window."""
from lib.player_back import run

if __name__ == '__main__':
    run()
