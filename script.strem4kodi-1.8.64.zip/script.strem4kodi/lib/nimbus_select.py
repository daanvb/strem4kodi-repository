"""Embedded Nimbus selector shared by account browsing filters."""
import xbmcgui


from lib.theme import window as themed_window


class Selector(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.left = kwargs.pop('left', 50)
        self.top = kwargs.pop('top', 600)
        self.heading = kwargs.pop('heading')
        self.options = kwargs.pop('options')
        self.preselect = kwargs.pop('preselect', -1)
        self.result = -1
        super().__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('heading', self.heading)
        rows = min(7, max(1, len(self.options)))
        height = 90 + rows * 64
        top = max(40, min(self.top, 1040 - height))
        left = max(40, min(self.left, 1240))
        for cid, x, y in ((601,0,0),(602,20,13),(600,10,75)):
            self.getControl(cid).setPosition(left+x, top+y)
        self.getControl(601).setHeight(height)
        self.getControl(600).setHeight(rows * 64)
        listing = self.getControl(600)
        listing.reset()
        listing.addItems([xbmcgui.ListItem(str(value)) for value in self.options])
        if 0 <= self.preselect < len(self.options):listing.selectItem(self.preselect)
        self.setFocusId(600)

    def onAction(self, action):
        if action.getId() in (10, 92, 216, 247):
            self.close()

    def onClick(self, control):
        if control == 600:
            self.result = self.getControl(600).getSelectedPosition()
            self.close()


class Dialog:
    def __init__(self, path, left=50, top=600):
        self.top = top
        self.path = path
        self.left = left

    def select(self, heading, options, preselect=-1):
        if not options:
            return -1
        window = themed_window(Selector, 'script-stremio-select.xml', self.path, 'Main', '1080i',
                          heading=heading, options=options, left=self.left, top=self.top, preselect=preselect)
        window.doModal()
        result = window.result
        del window
        return result
