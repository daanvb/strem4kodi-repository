"""Small, truthful loading summaries from completed add-on requests."""
from lib.stream_presenter import line


def properties(status, elapsed=0):
    total = max(0, int(status.get('total') or 0))
    completed = min(total, max(0, int(status.get('completed') or 0)))
    count = max(0, int(status.get('rows') or 0))
    failed = max(0, int(status.get('failed') or 0))
    limited = max(0, int(status.get('rate_limited') or 0))
    pending = [line(name, 40) for name in status.get('pending', []) if line(name, 40)]
    done = completed == total
    seconds = max(0, int(elapsed))
    heading = ('Search complete' if done else 'Searching add-ons') + ' · {} / {} checked'.format(completed, total)
    if count:
        heading += ' · {} sources found'.format(count)
    if seconds:
        heading += ' · {}s'.format(seconds)
    if limited:
        detail = '{} add-on{} rate limited'.format(limited, '' if limited == 1 else 's')
    elif done and failed:
        detail = '{} add-on{} unavailable'.format(failed, '' if failed == 1 else 's')
    elif pending:
        detail = 'Waiting for ' + ', '.join(pending[:2]) + (' and others' if len(pending) > 2 else '')
    else:
        detail = ''
    if not done and count:
        detail += (' · ' if detail else '') + 'You can choose a source now'
    elif not done and seconds >= 10:
        detail += (' · ' if detail else '') + 'Some add-ons are taking longer'
    return {'streams_search_status': heading, 'streams_search_detail': detail}
