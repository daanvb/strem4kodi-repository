"""Share overlapping source searches within a runtime; retain no completed jobs."""
from copy import deepcopy
import threading


class SourceRequests:
    def __init__(self):
        self.lock = threading.Lock()
        self.jobs = {}

    def request(self, key, loader, on_rows=None, on_progress=None):
        with self.lock:
            job = self.jobs.get(key)
            owner = job is None
            if owner:
                job = {'lock': threading.RLock(), 'event': threading.Event(),
                       'subscribers': [], 'rows': None, 'progress': None, 'result': None, 'error': None}
                self.jobs[key] = job
        callbacks = (on_rows, on_progress)
        def deliver(callback, value):
            if callback is not None and value is not None:
                try:
                    callback(deepcopy(value))
                except Exception:
                    pass
        with job['lock']:
            job['subscribers'].append(callbacks)
            deliver(on_rows, job['rows'])
            deliver(on_progress, job['progress'])
        def publish(field, value, index):
            with job['lock']:
                job[field] = deepcopy(value)
                for subscriber in job['subscribers']:
                    deliver(subscriber[index], value)
        if owner:
            try:
                job['result'] = loader(lambda rows: publish('rows', rows, 0),
                                       lambda status: publish('progress', status, 1))
            except Exception as error:
                job['error'] = error
            finally:
                with self.lock:
                    if self.jobs.get(key) is job:
                        del self.jobs[key]
                job['event'].set()
        else:
            job['event'].wait()
        if job['error'] is not None:
            raise job['error']
        return deepcopy(job['result'])


requests = SourceRequests()
