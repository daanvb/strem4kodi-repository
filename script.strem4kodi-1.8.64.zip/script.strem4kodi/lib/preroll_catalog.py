"""Cached public release catalogue; refresh never holds up playback."""
import json
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

TAG = 'prerolls-v1'
ORIGIN = 'https://github.com/daanvb/strem4kodi-repository/releases/download/'+TAG+'/'
API = 'https://api.github.com/repos/daanvb/strem4kodi-repository/releases/tags/'+TAG
REFRESH = 3600
RETRY = 300
MAX_BYTES = 2 * 1024 * 1024


def clean(rows):
    if not isinstance(rows,list):raise ValueError('Invalid pre-roll catalogue')
    result=[]
    seen=set()
    for row in rows:
        if not isinstance(row,dict):continue
        name=row.get('name')
        url=row.get('browser_download_url') or row.get('url')
        if not isinstance(name,str) or not isinstance(url,str):continue
        parsed=urlsplit(url)
        if (not url.startswith(ORIGIN) or parsed.query or parsed.fragment or
                not parsed.path.lower().endswith(('.mkv','.mp4','.m4v','.mov','.webm','.ts','.m2ts')) or
                row.get('state','uploaded') != 'uploaded' or url in seen):continue
        result.append({'name':name,'url':url})
        seen.add(url)
    return result


def fetch():
    # Public metadata only: no account token, title ID or viewing history.
    request=Request(API,headers={'Accept':'application/vnd.github+json','User-Agent':'Strem4Kodi'})
    with urlopen(request,timeout=6) as response:raw=response.read(MAX_BYTES+1)
    if len(raw)>MAX_BYTES:raise ValueError('Pre-roll catalogue too large')
    data=json.loads(raw)
    if not isinstance(data,dict) or data.get('tag_name') != TAG or data.get('draft'):
        raise ValueError('Invalid pre-roll release')
    return clean(data.get('assets'))


class Catalogue:
    def __init__(self, profile, fetcher=fetch, clock=time.time):
        self.path=Path(profile)/'cache'/'prerolls-catalog.json'
        self.fetcher,self.clock=fetcher,clock
        self.lock=threading.RLock()
        self.rows=None
        self.updated=0
        self.retry=0
        self.busy=False
        self.loaded=False

    def cached(self):
        with self.lock:
            if not self.loaded:
                self.loaded=True
                try:
                    payload=json.loads(self.path.read_text(encoding='utf-8'))
                    rows=clean(payload['assets'])
                    updated=float(payload['updated'])
                    self.rows,self.updated=rows,updated
                except (OSError,ValueError,KeyError,TypeError):pass
            return None if self.rows is None else [dict(row) for row in self.rows]

    def request(self):
        self.cached()
        with self.lock:
            now=self.clock()
            if self.busy or now < self.retry or (self.rows is not None and 0 <= now-self.updated < REFRESH):return
            self.busy=True
            self.retry=now+RETRY
        threading.Thread(target=self._refresh,daemon=True).start()

    def _refresh(self):
        try:
            rows=clean(self.fetcher())
            updated=self.clock()
            payload=json.dumps({'assets':rows,'updated':updated})
            self.path.parent.mkdir(parents=True,exist_ok=True)
            # Each process gets its own temporary name; readers see only a full file.
            import uuid
            temporary=self.path.with_name('prerolls-'+uuid.uuid4().hex+'.tmp')
            try:
                temporary.write_bytes(payload.encode('utf-8'))
                temporary.replace(self.path)
            finally:
                temporary.unlink(missing_ok=True)
            with self.lock:self.rows,self.updated=rows,updated
        except (OSError,ValueError,TypeError):pass
        finally:
            with self.lock:self.busy=False


_catalogues={}
_lock=threading.Lock()


def catalogue(profile):
    key=str(Path(profile))
    with _lock:
        if key not in _catalogues:_catalogues[key]=Catalogue(profile)
        return _catalogues[key]


class Watcher:
    def __init__(self, profile, addon):self.profile,self.addon=profile,addon
    def tick(self):
        if self.addon.getSetting('prerolls_enabled') == 'true':catalogue(self.profile).request()
