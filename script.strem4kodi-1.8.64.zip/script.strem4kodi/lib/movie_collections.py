"""Cached TMDB collection cards and their movies; no stream searches."""
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor
from search_match import normalized, relevance
from tmdb_metadata import request
from protocol import fetch
from lib.cache_policy import open_cache, read_policy


def get_addon():
    from addon_state import get_addon as configured_addon
    return configured_addon()


def collection_id(row):
    if not isinstance(row, dict) or row.get('type') != 'collection':
        return ''
    match = re.fullmatch(r'tmdb.collection:([1-9][0-9]{0,11})', str(row.get('id') or ''))
    return match[1] if match else ''


def image(path, size='w500'):
    return 'https://image.tmdb.org/t/p/' + size + path if isinstance(path,str) and re.fullmatch(r'/[\w.-]+',path) else ''


def clean_art(value):
    return value if isinstance(value,str) and re.fullmatch(r'https://image\.tmdb\.org/t/p/(?:w[0-9]+|original)/[\w.-]+',value) else ''


def card(identity, data):
    identity = str(identity)
    if not re.fullmatch(r'[1-9][0-9]{0,11}',identity) or not isinstance(data,dict):
        raise ValueError('Invalid collection identity')
    name = str(data.get('name') or 'Movie collection')[:200]
    return {'id':'tmdb.collection:'+identity, 'type':'collection', 'name':name, 'genres':['Collection'],
            'poster':clean_art(data.get('poster')) or image(data.get('poster_path')),
            'background':clean_art(data.get('background')) or image(data.get('backdrop_path'),'w1280'),
            'description':str(data.get('description') or data.get('overview') or 'Open this collection to browse its movies in release order.')[:1600],
            '_catalogue':{'id':'tmdb.collection:'+identity, '_tmdb_collection':identity,
                '_search_collection':True, 'kind':'movie', 'label':name, 'addon':'TMDB',
                'url':'', 'extras':[], 'defaults':{}, 'poster':clean_art(data.get('poster')) or image(data.get('poster_path')),
                'background':clean_art(data.get('background')) or image(data.get('backdrop_path'),'w1280'),
                'description':str(data.get('description') or data.get('overview') or '')[:1600]}}


def cached(operation, group, loader, cached_only=False):
    key = get_addon().getSetting('tmdb_api_key').strip()
    if not key:
        return []
    policy = read_policy()
    identity = 'movie-collections-v2:' + hashlib.sha256(key.encode()).hexdigest() + ':' + operation
    cache = None
    try:
        cache = open_cache(group, policy)
        entry = cache.get(identity) if cache else None
    except Exception:
        entry = None  # A cache fault must not hide successful online results.
    if isinstance(entry, dict) and 'value' in entry:
        refresh_at = entry.get('refresh_at')
        if refresh_at is None or (isinstance(refresh_at, (int, float)) and refresh_at > time.time()):
            return entry['value']
    if cached_only:
        return []
    result, complete = loader(key)
    if cache:
        ttl = policy[group] if complete else 60
        if ttl and policy[group] is not None:
            ttl = min(ttl, policy[group])
        # DiskCache reapplies user lifetimes on reads. Keep a separate deadline
        # so incomplete ID conversions still retry after one minute.
        entry = {'value': result, 'refresh_at': None if complete else time.time() + 60}
        try:
            cache.put(identity, entry, ttl)
        except Exception:
            pass

    return result


def search(query, limit=6, cached_only=False):
    term = normalized(str(query or '')[:200])
    if len(term) < 2:
        return []
    def load(key):
        payload = request(key,'search/collection',lambda url:fetch(url,timeout=4),
                          query=term,include_adult='false')
        if not isinstance(payload, dict) or not isinstance(payload.get('results'), list):
            raise ValueError('Collection search is unavailable. Try again shortly.')
        result, seen = [], set()
        for row in payload['results']:
            if not isinstance(row,dict) or row.get('adult'):continue
            identity=str(row.get('id') or '')
            score=relevance(term,row.get('name') or '')
            if score is None or identity in seen:continue
            try: converted=card(identity,row)
            except ValueError:continue
            seen.add(identity);result.append((score,len(result),converted))
        return [row for _,_,row in sorted(result,key=lambda r:r[:2])][:6], True
    try:
        return cached('search:'+term,'search',load,cached_only)[:limit]
    except Exception:
        return []


def movies(identity):
    identity=str(identity)
    if not re.fullmatch(r'[1-9][0-9]{0,11}',identity):
        raise ValueError('Invalid collection identity')
    if not get_addon().getSetting('tmdb_api_key').strip():
        raise ValueError('Add a TMDB API key in Settings to open movie collections.')
    def load(key):
        payload=request(key,'collection/'+identity,lambda url:fetch(url,timeout=8))
        if not isinstance(payload, dict) or not isinstance(payload.get('parts'),list):raise ValueError('Collection details are unavailable. Try again shortly.')
        parts,seen=[],set()
        for row in payload['parts']:
            if not isinstance(row,dict) or row.get('adult') or not re.fullmatch(r'[1-9][0-9]{0,11}',str(row.get('id') or '')):continue
            tid = str(row['id'])
            if tid in seen:continue
            seen.add(tid);parts.append(row)
        parts.sort(key=lambda r:(r.get('release_date') or '9999',str(r['id'])))
        def convert(row):
            tid=str(row['id']);failed=False
            def external(api_key):
                return request(api_key,'movie/'+tid+'/external_ids',lambda url:fetch(url,timeout=4)),True
            try:
                ids=cached('movie-id:'+tid,'metadata',external)
                imdb=ids.get('imdb_id')
            except Exception:
                imdb=None;failed=True
            imdb=imdb if re.fullmatch(r'tt[0-9]+',str(imdb or '')) else ''
            date=str(row.get('release_date') or '')
            result={'id':imdb or 'tmdb:'+tid,'imdb_id':imdb,'moviedb_id':tid,'type':'movie',
                    'name':row.get('title') or row.get('name') or 'Movie',
                    'poster':image(row.get('poster_path')), 'background':image(row.get('backdrop_path'),'w1280'),
                    'description':row.get('overview') or '', 'year':date[:4], 'released':date}
            return result,failed
        try:
            with ThreadPoolExecutor(max_workers=4) as pool:
                converted=list(pool.map(convert,parts))
        except RuntimeError:
            converted = [convert(row) for row in parts]
        return [row for row,_ in converted],not any(failed for _,failed in converted)
    return cached('parts:'+identity,'metadata',load)
