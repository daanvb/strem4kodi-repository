"""Names for the active Kodi audio track, never inferred from a release name."""
import re

FORMATS = {
    'ac3': 'Dolby Digital', 'eac3': 'Dolby Digital Plus',
    'eac3_ddp_atmos': 'Dolby Digital Plus / Dolby Atmos',
    'truehd': 'Dolby TrueHD', 'truehd_atmos': 'Dolby TrueHD / Dolby Atmos',
    'dca': 'DTS', 'dts': 'DTS', 'dtshd_ma': 'DTS-HD Master Audio',
    'dtshd_hra': 'DTS-HD High Resolution', 'dtshd_ma_x': 'DTS-HD Master Audio / DTS:X',
    'dtshd_ma_x_imax': 'DTS-HD Master Audio / DTS:X IMAX',
    'aac': 'AAC', 'aac_lc': 'AAC', 'he_aac': 'HE-AAC', 'he_aac_v2': 'HE-AAC v2',
    'flac': 'FLAC', 'vorbis': 'Vorbis', 'opus': 'Opus', 'mp3': 'MP3',
    'mp2': 'MPEG Audio', 'alac': 'Apple Lossless',
}


def clean(value):
    return re.sub(r'[\x00-\x1f\x7f\[\]]', '', str(value or '')).strip()


def codec_name(value):
    """Normalise Kodi codec identifiers and explicit format labels."""
    value = clean(value).lower()
    if value == 'dd+':
        return 'eac3'
    key = re.sub(r'[^a-z0-9]', '', value)
    aliases = {re.sub(r'[^a-z0-9]', '', name.lower()): codec for codec, name in FORMATS.items()}
    aliases.update({re.sub(r'[^a-z0-9]', '', codec): codec for codec in FORMATS})
    aliases.update({'dd':'ac3', 'dolbyatmos':'atmos', 'ec3':'eac3', 'ddp':'eac3', 'ddplus':'eac3', 'eac3ddp':'eac3',
                    'eac3atmos':'eac3_ddp_atmos', 'ec3atmos':'eac3_ddp_atmos',
                    'dolbydigitalplusatmos':'eac3_ddp_atmos', 'dolbytruehdatmos':'truehd_atmos'})
    return aliases.get(key, value)


def detected_codec(track, active_codec=''):
    codec = codec_name((track if isinstance(track, dict) else {}).get('codec'))
    active = codec_name(active_codec)
    if active in ('atmos', 'dolby atmos') and codec in ('eac3','truehd'):
        return 'eac3_ddp_atmos' if codec == 'eac3' else 'truehd_atmos'
    if not codec:
        return active
    if active in FORMATS and active.startswith(codec + '_'):
        return active
    return codec


def audio_description(track, language_name=None, active_codec=''):
    track = track if isinstance(track, dict) else {}
    codec = detected_codec(track, active_codec)
    format_name = FORMATS.get(codec)
    if not format_name:
        format_name = 'PCM' if codec.startswith('pcm_') else codec.upper() or 'Format unknown'
    language = clean(track.get('language'))
    if language.lower() in ('', 'und', 'unk', 'unknown'):
        language = 'Language unknown'
    elif language_name:
        try:
            language = clean(language_name(language)) or language
        except Exception:
            pass
    try:
        channels = int(track.get('channels') or 0)
    except (ValueError, TypeError):
        channels = 0
    channels_label = {1: 'Mono', 2: 'Stereo', 6: '5.1', 8: '7.1'}.get(channels)
    if not channels_label and channels > 0:
        channels_label = '{} channels'.format(channels)
    parts = [language, format_name]
    if channels_label:
        parts.append(channels_label)
    name = clean(track.get('name'))
    # A track title is useful for commentary/accessibility and optional Atmos
    # hints, but is not proof that Kodi detected an object-audio extension.
    if name and name.lower() not in (language.lower(), format_name.lower()):
        parts.append('Track: ' + name)
    return ' | '.join(parts)


class FinishEstimate:
    """Hold sub-second jitter steady; still follow pauses, seeks and buffering."""
    def __init__(self):
        self.value = None

    def update(self, now, duration, position, speed=1):
        if duration <= 0 or speed < 0 or speed > 1:
            self.value = None
            return None
        candidate = now + max(0, duration - position)
        if self.value is None or abs(candidate - self.value) > 2:
            self.value = candidate
        return self.value
