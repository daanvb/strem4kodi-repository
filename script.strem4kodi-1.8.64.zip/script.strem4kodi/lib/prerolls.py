"""Movie pre-roll selection from trusted public release assets; no title queries."""
import json
import hashlib
import random
import re
import threading
from pathlib import Path
from core.stream_ui import stream_card
from lib.preroll_catalog import ORIGIN, clean

PROPERTY = 'strem4kodi.preroll'
ROTATION_PROPERTY = 'strem4kodi.preroll.rotation'
_rotation_lock = threading.Lock()
_rotation_state = {}


def assets(profile=None):
    if profile is not None:
        from lib.preroll_catalog import catalogue
        cache=catalogue(profile)
        cache.request()
        rows=cache.cached()
        if rows is not None:return rows  # An empty release intentionally disables all clips.
    try:
        rows = json.loads((Path(__file__).resolve().parents[1]/'resources/prerolls.json').read_text(encoding='utf-8'))
        return clean(rows)
    except (OSError,ValueError):return []


def profile_for(addon):
    try:
        import xbmcvfs
        value=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        return value if isinstance(value,str) and value else None
    except (ImportError,AttributeError,TypeError):return None


def audio_family(tags):
    text = ' '.join(tags).lower()
    if 'atmos' in text:return 'atmos'
    if 'truehd' in text:return 'truehd'
    if 'dolby digital plus' in text:return 'ddplus'
    if 'dolby digital' in text:return 'dd'
    if 'dts' in text:return 'dts'
    return ''


def asset_family(name):
    text = re.sub(r'[._-]+',' ',str(name)).lower()
    if 'atmos' in text:return 'atmos'
    if 'truehd' in text:return 'truehd'
    if 'digital plus' in text:return 'ddplus'
    if 'digital' in text:return 'dd'
    return ''


def _clip_key(name):
    # Aspect/resolution variants of the same introduction count as one clip.
    words = re.split(r'[._ -]+', str(name).casefold())
    cut = next((i for i, word in enumerate(words) if word in
                ('cinemascope', 'widescreen', 'fhd', 'uhd', '4k', '1080p', '720p', 'sd', 'sdr', 'hdr', 'dovi')), len(words))
    return hashlib.sha256(' '.join(words[:cut]).encode()).hexdigest()[:24]


def _varied(candidates, family, choose):
    """Random bag per compatible audio pool, without disk or network work."""
    with _rotation_lock:
        window = None
        try:
            import xbmcgui
            window = xbmcgui.Window(10000)
            state = json.loads(window.getProperty(ROTATION_PROPERTY) or '{}')
            if not isinstance(state, dict):state = {}
        except (ImportError, AttributeError, RuntimeError, ValueError, TypeError):
            state = dict(_rotation_state)
        groups = {}
        for row in candidates:groups.setdefault(_clip_key(row['name']), []).append(row)
        pool = hashlib.sha256('\n'.join(sorted(row['url'] for row in candidates)).encode()).hexdigest()
        previous = state.get(family) or {}
        if not isinstance(previous, dict):previous = {}
        remaining = previous.get('remaining') if previous.get('pool') == pool else None
        if not isinstance(remaining, list):remaining = []
        remaining = [key for key in groups if key in remaining]
        if not remaining:
            remaining = list(groups)
            if len(remaining) > 1 and previous.get('last') in remaining:
                # Put the last clip back in the new bag after its first draw.
                options = [key for key in remaining if key != previous['last']]
            else:options = remaining
        else:options = remaining
        chosen = choose(options)
        row = choose(groups[chosen])
        state[family] = {'pool': pool, 'remaining': [key for key in remaining if key != chosen], 'last': chosen}
        state = {key: value for key, value in state.items() if key in ('atmos', 'truehd', 'ddplus', 'dd')}
        _rotation_state.clear();_rotation_state.update(state)
        if window is not None:
            try:window.setProperty(ROTATION_PROPERTY, json.dumps(state))
            except (AttributeError, RuntimeError):pass
        return row


def select(meta, stream, resume_ms, addon, rows=None, choose=random.choice, rotate=True):
    from continue_playback import resume_seconds
    if meta.get('type') != 'movie' or resume_seconds(resume_ms) or stream.get('_preroll_done'):
        return None
    if addon.getSetting('prerolls_enabled') != 'true':return None
    card = stream_card(stream)
    family = audio_family(card.get('audio_tags',[]))
    if family == 'dts':
        if addon.getSetting('prerolls_dts') == '1':return None
        family = 'dd'
    if not family:return None
    from lib.player_tests import fel7_asset
    candidates = [row for row in (assets(profile_for(addon)) if rows is None else rows)
                  if not fel7_asset(row.get('name')) and asset_family(row.get('name')) == family]
    # SDR introductions work for both HDR and SDR movies. DoVi-only intros
    # must not be selected for a source which does not report Dolby Vision.
    vision = 'Dolby Vision' in card.get('video_tags',[])
    candidates = [row for row in candidates if vision or not re.search(r'(?i)dovi|dolby[ .]vision',row['name'])]
    sdr = [row for row in candidates if re.search(r'(?i)\bSDR\b',row['name'])]
    if not candidates:return None
    return _varied(sdr or candidates, family, choose) if rotate else (sdr or candidates)[0]


def phase(gui=None):
    try:
        if gui is None:import xbmcgui as gui
        return gui.Window(10000).getProperty(PROPERTY)
    except Exception:return ''


def clear_phase(expected):
    try:
        import xbmcgui
        window=xbmcgui.Window(10000)
        if window.getProperty(PROPERTY) == expected:window.clearProperty(PROPERTY)
    except Exception:pass
