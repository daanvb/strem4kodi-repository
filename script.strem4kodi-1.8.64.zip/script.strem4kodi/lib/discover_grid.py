"""Vertical-only Discover grid with the same artwork size as Home."""
import xml.etree.ElementTree as ET
from lib.cinematic_cards import posters

ROW_IDS = (9500,)


def split(items, capacity=1):
    return [items] if items else []


def build(tree):
    controls = tree.getroot().find('controls')
    rows = tree.find('.//control[@id="2000"]')
    ET.SubElement(rows, 'visible').text = '!String.IsEqual(Window.Property(discover_grid),true)'
    listing = ET.SubElement(controls, 'control', type='panel', id='9500')
    for tag, value in {'left':50, 'top':660, 'width':1760, 'height':420,
                       'orientation':'vertical', 'scrolltime':180,
                       'onup':9200, 'ondown':9500, 'onleft':9000, 'onright':9500,
                       'visible':'String.IsEqual(Window.Property(discover_grid),true)'}.items():
        ET.SubElement(listing, tag).text = str(value)
    for tag in ('itemlayout', 'focusedlayout'):
        ET.SubElement(listing, tag, width='220', height='333')
    posters(listing)
    for layout in (listing.find('itemlayout'), listing.find('focusedlayout')):
        for node in list(layout):
            if node.get('type') == 'label' and float(node.findtext('top', '0')) >= 320:
                layout.remove(node)
            elif node.find('left') is not None:
                node.find('left').text = str(int(node.findtext('left')) - 5)
