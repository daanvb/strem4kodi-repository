"""Device-local catalogue artwork choices, keyed without storing provider URLs."""
import hashlib
import re
from pathlib import Path
from account import Store


def key(catalog):
    parts = (catalog.get('url') or '', catalog.get('kind') or '',
             catalog.get('catalog_id') or catalog.get('id') or '')
    return hashlib.sha256('\n'.join(str(p) for p in parts).encode()).hexdigest()


def sports(catalog):
    """Recognise sports types and provider hints used by Discover."""
    kind = str(catalog.get('kind') or catalog.get('type') or '').casefold()
    if kind in ('sport', 'sports'):
        return True
    if re.search(r'\bsports?\b', str(catalog.get('addon') or catalog.get('provider') or '').casefold()):
        return True
    rows = catalog.get('items') or []
    return bool(rows) and all(isinstance(row, dict) and str(row.get('type') or '').casefold() in ('sport', 'sports') for row in rows)


def load(profile, catalog):
    if sports(catalog):
        return 'wide'
    return (Store(Path(profile)/'catalogue-layouts').load().get('layouts') or {}).get(key(catalog), 'posters')


def save(profile, catalog, value):
    if value not in ('posters', 'wide'):raise ValueError('Unknown catalogue layout')
    store=Store(Path(profile)/'catalogue-layouts')
    values=store.load().get('layouts') or {}
    values[key(catalog)]=value
    store.save({'layouts':values})


def wide_art(row):
    return row.get('landscape') or row.get('thumbnail') or row.get('background') or row.get('poster') or ''


def add_layouts(listing, cid):
    import xml.etree.ElementTree as ET
    base='special://home/addons/script.strem4kodi/resources/skins/Main/media/'
    for tag in ('itemlayout','focusedlayout'):
        existing=listing.find(tag)
        if existing is None:continue
        existing.set('condition', '!String.IsEqual(Window.Property(layout%d),wide)' % cid)
        wide=ET.Element(tag, width='380', height=existing.get('height','393'),
                        condition='String.IsEqual(Window.Property(layout%d),wide)' % cid)
        def control(kind, x,y,w,h,values):
            c=ET.SubElement(wide,'control',type=kind)
            for name,value in dict(left=x,top=y,width=w,height=h,**values).items():ET.SubElement(c,name).text=str(value)
            return c
        control('image',10,18,356,200,{'texture':base+'episode-card-local/mask.png','colordiffuse':'FF15171C'})
        art=control('image',10,18,356,200,{'texture':'$INFO[ListItem.Property(wide_art)]','aspectratio':'scale'})
        art.find('texture').set('diffuse',base+'cinematic/wide-mask.png')
        control('label',320,25,38,30,{'label':'✓','font':'font23','textcolor':'FFFFFFFF','align':'center','visible':'String.IsEqual(ListItem.Property(watched),true)'})
        control('label',18,232,340,42,{'font':'font23_title' if tag=='focusedlayout' else 'font23','textcolor':'FFFFFFFF','label':'$INFO[ListItem.Label]','scroll':'true'})
        control('label',18,278,340,30,{'font':'font20','textcolor':'FFD3C4F6','label':'$INFO[ListItem.Property(release_label)]','visible':'!String.IsEmpty(ListItem.Property(release_label))','scroll':'true'})
        control('image',10,18,356,200,{'texture':base+'cinematic/wide-outline.png'})
        if tag == 'focusedlayout':
            control('image',10,18,356,200,{'texture':base+'cinematic/wide-focus.png',
                    'visible':'Control.HasFocus(%d)' % cid})
        from lib.poster_progress import append as append_progress
        append_progress(wide, 18, 207, 340)
        listing.insert(list(listing).index(existing),wide)
