"""Once-per-playback forced subtitles, scoped to videos started by this app."""
import hashlib
import re
import threading
import time
from pathlib import Path
from account import Store
from subtitles import language, collect_subtitles, download_original


def forced_track(tracks, preferred):
    for track in tracks:
        if not isinstance(track, dict) or language(track.get('language')) != preferred:
            continue
        if track.get('isforced') is True or re.search(r'(?i)\bforced\b', str(track.get('name') or '')):
            if isinstance(track.get('index'), int):
                return track
    return None


def matching_downloads(entries, preferred, filename):
    """Only explicitly forced files tied to the exact selected release filename."""
    def basename(value):
        return str(value or '').replace('\\', '/').rsplit('/', 1)[-1].strip().casefold()
    filename = basename(filename)
    if not filename:
        return []
    return [entry for entry in entries if entry.get('forced') is True
            and language(entry.get('lang')) == preferred
            and basename(entry.get('filename')) == filename][:2]


class ForcedSubtitleWatcher:
    def __init__(self, profile, addon, player, kodi, home, rpc, clock=time.monotonic):
        self.profile = Path(profile)
        self.addon, self.player, self.kodi, self.home, self.rpc = addon, player, kodi, home, rpc
        self.clock = clock
        self.session = None
        self.worker = None

    def _matches(self, session):
        try:
            return (self.session is session and self.player.isPlayingVideo()
                    and self.player.getPlayingFile() == session['file']
                    and getattr(self.player, '_playing_file', None) == session['file']
                    and self.home.getProperty('strem4kodi.subtitles.manual') != session['digest'])
        except Exception:
            return False

    def _properties(self):
        players = self.rpc('Player.GetActivePlayers') or []
        video = next((row for row in players if row.get('type') == 'video'), None)
        if not video:
            return None, {}
        return video['playerid'], self.rpc('Player.GetProperties', {
            'playerid': video['playerid'], 'properties': ['subtitles', 'currentsubtitle', 'subtitleenabled']})

    def tick(self):
        try:
            mode = self.addon.getSetting('forced_subtitles_mode') or '2'
            if not self.player.isPlayingVideo():
                self.session = None
                return
            file = self.player.getPlayingFile()
            if file != getattr(self.player, '_playing_file', None):
                return
            if self.session is None or self.session['file'] != file:
                self.session = {'file': file, 'digest': hashlib.sha256(file.encode()).hexdigest(),
                                'started': self.clock(), 'done': False, 'last': -3,
                                'defaults_applied': False}
            session = self.session
            age = self.clock() - session['started']
            if session['done'] or age > 30 or not self._matches(session):
                return
            if age - session['last'] < 3:
                return
            session['last'] = age
            preferred = 'eng'
            if self.addon.getSetting('forced_subtitles_language') == '1':
                from setup_profile import get_setting
                preferred = language(get_setting('locale.subtitlelanguage', 'English'))
                if preferred in ('forced_only', 'forced only', 'original', 'default'):
                    preferred = language(self.kodi.getInfoLabel('VideoPlayer.AudioLanguage'))
            allow_forced = bool(preferred and preferred not in ('none', 'off', 'und', 'unk'))
            player_id, props = self._properties()
            if player_id is None or not self._matches(session):
                return
            track = forced_track(props.get('subtitles') or [], preferred) if allow_forced else None
            if not session['defaults_applied']:
                # Kodi may apply its saved subtitle default after the first AV
                # sample. Recheck once after tracks have settled, then stop.
                session['defaults_applied'] = age >= 3
                already_forced = (mode != '0' and track
                                  and (props.get('currentsubtitle') or {}).get('index') == track['index'])
                if (self.addon.getSetting('subtitles_default_off') != 'false'
                        and props.get('subtitleenabled') and not already_forced and self._matches(session)):
                    self.rpc('Player.SetSubtitle', {'playerid': player_id, 'subtitle': 'off'})
                    props = dict(props, subtitleenabled=False)
            if mode == '0' or not allow_forced:
                session['done'] = age >= 3
                return
            if age < 3:
                return  # Give Kodi time to expose all embedded subtitle tracks.
            if props.get('subtitleenabled'):
                session['done'] = True  # Respect existing full captions/user choices.
                return
            if track:
                if self._matches(session):
                    self.rpc('Player.SetSubtitle', {'playerid': player_id,
                                                   'subtitle': track['index'], 'enable': True})
                session['done'] = True
                return
            if age < 10:
                return
            if mode != '2':
                session['done'] = True
                return
            if self.worker is not None and self.worker.is_alive():
                return
            context = Store(self.profile / 'playback').load()
            if context.get('url_hash') != session['digest'] or context.get('kind') not in ('movie', 'series'):
                return
            session['done'] = True
            self.worker = threading.Thread(target=self._download, args=(session, context, preferred, props), daemon=True)
            self.worker.start()
        except Exception:
            return  # A subtitle failure must never interrupt playback.

    def _download(self, session, context, preferred, initial):
        try:
            from provider_roles import ordered
            from lib.provider_config import state as provider_state
            state = provider_state(self.profile)
            entries = collect_subtitles(ordered(state, 'subtitles'), context['kind'], context['id'],
                                        [preferred], preferred, context.get('subtitles'), context.get('filename', ''))
            for entry in matching_downloads(entries, preferred, context.get('filename')):
                if not self._matches(session):
                    return
                try:
                    path = download_original(entry, self.profile / 'subtitles')
                except Exception:
                    continue
                player_id, current = self._properties()
                if (player_id is None or not self._matches(session) or current.get('subtitleenabled')
                        or current.get('currentsubtitle') != initial.get('currentsubtitle')):
                    return
                self.player.setSubtitles(path)
                if self._matches(session):
                    self.player.showSubtitles(True)
                return
        except Exception:
            return
