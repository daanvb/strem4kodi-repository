"""Short-lived fullscreen Back handler; no media/account requests."""
import hashlib
import json
import time

PROPERTY = 'strem4kodi.player.back'
STOPPING_PROPERTY = 'strem4kodi.player.stopping'
WINDOW_SECONDS = 3.0
# Kodi's native playback dialogs, including the nested adjustment slider.
PLAYBACK_DIALOGS = {10123, 10124, 10125, 10142, 10145, 10153, 10157, 10159, 12901}


def decide(raw, identity, now):
    try:
        previous = json.loads(raw)
        elapsed = now - float(previous['time'])
        if previous.get('identity') == identity and 0 <= elapsed <= WINDOW_SECONDS:
            return True, ''
    except (ValueError, TypeError, KeyError):
        pass
    return False, json.dumps({'identity': identity, 'time': now}, separators=(',', ':'))


def run(kodi=None, gui=None, clock=time.monotonic):
    if kodi is None:
        import xbmc as kodi
    if gui is None:
        import xbmcgui as gui
    window = gui.Window(10000)
    top = gui.getCurrentWindowDialogId()
    if top in PLAYBACK_DIALOGS:
        window.clearProperty(PROPERTY)
        kodi.executebuiltin('Dialog.Close(%s)' % top)
        return
    if isinstance(top, int) and top >= 10000:
        # Never count a press in a modal menu as a request to stop its video.
        window.clearProperty(PROPERTY)
        return
    player = kodi.Player()
    if not player.isPlayingVideo() or not kodi.getCondVisibility('Window.IsActive(fullscreenvideo)'):
        window.clearProperty(PROPERTY)
        return
    try:identity = hashlib.sha256(player.getPlayingFile().encode('utf-8')).hexdigest()
    except RuntimeError:return  # Playback can end between the two native queries.
    now=clock()
    # Stop is asynchronous. Remote repeats during that transition must not
    # launch another Stop or re-arm the first-press prompt.
    if decide(window.getProperty(STOPPING_PROPERTY),identity,now)[0]:return
    stop, state = decide(window.getProperty(PROPERTY), identity, now)
    if stop:
        window.clearProperty(PROPERTY)
        window.setProperty(STOPPING_PROPERTY,json.dumps({'identity':identity,'time':now}))
        try:player.stop()
        except RuntimeError:pass
    else:
        window.setProperty(PROPERTY, state)
        gui.Dialog().notification('Strem4Kodi', 'Press Back again to stop playback',
                                  time=3000, sound=False)
