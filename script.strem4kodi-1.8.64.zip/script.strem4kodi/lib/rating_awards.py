"""Explicit Rotten Tomatoes awards; never infer certification from a score."""


def confirmed(payload, source):
    if source not in ('tomatoes', 'tomatoesaudience'):
        return False
    field = ('rotten_tomatoes_critics_certified' if source == 'tomatoes'
             else 'rotten_tomatoes_users_certified')
    features = payload.get('whatson_features')
    if isinstance(features, dict) and type(features.get(field)) is bool:
        return features[field]
    # MDBList documents these provider-added keywords. No free-text matching.
    keywords = payload.get('keywords')
    if not isinstance(keywords, list):
        return False
    names = {value.get('name') if isinstance(value, dict) else value
             for value in keywords if isinstance(value, (str, dict))
             and isinstance(value.get('name') if isinstance(value, dict) else value, str)}
    return ('certified-fresh' if source == 'tomatoes' else 'certified-hot') in names


def icon(payload, source, value):
    if source == 'tomatoes':
        if value >= 70 and confirmed(payload, source):
            return 'rtcertified'
        return 'rtfresh' if value >= 60 else 'rtrotten'
    if source == 'tomatoesaudience':
        if value >= 80 and confirmed(payload, source):
            return 'popcorn_verified'
        return 'popcorn' if value >= 60 else 'popcorn_spilt'
    return ''
