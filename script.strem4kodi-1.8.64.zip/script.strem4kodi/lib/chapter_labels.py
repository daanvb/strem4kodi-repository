"""Small offline translations for common chapter labels; never guess scene titles."""
import re
import unicodedata

NUMBERED = r'(?:chapter|chapitre|cap[ií]tulo|capitolo|kapitel|hoofdstuk|rozdział|κεφάλαιο|глава|часть|розділ|章节|章節|章|チャプター|챕터)'
WORDS = {
    'вступление': 'Introduction', 'пролог': 'Prologue', 'эпилог': 'Epilogue',
    'начальные титры': 'Opening credits', 'вступительные титры': 'Opening credits',
    'конечные титры': 'End credits', 'финальные титры': 'End credits',
    'титры': 'Credits', 'конец': 'The end',
    'générique de début': 'Opening credits', 'générique de fin': 'End credits',
    'vorspann': 'Opening credits', 'abspann': 'End credits',
    'créditos iniciales': 'Opening credits', 'créditos finales': 'End credits',
    'titoli di testa': 'Opening credits', 'titoli di coda': 'End credits',
    'openingstitels': 'Opening credits', 'aftiteling': 'End credits',
    'napisy początkowe': 'Opening credits', 'napisy końcowe': 'End credits',
    'créditos iniciais': 'Opening credits', 'créditos finais': 'End credits',
    'початкові титри': 'Opening credits', 'кінцеві титри': 'End credits',
    '片头': 'Opening', '片尾': 'End credits', '片頭': 'Opening', '片尾字幕': 'End credits',
    '오프닝': 'Opening', '엔딩': 'Ending', '엔딩 크레딧': 'End credits',
    'introduction': 'Introduction', 'introducción': 'Introduction', 'introduzione': 'Introduction',
    'einleitung': 'Introduction', 'inleiding': 'Introduction',
    'オープニング': 'Opening', 'エンディング': 'Ending',
}


def english(name, number=1):
    text = unicodedata.normalize('NFC', str(name or '')).strip()
    match = re.fullmatch(NUMBERED + r'\s*[#№.:_-]?\s*(\d+)\s*', text, re.I)
    if match:
        return 'Chapter ' + match[1]
    return WORDS.get(text.casefold(), text) or 'Chapter ' + str(number)


def label(name, number, count=0):
    text = english(name, number)
    prefix = 'Chapter ' + str(number) + ('/' + str(count) if count else '')
    return prefix if re.fullmatch(r'Chapter \d+', text) else prefix + ' · ' + text
