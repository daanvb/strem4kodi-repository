"""Append catalogue pages without disturbing supplier order or showing repeats."""
from lib.catalogue_identity import combine as combine_titles


def combine(previous, incoming):
    return combine_titles(previous + incoming)


def more_card():
    return {'id': 'discover:load-more', 'type': 'collection', 'name': 'Load more titles',
            'description': 'Press OK to load the next page. The titles already loaded stay in this list.', '_discover_load_more': True}
