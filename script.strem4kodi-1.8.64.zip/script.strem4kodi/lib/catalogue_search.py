"""Local catalogue-name search and conservative account progress decoration."""
import hashlib
from lib.discovery_groups import clean_label, item_key, franchise, category
from search_match import normalized, relevance


def matches(query, specs, limit=8):
    if len(normalized(query)) < 2:
        return []
    found, seen = [], set()
    for spec in specs:
        if str(spec.get('kind', '')).lower() not in ('movie', 'series', 'all', 'marvel', 'dc', 'starwars', 'star wars', 'doctorwho', 'doctor who'):
            continue
        label = category(spec) if franchise(spec) else clean_label(spec['label']) or spec['label']
        score = relevance(query, label)
        key = (spec.get('url'), spec.get('kind'), spec.get('id'))
        if score is None or key in seen:
            continue
        seen.add(key)
        identity = hashlib.sha256(repr(key).encode()).hexdigest()[:24]
        found.append((score, len(found), {'id': 'catalogue:' + identity, 'type': 'collection',
            'name': label, 'poster': '', '_catalogue': dict(spec, _search_collection=True),
            'description': 'Browse this catalogue in its supplied order, with synced watched status and progress.'}))
    return [row for _, _, row in sorted(found, key=lambda r: r[:2])][:limit]


def with_progress(rows, library, unwatched=False):
    saved = {item_key(dict(r, id=r.get('_id') or r.get('id'))): r
             for r in library if isinstance(r, dict) and not r.get('removed')}
    seen, result = set(), []
    for row in rows:
        if row.get('type') not in ('movie', 'series'):
            continue
        key = item_key(row)
        if key in seen:
            continue
        seen.add(key)
        state = (saved.get(key) or {}).get('state') or {}
        state = state if isinstance(state, dict) else {}
        try:
            offset, duration = float(state.get('timeOffset') or 0), float(state.get('duration') or 0)
        except (TypeError, ValueError):
            offset = duration = 0
        partial = duration > 0 and 1000 <= offset < duration * .9
        # A last-watched date or episode bitmap alone does not mean a whole series is finished.
        watched = (bool(state.get('flaggedWatched')) or duration > 0 and offset >= duration * .9) and not partial
        if row.get('type') == 'series':
            from lib.episode_state import watched_ids
            videos = (saved.get(key) or {}).get('videos') or row.get('videos') or []
            regular = [v for v in videos if isinstance(v, dict) and v.get('id') and str(v.get('season') or '0').isdigit() and int(v.get('season') or 0) > 0]
            finished = watched_ids(videos, dict(state=state))
            watched = bool(regular) and all(v['id'] in finished for v in regular) and not partial
        if unwatched and watched:
            continue
        result.append(dict(row, state=dict(state), _catalogue_watched=watched))
    return result
