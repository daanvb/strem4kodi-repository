"""Cited, title-specific production facts from public Wikimedia APIs.

No generated text, title-name guesses, credentials or IMDb website scraping.
Wikipedia contributors supply these facts; citations are not independent verification.
"""
from html.parser import HTMLParser
import gzip
from io import BytesIO
import json
import re
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen

WIKIDATA = 'https://www.wikidata.org/w/api.php'
WIKIPEDIA = 'https://en.wikipedia.org/w/api.php'
LICENSE = 'https://creativecommons.org/licenses/by-sa/4.0/'
USER_AGENT = 'Strem4Kodi/1.8 (https://github.com/daanvb/strem4kodi-repository)'
MAX_BYTES = 2 * 1024 * 1024
SECTION = re.compile(r'\b(production|development|filming|visual effects|special effects|music|animation|writing|concept|design|soundtrack|conception|editing)\b', re.I)
EXCLUDED = re.compile(r'\b(plot|synopsis|story|cast|casting|episodes|reception|release|references|legacy|awards)\b', re.I)
INTERESTING = re.compile(r'\b(filmed|filming|shot|inspired|originally|initially|improvis\w*|animat\w*|practical|visual effects?|special effects?|miniatures?|designed|recorded|rewritten|puppets?|prosthe\w*|camera|composed|theme|costumes?|computer.generated|sound effects?|stop.motion)\b', re.I)
SPOILER = re.compile(r'\b(spoilers?|ending|dies|killed|death|final scene|twist|revealed|murderer)\b', re.I)
DEPENDENT = re.compile(r'^(he|she|they|it|this|these|those|his|her|their|however|therefore|instead|also)\b', re.I)


def request(base, params, timeout=5):
    # These are small, cached reads for an interactive title view, never bulk edits.
    params = dict(params, format='json', formatversion=2)
    req = Request(base + '?' + urlencode(params), headers={
        'User-Agent': USER_AGENT, 'Accept': 'application/json', 'Accept-Encoding': 'gzip'})
    with urlopen(req, timeout=timeout) as response:
        deadline = time.monotonic() + timeout
        chunks = []; size = 0
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError('Trivia response deadline')
            chunk = response.read1(min(65536, MAX_BYTES + 1 - size))
            if not chunk:break
            chunks.append(chunk); size += len(chunk)
            if size > MAX_BYTES:raise ValueError('Trivia response too large')
        data = b''.join(chunks)
        if response.getheader('Content-Encoding', '').lower() == 'gzip':
            with gzip.GzipFile(fileobj=BytesIO(data)) as compressed:
                data = compressed.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('Trivia response too large')
    payload = json.loads(data)
    error = payload.get('error') if isinstance(payload, dict) else None
    if isinstance(error, dict) and error.get('code') in ('maxlag', 'ratelimited'):
        from urllib.error import HTTPError
        raise HTTPError(base, 503 if error['code'] == 'maxlag' else 429,
                        'Trivia API busy', {'Retry-After': '300'}, None)
    if not isinstance(payload, dict) or error:
        raise ValueError('Trivia API unavailable')
    return payload


class ProductionHTML(HTMLParser):
    """Read paragraphs in production sections, retaining citation evidence."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []; self.headings = {}; self.heading = None
        self.paragraph = None; self.parts = []; self.cited = False
        self.rows = []; self.section = ''

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        blocked = bool(self.stack and self.stack[-1][1]) or tag in ('script', 'style', 'table', 'figure', 'ul', 'ol')
        classes = attrs.get('class', '').split()
        reference = tag == 'sup' and 'reference' in classes
        if reference and self.paragraph is not None:
            self.cited = True
        blocked = blocked or reference or any(c in classes for c in ('mw-editsection', 'noprint', 'hatnote', 'reference', 'mw-empty-elt'))
        if tag not in ('br', 'hr', 'img', 'meta', 'link', 'input', 'wbr'):
            self.stack.append((tag, blocked))
        if blocked:
            return
        if re.fullmatch(r'h[2-6]', tag):
            self.heading = int(tag[1]); self.parts = []
        elif tag == 'p' and self.heading is None:
            self.paragraph = tag; self.parts = []; self.cited = False

    def handle_data(self, text):
        if (self.heading is not None or self.paragraph is not None) and not (self.stack and self.stack[-1][1]):
            self.parts.append(text)

    def handle_endtag(self, tag):
        if self.heading is not None and tag == 'h' + str(self.heading):
            heading = ' '.join(''.join(self.parts).split())
            self.headings = {level: value for level, value in self.headings.items() if level < self.heading}
            self.headings[self.heading] = heading
            self.section = heading
            self.heading = None; self.parts = []
        elif tag == 'p' and self.paragraph:
            sections = ' '.join(self.headings.values())
            if self.cited and SECTION.search(sections) and not EXCLUDED.search(sections):
                self.rows.append((self.section, ' '.join(''.join(self.parts).split())))
            self.paragraph = None; self.parts = []
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break


def extract(html, revision):
    if not isinstance(html, str) or len(html.encode('utf-8')) > MAX_BYTES or type(revision) is not int or revision <= 0:
        return []
    parser = ProductionHTML(); parser.feed(html); parser.close()
    candidates = []
    for section, paragraph in parser.rows:
        # Select complete sentences that fit. Never shorten a fact mid-sentence.
        boundaries = []
        for match in re.finditer(r'(?<=[.!?])\s+(?=[A-Z“"\[])', paragraph):
            if not re.search(r'\b(?:[A-Z]|Mr|Mrs|Ms|Dr|Prof|St|vs|etc|e\.g|i\.e)\.$', paragraph[:match.start()]):
                boundaries.append((match.start(), match.end()))
        start = 0; sentences = []
        for end, following in boundaries:
            sentences.append(paragraph[start:end]); start = following
        sentences.append(paragraph[start:])
        for sentence in sentences:
            sentence = sentence.strip()
            if not 65 <= len(sentence) <= 190 or not re.search(r'[.!?][”"\']?$', sentence):
                continue
            if (DEPENDENT.search(sentence) or SPOILER.search(sentence) or not INTERESTING.search(sentence)
                    or re.search(r'\b(he|she|his|her|their|they|this|these|those|the scene|the reason|the work|first meet|scripted to|actions in)\b', sentence, re.I)):
                continue
            if re.search(r'https?://|\[|\]|citation needed|according to', sentence, re.I):
                continue
            score = len(INTERESTING.findall(sentence)) + 3 * len(re.findall(r'\b(first|originally|initially|inspired|improvis\w*|miniature\w*|instead)\b', sentence, re.I))
            candidates.append((-score, section, sentence))
    result = []; seen = set(); per_section = {}
    for _, section, sentence in sorted(candidates):
        if sentence.casefold() in seen or per_section.get(section, 0) >= 3:
            continue
        seen.add(sentence.casefold()); per_section[section] = per_section.get(section, 0) + 1
        result.append({'text': sentence, 'source': 'https://en.wikipedia.org/w/index.php?oldid=' + str(revision),
                       'license': LICENSE, 'origin': 'wikipedia'})
        if len(result) == 10:
            break
    return result


def fetch(imdb, fetcher=request, clock=time.monotonic):
    if not isinstance(imdb, str) or not re.fullmatch(r'tt\d+', imdb):
        return []
    deadline = clock() + 12
    def get(base, params):
        remaining = deadline - clock()
        if remaining <= 0:
            raise TimeoutError('Trivia request deadline')
        return fetcher(base, params, timeout=min(5, remaining))
    search = get(WIKIDATA, {'action': 'query', 'list': 'search',
        'srsearch': 'haswbstatement:P345=' + imdb, 'srnamespace': 0, 'srlimit': 3, 'srprop': ''})
    matches = search.get('query', {}).get('search', [])
    if (not 1 <= len(matches) <= 3 or search.get('query', {}).get('searchinfo', {}).get('totalhits', len(matches)) > 3
            or any(not isinstance(row, dict) or not re.fullmatch(r'Q\d+', str(row.get('title', ''))) for row in matches)):
        return []
    qids = [row['title'] for row in matches]
    entities = get(WIKIDATA, {'action': 'wbgetentities', 'ids': '|'.join(qids),
        'props': 'claims|sitelinks', 'sitefilter': 'enwiki'}).get('entities', {})
    articles = []
    for qid in qids:
        entity = entities.get(qid, {})
        claims = entity.get('claims', {}).get('P345', [])
        ids = {row.get('mainsnak', {}).get('datavalue', {}).get('value') for row in claims
               if isinstance(row, dict) and row.get('rank') != 'deprecated'}
        article = entity.get('sitelinks', {}).get('enwiki', {}).get('title')
        if ids == {imdb} and isinstance(article, str) and article and len(article) <= 300:
            articles.append(article)
    # Deprecated cancelled adaptations can share a search hit with the real show.
    # Require a single verified article after checking all returned claims.
    if len(articles) != 1:
        return []
    page = get(WIKIPEDIA, {'action': 'parse', 'page': articles[0], 'prop': 'text|revid',
        'disableeditsection': 1}).get('parse', {})
    return extract(page.get('text'), page.get('revid'))
