"""Episode-only scores; never substitute a show's overall rating."""
import re

SOURCES=(('imdb','IMDb','imdbRating',10),('tmdb','TMDB','tmdbRating',10),
         ('trakt','Trakt','traktRating',10),('tomatoes','Rotten Tomatoes','rottenTomatoesRating',100),
         ('tomatoesaudience','Popcornmeter','rottenTomatoesAudienceRating',100),
         ('metacritic','Metacritic','metacriticRating',100),
         ('mdblist','MDBList','mdblistRating',100))


def badges(row,get_setting):
    aliases={'rottentomatoes':'tomatoes','rotten tomatoes':'tomatoes','rt':'tomatoes','tmdb':'tmdb','imdb':'imdb',
             'popcorn':'tomatoesaudience','popcornmeter':'tomatoesaudience'}
    supplied={aliases.get(str(r.get('source','')).casefold(),str(r.get('source','')).casefold()):r.get('value') for r in (row.get('ratings') or []) if isinstance(r,dict)}
    output=[]
    for source,label,field,scale in SOURCES:
        if get_setting('rating_'+source)=='false':continue
        setting=get_setting('episode_rating_'+source)
        if setting=='false' or (setting!='true' and source not in ('imdb','tmdb')):continue
        value=row.get(field)
        if source=='tomatoesaudience' and value in (None,''):value=row.get('popcornRating')
        if value in (None,''):value=supplied.get(source)
        if source=='imdb' and value in (None,''):value=row.get('rating')
        if value in (None,'') or isinstance(value,bool):continue
        match=re.fullmatch(r'\s*(\d+(?:\.\d+)?)\s*%?\s*',str(value))
        if not match:continue
        number=float(match.group(1))
        if not 0<number<=scale:continue
        output.append({'source':source,'value':f'{number:.1f}' if scale==10 else f'{number:g}%'})
    return output


def icon(badge):
    source = badge['source']
    if source in ('tomatoes', 'tomatoesaudience'):
        positive = float(badge['value'].rstrip('%')) >= 60
        return ('rtfresh' if positive else 'rtrotten') if source == 'tomatoes' else ('popcorn' if positive else 'popcorn_spilt')
    return source
