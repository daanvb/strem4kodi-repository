"""Explicit diagnostic video playback, separate from title/progress playback."""
import re
from urllib.parse import urlsplit

# Original V4 MKV pattern, from the FEL test folder linked by Kodi's samples wiki.
DEFAULT_FEL7_URL = 'https://drive.usercontent.google.com/download?id=17qa-6NLxVJU4Ivsq40E2Lk35XtC1lwME&export=download&confirm=t'


def fel7_asset(name):
    text=re.sub(r'[._-]+',' ',str(name)).lower()
    return bool(re.search(r'\bfel\s*7\b',text) or
                (re.search(r'\bfel\b',text) and re.search(r'\btest\b|\bpattern\b|\bcheck\b',text)))


def video_url(value):
    value=str(value or '').strip()
    try:
        parsed=urlsplit(value)
        if (parsed.scheme == 'https' and parsed.hostname and not parsed.username and not parsed.password
                and not re.search(r'[\s\x00-\x1f]',value)):
            return value
    except ValueError:pass
    return ''


def play_fel7(addon, profile, picker, kodi, gui, owner=None):
    from lib.preroll_catalog import catalogue
    url=video_url(addon.getSetting('fel7_test_url'))
    if not url:
        cache=catalogue(profile)
        cache.request()
        matches=[row for row in (cache.cached() or []) if fel7_asset(row['name'])]
        if len(matches)>1:
            selected=picker.select('FEL7 test video',[row['name'] for row in matches])
            if selected<0:return False
            url=video_url(matches[selected]['url'])
        elif matches:url=video_url(matches[0]['url'])
    if not url:url=DEFAULT_FEL7_URL
    # No Stremio playback key or movie identity: observers cannot save progress.
    item=gui.ListItem(label='FEL7 decoding test',path=url)
    item.setProperty('Strem4KodiDiagnostic','true')
    from lib.prerolls import PROPERTY
    gui.Window(10000).clearProperty(PROPERTY)
    if owner is not None:owner.close()
    kodi.Player().play(url,item)
    return True
