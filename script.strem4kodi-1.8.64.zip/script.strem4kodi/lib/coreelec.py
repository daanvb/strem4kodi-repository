"""Reversible addon-only CoreELEC preset; never changes Kodi decoder settings."""
def enabled(addon):
    # Index 0 previously meant Automatic. Existing installs now keep full quality.
    return addon.getSetting('coreelec_preset')=='1'

def trailer_quality(addon):
    value=addon.getSetting('trailers_quality')
    return '1' if enabled(addon) and value in ('','0') else value
