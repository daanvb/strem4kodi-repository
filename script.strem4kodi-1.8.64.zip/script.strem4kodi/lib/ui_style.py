"""App-owned typography and neutral text colours, independent of native skin fonts."""

# Preserve the existing layout scale while resolving missing or ambiguous names.
FONT_ALIASES = {
    'font10': 'Strem4Kodi21', 'font18': 'Strem4Kodi21',
    'font12': 'Strem4Kodi23', 'font20': 'Strem4Kodi23',
    'font22': 'Strem4Kodi23', 'font25': 'Strem4Kodi23',
    'font23': 'Strem4Kodi25', 'font27': 'Strem4Kodi27',
    'font13': 'Strem4Kodi28', 'font30': 'Strem4Kodi28',
    'font32': 'Strem4Kodi30', 'font35': 'Strem4Kodi35',
    'font37': 'Strem4Kodi35', 'font45': 'Strem4Kodi43',
    'font18_title': 'Strem4Kodi20Bold', 'font23_title': 'Strem4Kodi25Bold',
    'font27_title': 'Strem4Kodi27Bold', 'font32_title': 'Strem4Kodi30Bold',
    'font52_title': 'Strem4Kodi50Bold',
}
FONT_SIZES = {21, 23, 25, 27, 28, 30, 35, 37, 43}
BOLD_SIZES = {20, 25, 27, 30, 50}

PRIMARY = 'FFE5E5E7'
SECONDARY = 'FFADACB5'
MUTED = 'FF777582'
NEUTRAL_TEXT = {
    'FFD2D0D8': PRIMARY, 'FFD2D8E2': PRIMARY, 'FFD8D4E2': PRIMARY,
    'FFE6E3E9': PRIMARY, 'FFE8E8E8': PRIMARY, 'FFCDD0D5': PRIMARY,
    'FFCBC5D8': SECONDARY, 'FFBFC4CE': SECONDARY, 'FFADB4C0': SECONDARY,
    'FFB8BDC6': SECONDARY, 'FFBBBBBB': SECONDARY, 'FFAAAAAA': SECONDARY,
    'FFB7B7BD': SECONDARY, 'FFBCCAD8': SECONDARY, 'FFC6C9CF': SECONDARY,
    'FF929AA6': SECONDARY, 'FF9A98A6': MUTED,
    'FFAFA6BD': SECONDARY,
    'white': 'FFFFFFFF', 'grey': SECONDARY, 'unfocused_text': SECONDARY,
}


def apply(tree, dark_text):
    for node in tree.iter():
        if node.tag == 'font':
            node.text = FONT_ALIASES.get((node.text or '').lower(), node.text)
        elif node.tag in ('textcolor', 'selectedcolor', 'disabledcolor'):
            node.text = NEUTRAL_TEXT.get(node.text, node.text)
    # Theme focus fills are pale; outlined controls and white playheads keep
    # their existing text. Native Kodi controls are not passed through here.
    for control in tree.iter('control'):
        focus = control.find('texturefocus')
        text = control.find('focusedcolor')
        if focus is not None and text is not None and (focus.text or '').strip():
            texture = focus.text or ''
            if not any(name in texture for name in ('outline', 'border', 'focus.png')):
                text.text = dark_text
