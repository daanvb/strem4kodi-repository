"""Long-OK credits shortcut limited to owned episode playback."""
def run(fallback='PlayPause', kodi=None, gui=None):
    if kodi is None:
        import xbmc as kodi
    if gui is None:
        import xbmcgui as gui
    top = gui.getCurrentWindowDialogId()
    if top not in (-1, 0, 10115, 12901):
        return
    player = kodi.Player()
    home = gui.Window(10000)
    owned = (kodi.getSkinDir() == 'skin.strem4kodi'
             and home.getProperty('strem4kodi.player.active') == 'true'
             and player.isPlayingVideo()
             and not kodi.getCondVisibility('VideoPlayer.Content(livetv)'))
    if owned:
        import hashlib
        from pathlib import Path
        import xbmcvfs
        from account import Store
        from addon_state import get_addon
        try:
            context = Store(Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile'))) / 'playback').load()
            owned = context.get('kind') == 'series' and context.get('url_hash') == hashlib.sha256(player.getPlayingFile().encode()).hexdigest()
        except (OSError, RuntimeError, ValueError):
            # Playback can end while the shortcut is being dispatched.
            return
    if not owned:
        if fallback in ('PlayPause','ContextMenu','OSD','Select'):
            kodi.executebuiltin('Action(' + fallback + ')')
        return
    if home.getProperty('strem4kodi.player.credits-menu'):
        return
    home.setProperty('strem4kodi.player.credits-menu', 'true')
    try:
        from lib.player_controls import run as controls
        controls('credits-quick')
    finally:
        home.clearProperty('strem4kodi.player.credits-menu')
