"""Bounded local request summaries. Never persist URLs, queries or exception messages."""
import math
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit
from account import Store, AccountError, AccountConflict
from provider_roles import key, name

_lock = threading.RLock()
_profile = None
_providers = []
_rows = {}
_saved = 0
_FAILURE_REASONS = frozenset((
    'Request timed out', 'Server address could not be resolved',
    'Server certificate could not be verified', 'Secure connection failed',
    'Connection to server failed', 'Addon returned invalid JSON',
    'Addon response is too large', 'Addon returned an invalid response',
    'Addon returned an error', 'Request failed',
))


def _merge(*histories):
    """Keep the newest summary per operation, including other Kodi invocations."""
    merged = {}
    for history in histories:
        for row in history if isinstance(history, list) else []:
            if not isinstance(row, dict):
                continue
            identity = (row.get('provider'), row.get('resource'))
            checked = row.get('checked')
            if (not all(isinstance(value, str) for value in identity)
                    or not isinstance(checked, (int, float)) or not math.isfinite(checked)):
                continue
            previous = merged.get(identity, {})
            if checked >= previous.get('checked', 0):
                merged[identity] = dict(row)
    return dict(sorted(merged.items(), key=lambda item: item[1]['checked'], reverse=True)[:48])


def _read(root):
    try:
        return Store(root).load().get('requests') or []
    except AccountError:
        return []


def _save(root, current):
    store = Store(root)
    for _ in range(3):
        try:
            snapshot = store.load()
        except AccountError:
            snapshot = {}
        snapshot['requests'] = list(_merge(snapshot.get('requests'), current).values())
        try:
            store.save(snapshot)
            return
        except AccountConflict:
            continue  # Re-read and merge a concurrent resolver's request summary.


def configure(profile, providers):
    global _profile, _providers, _rows, _saved
    with _lock:
        root = Path(profile) / 'diagnostics'
        if root != _profile:
            _profile, _rows, _saved = root, _merge(_read(root)), 0
        _providers = [(p.get('transportUrl', '')[:-len('/manifest.json')], key(p), name(p))
                      for p in providers if str(p.get('transportUrl', '')).endswith('/manifest.json')]


def classify(url):
    for base, identity, label in sorted(_providers, key=lambda r: len(r[0]), reverse=True):
        if not url.startswith(base + '/'):
            continue
        tail = url[len(base) + 1:]
        resource = tail.split('/', 1)[0]
        if resource == 'manifest.json':
            resource = 'manifest'
        if resource in ('catalog', 'meta', 'stream', 'subtitles', 'manifest'):
            return identity + ':' + resource, label, resource
    parsed = urlsplit(url)
    if parsed.hostname == 'v3-cinemeta.strem.io':
        resource = parsed.path.lstrip('/').split('/', 1)[0]
        if resource in ('catalog', 'meta', 'manifest.json'):
            return 'cinemeta:' + resource, 'Cinemeta', resource.replace('.json', '')
    return None


def record(url, started, status, http=None, reason=None, timeout=None):
    global _saved
    with _lock:
        if _profile is None:
            return
        source = classify(url)
        if source is None or status not in ('refreshed', 'cached', 'failed'):
            return
        _, label, resource = source
        identity = (label, resource)
        now = time.time()
        previous = _rows.get(identity, {})
        row = {'provider': label, 'resource': resource, 'status': status, 'checked': now,
               'ms': max(0, min(1800000, int((time.monotonic() - started) * 1000)))}
        if status == 'refreshed':
            row['refreshed'] = now
        elif previous.get('refreshed'):
            row['refreshed'] = previous['refreshed']
        if status == 'failed':
            if isinstance(timeout, (int, float)) and not isinstance(timeout, bool) and math.isfinite(timeout) and 0 < timeout <= 1800:
                row['timeout'] = timeout
            row['reason'] = ('HTTP {}'.format(http) if isinstance(http, int) and 100 <= http <= 599
                             else reason if reason in _FAILURE_REASONS else 'Request failed')
        _rows[identity] = row
        if len(_rows) > 48:
            del _rows[min(_rows, key=lambda k: _rows[k]['checked'])]
        # Do not fsync for every cache read or fan out extra work during startup.
        if status == 'failed' or now - _saved >= 15:
            _save(_profile, list(_rows.values()))
            _saved = now


def rows(profile):
    with _lock:
        saved = _read(Path(profile) / 'diagnostics')
        current = list(_rows.values()) if _profile == Path(profile) / 'diagnostics' else []
        return list(_merge(saved, current).values())
