"""Spoiler-safe episode artwork using Kodi's local texture resizing."""
from urllib.parse import parse_qs, quote, unquote, urlsplit


def thumbnail(row, background, watched, mode='0'):
    supplied = row.get('thumbnail') or ''
    artwork = supplied or background or ''
    # Restore our own low-resolution spoiler transform first.
    if watched and artwork.startswith('image://'):
        wrapped = urlsplit(artwork)
        options = parse_qs(wrapped.query)
        if (wrapped.path in ('/', '/transform')
                and options == {'width': ['8'], 'height': ['5'],
                                'scaling_algorithm': ['bilinear']}):
            artwork = unquote(wrapped.netloc)
    if watched and artwork.startswith(('https://', 'http://')):
        # AIOMetadata's explicit blur endpoint carries the unmodified source.
        # It has no account watched-state check, so use that source once watched.
        # Never alter arbitrary provider images or signed artwork proxy routes.
        wrapped = urlsplit(artwork)
        sources = parse_qs(wrapped.query).get('url', [])
        if wrapped.path == '/api/image/blur' and len(sources) == 1:
            try:
                source = urlsplit(sources[0])
                if source.scheme in ('http', 'https') and source.hostname and not source.username and not source.password:
                    artwork = sources[0]
            except ValueError:
                pass
    # Off leaves existing provider blur untouched; it cannot reconstruct artwork.
    blur = not watched and (mode == '1' or (mode == '2' and not supplied))
    if watched and artwork.startswith(('https://', 'http://')):
        # Give the restored image its own full-size cache identity. Older Kodi
        # textures can outlive a card's watched state or a previous blur layout.
        # Options stay in the image wrapper, never in the provider request URL.
        return ('image://' + quote(artwork, safe='')
                + '/transform?width=780&height=439&scaling_algorithm=bicubic')
    if not artwork or not blur:
        return artwork
    if artwork.startswith('image://'):
        artwork = unquote(artwork[len('image://'):].split('/', 1)[0])
    # A tiny locally cached texture is smoothly enlarged by Kodi. No image proxy,
    # Python image library, network analyser or full-resolution copy is required.
    return 'image://' + quote(artwork, safe='') + '/transform?width=8&height=5&scaling_algorithm=bilinear'
