"""SQLite-backed Continue Watching index for fast Kodi Home rendering."""
import json, sqlite3, threading, time
from pathlib import Path

_lock=threading.RLock()
LOGIC_VERSION=4

def _path(profile): return Path(profile)/'continue_index.sqlite'
def _db(profile):
    db=sqlite3.connect(str(_path(profile)),timeout=2)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('''CREATE TABLE IF NOT EXISTS continue_items (
      media_type TEXT NOT NULL, media_id TEXT NOT NULL, status TEXT NOT NULL,
      last_video_id TEXT, next_video_id TEXT, next_release TEXT,
      progress_ms INTEGER NOT NULL DEFAULT 0, last_watched TEXT,
      item_json TEXT NOT NULL, source_mtime TEXT, updated REAL NOT NULL, next_check REAL NOT NULL DEFAULT 0,
      PRIMARY KEY(media_type,media_id))''')
    
    try: db.execute('ALTER TABLE continue_items ADD COLUMN next_check REAL NOT NULL DEFAULT 0')
    except sqlite3.OperationalError: pass
    db.execute('CREATE INDEX IF NOT EXISTS cw_status_recent ON continue_items(status,last_watched DESC)')
    db.execute('CREATE TABLE IF NOT EXISTS continue_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)')
    row=db.execute("SELECT value FROM continue_meta WHERE key='logic_version'").fetchone()
    if not row or str(row[0])!=str(LOGIC_VERSION):
        db.execute('DELETE FROM continue_items')
        db.execute("INSERT OR REPLACE INTO continue_meta(key,value) VALUES('logic_version',?)",(str(LOGIC_VERSION),))
        db.commit()
    return db

def seed(profile, library):
    """Import all plausible CW pointers from Stremio without network metadata."""
    now=time.time(); seen=set()
    with _lock:
      db=_db(profile)
      try:
        for row in library or []:
          if not isinstance(row,dict) or row.get('type') not in ('movie','series'): continue
          state=row.get('state') if isinstance(row.get('state'),dict) else {}
          media_id=str(row.get('_id') or row.get('id') or ''); typ=row.get('type')
          if not media_id: continue
          try: offset=max(0,int(float(state.get('timeOffset') or 0)))
          except (TypeError,ValueError): offset=0
          try: duration=max(0,int(float(state.get('duration') or 0)))
          except (TypeError,ValueError): duration=0
          completed = (duration>0 and offset>=duration*0.90) or (bool(state.get('flaggedWatched')) and (duration<=0 or offset<=1))
          # Movies belong in CW only for genuine incomplete progress. A stale
          # offset on a watched/90%+ movie must never resurrect it.
          movie_pointer=typ=='movie' and offset>0 and not completed
          # Series keep completed episode pointers only as unresolved candidates;
          # metadata must prove an already-aired next episode before Home shows them.
          series_pointer=typ=='series' and (bool(state.get('video_id')) and (offset>0 or completed)
                                           or not row.get('removed') and not row.get('temp'))
          if not (series_pointer or movie_pointer): continue
          status=('waiting' if typ=='series' and (completed or offset<=1 or not state.get('video_id')) else 'partial')
          key=(typ,media_id);seen.add(key)
          item=dict(row,id=media_id);mtime=str(row.get('_mtime') or '');video_id=str(state.get('video_id') or '')
          existing=db.execute('SELECT status,last_video_id,source_mtime,next_video_id,next_release,item_json,progress_ms FROM continue_items WHERE media_type=? AND media_id=?',key).fetchone()
          if existing and existing[1]==video_id and existing[2]==mtime and (existing[0] in ('next_ready','finished','waiting') or existing[0]=='partial' and existing[6]==offset):
            # No Stremio state change: preserve the resolved episode/status.
            db.execute('UPDATE continue_items SET last_watched=?,updated=? WHERE media_type=? AND media_id=?',(str(state.get('lastWatched') or mtime),now,typ,media_id))
          else:
            db.execute('''INSERT INTO continue_items(media_type,media_id,status,last_video_id,next_video_id,next_release,progress_ms,last_watched,item_json,source_mtime,updated)
              VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(media_type,media_id) DO UPDATE SET
              status=excluded.status,last_video_id=excluded.last_video_id,next_video_id=NULL,next_release=NULL,progress_ms=excluded.progress_ms,
              last_watched=excluded.last_watched,item_json=excluded.item_json,source_mtime=excluded.source_mtime,updated=excluded.updated,next_check=0''',
              (typ,media_id,status,video_id,None,None,offset,str(state.get('lastWatched') or mtime),json.dumps(item,separators=(',',':')),mtime,now))
        # Entries no longer represented by Stremio CW state are removed. Resolved waiting/finished
        # rows remain represented because completed series pointers are seeded above.
        rows=db.execute('SELECT media_type,media_id FROM continue_items').fetchall()
        for key in rows:
          if tuple(key) not in seen: db.execute('DELETE FROM continue_items WHERE media_type=? AND media_id=?',key)
        db.commit()
      finally: db.close()

def resolve_series(profile, media_id, item, target, resume_ms=0, confirmed_finished=False):
    status='next_ready' if target else ('finished' if confirmed_finished else 'waiting')
    next_id=str((target or {}).get('id') or '')
    release=str((target or {}).get('released') or (target or {}).get('firstAired') or '')
    display=dict(item)
    display['state']=dict(display.get('state') or {})
    if target:
      display['state']['video_id']=next_id;display['state']['timeOffset']=int(resume_ms) if resume_ms else 1
    with _lock:
      db=_db(profile)
      try:
       db.execute('UPDATE continue_items SET status=?,next_video_id=?,next_release=?,progress_ms=?,item_json=?,updated=?,next_check=? WHERE media_type=? AND media_id=?',
                  (status,next_id,release,int(resume_ms or 0),json.dumps(display,separators=(',',':')),time.time(),time.time()+(86400 if status in ('finished','waiting') else 0),'series',media_id));db.commit()
      finally: db.close()

def rows(profile, limit=100):
    with _lock:
      db=_db(profile)
      try: data=db.execute("SELECT item_json,status,progress_ms FROM continue_items WHERE status IN ('partial','next_ready') ORDER BY last_watched DESC LIMIT ?",(int(limit),)).fetchall()
      finally: db.close()
    out=[]
    for raw,status,progress in data:
      try:
        row=json.loads(raw)
        if status=='next_ready' and progress<=1:
          target_id=(row.get('state') or {}).get('video_id')
          target=next((v for v in row.get('videos',[]) if v.get('id')==target_id),None)
          if target:row['_next_episode']=dict(target)
        out.append(row)
      except Exception: pass
    return out

def unresolved_series(profile, limit=32):
    with _lock:
      db=_db(profile)
      try:data=db.execute("SELECT media_id,item_json FROM continue_items WHERE media_type='series' AND status IN ('waiting','finished') AND next_check<=? ORDER BY CASE WHEN status='waiting' THEN 0 ELSE 1 END,last_watched DESC LIMIT ?",(time.time(),int(limit))).fetchall()
      finally:db.close()
    out=[]
    for media_id,raw in data:
      try:out.append((media_id,json.loads(raw)))
      except Exception:pass
    return out


def upcoming(profile, limit=100, now=None):
    """Next dated future episode per saved series, read from resolved local metadata."""
    from datetime import datetime, timezone
    from lib.episode_state import watched_ids
    instant = now or datetime.now().astimezone()
    if instant.tzinfo is None:
      instant = instant.replace(tzinfo=timezone.utc)
    with _lock:
      db = _db(profile)
      try: data = db.execute("SELECT item_json FROM continue_items WHERE media_type='series'").fetchall()
      finally: db.close()
    result = []
    for (raw,) in data:
      try:
        row = json.loads(raw)
        videos = row.get('videos') or []
        watched = watched_ids(videos, row)
        candidates = []
        for video in videos:
          if not video.get('id') or video['id'] in watched or int(video.get('season') or 0) <= 0:
            continue
          try:
            date = datetime.fromisoformat(str(video.get('released') or video.get('firstAired') or '').replace('Z', '+00:00'))
            if date.tzinfo is None: date = date.replace(tzinfo=timezone.utc)
          except ValueError: continue
          # Providers often supply midnight as an air date, not an exact start time.
          # Retain today's unwatched release all day; this does not imply a stream exists.
          if date.date() >= instant.date(): candidates.append((date, video))
        if candidates:
          date, episode = min(candidates, key=lambda pair: pair[0])
          card = dict(row, _focus_video_id=episode['id'], _upcoming_episode=True)
          card['name'] = '{} - S{:02d}E{:02d}'.format(row.get('name', ''), int(episode.get('season') or 0), int(episode.get('episode') or episode.get('number') or 0))
          days = (date.date() - instant.date()).days
          card['_release_label'] = ('Airs today' if days == 0 else 'Airs tomorrow' if days == 1 else 'Expected ' + date.strftime('%d %b %Y'))
          card['description'] = episode.get('description') or episode.get('overview') or row.get('description', '')
          result.append((date, card))
      except (ValueError, TypeError): continue
    return [card for _, card in sorted(result, key=lambda pair: pair[0])[:limit]]

def prefetch_rows(profile, limit=6):
    """Recent visible CW items with their exact stream identity."""
    out=[]
    for item in rows(profile,limit):
      typ=item.get('type');media_id=str(item.get('id') or item.get('_id') or '')
      state=item.get('state') if isinstance(item.get('state'),dict) else {}
      identity=str(state.get('video_id') or media_id) if typ=='series' else media_id
      if typ in ('movie','series') and media_id and identity:out.append((typ,identity,item))
    return out


def resolved_series(profile):
    """Return local episode metadata without starting network lookups."""
    with _lock:
        db = _db(profile)
        try:
            data = db.execute("SELECT item_json FROM continue_items WHERE media_type='series'").fetchall()
        finally:
            db.close()
    result = []
    for (raw,) in data:
        try:
            row = json.loads(raw)
            if isinstance(row, dict) and row.get('videos'):
                result.append(row)
        except (ValueError, TypeError):
            continue
    return result
