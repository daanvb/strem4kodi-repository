"""Device-local successful-source fingerprints, never saved playback URLs."""
import hashlib
import json
import time
from pathlib import Path
from account import Store

MAX_AGE = 30 * 24 * 60 * 60
LIMIT = 500


def digest(value):
    return hashlib.sha256(str(value).encode('utf-8')).hexdigest()


def key(kind, identity):
    return digest(json.dumps([kind, identity], separators=(',', ':')))


def fingerprint(row):
    filename = str(row.get('filename') or '').strip().casefold()
    provider = str(row.get('provider') or '').strip().casefold()
    return {'url': digest(row['url']) if row.get('url') else '',
            'release': digest(json.dumps([provider, filename], separators=(',', ':'))) if filename and provider else ''}


def remember(profile, kind, identity, row, now=None):
    if not kind or not identity or not row.get('url'):
        return False
    now = time.time() if now is None else now
    store = Store(Path(profile) / 'successful-sources')
    entries = store.load().get('entries') or {}
    entries = {k: v for k, v in entries.items() if isinstance(v, dict)
               and isinstance(v.get('updated'), (float, int)) and 0 <= now - v['updated'] <= MAX_AGE}
    entries[key(kind, identity)] = dict(fingerprint(row), updated=now)
    entries = dict(sorted(entries.items(), key=lambda pair: pair[1]['updated'], reverse=True)[:LIMIT])
    store.save({'entries': entries})
    return True


def load(profile, kind, identity, now=None):
    try:
        row = (Store(Path(profile) / 'successful-sources').load().get('entries') or {}).get(key(kind, identity))
        now = time.time() if now is None else now
        return row if isinstance(row, dict) and 0 <= now - float(row.get('updated', 0)) <= MAX_AGE else None
    except (OSError, ValueError, TypeError):
        return None


def match(rows, saved):
    if not saved:
        return None
    for field in ('url', 'release'):
        if not saved.get(field):
            continue
        matches = [row for row in rows if fingerprint(row)[field] == saved[field]]
        if len(matches) == 1:
            return matches[0]
    return None
