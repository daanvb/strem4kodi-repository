"""Conservative grouping: exact release filename and technical metadata or URL."""
import re
from core.stream_ui import stream_card
from lib.playback_recovery import digest
from lib.fel_catalog import badge

def group_rows(rows):
    groups={};result=[]
    for row in rows:
        card=stream_card(row);name=card.get('filename','')
        if re.search(r'\.(?:mkv|mp4|m2ts|avi|ts)$',name,re.I):
            key=('file',name.casefold(),card.get('quality'),card.get('size'),card.get('tech'),card.get('languages'),badge(row))
        elif row.get('url'):key=('url',digest(row['url']))
        else:key=('unique',len(result))
        if key not in groups:
            group=dict(row);group['_alternatives']=[];groups[key]=group;result.append(group)
        groups[key]['_alternatives'].append(row)
    for group in result:
        group['_session_failed']=all(r.get('_session_failed') for r in group['_alternatives'])
    return result
