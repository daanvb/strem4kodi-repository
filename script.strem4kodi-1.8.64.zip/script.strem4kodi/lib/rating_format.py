"""Consistent display of ten-point ratings, independent of provider."""
import math

def ten_point(value):
    try:
        number=float(value)
        if not math.isfinite(number) or not 0<=number<=10:return ''
        return f'{number:.1f}'
    except (ValueError,TypeError):return ''
