"""Account-scoped Favourite/Watchlist tags; Stremio owns saved membership."""
import hashlib
import json
import math
import re
import sqlite3
import time
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

ROLES = ('watchlist', 'favourite')


def clean(data):
    out = {}
    if not isinstance(data, dict):
        return out
    for identity, roles in data.items():
        if not isinstance(identity, str) or not re.fullmatch(r'(?:(?:movie|series):[A-Za-z0-9_.:-]{1,200}|collection:tmdb.collection:[1-9][0-9]{0,11})', identity) or not isinstance(roles, dict):
            continue
        row = {}
        for role in ROLES:
            value = roles.get(role)
            if not isinstance(value, dict) or not isinstance(value.get('value'), bool):
                continue
            stamp = value.get('updated')
            if isinstance(stamp, bool) or not isinstance(stamp, (int, float)) or not math.isfinite(stamp) or stamp < 0:
                continue
            row[role] = {'value': value['value'], 'updated': stamp}
        if identity.startswith('collection:'):
            value = roles.get('card')
            if isinstance(value, dict):
                stamp = value.get('updated')
                if type(stamp) in (int, float) and math.isfinite(stamp) and 0 <= stamp <= 253402300799:
                    from lib.movie_collections import clean_art
                    row['card'] = {name:str(value.get(name) or '')[:limit] for name,limit in
                                   (('name',200),('description',1600)) if isinstance(value.get(name,''),str)}
                    row['card'].update(poster=clean_art(value.get('poster')), background=clean_art(value.get('background')),updated=stamp)
        if row:
            out[identity] = row
    return out


def merge(left, right):
    out = clean(left)
    for identity, roles in clean(right).items():
        row = out.setdefault(identity, {})
        for role, value in roles.items():
            previous = row.get(role)
            if role == 'card':
                if previous is None or (value['updated'],json.dumps(value,sort_keys=True)) > (previous['updated'],json.dumps(previous,sort_keys=True)):
                    row[role] = value
                continue
            # Equal timestamps resolve to removal on every device.
            if previous is None or (value['updated'], not value['value']) > (previous['updated'], not previous['value']):
                row[role] = value
    return out


class SavedLists:
    def __init__(self, profile, token):
        scope = hashlib.sha256(str(token or '').encode()).hexdigest()
        directory = Path(profile) / 'saved-list-tags' / scope
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / 'tags.sqlite'
        with closing(self.connect()) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS tags (identity TEXT, role TEXT, value INTEGER, updated REAL, PRIMARY KEY(identity, role))')
            db.execute('CREATE TABLE IF NOT EXISTS collection_cards (identity TEXT PRIMARY KEY, card TEXT)')

    def connect(self):
        return sqlite3.connect(str(self.path), timeout=5)

    def key(self, meta):
        return str(meta.get('type')) + ':' + str(meta.get('_id') or meta.get('id'))

    def _snapshot(self, db):
        out = {}
        for identity, role, value, stamp in db.execute('SELECT identity, role, value, updated FROM tags'):
            out.setdefault(identity, {})[role] = {'value': bool(value), 'updated': stamp}
        for identity, raw in db.execute('SELECT identity, card FROM collection_cards'):
            try:out.setdefault(identity,{})['card'] = json.loads(raw)
            except (ValueError,TypeError):pass
        return out

    def snapshot(self):
        with closing(self.connect()) as db:
            return self._snapshot(db)

    def merge(self, remote):
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            out = merge(self._snapshot(db), remote)
            db.executemany('INSERT OR REPLACE INTO tags VALUES (?, ?, ?, ?)',
                           [(identity, role, int(value['value']), value['updated']) for identity, roles in out.items() for role, value in roles.items() if role in ROLES])
            db.executemany('INSERT OR REPLACE INTO collection_cards VALUES (?, ?)',
                           [(identity,json.dumps(roles['card'],sort_keys=True)) for identity,roles in out.items() if 'card' in roles])
            return out

    def _roles(self, meta, saved, snapshot):
        if not saved:
            return {role: False for role in ROLES}
        row = snapshot.get(self.key(meta), {})
        return {role: bool(row.get(role, {}).get('value', role == 'watchlist' and meta.get('type') != 'collection')) for role in ROLES}

    def roles(self, meta, saved):
        return self._roles(meta, saved, self.snapshot())

    def set_role(self, meta, role, enabled, previously_saved):
        if role not in ROLES:
            raise ValueError('Unknown saved list')
        return self.set_roles(meta, {role: bool(enabled)}, previously_saved)

    def set_roles(self, meta, values, previously_saved):
        if not values or any(role not in ROLES for role in values):
            raise ValueError('Unknown saved list')
        identity = self.key(meta)
        if not clean({identity: {role: {'value': bool(value), 'updated': 0} for role, value in values.items()}}):
            raise ValueError('Unsupported saved title identity')
        from lib.movie_collections import collection_id, card
        collection = card(collection_id(meta), meta) if meta.get('type') == 'collection' else None
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            now = time.time()
            latest = db.execute('SELECT MAX(updated) FROM tags WHERE identity=?', (identity,)).fetchone()[0] or 0
            now = max(now, latest + .000001)
            db.executemany('INSERT OR IGNORE INTO tags VALUES (?, ?, ?, ?)',
                           [(identity, name, int(previously_saved and name == 'watchlist' and collection is None), now) for name in ROLES])
            db.executemany('INSERT OR REPLACE INTO tags VALUES (?, ?, ?, ?)', [(identity, role, int(value), now) for role, value in values.items()])
            if collection and any(values.values()):
                record = {key:collection[key] for key in ('name','poster','background','description')}
                record['updated'] = now
                db.execute('INSERT OR REPLACE INTO collection_cards VALUES (?, ?)',(identity,json.dumps(record,sort_keys=True)))

    def entries(self, entries, role):
        if role not in ROLES:
            raise ValueError('Unknown saved list')
        snapshot = self.snapshot()
        result = [row for row in entries if row.get('type') in ('movie','series') and not row.get('removed') and not row.get('temp') and self._roles(row, True, snapshot)[role]]
        from lib.movie_collections import card
        for identity, record in clean(snapshot).items():
            if identity.startswith('collection:') and record.get(role,{}).get('value') and 'card' in record:
                row = card(identity.rsplit(':',1)[1],record['card'])
                row['_ctime'] = datetime.fromtimestamp(record['card']['updated'],timezone.utc).isoformat()
                result.append(row)
        return result
