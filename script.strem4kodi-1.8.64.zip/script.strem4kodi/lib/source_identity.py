"""Reject explicit episode conflicts before ranking automatic candidates."""
import re
import unicodedata

EPISODE = re.compile(r'(?i)\bs(\d{1,3})[ ._-]*e(\d{1,3})(?!\d)|\b(\d{1,3})x(\d{1,3})(?!\d)')


def target(meta, identity):
    if meta.get('type') != 'series' or not identity:
        return None
    video = next((v for v in meta.get('videos') or [] if isinstance(v, dict) and v.get('id') == identity), {})
    try:
        return int(video['season']), int(video.get('episode', video.get('number')))
    except (KeyError, TypeError, ValueError):
        match = re.search(r':(\d+):(\d+)$', str(identity))
        return (int(match[1]), int(match[2])) if match else None


def words(value):
    text = unicodedata.normalize('NFKD', str(value)).encode('ascii', 'ignore').decode().casefold()
    return tuple(w for w in re.findall(r'[a-z0-9]+', text)
                 if w not in ('the', 'a', 'an') and not re.fullmatch(r'(19|20)\d{2}', w))


def status(row, meta, identity):
    expected = target(meta, identity)
    if expected is None:
        return 'unknown'
    verified = False
    for field in ('seriesId', 'imdbId'):
        supplied = str(row.get(field) or '')
        wanted = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
        if supplied.startswith('tt') and wanted.startswith('tt'):
            if supplied.split(':')[0] != wanted:
                return 'conflict'
    if row.get('season') is not None and row.get('episode') is not None:
        try:
            if (int(row['season']), int(row['episode'])) != expected:
                return 'conflict'
            verified = True
        except (TypeError, ValueError):
            pass
    filename = str(row.get('filename') or (row.get('card') or {}).get('filename') or '').replace('\\', '/').rsplit('/', 1)[-1]
    text = filename or str(row.get('title') or row.get('detail') or '')
    marks = list(EPISODE.finditer(text))
    if marks:
        numbers = {(int(m[1] or m[3]), int(m[2] or m[4])) for m in marks}
        # Multi-episode files are left for manual selection: their internal
        # timeline cannot safely be inferred from a release name.
        if numbers != {expected} or re.search(r'(?i)e\d+[ ._-]*e\d+|e\d+-\d+', text):
            return 'conflict'
        verified = True
        if filename and meta.get('name'):
            prefix = filename[:marks[0].start()]
            actual, wanted = words(prefix), words(meta['name'])
            if actual and wanted and actual != wanted:
                return 'conflict'
    return 'match' if verified else 'unknown'


def eligible(rows, meta, identity):
    if target(meta, identity) is None:
        return list(rows)
    classified = [(row, status(row, meta, identity)) for row in rows]
    matches = [row for row, result in classified if result == 'match']
    # Unlabelled streams remain usable after search completion. Explicit
    # mismatches are never rescued by quality, preferences or resume history.
    return matches or [row for row, result in classified if result == 'unknown']
