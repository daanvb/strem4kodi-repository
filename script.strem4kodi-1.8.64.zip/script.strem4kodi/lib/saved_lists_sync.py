"""Private GitHub sync of classifications, separately from Stremio membership."""
import base64
import json
import threading
import time
from pathlib import Path
from account import Store
from lib.credits_sync import request, SyncError, LIMIT
from lib.saved_lists import SavedLists, clean, merge

FILE = '/contents/saved-lists.json'


def decode(response):
    if response is None:
        return {}, None
    try:
        if response.get('encoding') != 'base64' or not isinstance(response.get('sha'), str):
            raise ValueError()
        raw = base64.b64decode(response['content'])
        data = json.loads(raw)
        if len(raw) > LIMIT or data.get('version') not in (1,2) or not isinstance(data.get('titles'), dict):
            raise ValueError()
        return clean(data['titles']), response['sha']
    except Exception:
        raise SyncError('Invalid saved-list file; remote data was kept') from None


def synchronize(memory, token, still_current=lambda: True, transport=request):
    if transport(token).get('private') is not True:
        raise SyncError('Saved-list sync requires a private repository')
    if not still_current():
        return False
    remote, sha = decode(transport(token, FILE))
    if not still_current():
        return False
    local = memory.merge(remote)
    if local == remote:
        return True
    raw = json.dumps({'version': 2 if any(k.startswith('collection:') for k in local) else 1, 'titles': local}, sort_keys=True, separators=(',', ':')).encode()
    if len(raw) > LIMIT // 2:
        raise SyncError('Saved-list data is too large; local tags were kept')
    payload = {'message': 'Merge favourite and watchlist tags', 'content': base64.b64encode(raw).decode()}
    if sha:
        payload['sha'] = sha
    if not still_current():
        return False
    transport(token, FILE, payload)
    verified, _ = decode(transport(token, FILE))
    if merge(verified, local) != verified:
        raise SyncError('Saved-list upload could not be confirmed; retrying')
    if not still_current():
        return False
    memory.merge(verified)
    return True


def summary(profile, addon):
    if addon.getSetting('lists_github_enabled') != 'true':
        return 'Off'
    if not Store(profile).load().get('token'):
        return 'Connect Stremio first'
    if not addon.getSetting('credits_github_token').strip():
        return 'Add a private GitHub sync token'
    return str(Store(Path(profile) / 'saved-lists-sync').load().get('status') or 'Waiting for first sync')


class SavedListsSync:
    def __init__(self, profile, addon):
        self.profile = profile
        self.addon = addon
        self.status = Store(Path(profile) / 'saved-lists-sync')
        self.busy = False
        self.next_check = self.last_push = 0
        self.signature = self.last_config = None

    def config(self):
        return (self.addon.getSetting('lists_github_enabled'), self.addon.getSetting('credits_github_token').strip(), Store(self.profile).load().get('token'))

    def tick(self):
        config = self.config()
        if self.busy or config[0] != 'true' or not all(config[1:]):
            return
        if config != self.last_config:
            self.next_check = 0
            self.last_config = config
        memory = SavedLists(self.profile, config[2])
        signature = json.dumps(memory.snapshot(), sort_keys=True)
        now = time.monotonic()
        if now < self.next_check and (signature == self.signature or now - self.last_push < 60):
            return
        self.busy = True
        self.next_check = now + 60
        self.last_push = now
        try:
            threading.Thread(target=self.run, args=(config, memory), daemon=True).start()
        except RuntimeError:
            self.busy = False

    def run(self, config, memory):
        try:
            before = memory.snapshot()
            if synchronize(memory, config[1], lambda: self.config() == config):
                after = memory.snapshot()
                self.signature = json.dumps(after, sort_keys=True)
                self.status.save({'status': 'Synced with private GitHub', 'last_sync': time.time()})
                if after != before:
                    import xbmcgui
                    xbmcgui.Window(10000).setProperty('strem4kodi.saved_lists.revision', str(time.time_ns()))
        except SyncError as error:
            self.status.save({'status': str(error)})
        except Exception:
            try:
                self.status.save({'status': 'Sync will retry; local tags were kept'})
            except Exception:
                pass
        finally:
            self.busy = False
