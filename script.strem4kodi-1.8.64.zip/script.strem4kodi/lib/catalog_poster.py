"""Resolve preferred posters independently of catalogue membership."""
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor

from addons_core import active_addons
from protocol import fetch, resource_url
from sources import supports
from provider_roles import artwork_providers, name, selected
from lib.catalogue_identity import identity, aliases, share_missing, ARTWORK_FIELDS


def fallback(row):
    """An independent image when the configured poster server fails."""
    original = row.get('_original_poster')
    if isinstance(original, str) and original.startswith(('https://', 'http://')) and original != row.get('poster'):
        return original
    title = identity(row)
    if title and re.fullmatch(r'tt\d+', title[1]):
        return 'https://images.metahub.space/poster/medium/' + title[1] + '/img'
    return 'special://home/addons/script.strem4kodi/resources/skins/Main/media/DefaultMovies.png'


def retain_preferred(catalogs, current, signature):
    """Progress/snapshot updates must not replace newer resolved artwork."""
    known = {}
    for row in current:
        title = identity(row)
        if (title and row.get('poster') and row.get('_poster_preferred')
                and row.get('_poster_signature') == signature):
            previous = known.get(title)
            if previous is None or row.get('_poster_resolved_at', 0) > previous.get('_poster_resolved_at', 0):
                known[title] = row
    result = []
    for catalog in catalogs:
        items = []
        for row in catalog.get('items', []):
            preferred = known.get(identity(row))
            incoming_current = row.get('_poster_signature') == signature and row.get('_poster_preferred')
            if preferred and (not incoming_current or row.get('_poster_resolved_at', 0) < preferred.get('_poster_resolved_at', 0)):
                row = dict(row, **{key: preferred[key] for key in ARTWORK_FIELDS if key in preferred})
            items.append(row)
        result.append(dict(catalog, items=items))
    return result


class Posters:
    def __init__(self, state, cache=None, fetcher=None):
        self.providers = artwork_providers(state)
        self.explicit = selected(state, 'artwork') is not None
        self.trust_catalog = not state.get('artworkRevision')
        self.signature = hashlib.sha256(repr(([p.get('transportUrl') for p in self.providers],
                                               state.get('artworkRevision', 0))).encode()).hexdigest()
        self.cache = cache
        # Configured metadata may need to resolve IDs and generate custom art.
        # This runs off the UI thread; use the normal metadata request budget.
        self.fetcher = fetcher or (lambda url: fetch(url, timeout=15, use_cache=False))

    def key(self, title):
        return 'configured-poster-v1:' + self.signature + ':' + title[0] + ':' + title[1]

    def known(self, catalogs, include_catalog=True):
        result = {}
        if not self.providers:
            return result
        names = {name(p) for p in self.providers}
        urls = {p.get('transportUrl') for p in self.providers}
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                owner = catalog.get('addon') or ''
                current = (catalog.get('url') in urls if catalog.get('url') else
                           not self.explicit and len(self.providers) == 1 and owner in names)
                if include_catalog and title and row.get('poster') and current and self.trust_catalog:
                    result.setdefault(title, {'poster': row['poster'], '_poster_provider': owner,
                                              '_poster_preferred': True, '_poster_response': 'Provider catalogue',
                                              '_poster_signature': self.signature, '_poster_resolved_at': 0})
        if self.cache is not None:
            keys = {self.key(identity(row)) for catalog in catalogs for row in catalog.get('items', [])
                    if identity(row)}
            try:
                bulk = self.cache.get_many(keys) if hasattr(self.cache, 'get_many') else None
            except Exception:
                bulk = {}
            checked = set()
            for catalog in catalogs:
                for row in catalog.get('items', []):
                    title = identity(row)
                    if title and title not in checked:
                        checked.add(title)
                        try:
                            cached = bulk.get(self.key(title)) if bulk is not None else self.cache.get(self.key(title))
                            if isinstance(cached, dict) and cached.get('expires', 0) > time.time():
                                artwork = cached.get('artwork') or {}
                                if artwork or not include_catalog:
                                    result[title] = dict(artwork, _poster_response='Cached provider response',
                                                         _poster_signature=self.signature) if artwork else {}
                        except Exception:
                            pass
        return result

    @staticmethod
    def apply(catalogs, known):
        return [dict(catalog, items=[dict(row, **known.get(identity(row), {}))
                                     for row in catalog.get('items', [])]) for catalog in catalogs]

    def cached(self, catalogs):
        return self.apply(catalogs, self.known(catalogs))

    def refresh(self, catalogs, cancelled=lambda: False):
        # Catalogue/snapshot images are immediate placeholders. They must not
        # permanently prevent checking the configured metadata artwork endpoint.
        known = self.known(catalogs, include_catalog=False)
        pending = []
        request_ids = {}
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                if title and title not in known and title not in pending:
                    pending.append(title)
                    # Canonical aliases are cache keys; preserve a provider's
                    # original non-IMDb request syntax (e.g. tmdb:tv:007).
                    original = row.get('id') or row.get('_id')
                    request_ids[title] = title[1] if re.fullmatch(r'tt\d+', title[1]) else str(original or title[1])
        if not self.providers:
            return

        def lookup(title):
            if cancelled():
                return title, {}
            kind, _ = title
            media_id = request_ids[title]
            for provider in self.providers:
                if not supports(provider.get('manifest') or {}, kind, media_id, 'meta'):
                    continue
                try:
                    payload = self.fetcher(resource_url(provider['transportUrl'], 'meta', kind, media_id))
                    meta = payload.get('meta') if isinstance(payload, dict) else None
                    poster = meta.get('poster') if isinstance(meta, dict) else None
                    if (isinstance(meta, dict) and meta.get('type', kind) == kind
                            and title in aliases(dict(meta, type=kind)) and isinstance(poster, str)
                            and poster.startswith(('https://', 'http://'))):
                        return title, {'poster': poster, '_poster_provider': name(provider), '_poster_preferred': True,
                                       '_poster_response': 'Fresh provider response', '_poster_signature': self.signature,
                                       '_poster_resolved_at': time.time()}
                except Exception:
                    # URLs may contain private configuration: never log them.
                    continue
            return title, {}

        for offset in range(0, len(pending), 8):
            if cancelled():
                return
            with ThreadPoolExecutor(max_workers=4) as pool:
                results = list(pool.map(lookup, pending[offset:offset + 8]))
            if cancelled():
                return
            changed = False
            for title, artwork in results:
                if self.cache is not None:
                    ttl = 900 if artwork else 60
                    try:
                        self.cache.put(self.key(title), {'artwork': artwork, 'expires': time.time() + ttl}, ttl)
                    except Exception:
                        pass
                if artwork:
                    known[title] = artwork
                    changed = True
            if changed:
                yield self.apply(catalogs, known)


def configured(state):
    from lib.cache_policy import open_cache, read_policy
    try:
        from addon_state import get_addon
        import xbmcvfs
        from lib.provider_config import state as provider_state
        state = provider_state(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')), state)
    except (ImportError, AttributeError):
        pass
    posters = Posters(state)
    if posters.providers:
        posters.cache = open_cache('metadata', read_policy())
    return posters
