"""Short-lived, playback-bound credits completion signal for the observer."""
import hashlib
import json
import time
from account import Store

PROPERTY = 'strem4kodi.player.credits-watched'


def signal(profile, player, expected_hash=None, expected_id=None):
    try:
        import xbmcgui
        file = player.getPlayingFile()
        digest = hashlib.sha256(file.encode()).hexdigest()
        if expected_hash is not None and digest != expected_hash:
            return False
        context = Store(profile / 'playback').load()
        if (not player.isPlayingVideo() or context.get('kind') != 'series'
                or context.get('url_hash') != digest or not context.get('id')
                or (expected_id is not None and context.get('id') != expected_id)):
            return False
        xbmcgui.Window(10000).setProperty(PROPERTY, json.dumps(
            {'digest': digest, 'id': context['id'], 'created': time.time()}))
        return True
    except Exception:
        return False


def consume(context, file):
    if not context or context.get('kind') != 'series' or not file:
        return False
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        event = json.loads(home.getProperty(PROPERTY) or '{}')
        age = time.time() - float(event.get('created') or 0)
        if not 0 <= age <= 10:
            home.clearProperty(PROPERTY)
            return False
        if (event.get('id') != context.get('video_id')
                or event.get('digest') != hashlib.sha256(file.encode()).hexdigest()):
            return False
        home.clearProperty(PROPERTY)
        return True
    except Exception:
        return False
