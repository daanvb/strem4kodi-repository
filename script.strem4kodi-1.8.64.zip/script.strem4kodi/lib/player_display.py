"""Publish bounded, local playback labels for the optional companion skin."""
from datetime import datetime
import time

from lib.player_audio import FinishEstimate, audio_description

PREFIX = 'strem4kodi.player.'
KEYS = ('active', 'audio', 'ends', 'chapter')


class PlayerDisplay:
    def __init__(self, player, kodi=None, window=None, rpc=None, clock=time.time):
        if kodi is None:
            import xbmc as kodi
        if window is None:
            import xbmcgui
            window = xbmcgui.Window(10000)
        if rpc is None:
            from setup_profile import rpc
        self.player = player
        self.kodi = kodi
        self.window = window
        self.rpc = rpc
        self.clock = clock
        self.file = None
        self.estimate = FinishEstimate()

    def close(self):
        for key in KEYS:
            self.window.clearProperty(PREFIX + key)
        self.file = None
        self.estimate = FinishEstimate()

    def tick(self):
        try:
            file = getattr(self.player, '_playing_file', None)
            if not file or not self.player.isPlayingVideo() or self.player.getPlayingFile() != file:
                self.close()
                return
            if self.file != file:
                self.close()
                self.file = file
            self.window.setProperty(PREFIX + 'active', 'true')
            from lib.chapter_labels import label
            try:
                number = int(self.kodi.getInfoLabel('Player.Chapter') or 0)
                count = int(self.kodi.getInfoLabel('Player.ChapterCount') or 0)
            except (TypeError, ValueError):
                number = count = 0
            self.window.setProperty(PREFIX + 'chapter',
                label(self.kodi.getInfoLabel('Player.ChapterName'), number, count) if number > 0 else '')
            speed = 2 if self.kodi.getCondVisibility('Player.Forwarding | Player.Rewinding') else 1
            end = self.estimate.update(self.clock(), self.player.getTotalTime(), self.player.getTime(), speed)
            if end is None:
                self.window.clearProperty(PREFIX + 'ends')
            else:
                self.window.setProperty(PREFIX + 'ends', 'Ends at ' + datetime.fromtimestamp(end).strftime('%H:%M'))
            # The service samples only while our player bar is visible. Kodi's
            # native labels continue to work when the service is not running.
            if not self.kodi.getCondVisibility('Window.IsVisible(videoosd)'):
                return
            players = self.rpc('Player.GetActivePlayers') or []
            video = next((p for p in players if p.get('type') == 'video'), None)
            if not video:
                self.close()
                return
            properties = self.rpc('Player.GetProperties', {
                'playerid': video['playerid'], 'properties': ['currentaudiostream', 'speed']})
            # Validate again after the request: a next episode may have started.
            if self.player.getPlayingFile() != file:
                self.close()
                return
            self.window.setProperty(PREFIX + 'audio', audio_description(
                properties.get('currentaudiostream'),
                lambda code: self.kodi.convertLanguage(code, self.kodi.ENGLISH_NAME),
                self.kodi.getInfoLabel('VideoPlayer.AudioCodec')))
        except Exception:
            # Never leave audio or finish-time data from a previous track.
            self.window.clearProperty(PREFIX + 'audio')
            self.window.clearProperty(PREFIX + 'ends')
