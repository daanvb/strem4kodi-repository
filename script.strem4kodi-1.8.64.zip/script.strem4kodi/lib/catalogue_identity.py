"""Share catalogue details using explicit IDs, never similar title names."""
import re


def aliases(row):
    kind = row.get('type')
    if kind not in ('movie', 'series'):
        return set()
    result = set()

    def add(value, namespace=''):
        value = str(value or '').strip()
        imdb = re.fullmatch(r'(?:imdb:)?(tt\d+)(?::\d+:\d+)?', value, re.I)
        if imdb:
            result.add((kind, imdb[1].lower()))
            return
        external = re.fullmatch(r'(tmdb|tvdb|thetvdb|imdb):(?:(movie|series|tv):)?(\d+)', value, re.I)
        if external:
            declared = external[2]
            if declared and ('series' if declared.lower() == 'tv' else declared.lower()) != kind:
                return
            namespace, value = external[1].lower(), external[3]
        if namespace in ('tmdb', 'tvdb', 'thetvdb') and value.isdigit() and int(value) > 0:
            result.add((kind, ('tvdb' if namespace == 'thetvdb' else namespace) + ':' + str(int(value))))
        elif not namespace and value:
            result.add((kind, value))

    for field in ('imdb_id', 'imdbId', '_imdbId'):
        add(row.get(field), 'imdb')
    for field in ('id', '_id'):
        add(row.get(field))
    for namespace, fields in (
        ('tmdb', ('moviedb_id', 'tmdb_id', 'tmdbId', '_tmdbId')),
        ('tvdb', ('tvdb_id', 'tvdbId', '_tvdbId')),
    ):
        for field in fields:
            add(row.get(field), namespace)
    for field in ('ids', 'external_ids', 'externalIds'):
        nested = row.get(field)
        if isinstance(nested, dict):
            for namespace, names in (('imdb', ('imdb', 'imdb_id', 'imdbId')),
                                     ('tmdb', ('tmdb', 'tmdb_id', 'moviedb_id')),
                                     ('tvdb', ('tvdb', 'tvdb_id'))):
                for name in names:
                    add(nested.get(name), namespace)
    return result


def identity(row):
    values = aliases(row)
    if not values:
        return None
    # Every feature uses the same preference, independent of provider field order.
    return min(values, key=lambda key: (0 if re.fullmatch(r'tt\d+', key[1]) else
                                       1 if key[1].startswith('tmdb:') else
                                       2 if key[1].startswith('tvdb:') else 3, key[1]))


ARTWORK_FIELDS = ('poster', '_poster_provider', '_poster_preferred', '_poster_response',
                  '_poster_signature', '_poster_resolved_at', '_original_poster')
DETAIL_FIELDS = ('name', 'title', 'description', 'background', 'landscape', 'logo',
                 'year', 'releaseInfo', 'released', 'runtime', 'genres', 'imdbRating',
                 'ratings', 'certification', 'mpaa', 'certificate_gb', 'certificate_country',
                 'imdb_id', 'moviedb_id', 'tvdb_id')


def _groups(rows):
    parents = list(range(len(rows)))
    imdbs = [{key for key in aliases(row) if re.fullmatch(r'tt\d+', key[1])} for row in rows]
    known = {}

    def root(index):
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    for index, row in enumerate(rows):
        for key in sorted(aliases(row)):
            current = root(index)
            if key in known:
                previous = root(known[key])
                # Bad provider aliases must never join two different IMDb titles.
                if current != previous and len(imdbs[current] | imdbs[previous]) <= 1:
                    parents[current] = previous
                    imdbs[previous].update(imdbs[current])
            else:
                known[key] = index
    return [root(index) for index in range(len(rows))]


def _details(rows):
    result = {}
    for row in rows:
        for field in DETAIL_FIELDS:
            if not result.get(field) and row.get(field):
                result[field] = row[field]
        if row.get('poster') and (not result.get('poster') or
                                 row.get('_poster_preferred') and not result.get('_poster_preferred')):
            for field in ARTWORK_FIELDS:
                result.pop(field, None)
                if field in row:
                    result[field] = row[field]
        canonical = identity(row)
        if canonical and re.fullmatch(r'tt\d+', canonical[1]):
            result.setdefault('imdb_id', canonical[1])
    return result


def _fill(row, details):
    result = dict(row)
    for field in DETAIL_FIELDS:
        if field == 'imdb_id' and identity(row) == (row.get('type'), details.get(field)):
            continue
        if not result.get(field) and details.get(field):
            result[field] = details[field]
    if not result.get('poster') and details.get('poster'):
        for field in ARTWORK_FIELDS:
            if field in details:
                result[field] = details[field]
    return result


def combine(rows):
    """Keep supplier ranking and playback state; enrich the first duplicate."""
    rows = list(rows)
    keys = _groups(rows)
    grouped = {}
    for key, row in zip(keys, rows):
        grouped.setdefault(key, []).append(row)
    return [_fill(values[0], _details(values)) for values in grouped.values()]


def share_missing(catalogs):
    """Fill blank details across lists without removing their shared titles."""
    rows = [row for catalog in catalogs for row in catalog.get('items', [])]
    keys = _groups(rows)
    grouped = {}
    for key, row in zip(keys, rows):
        grouped.setdefault(key, []).append(row)
    details = {key: _details(values) for key, values in grouped.items()}
    filled = iter(_fill(row, details[key]) for key, row in zip(keys, rows))
    return [dict(catalog, items=[next(filled) for _ in catalog.get('items', [])]) for catalog in catalogs]
