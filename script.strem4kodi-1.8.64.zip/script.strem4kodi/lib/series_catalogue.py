"""Small shipped series seed. Runtime reads are local and have no API quota."""
import json
import re
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def records():
    from lib.available_formats import merge_formats
    from lib.format_database import TAGS
    try:
        payload = json.loads((Path(__file__).resolve().parents[1] / 'resources' / 'series-formats.json').read_text(encoding='utf-8'))
        if payload.get('version') != 1 or not isinstance(payload.get('series'), dict):
            return {}
        result = {}
        for identity, row in payload['series'].items():
            values = row.get('formats') if isinstance(row, dict) else None
            if re.fullmatch(r'tt\d+', identity) and isinstance(values, list) and all(v in TAGS for v in values):
                result[identity] = merge_formats(values)
        return result
    except (OSError, ValueError, TypeError):
        return {}


def formats(identity):
    return list(records().get(identity, []))
