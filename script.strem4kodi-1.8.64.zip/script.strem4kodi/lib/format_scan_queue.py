"""Bounded local discovery queue; contains identities, never stream URLs."""
import json
import sqlite3
import time
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

LIMIT = 600
RETENTION = 30 * 86400
PRIORITY_LIMITS = {0: 200, 1: 150, 2: 200, 3: 50}


def unreleased(row, now=None):
    now = time.time() if now is None else now
    value = row.get('released') or row.get('firstAired')
    try:
        if value:
            date = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            if date.tzinfo is None:
                date = date.replace(tzinfo=timezone.utc)
            return date.timestamp() > now
        year = str(row.get('year') or row.get('releaseInfo') or '')[:4]
        return year.isdigit() and int(year) > datetime.fromtimestamp(now, timezone.utc).year
    except (TypeError, ValueError, OverflowError):
        return False


class Queue:
    def __init__(self, profile):
        directory = Path(profile) / 'cache'
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / 'format-discovery.sqlite'
        with closing(self.connect()) as db, db:
            db.execute('CREATE TABLE IF NOT EXISTS candidates (identity TEXT PRIMARY KEY, priority INTEGER, updated REAL, payload TEXT)')

    def connect(self):
        return sqlite3.connect(str(self.path), timeout=2)

    def add(self, rows, priority=3, now=None):
        from lib.catalog_poster import identity
        now = time.time() if now is None else now
        values = []
        for row in rows:
            if (not isinstance(row, dict) or row.get('_catalogue') or row.get('removed') or row.get('temp')
                    or unreleased(row, now)):
                continue
            title = identity(row)
            if not title or len(title[1]) > 200:
                continue
            meta = dict(type=title[0], id=title[1])
            for field in ('released', 'firstAired', 'year', 'releaseInfo'):
                value = row.get(field)
                if isinstance(value, (str, int)):
                    meta[field] = str(value)[:40]
            target = row.get('_focus_video_id')
            if title[0] == 'series' and isinstance(target, str) and target.startswith(title[1] + ':'):
                meta['_focus_video_id'] = target[:240]
            values.append((':'.join(title), priority, now, json.dumps(meta)))
        if not values:
            return
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            db.executemany('INSERT INTO candidates VALUES (?, ?, ?, ?) ON CONFLICT(identity) DO UPDATE SET '
                           'priority=MIN(priority,excluded.priority), updated=excluded.updated, payload=excluded.payload', values)
            db.execute('DELETE FROM candidates WHERE updated < ?', (now - RETENTION,))
            # A large saved library must not evict every chart/recent candidate.
            for level, limit in PRIORITY_LIMITS.items():
                db.execute('DELETE FROM candidates WHERE priority=? AND identity NOT IN '
                           '(SELECT identity FROM candidates WHERE priority=? ORDER BY updated DESC, identity LIMIT ?)',
                           (level, level, limit))
            db.execute('DELETE FROM candidates WHERE identity NOT IN (SELECT identity FROM candidates '
                       'ORDER BY priority, updated DESC, identity LIMIT ?)', (LIMIT,))

    def rows(self, now=None):
        now = time.time() if now is None else now
        with closing(self.connect()) as db:
            return [json.loads(row[0]) for row in db.execute(
                'SELECT payload FROM candidates WHERE updated >= ? ORDER BY priority, updated DESC, identity LIMIT ?',
                (now - RETENTION, LIMIT))]


def remember(profile, addon, rows, priority=3):
    """UI hook: save identities locally without starting any network work."""
    if addon.getSetting('formats_slow_scan') != 'true':
        return
    try:
        Queue(profile).add(rows, priority)
    except (OSError, ValueError, TypeError, sqlite3.Error):
        pass
