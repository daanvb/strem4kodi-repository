"""Map provider metadata to Nimbus FlixInfoIcon labels."""
import re
from datetime import datetime, timedelta


def finish_time(row, now=None, saved=None):
    """Finish the relevant movie/episode from its saved resume position."""
    from continue_playback import next_series_episode, resume_seconds
    kind = row.get('type')
    if kind not in ('movie', 'series'):
        return ''
    state = (saved or row).get('state') or {}
    target = row.get('_focus_video_id') or (row.get('id') if kind == 'movie' else '')
    episode = row.get('_finish_episode') or {}
    if kind == 'series' and not target and row.get('videos'):
        video, _ = next_series_episode(row['videos'], row.get('id'), saved or row)
        episode = video or {}
        target = episode.get('id')
    if kind == 'series' and target and not episode:
        episode = next((v for v in row.get('videos', []) if v.get('id') == target), {})
    if kind == 'series' and not target and resume_seconds(state.get('timeOffset')):
        target = state.get('video_id')
    matching = kind == 'movie' or bool(target and target == state.get('video_id'))
    offset = resume_seconds(state.get('timeOffset')) if matching else 0
    raw_runtime = episode.get('runtime') or row.get('runtime')
    if not episode.get('runtime') and episode.get('duration'):
        value = episode['duration']
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            raw_runtime = str(round(value / 60000 if value > 10000 else value / 60 if value > 300 else value))
        else:
            raw_runtime = value
    runtime = str(raw_runtime or '').strip().lower()
    iso = re.fullmatch(r'pt(?:(\d+)h)?(?:(\d+)m)?', runtime)
    if iso and (iso[1] or iso[2]):
        runtime = str(int(iso[1] or 0)*60 + int(iso[2] or 0))
    plain = re.fullmatch(r'(\d+)\s*(?:m|min|mins|minutes)?', runtime)
    hours = re.fullmatch(r'(\d+)\s*h(?:ours?)?\s*(?:(\d+)\s*m(?:in(?:utes?)?)?)?', runtime)
    minutes = int(plain[1]) if plain else int(hours[1])*60 + int(hours[2] or 0) if hours else 0
    seconds = minutes * 60 if 0 < minutes <= 1440 else 0
    if offset:
        try:
            measured = float(state.get('duration') or 0) / 1000
            if offset < measured <= 86400:
                seconds = measured
        except (TypeError, ValueError):
            pass
    if not seconds:
        return ''
    # Completed/invalid offsets are replay estimates, never a negative runtime.
    remaining = seconds - offset if 0 < offset < seconds else seconds
    return ((now or datetime.now()) + timedelta(seconds=remaining)).strftime('%H:%M')


def upcoming_preview(full, preview):
    """Keep episode presentation separate from cached series metadata."""
    result = dict(full)
    for key in ('_focus_video_id', 'state'):
        if key in preview:
            result[key] = preview[key]
    if preview.get('_upcoming_episode'):
        result.update({key: preview[key] for key in
                       ('name', 'description', '_release_label', '_upcoming_episode') if key in preview})
    return result


def tags(row):
    date = str(row.get('released') or row.get('releaseInfo') or row.get('year') or '')
    match_year = re.match(r'^(\d{4})',date)
    date = match_year.group(0) if match_year else ''
    runtime = str(row.get('runtime') or '')
    match = re.fullmatch(r'(\d+)\s*(?:min|mins|minutes)?', runtime.strip(), re.I)
    if match:
        minutes = int(match[1])
        runtime = ('{}h'.format(minutes // 60) + (' {}m'.format(minutes % 60) if minutes % 60 else '')) if minutes >= 60 else '{}m'.format(minutes)
    value = str(row.get('certificate_gb') or '')
    if not value and row.get('certificate_country') == 'GB':
        value = str(row.get('certification') or row.get('mpaa') or '')
    value = value.upper().strip()
    if value not in ('U', 'PG', '12', '12A', '15', '18', 'R18'):value = ''
    return {'premiered': date, 'certificate': 'UK ' + value if value else '',
            'genre_tag':' · '.join((row.get('genres') or [])[:2]), 'runtime_tag':runtime}
