"""Reviewed home-release formats, read locally without provider requests."""
import json
import re
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def records():
    from lib.available_formats import merge_formats
    from lib.format_database import TAGS
    try:
        payload = json.loads((Path(__file__).resolve().parents[1] / 'resources' / 'movie-formats.json').read_text(encoding='utf-8'))
        if payload.get('version') != 1 or not isinstance(payload.get('movie'), dict):
            return {}
        return {identity: merge_formats(row['formats']) for identity, row in payload['movie'].items()
                if re.fullmatch(r'tt\d+', identity) and isinstance(row, dict)
                and isinstance(row.get('formats'), list) and all(v in TAGS for v in row['formats'])}
    except (OSError, ValueError, TypeError):
        return {}


def formats(identity):
    return list(records().get(identity, []))
