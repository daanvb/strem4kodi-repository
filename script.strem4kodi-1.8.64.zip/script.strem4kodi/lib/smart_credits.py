"""Cached credits estimates learned only from observed IntroDB markers."""
import math
import statistics
import threading
import time
from pathlib import Path
from account import Store

_LOCK = threading.RLock()
CHOICES = (None, 30, 60, 120, 180, 300)
LABELS = ('Automatic', '30 seconds', '1 minute', '2 minutes', '3 minutes', '5 minutes')


def series_key(identity):
    value = str(identity or '').split(':')[0]
    return value if value.startswith('tt') and value[2:].isdigit() else ''


def marker_start(credits, duration):
    try:
        start, end = float(credits['start']), float(credits['end'])
        if all(math.isfinite(x) for x in (duration, start, end)) and duration > 120 and duration / 2 <= start < end <= duration + 10:
            return start
    except (TypeError, ValueError, KeyError):pass
    return None


class CreditsMemory:
    def __init__(self, profile):self.store = Store(Path(profile) / 'smart-credits')

    def _load(self):
        try:
            from lib.credits_sync import clean
            return clean(self.store.load())
        except Exception:return {}

    def override(self, identity):
        value = self._load().get(series_key(identity), {}).get('override')
        return value if value in CHOICES[1:] else None

    def set_override(self, identity, value):
        key = series_key(identity)
        if not key or value not in CHOICES:return
        with _LOCK:
            data = self._load()
            row=data.setdefault(key,{})
            row['override']=value
            row['updated']=time.time()
            self.store.save(data)

    def mark_start(self, identity, duration, position):
        """An explicit per-episode marker, also usable as a learned sample."""
        key = series_key(identity)
        if not key or len(str(identity).split(':')) < 3:
            return False
        if not all(isinstance(v, (int, float)) and math.isfinite(v) for v in (duration, position)):
            return False
        lead = duration - position
        if duration <= 120 or position < duration / 2 or not 20 <= lead <= min(600, duration * .35):
            return False
        with _LOCK:
            data = self._load()
            row = data.setdefault(key, {})
            samples = row.setdefault('samples', {})
            ignored = samples.get(identity, {}).get('deleted') is True or samples.get(identity, {}).get('ignore_introdb') is True
            samples[identity] = {'duration': round(duration), 'lead': round(lead),
                                 'manual': True, 'updated': time.time()}
            if ignored:
                samples[identity]['ignore_introdb'] = True
            from lib.credits_sync import trim_samples
            row['samples'] = trim_samples(samples)
            self.store.save(data)
        return True

    def observe(self, identity, duration, credits, position):
        key = series_key(identity)
        start = marker_start(credits, duration)
        try:confidence = float(credits.get('confidence') or 0)
        except (TypeError, ValueError, AttributeError):return False
        # Do not learn from abandoned playback, weak markers, or extreme tails.
        if not key or start is None or position < start or not math.isfinite(confidence) or confidence < .8:return False
        lead = duration - start
        if not 20 <= lead <= min(600, duration * .35):return False
        with _LOCK:
            data = self._load()
            row = data.setdefault(key, {})
            samples = row.setdefault('samples', {})
            if samples.get(identity, {}).get('manual') is True or samples.get(identity, {}).get('deleted') is True:
                return False
            sample = {'duration':round(duration), 'lead':round(lead)}
            if all(samples.get(identity,{}).get(k)==v for k,v in sample.items()):return False
            sample['updated']=time.time()
            samples.pop(identity, None)
            samples[identity] = sample
            from lib.credits_sync import trim_samples
            row['samples'] = trim_samples(samples)
            # Bound local storage while retaining explicit overrides.
            while len(data) > 200:
                removable = next((k for k, v in data.items() if not v.get('override') and k != key), None)
                if removable is None:break
                del data[removable]
            self.store.save(data)
        return True

    def remove(self, identity, whole_series=False):
        key = series_key(identity)
        if not key:
            return False
        with _LOCK:
            data = self._load()
            row = data.setdefault(key, {'override':None, 'updated':0, 'samples':{}})
            samples = row.setdefault('samples', {})
            targets = list(samples) if whole_series else [identity]
            if not whole_series and len(str(identity).split(':')) < 3:
                return False
            now = time.time()
            for episode in targets:
                samples[episode] = {'deleted':True, 'updated':now}
            self.store.save(data)
        return True

    def merge(self, incoming):
        """Merge per-field timestamps, including Automatic override tombstones."""
        from lib.credits_sync import merge
        with _LOCK:
            data=merge(self._load(),incoming)
            self.store.save(data)
            return data

    def snapshot(self):
        with _LOCK:return self._load()

    def estimate(self, identity, duration):
        samples = self._load().get(series_key(identity), {}).get('samples', {})
        season = ':'.join(str(identity).split(':')[:2]) + ':'
        candidates = [(k, v) for k, v in samples.items()
                      if k != identity and isinstance(v, dict) and .75 * duration <= v.get('duration', 0) <= 1.25 * duration
                      and 20 <= v.get('lead', 0) <= min(600, duration * .35)]
        same_season = [v['lead'] for k, v in candidates if k.startswith(season)]
        leads = same_season if len(same_season) >= 3 else [v['lead'] for k, v in candidates]
        if len(leads) < 3:return None
        middle = statistics.median(leads)
        # Require three agreeing episodes and a clear majority. A split between
        # different credit lengths must not masquerade as a reliable average.
        consistent = [v for v in leads if abs(v-middle) <= max(20, middle * .25)]
        if len(consistent) < 3 or len(consistent) / len(leads) < .75:
            return None
        return round(statistics.median(consistent))

    def timing(self, identity, duration, credits, fallback, smart=True):
        manual = self._load().get(series_key(identity), {}).get('samples', {}).get(identity, {})
        ignored = manual.get('deleted') is True or manual.get('ignore_introdb') is True
        start = None if ignored else marker_start(credits, duration)
        if start is not None:return start, 'IntroDB credits'
        if manual.get('manual') is True and abs(manual.get('duration', 0) - duration) <= 5:
            return max(duration / 2, duration - manual['lead']), 'Your credits marker'
        lead = self.override(identity)
        source = 'Series timing'
        if lead is None and smart:
            lead = self.estimate(identity, duration)
            source = 'Estimated credits'
        if lead is None:lead, source = fallback, 'Fallback timing'
        return max(duration / 2, duration - lead), source


def choose_timing(profile, identity, title):
    from lib.ui_dialogs import dialog
    memory = CreditsMemory(profile)
    value = memory.override(identity)
    selected = dialog().select('Up Next timing · ' + str(title or 'This series'), list(LABELS), preselect=CHOICES.index(value))
    if selected >= 0:memory.set_override(identity, CHOICES[selected])


def manage(profile, identity, title='This series', picker=None):
    from lib.ui_dialogs import dialog
    from lib.player_chapter_timeline import timestamp
    picker = picker or dialog()
    memory = CreditsMemory(profile)
    choice = picker.select('Smart credits · ' + str(title or 'This series'),
                           ['Ignore credits timing for this episode', 'Review and remove series samples',
                            'Clear all samples for this series'], preselect=-1)
    if choice == 0:
        memory.remove(identity)
        picker.notification('Smart credits', 'Episode timing ignored. Mark Credits start again to replace it.')
    elif choice == 1:
        samples = memory.snapshot().get(series_key(identity), {}).get('samples', {})
        entries = sorted((k,v) for k,v in samples.items() if not v.get('deleted'))
        if not entries:
            picker.ok('Smart credits', 'No saved samples for this series.')
            return
        labels = []
        for episode, sample in entries:
            parts = episode.split(':')
            label = 'S' + parts[1] + ' E' + parts[2] if len(parts) >= 3 else episode
            labels.append(label + ' | Credits ' + timestamp(sample['lead']) + ' before end | ' +
                          ('Your marker' if sample.get('manual') else 'IntroDB sample'))
        selected = picker.select('Select a sample to remove', labels, preselect=-1)
        if 0 <= selected < len(entries):
            memory.remove(entries[selected][0])
            picker.notification('Smart credits', 'Sample removed and excluded from estimates.')
    elif choice == 2 and picker.yesno('Smart credits', 'Clear learned samples and manual episode markers for this series? Your series timing override will remain.'):
        memory.remove(identity, whole_series=True)
        picker.notification('Smart credits', 'Series samples cleared.')
