"""Device-local preferences, saved separately from concurrent account sync."""
from pathlib import Path
from account import Store, AccountError


def _load(profile):
    try:
        return Store(Path(profile) / 'providers').load()
    except AccountError:
        return {}  # A damaged preference file must not prevent account playback.


def state(profile, account=None):
    account = Store(profile).load() if account is None else account
    config = _load(profile)
    return dict(account, providerPreferences=config.get('providerPreferences') or {},
                artworkRevision=config.get('artworkRevision', 0))


def choose(profile, role, value):
    from provider_roles import save_preference
    current = state(profile)
    save_preference(current, role, value)
    store = Store(Path(profile) / 'providers')
    config = _load(profile)
    config['providerPreferences'] = current['providerPreferences']
    store.save(config)


def refresh_artwork(profile):
    """Invalidate resolved posters without clearing catalogue/login/progress data."""
    store = Store(Path(profile) / 'providers')
    config = _load(profile)
    config['artworkRevision'] = int(config.get('artworkRevision') or 0) + 1
    store.save(config)
    return config['artworkRevision']
