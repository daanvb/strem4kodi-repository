"""Short-lived resolver handoff, independent of the shared source/account cache.

Atomic owner-only files are IPC, not durable account data: no account mutex or
fsync is needed. Private URLs never appear in filenames, properties or logs.
"""
import json
import os
from pathlib import Path
import re
import tempfile
import time

MAX_AGE = 3600


def _path(profile, key):
    if not isinstance(key, str) or not re.fullmatch(r'[0-9a-f]{32}', key):
        return None
    return Path(profile) / 'playback-requests' / (key + '.json')


def write(profile, key, stream, now=None):
    path = _path(profile, key)
    if path is None:
        raise ValueError('Invalid playback request key')
    data = json.dumps({'created': time.time() if now is None else now,
                       'urls': {key: stream}}).encode('utf-8')
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd, temporary = tempfile.mkstemp(dir=path.parent, prefix='.request-')
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def load(profile, key):
    path = _path(profile, key)
    if path is not None and path.exists():
        # A broken new request must fail, never reuse another cached source.
        data = json.loads(path.read_bytes())
        if not isinstance(data, dict) or not isinstance(data.get('urls'), dict):
            raise ValueError('Invalid playback request')
        return data
    from account import Store
    return Store(Path(profile) / 'streams').load()  # Existing/legacy source links.


def prune(profile, now=None):
    """Called off the startup path; retain requests for all playback observers."""
    now = time.time() if now is None else now
    directory = Path(profile) / 'playback-requests'
    try:
        for path in directory.glob('*.json'):
            if _path(profile, path.stem) != path:
                continue
            try:
                if now - path.stat().st_mtime > MAX_AGE:
                    path.unlink()
            except OSError:
                pass
    except OSError:
        pass
