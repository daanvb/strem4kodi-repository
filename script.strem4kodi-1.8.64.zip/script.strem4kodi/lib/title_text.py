"""Display a title's optional tagline without changing its stored synopsis."""
import html
import re


def plain(value):
    if not isinstance(value, str):return ''
    value = re.sub(r'<[^>]*>', '', html.unescape(value))
    return re.sub(r'\[/?(?:B|I|COLOR[^\]]*|UPPERCASE|LOWERCASE)\]', '', value, flags=re.I).strip()


def synopsis(meta, visible=True):
    if not visible:return ''
    description = plain(meta.get('description'))
    tagline = ' '.join(plain(meta.get('tagline')).split()).strip('"“”')
    # Leave provider text intact when its opening already contains the tagline.
    if not tagline or len(tagline) > 250:return description
    opening = description.lstrip('"“”').casefold()
    if opening.startswith(tagline.casefold()):return description
    return '[I]“' + tagline + '”[/I]' + ('\n\n' + description if description else '')


def parts(meta, visible=True):
    """Separate the fixed tagline from the scrolling plot; keep stored text intact."""
    if not visible:return '', ''
    description = plain(meta.get('description'))
    tagline = ' '.join(plain(meta.get('tagline')).split()).strip('"“”')
    if not tagline or len(tagline)>250:return '', description
    opening = description.lstrip('"“”')
    if opening.casefold().startswith(tagline.casefold()):
        description = opening[len(tagline):].lstrip('"“” \t\r\n')
    return '[I]“' + tagline + '”[/I]', description
