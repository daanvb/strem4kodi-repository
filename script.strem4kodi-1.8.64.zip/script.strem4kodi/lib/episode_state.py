"""Read Stremio's anchored per-video watched bitmap without changing account state."""
import base64
import zlib


def selected_episode(control, rows):
    """Use the displayed item's identity rather than a parallel list offset."""
    try:
        identity=control.getSelectedItem().getProperty('id')
    except (AttributeError,RuntimeError):
        identity=''
    if isinstance(identity,str) and identity:
        return next((row for row in rows if str(row.get('id'))==identity),None)
    position=control.getSelectedPosition()
    return rows[position] if 0<=position<len(rows) else None


def watched_ids(videos, saved):
    # The bitmap reader and every writer must use exactly the same ordering,
    # including providers using numeric strings or the alternate number field.
    from playback_progress import _video_ids
    ids = _video_ids(videos or [])
    value = ((saved or {}).get('state') or {}).get('watched')
    if not isinstance(value, str) or len(value) > 100000:
        return set()
    try:
        anchor, length, packed = value.rsplit(':', 2)
        length = int(length)
        if not 0 < length <= 1000000 or anchor not in ids:
            return set()
        inflater = zlib.decompressobj()
        bits = inflater.decompress(base64.b64decode(packed, validate=True), 125001)
        if not inflater.eof or len(bits) > 125000:
            return set()
        offset = length - 1 - ids.index(anchor)
        return {identity for i, identity in enumerate(ids)
                if 0 <= i + offset < (length if offset else len(bits) * 8)
                and (i + offset) // 8 < len(bits)
                and bits[(i + offset) // 8] & (1 << ((i + offset) % 8))}
    except (ValueError, TypeError, zlib.error):
        return set()
