"""Optional format learning during settled Strem4Kodi playback."""
import threading
import time
from pathlib import Path

from account import Store
from lib.format_scan_queue import Queue
from lib.slow_format_scan import Scanner, INTERVAL

SETTLE = 180


def playback_key(player, caching=lambda: False, viewing=lambda: True):
    """Trailers, pre-rolls, paused/buffering video and episode endings are excluded."""
    try:
        context = getattr(player, '_context', None)
        if (not context or not viewing() or not player.isPlayingVideo() or not getattr(player, '_counting', False)
                or caching() or player.getPlayingFile() != getattr(player, '_playing_file', None)
                or player.getTotalTime() - player.getTime() < 120):
            return None
        return (context['kind'], context['meta_id'], context['video_id'], player._playing_file)
    except (KeyError, TypeError, RuntimeError):
        return None


class Discovery:
    def __init__(self, profile, addon, player, caching=lambda: False, viewing=lambda: True):
        self.profile, self.addon, self.player, self.caching = Path(profile), addon, player, caching
        self.viewing = viewing
        self.scanner = Scanner(profile, addon)
        self._queue = None
        self.state = Store(self.profile / 'format-discovery-lists')
        self.session = None
        self.started = 0
        self.next_tick = 0
        self.busy = False
        self.closed = False

    @property
    def queue(self):
        if self._queue is None:
            self._queue = Queue(self.profile)
        return self._queue

    def tick(self):
        key = playback_key(self.player, self.caching, self.viewing) if self.scanner.enabled() and not self.closed else None
        now = time.monotonic()
        if key != self.session:
            self.session, self.started = key, now
        if not key or self.busy or now - self.started < SETTLE or now < self.next_tick:
            return
        self.next_tick = now + INTERVAL
        self.busy = True
        def current():
            return (not self.closed and self.scanner.enabled() and self.session == key
                    and playback_key(self.player, self.caching, self.viewing) == key)
        def work():
            try:
                from lib import backend as api
                self.run(api, current, key[:2])
            except Exception:
                pass  # Optional learning must never interrupt playback.
            finally:
                self.busy = False
        try:
            threading.Thread(target=work, daemon=True).start()
        except RuntimeError:
            self.busy = False

    def run(self, api, current, watching):
        from lib.format_budget import retry_after
        if not current() or retry_after(self.profile) not in (None, 1):
            return
        # These are local account/progress reads, not account or source searches.
        entries = api.account_library(False)
        watchlist = api.saved_list_entries(entries, 'watchlist')
        self.queue.add(watchlist, priority=0)
        for section in api.account_home(False):
            if section.get('label') in ('Up Next', 'Continue Watching'):
                self.queue.add(section.get('items') or [], priority=0)
        try:
            self.refresh_charts(api, current)
        except Exception:
            pass  # An unavailable catalogue must not block local candidates.
        if current():
            rows = [row for row in self.queue.rows() if (row['type'], row['id']) != watching]
            self.scanner.scan(rows, api, current, lambda: not current())

    def refresh_charts(self, api, current):
        """At most one catalogue page per tick, once daily per chart/type."""
        from lib.browse import discover_catalogs
        from lib.discovery_groups import category, family
        now = time.time()
        state = self.state.load()
        checked = state.get('checked') or {}
        seen = set()
        for spec in discover_catalogs(api.providers()):
            group = category(spec)
            key = str(spec.get('kind')) + ':' + group
            if (spec.get('kind') not in ('movie', 'series') or group not in ('Popular', 'Trending')
                    or family(spec) != 'Highlights' or key in seen):
                continue
            seen.add(key)
            if checked.get(key, 0) > now or not current():
                continue
            # Save before network I/O: failure must not repeatedly hit a catalogue.
            checked[key] = now + 86400
            self.state.save({'checked': checked})
            rows = api.discover_items(spec)
            if current():
                self.queue.add(rows[:100], priority=2)
            return

    def close(self):
        self.closed = True
