"""Keep only an owned trailer in its original browsing window."""


# Kodi Omega returns WINDOW_INVALID (9999) when no modal dialog is active.
# Retain the older sentinel values used by compatible hosts.
NO_DIALOG = (0, -1, 9999)


def can_start(gui, window_id):
    """A delayed preview belongs only to the unobstructed originating window."""
    try:
        return (isinstance(window_id, int) and window_id not in (0, -1, 9999, 12005)
                and gui.getCurrentWindowId() == window_id
                and gui.getCurrentWindowDialogId() in NO_DIALOG)
    except Exception:
        return False


def keep_windowed(kodi, gui, player, url, window_id):
    try:
        if not url or not isinstance(window_id, int) or window_id in (0, -1, 9999, 12005):
            return False
        if (gui.getCurrentWindowId() != 12005 or gui.getCurrentWindowDialogId() not in NO_DIALOG
                or not player.isPlayingVideo() or player.getPlayingFile() != url):
            return False
        kodi.executebuiltin('ActivateWindow({})'.format(window_id))
        return True
    except Exception:
        return False
