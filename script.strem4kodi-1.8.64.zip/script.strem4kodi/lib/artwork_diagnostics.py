"""Explain artwork selection locally without exposing configured image URLs."""
import re
from urllib.parse import urlsplit, unquote


def safe_name(value):
    text = str(value or '')
    text = re.sub(r'https?://\S+', '[private link]', text)
    return re.sub(r'\[[^\]]*\]|[\r\n]', '', text)[:120]


def report(row, background='', watched=None, mode='0', provider=''):
    lines = ['Title: ' + (safe_name(row.get('name') or row.get('title')) or 'Selected item')]
    if watched is None:
        lines += ['Poster provider: ' + (safe_name(row.get('_poster_provider') or provider) or 'Catalogue artwork'),
                  'Selection: ' + ('Preferred provider' if row.get('_poster_preferred') else 'Catalogue fallback'),
                  'Response: ' + (row.get('_poster_response') if row.get('_poster_response') in ('Provider catalogue', 'Cached provider response', 'Fresh provider response') else 'Catalogue or saved snapshot')]
    else:
        supplied = bool(row.get('thumbnail'))
        artwork = row.get('thumbnail') or background or ''
        if artwork.startswith('image://'):
            artwork = unquote(artwork[8:].split('/', 1)[0])
        try:
            provider_blur = urlsplit(artwork).path == '/api/image/blur'
        except ValueError:
            provider_blur = False
        blur = not watched and (mode == '1' or (mode == '2' and not supplied))
        reason = ('Watched episode' if watched else 'Protection off' if mode == '0' else
                  'Provider thumbnail kept untouched' if mode == '2' and supplied else 'Unwatched episode')
        lines += ['Thumbnail: ' + ('Provider episode image' if supplied else 'Series background fallback' if background else 'No image supplied'),
                  'Thumbnail provider: ' + (safe_name(provider) or 'Not recorded'),
                  'Watched: ' + ('Yes' if watched else 'No'),
                  'Strem4Kodi blur: ' + ('On' if blur else 'Off') + ' — ' + reason,
                  'Provider blur route: ' + ('Detected; watched episodes restore the source when safe' if provider_blur else 'Not detected')]
        lines.append('Provider images may already be blurred. Their pixels cannot be reconstructed by the app.')
    lines += ['Image cache: managed by Kodi; this report cannot confirm which pixels Kodi has cached.',
              'Refresh artwork under Providers to recheck poster selection. Private image links are excluded.']
    return '\n\n'.join(lines)


def show(row, **kwargs):
    from lib.ui_dialogs import dialog
    dialog().textviewer('Artwork details', report(row, **kwargs))
