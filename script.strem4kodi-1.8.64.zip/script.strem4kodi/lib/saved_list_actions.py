"""Visible names and actions for the existing account-scoped saved-list roles."""


def list_label(role):
    return 'Favourites' if role == 'favourite' else 'Watch Later'


def options(roles):
    return [
        {'action': 'save_favourite', 'icon': 'favourite',
         'label': 'Remove from Favourites' if roles.get('favourite') else 'Favourite'},
        {'action': 'save_watchlist', 'icon': 'watch-later',
         'label': 'Remove from Watch Later' if roles.get('watchlist') else 'Watch Later'},
    ]
