"""Suppress accidental chapter/large-seek Up presses in the owned player."""


def run(kodi=None, gui=None):
    if kodi is None:
        import xbmc as kodi
    if gui is None:
        import xbmcgui as gui
    top = gui.getCurrentWindowDialogId()
    if (kodi.getSkinDir() == 'skin.strem4kodi'
            and (top == 12901 or (top in (-1, 0) and kodi.getCondVisibility('Window.IsVisible(videoosd)')))):
        if gui.Window(12901).getFocusId() == 9007:
            kodi.executebuiltin('RunScript(special://home/addons/script.strem4kodi/player_controls.py,chapter-timeline)')
        else:
            kodi.executebuiltin('Action(Up)')
        return
    if isinstance(top, int) and top >= 10000:
        kodi.executebuiltin('Action(Up)')
        return
    if not kodi.getCondVisibility('Window.IsActive(fullscreenvideo)'):
        return
    if (kodi.getSkinDir() == 'skin.strem4kodi'
            and gui.Window(10000).getProperty('strem4kodi.player.active') == 'true'
            and kodi.Player().isPlayingVideo()
            and not kodi.getCondVisibility('VideoPlayer.Content(livetv)')):
        return
    kodi.executebuiltin('Action(ChapterOrBigStepForward)')
