"""Preview remote seeks, coalescing button repeats before touching playback."""
import math
import time
from lib.player_chapter_timeline import timestamp


class Scrub:
    RELEASE_DELAY = .4

    def __init__(self, duration, position, confirm=False):
        if not math.isfinite(duration) or duration <= 0 or not math.isfinite(position):
            raise ValueError('Invalid timeline')
        self.confirm = confirm
        self.duration = duration
        self.target = max(0, min(duration - .1, position))
        self.origin = self.target
        self.last_input = None
        self.last_move = None
        self.hold_start = None
        self.direction = None
        self.pending = False
        self.immediate = False

    def move(self, direction, now, position):
        # Ignore excessive remote repeat rates, without letting them trigger a
        # release. A tap always moves ten seconds, independent of movie length.
        previous = self.last_input
        self.last_input = now
        if direction == self.direction and previous is not None and self.last_move is not None and now - self.last_move < .15:
            return
        if not self.pending:
            self.hold_start = now
            self.origin = self.target = max(0, min(self.duration - .1, position))
        if self.direction != direction or previous is None or now - previous > .65:
            self.hold_start = now
        held = now - self.hold_start
        step = 10 if held < 3 else 20 if held < 6 else 40
        self.target = max(0, min(self.duration - .1, self.target + direction * step))
        self.last_move = now
        self.direction = direction
        self.pending = True
        self.immediate = False

    def take_seek(self, now):
        if not self.pending or (not self.immediate and (self.confirm or now - self.last_input < self.RELEASE_DELAY)):
            return None
        self.pending = False
        return self.target

    def follow(self, position):
        if self.pending or not math.isfinite(position):
            return False
        position = max(0, min(self.duration - .1, position))
        changed = position != self.target
        self.origin = self.target = position
        return changed

    @property
    def label(self):
        delta = round(self.target - self.origin)
        return '{}{} · {}'.format('+' if delta >= 0 else '−', timestamp(abs(delta)), timestamp(self.target))

    @property
    def x(self):
        return round(80 + 1760 * self.target / self.duration - 4)


def show(direction=0):
    import threading
    import xbmc
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window
    from lib.player_controls import menu_session_active
    home = xbmcgui.Window(10000)
    key = 'strem4kodi.player.scrubbing'
    if home.getProperty(key):
        return
    player = xbmc.Player()
    file = player.getPlayingFile()
    if not menu_session_active(player, file) or not xbmc.getCondVisibility('Player.SeekEnabled'):
        return
    state = Scrub(player.getTotalTime(), player.getTime(), confirm=get_addon().getSetting('scrub_commit') == '1')
    lock = threading.RLock()
    home.setProperty(key, 'true')
    try:
        # Keep no underlying OSD to flash between our modal timeline panels.
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        class Timeline(xbmcgui.WindowXMLDialog):
            def onInit(self):
                self.closed = False
                self.destination = 'close'
                self.last_activity = time.monotonic()
                self.position = state.target
                self.in_flight = False
                self.position_settles = 0
                self.next_follow = 0
                from lib.player_osd import DELAYS
                try:
                    index = int(get_addon().getSetting('playback_controls_hide') or '1')
                    self.hide_delay = DELAYS[index] if 0 <= index < len(DELAYS) else 5
                except (ValueError, TypeError):
                    self.hide_delay = 5
                self.setProperty('scrub_commit_help', 'OK to jump' if state.confirm else 'Release or OK to jump')
                self.setFocusId(600)
                if direction:
                    state.move(direction, self.last_activity, self.position)
                self.render()

                def watch():
                    monitor = xbmc.Monitor()
                    while not monitor.waitForAbort(.05):
                        if self.closed:
                            return
                        if not menu_session_active(player, file):
                            self.close(); return
                        now = time.monotonic()
                        with lock:
                            target = state.take_seek(now)
                            self.in_flight = target is not None
                        if target is not None:
                            # Never hold the input lock or run seeks on the GUI
                            # thread. Only this worker may issue a seek.
                            if not self.closed and menu_session_active(player, file) and xbmc.getCondVisibility('Player.SeekEnabled'):
                                try:
                                    player.seekTime(target)
                                    self.position = target
                                    self.position_settles = time.monotonic() + .5
                                except Exception:
                                    self.close(); return
                            self.in_flight = False
                            with lock:
                                self.render()
                        elif not state.pending and now >= self.position_settles and now >= self.next_follow:
                            try:
                                position = player.getTime()
                            except Exception:
                                self.close(); return
                            with lock:
                                self.position = position
                                self.next_follow = now + .25
                                if not self.closed and not self.in_flight and state.follow(position):
                                    self.render()
                        with lock:
                            idle = not state.pending and not self.in_flight and self.hide_delay is not None and now - self.last_activity >= self.hide_delay
                        if idle and not xbmc.getCondVisibility('Player.Paused | Player.Caching'):
                            self.close(); return
                threading.Thread(target=watch, daemon=True).start()

            def render(self):
                self.setProperty('scrub_target', timestamp(state.target))
                delta = round(state.target - state.origin)
                self.setProperty('scrub_change', (('Forward ' if delta >= 0 else 'Back ') + timestamp(abs(delta)) + ' from current position') if state.pending else 'Choose where to continue watching')
                self.getControl(600).setPosition(state.x, 924)
                self.getControl(601).setWidth(max(1, state.x - 76))

            def close(self):
                with lock:
                    self.closed = True
                    state.pending = False
                super().close()

            def onClick(self, cid):
                if cid == 600:
                    with lock:
                        if state.pending:
                            state.immediate = True
                        self.last_activity = time.monotonic()

            def onAction(self, action):
                aid = action.getId()
                with lock:
                    self.last_activity = time.monotonic()
                    if aid in (1, 2):
                        # While a seek is in flight, continue from the requested
                        # target rather than Kodi's temporarily stale playhead.
                        position = state.target if self.in_flight else self.position
                        state.move(-1 if aid == 1 else 1, self.last_activity, position)
                        self.render()
                    elif aid == 7 and state.pending:
                        state.immediate = True
                    elif aid in (3, 4, 10, 92, 216, 247):
                        self.destination = 'chapters' if aid == 3 else 'controls' if aid == 4 else 'close'
                        self.close()

        dialog = window(Timeline, 'script-strem4kodi-player-scrub.xml', get_addon().getAddonInfo('path'), 'Main', '1080i')
        dialog.closed = False
        dialog.destination = 'close'
        dialog.doModal()
        if menu_session_active(player, file):
            if dialog.destination == 'chapters':
                xbmc.executebuiltin('RunScript(special://home/addons/script.strem4kodi/player_controls.py,chapter-timeline)')
            elif dialog.destination == 'controls':
                xbmc.executebuiltin('ActivateWindow(videoosd)')
                xbmc.executebuiltin('SetFocus(9001)')
            else:
                xbmc.executebuiltin('Dialog.Close(videoosd)')
    finally:
        home.clearProperty(key)
