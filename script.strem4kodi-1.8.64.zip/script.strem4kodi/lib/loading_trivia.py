"""Live title facts, fetched off the playback path, with a curated offline fallback."""
from collections import OrderedDict
from functools import lru_cache
import json
from pathlib import Path
import random
import re
import threading
import time
from lib.stream_presenter import line

_previous = OrderedDict()
_lock = threading.Lock()


def _load_live(key):
    """Runs only on the optional worker, including all SQLite and HTTP work."""
    from lib.cache_policy import open_cache, read_policy
    from lib.wiki_trivia import fetch
    policy = read_policy()
    ttl = min(policy['metadata'] or 86400, 7 * 86400)
    cache = open_cache('metadata', policy)
    cache_key = 'title-trivia-v1:' + key
    try:
        stored = cache.get(cache_key) if cache else None
    except Exception:
        stored = None
    if (isinstance(stored, dict) and stored.get('identity') == key and isinstance(stored.get('rows'), list)
            and isinstance(stored.get('expires'), (int, float)) and stored['expires'] > time.time()):
        return stored['rows'], min(ttl, stored['expires'] - time.time())
    rows = fetch(key.split(':', 1)[1])
    ttl = ttl if rows else min(ttl, 6 * 3600)
    if cache:
        try:cache.put(cache_key, {'identity': key, 'rows': rows, 'expires': time.time() + ttl}, ttl)
        except Exception:pass
    return rows, ttl


class LiveTrivia:
    """One daemon worker, coalesced requests, bounded queue and memory cache."""
    def __init__(self, loader=_load_live, clock=time.time):
        self.loader = loader; self.clock = clock; self.lock = threading.Lock()
        self.memory = OrderedDict(); self.jobs = OrderedDict(); self.active = None
        self.worker = None; self.blocked_until = 0

    def cached(self, key):
        with self.lock:
            value = self.memory.get(key)
            if value and value[0] > self.clock():
                self.memory.move_to_end(key)
                return value[1]
        return []

    def request(self, meta, callback=None):
        key = identity(meta)
        if not key:return
        with self.lock:
            if key in self.jobs:
                if callback and len(self.jobs[key]) < 8:self.jobs[key].append(callback)
                return
            # Never accumulate work for every poster passed while browsing.
            if len(self.jobs) >= 4:return
            self.jobs[key] = [callback] if callback else []
            if self.worker is None:
                self.worker = threading.Thread(target=self._run, daemon=True)
                try:self.worker.start()
                except RuntimeError:
                    self.worker = None; self.jobs.pop(key, None)

    def _run(self):
        while True:
            with self.lock:
                if not self.jobs:
                    self.worker = None; self.active = None
                    return
                key = next(iter(self.jobs)); self.active = key
                value = self.memory.get(key)
            ttl = 600
            try:
                if value and value[0] > self.clock():
                    rows, ttl = value[1], value[0] - self.clock()
                elif self.clock() < self.blocked_until:
                    rows, ttl = [], self.blocked_until - self.clock()
                else:
                    rows, ttl = self.loader(key)
            except Exception as error:
                rows = []
                if getattr(error, 'code', None) in (429, 503):
                    try:retry = int(error.headers.get('Retry-After', '600'))
                    except (AttributeError, ValueError, TypeError):retry = 600
                    self.blocked_until = self.clock() + max(60, min(retry, 3600))
            rows = _sourced(rows)[:10] if isinstance(rows, list) else []
            with self.lock:
                self.memory[key] = (self.clock() + max(1, ttl), rows)
                self.memory.move_to_end(key)
                while len(self.memory) > 128:self.memory.popitem(last=False)
                callbacks = self.jobs.pop(key, [])
            for callback in callbacks:
                try:callback(rows)
                except Exception:pass  # Optional enrichment cannot stop the worker.


live = LiveTrivia()


@lru_cache(maxsize=1)
def catalogue():
    try:
        rows = json.loads((Path(__file__).resolve().parents[1] / 'resources/trivia.json').read_text(encoding='utf-8'))
        return rows if isinstance(rows, dict) else {}
    except (OSError, ValueError):return {}


def identity(meta):
    kind = meta.get('type')
    imdb = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
    if kind not in ('movie', 'series') or not re.fullmatch(r'tt\d+', imdb):return ''
    return kind + ':' + imdb


def _sourced(rows):
    return [row for row in rows if isinstance(row,dict) and isinstance(row.get('text'),str)
            and isinstance(row.get('source'),str) and row['source'].startswith('https://')]


def facts(meta):
    rows=live.cached(identity(meta)) or _sourced(catalogue().get(identity(meta),[]))
    if rows:return 'Did you know?',list(dict.fromkeys(line(row['text'],190) for row in rows))
    return 'Did you know?',[]


def choose(meta, rows=None):
    """Avoid consecutive repeats during this app session, with bounded history."""
    records = _sourced(rows if rows is not None else live.cached(identity(meta)) or catalogue().get(identity(meta), []))
    rows = list(dict.fromkeys(line(row['text'], 190) for row in records))
    if not rows:return {}
    label = 'Did you know?'
    labels = {line(row['text'], 190): label + ' · Wikipedia · CC BY-SA 4.0'
              if row.get('origin') == 'wikipedia' else label for row in records}
    key = identity(meta) or (str(meta.get('type')), str(meta.get('id')))
    with _lock:
        previous = _previous.pop(key, '')
        selected = random.choice([row for row in rows if row != previous] or rows)
        _previous[key] = selected
        while len(_previous) > 512:_previous.popitem(last=False)
    choices = [(labels[row], row) for row in rows]
    sources = {line(row['text'], 190): row['source'] for row in records}
    return {'trivia_label': labels[selected], 'trivia': selected, 'trivia_choices': choices,
            'trivia_sources': sources}


def prefetch(meta, callback=None):
    live.request(dict(meta), callback)
