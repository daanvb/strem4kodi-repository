"""Local recent searches; no account credentials or remote upload."""
import json
from pathlib import Path
from setup_profile import atomic_write
from search_match import normalized


def recent(profile):
    try:
        rows = json.loads((Path(profile) / 'search-history.json').read_text(encoding='utf-8'))
        return [s for s in rows if isinstance(s, str) and s.strip()][:20] if isinstance(rows, list) else []
    except Exception:
        return []


def remember(profile, query):
    value = str(query or '').strip()[:200]
    rows = [r for r in recent(profile) if normalized(r) != normalized(value)]
    if value:
        rows.insert(0, value)
    atomic_write(Path(profile) / 'search-history.json', json.dumps(rows[:20], ensure_ascii=False).encode('utf-8'))


def clear(profile):
    atomic_write(Path(profile) / 'search-history.json', b'[]')


def suggestions(query, history, matches=()):
    key = normalized(query)
    rows = [r for r in history if not key or key in normalized(r)]
    rows += [str(r.get('name') or '') for r in matches if isinstance(r, dict) and r.get('name')]
    output, seen = [], set()
    for value in rows:
        if normalized(value) not in seen:
            output.append(value);seen.add(normalized(value))
    return output[:8]
