"""Allowlisted Kodi defaults for an explicitly approved device enrollment.

Hardware/audio/display preferences are deliberately not copied. The journal is
private device state; it can contain the previous web-server password.
"""

TARGET_SKIN = 'skin.freebird'
AERIAL_ADDON = 'screensaver.atv4'
SCREENSAVER_SETTINGS = ('screensaver.mode', 'screensaver.usedimonpause')
KODI_DEFAULTS = {
    'eventlog.enabled': True,
    'services.webserverauthentication': False,
    'services.webserverusername': 'kodi',
    'services.webserverpassword': '',
    'services.esenabled': True,
    'addons.unknownsources': True,
    'services.webserver': True,
    'screensaver.mode': AERIAL_ADDON,
    # Let the selected screensaver run after the normal timeout while video
    # is paused; active playback remains protected by Kodi.
    'screensaver.usedimonpause': False,
}
SKIN_DEFAULTS = {
    **{name: True for name in (
        'HomeMenuNoMovieButton', 'HomeMenuNoTVShowButton',
        'HomeMenuNoMusicButton', 'HomeMenuNoDiscButton',
        'HomeMenuNoMusicVideoButton', 'HomeMenuNoTVButton',
        'HomeMenuNoRadioButton', 'HomeMenuNoGamesButton',
        'HomeMenuNoPicturesButton', 'HomeMenuNoVideosButton',
        'HomeMenuNoWeatherButton',
    )},
    'HomeMenuNoProgramsButton': False,
    'HomeMenuNoFavButton': False,
    'home_no_categories_widget': False,
}


def apply(store, backend, include_skin=True):
    """Back up before writes, confirm readback, and retry only unfinished writes."""
    journal = store.load()
    pending = []
    for group, defaults in (('settings', KODI_DEFAULTS), ('skin_settings', SKIN_DEFAULTS)):
        if group == 'skin_settings':
            if not include_skin:
                continue
            if backend.skin() != TARGET_SKIN:
                pending.append('skin_settings')
                continue  # Skin builtins always affect the currently active skin.
        for name, desired in defaults.items():
            if name in SCREENSAVER_SETTINGS and not include_skin:
                continue  # The screensaver belongs to the companion appearance setup.
            entries = journal.setdefault(group, {})
            entry = entries.get(name)
            if entry and entry.get('done'):
                continue  # Never overwrite a preference edited after enrollment.
            try:
                current = backend.get(group, name)
            except Exception:
                pending.append(name)
                continue
            if entry is None:
                entry = {'before': current, 'applied': desired, 'done': False}
                entries[name] = entry
                store.save(journal)  # A failed backup must prevent mutation.
            try:
                if type(current) is not type(desired) or current != desired:
                    backend.set(group, name, desired)
                actual = backend.get(group, name)
                confirmed = type(actual) is type(desired) and actual == desired
            except Exception:
                confirmed = False
            if confirmed:
                entry['done'] = True
                store.save(journal)
            else:
                pending.append(name)
    return pending


def restore(store, backend):
    """Undo our values only if the user has not subsequently changed them."""
    journal = store.load()
    count, pending = 0, []
    for group in ('settings', 'skin_settings'):
        entries = journal.get(group, {})
        if group == 'skin_settings' and entries and backend.skin() != TARGET_SKIN:
            pending.append('skin_settings')
            continue
        # Restore service state first, then credentials, then authentication.
        ordered = list(entries.items())
        if group == 'settings':ordered.reverse()
        for name, entry in ordered:
            try:
                current = backend.get(group, name)
                desired = entry['applied']
                before = entry['before']
                if type(current) is type(desired) and current == desired and current != before:
                    backend.set(group, name, before)
                    actual = backend.get(group, name)
                    if type(actual) is not type(before) or actual != before:
                        raise ValueError('Kodi did not restore the setting')
                    count += 1
            except Exception:
                pending.append(name)
                continue
            del entries[name]
            store.save(journal)
    return count, pending
