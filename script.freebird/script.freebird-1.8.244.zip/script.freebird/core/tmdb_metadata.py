"""Exact-title TMDB credits and recommendations, using the viewer's API key."""
import re
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
from protocol import fetch


def request(key, path, fetcher=fetch, **params):
    return fetcher('https://api.themoviedb.org/3/' + path + '?' +
                   urlencode(dict(api_key=key, language='en-US', **params)))


def identity(meta, key, fetcher=fetch):
    kind = {'series': 'tv', 'movie': 'movie'}.get(meta.get('type'))
    if not kind or not key:
        return None
    imdb = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
    # IMDb lookup avoids confusing TMDB season/episode IDs with series IDs.
    if re.fullmatch(r'tt\d+', imdb):
        matches = request(key, 'find/' + imdb, fetcher,
                          external_source='imdb_id').get(kind + '_results', [])
        if len(matches) == 1:
            return kind, str(matches[0]['id'])
        return None
    value = str(meta.get('moviedb_id') or '')
    if re.fullmatch(r'[1-9]\d*', value):
        return kind, value
    return None


def photo(path):
    return 'https://image.tmdb.org/t/p/w342' + path if isinstance(path, str) and re.fullmatch(r'/[\w./-]+', path) else ''


def season_details(meta, season, key, fetcher=fetch):
    resolved = identity(meta, key, fetcher)
    if not resolved or resolved[0] != 'tv':return []
    payload = request(key, 'tv/' + resolved[1] + '/season/' + str(int(season)), fetcher)
    rows = []
    for episode in payload.get('episodes', []):
        if not isinstance(episode, dict) or type(episode.get('episode_number')) is not int:continue
        row = {'episode': episode['episode_number']}
        runtime = episode.get('runtime')
        if type(runtime) is int and 0 < runtime <= 1440:
            row['runtime'] = runtime
        if isinstance(episode.get('overview'), str) and episode['overview'].strip():
            row['description'] = episode['overview'].strip()
        if (isinstance(episode.get('vote_count'), int) and episode['vote_count'] > 0
                and isinstance(episode.get('vote_average'), (int, float))):
            row['tmdbRating'] = episode['vote_average']
        rows.append(row)
    return rows


def season_ratings(meta, season, key, fetcher=fetch):
    return [{'episode': row['episode'], 'tmdbRating': row['tmdbRating']}
            for row in season_details(meta, season, key, fetcher) if 'tmdbRating' in row]


def certificate_gb(meta, key, fetcher=fetch):
    """Use actual GB classifications, preferring home releases over cinema cuts."""
    resolved = identity(meta, key, fetcher)
    if not resolved:return ''
    kind, tid = resolved
    endpoint = '/release_dates' if kind == 'movie' else '/content_ratings'
    payload = request(key, kind + '/' + tid + endpoint, fetcher)
    return _certificate_gb(kind, payload)


def _certificate_gb(kind, payload):
    allowed = {'U', 'PG', '12', '12A', '15', '18', 'R18'}
    for country in payload.get('results', []):
        if not isinstance(country, dict) or country.get('iso_3166_1') != 'GB':continue
        if kind == 'tv':
            value = str(country.get('rating') or '').upper().strip()
            return value if value in allowed else ''
        rows = [r for r in country.get('release_dates', []) if isinstance(r, dict)]
        priority = {4: 0, 5: 1, 6: 2, 3: 3, 2: 4, 1: 5}
        for row in sorted(rows, key=lambda r: priority.get(r.get('type'), 6)):
            value = str(row.get('certification') or '').upper().strip()
            if value in allowed:return value
    return ''


def title_details(meta, key, fetcher=fetch):
    """Tagline and safe facts alongside the existing classification request."""
    resolved = identity(meta, key, fetcher)
    if not resolved:return {}
    kind, tid = resolved
    ratings = 'release_dates' if kind == 'movie' else 'content_ratings'
    payload = request(key, kind + '/' + tid, fetcher, append_to_response=ratings)
    result = {}
    for target, field in [('tagline', 'tagline'), ('original_title', 'original_title' if kind == 'movie' else 'original_name')]:
        value = payload.get(field)
        if isinstance(value, str) and value.strip():result[target] = value.strip()[:250]
    creators = [r['name'].strip()[:80] for r in payload.get('created_by', [])
                if isinstance(r, dict) and isinstance(r.get('name'), str) and r['name'].strip()]
    if creators:result['creators'] = creators[:4]
    status = payload.get('status')
    if kind == 'tv' and isinstance(status, str) and status.strip():
        result['status'] = status.strip()[:40]
    value = _certificate_gb(kind, payload.get(ratings) or {})
    if value:result.update(certificate_gb=value, certificate_country='GB')
    return result


def credits(meta, key, role='cast', fetcher=fetch):
    resolved = identity(meta, key, fetcher)
    if not resolved:
        return []
    kind, tid = resolved
    payload = request(key, kind + '/' + tid + ('/aggregate_credits' if kind == 'tv' else '/credits'), fetcher)
    rows = []
    for entry in payload.get('crew' if role == 'crew' else 'cast', []):
        if not isinstance(entry, dict) or not entry.get('name'):
            continue
        jobs = entry.get('jobs' if role == 'crew' else 'roles') or []
        job = ' / '.join(dict.fromkeys(str(j.get('job' if role == 'crew' else 'character') or '') for j in jobs if isinstance(j, dict)))
        job = job or entry.get('job' if role == 'crew' else 'character') or ('Crew' if role == 'crew' else 'Cast')
        if role == 'cast' and job != 'Cast':
            job = 'as ' + job
        person = {'name': entry['name'], 'job': job, 'poster': photo(entry.get('profile_path'))}
        if re.fullmatch(r'[1-9]\d*', str(entry.get('id') or '')):
            person['tmdb_person_id'] = str(entry['id'])
        rows.append(person)
    return rows


def released_credit(value, today=None):
    """Require a known full release/first-air date, including today's releases."""
    from datetime import date
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        return False
    try:return date.fromisoformat(value) <= (today or date.today())
    except ValueError:return False


def filmography(person, key, role='cast', fetcher=fetch, today=None):
    """Playable movie/TV credits, deduplicated and ordered newest first."""
    pid = str(person.get('tmdb_person_id') or '')
    if not key or not re.fullmatch(r'[1-9]\d*', pid):
        return []
    payload = request(key, 'person/' + pid + '/combined_credits', fetcher)
    candidates, seen = [], set()
    for row in payload.get('crew' if role == 'crew' else 'cast', []):
        if not isinstance(row, dict) or row.get('adult'):
            continue
        kind, tid = row.get('media_type'), str(row.get('id') or '')
        if kind not in ('movie', 'tv') or not re.fullmatch(r'[1-9]\d*', tid) or (kind, tid) in seen:
            continue
        if not released_credit(row.get('release_date') if kind == 'movie' else row.get('first_air_date'), today):
            continue
        seen.add((kind, tid))
        candidates.append(row)
    candidates.sort(key=lambda r: r.get('release_date') or r.get('first_air_date') or '', reverse=True)

    def convert(row):
        try:
            imdb = request(key, row['media_type'] + '/' + str(row['id']) + '/external_ids', fetcher).get('imdb_id')
            if not re.fullmatch(r'tt\d+', str(imdb or '')):
                return None
            date = row.get('release_date') or row.get('first_air_date') or ''
            return {'id': imdb, 'imdb_id': imdb, 'moviedb_id': row['id'],
                    'type': 'series' if row['media_type'] == 'tv' else 'movie',
                    'name': row.get('title') or row.get('name') or '',
                    'released': date, 'year': date[:4], 'description': row.get('overview') or '',
                    'poster': photo(row.get('poster_path')),
                    'background': 'https://image.tmdb.org/t/p/w780' + row['backdrop_path'] if row.get('backdrop_path') else ''}
        except Exception:
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        return [row for row in pool.map(convert, candidates) if row]


def recommendations(meta, key, limit=24, fetcher=fetch):
    resolved = identity(meta, key, fetcher)
    if not resolved:
        return []
    kind, tid = resolved
    candidates = request(key, kind + '/' + tid + '/recommendations', fetcher).get('results', [])
    def convert(row):
        try:
            if not isinstance(row, dict) or row.get('adult') or not str(row.get('id', '')).isdigit():
                return None
            imdb = request(key, kind + '/' + str(row['id']) + '/external_ids', fetcher).get('imdb_id')
            if not re.fullmatch(r'tt\d+', str(imdb or '')):
                return None
            return {'id': imdb, 'imdb_id': imdb, 'moviedb_id': row['id'], 'type': meta['type'],
                    'name': row.get('title') or row.get('name') or '',
                    'description': row.get('overview') or '',
                    'poster': photo(row.get('poster_path')),
                    'background': 'https://image.tmdb.org/t/p/w780' + row['backdrop_path'] if row.get('backdrop_path') else '',
                    'recommendation_source': 'TMDB'}
        except Exception:
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        return [r for r in pool.map(convert, candidates[:limit]) if r and r['id'] != meta.get('id')][:limit]
