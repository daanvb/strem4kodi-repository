"""Resolve only the independent freeBird add-on context."""
import xbmcaddon

ADDON_ID = 'script.freebird'


def get_addon():
    # Adapted from upstream 0d24a03: recover only our own running context.
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
    except RuntimeError:
        addon = xbmcaddon.Addon()
        if addon.getAddonInfo('id') != ADDON_ID:
            raise RuntimeError('freeBird addon context unavailable') from None
    # Independent profile: do not import settings from the upstream addon.
    return addon
