"""Preview remote seeks, coalescing button repeats before touching playback."""
import math
import time
from lib.player_chapter_timeline import timestamp


def live_target(target, duration, elapsed, current_duration):
    """Keep the chosen broadcast moment as a live window rolls forward."""
    if not math.isfinite(current_duration) or current_duration <= 0:
        raise ValueError('Invalid live timeline')
    return max(0, min(current_duration - .1,
                      target + current_duration - duration - max(0, elapsed)))


class Scrub:
    RELEASE_DELAY = .4

    def __init__(self, duration, position, confirm=False):
        if not math.isfinite(duration) or duration <= 0 or not math.isfinite(position):
            raise ValueError('Invalid timeline')
        self.confirm = confirm
        self.duration = duration
        self.target = max(0, min(duration - .1, position))
        self.origin = self.target
        self.last_input = None
        self.last_move = None
        self.hold_start = None
        self.direction = None
        self.pending = False
        self.immediate = False

    def move(self, direction, now, position):
        # Ignore excessive remote repeat rates, without letting them trigger a
        # release. A tap always moves ten seconds, independent of movie length.
        previous = self.last_input
        self.last_input = now
        if direction == self.direction and previous is not None and self.last_move is not None and now - self.last_move < .15:
            return
        if not self.pending:
            self.hold_start = now
            self.origin = self.target = max(0, min(self.duration - .1, position))
        if self.direction != direction or previous is None or now - previous > .65:
            self.hold_start = now
        held = now - self.hold_start
        step = 10 if held < 3 else 20 if held < 6 else 40
        self.target = max(0, min(self.duration - .1, self.target + direction * step))
        self.last_move = now
        self.direction = direction
        self.pending = True
        self.immediate = False

    def take_seek(self, now):
        if not self.pending or (not self.immediate and (self.confirm or now - self.last_input < self.RELEASE_DELAY)):
            return None
        self.pending = False
        return self.target

    def follow(self, position):
        if self.pending or not math.isfinite(position):
            return False
        position = max(0, min(self.duration - .1, position))
        changed = position != self.target
        self.origin = self.target = position
        return changed

    @property
    def label(self):
        delta = round(self.target - self.origin)
        return '{}{} · {}'.format('+' if delta >= 0 else '−', timestamp(abs(delta)), timestamp(self.target))

    @property
    def x(self):
        return round(80 + 1760 * self.target / self.duration - 4)


def show(direction=0):
    import threading
    import xbmc
    import xbmcgui
    from addon_state import get_addon
    from lib.theme import window
    from lib.player_controls import menu_session_active
    from lib.window_lifetime import Lifetime
    home = xbmcgui.Window(10000)
    key = 'strem4kodi.player.scrubbing'
    if home.getProperty(key):
        return
    player = xbmc.Player()
    file = player.getPlayingFile()
    if not menu_session_active(player, file) or not xbmc.getCondVisibility('Player.SeekEnabled'):
        return
    live = home.getProperty('strem4kodi.player.live') == 'true'
    try:
        state = Scrub(player.getTotalTime(), player.getTime(), confirm=get_addon().getSetting('scrub_commit') == '1')
    except (RuntimeError, ValueError, TypeError):
        return
    lock = threading.RLock()
    home.setProperty(key, 'true')
    try:
        # Keep no underlying OSD to flash between our modal timeline panels.
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        class Timeline(xbmcgui.WindowXMLDialog):
            def onInit(self):
                self.lifetime = Lifetime()
                self.thumb = self.getControl(600)
                self.fill = self.getControl(601)
                self.painted = {}
                self.closed = False
                self.destination = 'close'
                self.last_activity = time.monotonic()
                self.position = state.target
                self.in_flight = False
                self.position_settles = 0
                self.next_follow = 0
                self.anchor = self.last_activity
                from lib.player_osd import DELAYS
                try:
                    index = int(get_addon().getSetting('playback_controls_hide') or '1')
                    self.hide_delay = DELAYS[index] if 0 <= index < len(DELAYS) else 5
                except (ValueError, TypeError):
                    self.hide_delay = 5
                self.setProperty('scrub_commit_help', 'OK to jump' if state.confirm else 'Release or OK to jump')
                self.setProperty('scrub_kind', 'LIVE' if live else 'SCRUB')
                self.setFocusId(600)
                if direction:
                    state.move(direction, self.last_activity, self.position)
                self.render()

                def watch():
                    monitor = xbmc.Monitor()
                    while not monitor.waitForAbort(.1):
                        if self.closed:
                            return
                        if not menu_session_active(player, file):
                            self.close(); return
                        now = time.monotonic()
                        with lock:
                            target = state.take_seek(now)
                            self.in_flight = target is not None
                            duration, anchor = state.duration, self.anchor
                        if target is not None:
                            # Never hold the input lock or run seeks on the GUI
                            # thread. Only this worker may issue a seek.
                            if not self.closed and menu_session_active(player, file) and xbmc.getCondVisibility('Player.SeekEnabled'):
                                try:
                                    if live:
                                        target = live_target(target, duration, time.monotonic() - anchor, player.getTotalTime())
                                    if self.closed or not menu_session_active(player, file):
                                        self.close(); return
                                    player.seekTime(target)
                                    with lock:
                                        self.position = target
                                        self.position_settles = time.monotonic() + 2
                                except Exception:
                                    self.close(); return
                            with lock:
                                self.in_flight = False
                        elif not state.pending and now >= self.next_follow:
                            try:
                                position = player.getTime()
                                duration = player.getTotalTime() if live else state.duration
                            except Exception:
                                self.close(); return
                            with lock:
                                self.next_follow = now + .25
                                # A slow decoder may still report the old playhead
                                # after seekTime returns. Keep the requested point
                                # until it acknowledges the seek or settles.
                                settled = abs(position - self.position) <= 2 or now >= self.position_settles
                                if not self.closed and not state.pending and not self.in_flight and settled:
                                    self.position = position
                                    if math.isfinite(duration) and duration > 0:
                                        state.duration = duration
                                        self.anchor = now
                                        state.follow(position)
                        with lock:
                            idle = not state.pending and not self.in_flight and self.hide_delay is not None and now - self.last_activity >= self.hide_delay
                        if idle and not xbmc.getCondVisibility('Player.Paused | Player.Caching'):
                            self.close(); return
                def paint():
                    monitor = xbmc.Monitor()
                    while not monitor.waitForAbort(.1) and not self.closed:
                        self.render()
                threading.Thread(target=watch, daemon=True, name='freebird-scrub-seek').start()
                threading.Thread(target=paint, daemon=True, name='freebird-scrub-paint').start()

            def render(self):
                with lock:
                    if self.closed:
                        return
                    delta = round(state.target - state.origin)
                    target = live_target(state.target, state.duration, time.monotonic() - self.anchor, state.duration) if live else state.target
                    title = (timestamp(max(0, state.duration - target)) + ' behind live') if live else timestamp(target)
                    change = (('Forward ' if delta >= 0 else 'Back ') + timestamp(abs(delta)) + ' from current position') if state.pending else 'Choose where to continue watching'
                    x = round(80 + 1760 * target / state.duration - 4) if live else state.x
                    values = {'scrub_target': title, 'scrub_change': change, 'x': x}
                # Native GUI calls must never hold the input lock. Coalesce
                # remote bursts and avoid publishing identical pixels/text.
                for key, value in values.items():
                    if self.painted.get(key) == value:
                        continue
                    if key == 'x':
                        self.lifetime.publish(self.thumb.setPosition, value, 924)
                        self.lifetime.publish(self.fill.setWidth, max(1, value - 76))
                    else:
                        self.lifetime.publish(self.setProperty, key, value)
                    self.painted[key] = value

            def close(self):
                with lock:
                    if self.closed:
                        return
                    self.closed = True
                    state.pending = False
                self.lifetime.retire(super().close)

            def onClick(self, cid):
                if cid == 600:
                    with lock:
                        if state.pending:
                            state.immediate = True
                        self.last_activity = time.monotonic()

            def onAction(self, action):
                aid = action.getId()
                with lock:
                    self.last_activity = time.monotonic()
                    if aid in (1, 2):
                        # While a seek is in flight, continue from the requested
                        # target rather than Kodi's temporarily stale playhead.
                        position = state.target if self.in_flight or self.last_activity < self.position_settles else self.position
                        state.move(-1 if aid == 1 else 1, self.last_activity, position)
                    elif aid == 7 and state.pending:
                        state.immediate = True
                    elif aid in (3, 4, 10, 92, 216, 247):
                        self.destination = 'chapters' if aid == 3 and not live else 'close'
                    else:
                        return
                if aid in (3, 4, 10, 92, 216, 247):
                    self.close()

        dialog = window(Timeline, 'script-freebird-player-scrub.xml', get_addon().getAddonInfo('path'), 'Main', '1080i')
        dialog.lifetime = Lifetime()
        dialog.closed = False
        dialog.destination = 'close'
        dialog.doModal()
        if menu_session_active(player, file):
            if dialog.destination == 'chapters':
                xbmc.executebuiltin('RunScript(special://home/addons/script.freebird/player_controls.py,chapter-timeline)')
            else:
                xbmc.executebuiltin('Dialog.Close(videoosd)')
    finally:
        if 'dialog' in locals():
            dialog.close()
        home.clearProperty(key)
