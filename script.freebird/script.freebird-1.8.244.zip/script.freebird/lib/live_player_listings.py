"""Read the playing channel's EPG off the Kodi service thread."""
from threading import Event, Thread
import time

from lib import live_tv_epg as epg


class PlayerListings:
    def __init__(self, load=epg.load, clock=time.monotonic):
        self.load = load
        self.clock = clock
        self.channel = None
        self.rows = []
        self.refresh_at = 0
        self.pending = None

    def close(self):
        if self.pending:
            self.pending[1].set()
        self.rows = []
        self.channel = None
        self.refresh_at = 0

    def programme(self, channel, stamp):
        if self.channel != channel:
            self.close()
            self.channel = channel
        now = self.clock()
        if self.pending:
            worker, cancelled, result = self.pending
            if not worker.is_alive():
                self.pending = None
                if not cancelled.is_set():
                    if result:
                        self.rows = result
                    self.refresh_at = now + (900 if result else 60)
        if channel in epg.SERVICES and self.pending is None and now >= self.refresh_at:
            cancelled, result = Event(), []

            def fetch():
                try:
                    data = self.load(channels=(channel,), cancelled=cancelled.is_set)
                    if data:
                        result.extend(data.get(channel, ()))
                except Exception:
                    pass  # Keep the previous listings and retry after a minute.

            worker = Thread(target=fetch, daemon=True, name='freebird-player-listings')
            self.pending = worker, cancelled, result
            worker.start()
        if stamp is not None:
            return next((p for p in self.rows if p['start'] <= stamp < p['end']), None)
        return None
