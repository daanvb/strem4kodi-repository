"""Bundled channel identification artwork, shared by guide and playback."""
from lib.live_tv_provider import CHANNEL_IDS

ROOT = 'special://home/addons/script.freebird/resources/branding/channels/'


def channel_icon(channel):
    return ROOT + channel + '.png' if channel in CHANNEL_IDS else ''
