"""Live channel registry and BBC DASH adapter; no source URLs in diagnostics."""
import json
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit
from urllib.request import Request, HTTPRedirectHandler, build_opener

from lib.live_tv_manifest import MAX_BYTES, TAG, filter_dash
from lib.live_tv_quality import HDUnavailable
from lib.live_tv_commercial import CHANNELS as COMMERCIAL_CHANNELS, resolve_commercial

BBC_CHANNELS = (
    ('bbc_one_hd', 'BBC One'), ('bbc_two_hd', 'BBC Two'),
    ('bbc_three_hd', 'BBC Three'), ('bbc_four_hd', 'BBC Four'),
    ('cbbc_hd', 'CBBC'), ('cbeebies_hd', 'CBeebies'),
    ('bbc_news24', 'BBC News'), ('bbc_scotland', 'BBC Scotland'),
)
CHANNELS = BBC_CHANNELS + COMMERCIAL_CHANNELS
BBC_IDS = frozenset(identity for identity, _ in BBC_CHANNELS)
CHANNEL_IDS = frozenset(identity for identity, _ in CHANNELS)


class SecureRedirect(HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        target = urlsplit(newurl)
        if target.scheme != 'https' or target.username or target.password:
            raise HDUnavailable('Insecure broadcaster redirect.')
        return super().redirect_request(request, fp, code, msg, headers, newurl)


def read_https(url, limit=MAX_BYTES):
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise HDUnavailable('Unsupported broadcaster address.')
    request = Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Accept-Encoding': 'identity'})
    try:
        with build_opener(SecureRedirect()).open(request, timeout=10) as response:
            final = response.geturl()
            if urlsplit(final).scheme != 'https':
                raise HDUnavailable('Insecure broadcaster redirect.')
            data = response.read(limit + 1)
            if len(data) > limit:
                raise HDUnavailable('Broadcaster response is too large.')
            return data, final
    except HDUnavailable:
        raise
    except Exception:
        raise HDUnavailable('The broadcaster is unavailable. Please try again.') from None


def resolve_bbc(channel, fetch=read_https, prefer_hevc=True):
    if channel not in BBC_IDS:
        raise HDUnavailable('Unknown live channel.')
    if prefer_hevc:
        native = ('https://open.live.bbc.co.uk/mediaselector/6/select/version/2.0/'
                  'mediaset/iptv-native-hd/vpid/' + channel + '/format/json')
        try:
            data, _ = fetch(native)
            payload = json.loads(data)
            candidates = []
            for media in payload.get('media', []):
                if media.get('encoding') != 'h265' or not str(media.get('kind', '')).startswith('video'):
                    continue
                for connection in media.get('connection', []):
                    url = connection.get('href', '')
                    if (connection.get('transferFormat') == 'dash' and urlsplit(url).scheme == 'https'
                            and url not in candidates):
                        candidates.append(url)
            # Bound start-up latency. A failing native CDN must not break the
            # established AVC path. Validate actual manifest dimensions, not
            # the selector's packaging-profile height or a filename.
            for candidate in candidates[:2]:
                try:
                    raw, final = fetch(candidate)
                    root = ET.fromstring(filter_dash(raw, final))
                    if any(node.tag.endswith('ContentProtection') for node in root.iter()):
                        continue
                    if any(int(rep.get('width', adaptation.get('width', '0'))) >= 1920
                           and int(rep.get('height', adaptation.get('height', '0'))) >= 1080
                           for adaptation in root.iter(TAG + 'AdaptationSet')
                           for rep in adaptation.findall(TAG + 'Representation')):
                        return candidate
                except Exception:
                    continue
        except Exception:
            pass
    url = ('https://open.live.bbc.co.uk/mediaselector/6/select/version/2.0/'
           'mediaset/pc/vpid/' + channel + '/format/json')
    try:
        data, _ = fetch(url)
        payload = json.loads(data)
        for media in payload.get('media', []):
            if not str(media.get('kind', '')).startswith('video'):
                continue
            for connection in media.get('connection', []):
                candidate = connection.get('href', '')
                if (connection.get('transferFormat') == 'dash'
                        and urlsplit(candidate).scheme == 'https'):
                    return candidate
    except HDUnavailable:
        raise
    except Exception:
        raise HDUnavailable('The broadcaster returned an invalid response.') from None
    raise HDUnavailable('No compatible live stream is available in your region.')


def resolve_channel(channel):
    if channel in BBC_IDS:
        import xbmcaddon
        prefer = xbmcaddon.Addon('script.freebird').getSetting('live_tv_bbc_hevc') != 'false'
        return resolve_bbc(channel, prefer_hevc=prefer)
    return resolve_commercial(channel)
