"""Idle control-bar cleanup limited to video started by Strem4Kodi."""
import time

# Preserve existing saved enum indices when adding choices.
DELAYS = (None, 5, 10, 15, 3, 7, 12)
HIDDEN = 'strem4kodi.player.idle_hidden'


class PlayerOSD:
    def __init__(self, player, addon, kodi=None, gui=None, clock=time.monotonic):
        if kodi is None:
            import xbmc as kodi
        if gui is None:
            import xbmcgui as gui
        self.player=player;self.addon=addon;self.kodi=kodi;self.gui=gui
        self.clock=clock;self.visible_since=None
        self.session=None

    def reset(self):
        self.visible_since=None
        self.gui.Window(10000).clearProperty(HIDDEN)

    def tick(self):
        try:
            index=int(self.addon.getSetting('playback_controls_hide') or '1')
            delay=DELAYS[index] if 0 <= index < len(DELAYS) else 5
            live_file=getattr(self.player, '_live_file', None)
            file=live_file if isinstance(live_file, str) and live_file else getattr(self.player,'_playing_file',None)
            actual = self.player.getPlayingFile() if self.player.isPlayingVideo() else ''
            endpoint = self.gui.Window(10000).getProperty('s4k.live.endpoint')
            # Native TV belongs to the active local service, rather than the
            # movie/series observer. Match that session before applying its timer.
            if (isinstance(endpoint, str) and endpoint and isinstance(actual, str)
                    and actual.startswith(endpoint)):
                file = actual
            if delay is None or not file or actual != file:
                self.session=None;self.reset();return
            if self.session != file:
                self.session=file;self.reset()
            top=self.gui.getCurrentWindowDialogId()
            # Seek feedback is modeless and may have no current modal dialog.
            # Never close or shift focus while any options/chapter menu is open.
            controls=(top == 12901 or (top in (-1, 0, 9999, 10115)
                       and self.kodi.getCondVisibility('Window.IsVisible(videoosd)')))
            feedback=(top in (-1, 0, 9999, 10115) and self.kodi.getCondVisibility('Window.IsVisible(seekbar)'))
            if not controls and not feedback:
                self.reset();return
            if self.kodi.getCondVisibility('Player.Paused | Player.Caching | Player.Forwarding | Player.Rewinding'):
                self.reset();return
            now=self.clock()
            idle=self.kodi.getGlobalIdleTime()
            if idle < delay:
                self.gui.Window(10000).clearProperty(HIDDEN)
            # Recent actual seeks extend the timer, rather than treating an
            # indefinitely retained Player.Seeking flag as fresh remote input.
            if self.kodi.getCondVisibility('Player.HasPerformedSeek(2)'):
                self.reset();return
            if self.visible_since is None:self.visible_since=now
            if now-self.visible_since>=delay and idle>=delay:
                if controls:
                    current_focus = self.gui.Window(12901).getFocusId()
                    if current_focus in (9007, 9020, 9021):
                        focus = 9001 if current_focus == 9007 or self.kodi.getCondVisibility('Player.PauseEnabled') else 9002
                        self.kodi.executebuiltin('SetFocus(%s)' % focus)
                    self.kodi.executebuiltin('Dialog.Close(videoosd)')
                # SeekBar can immediately reopen from retained ShowTime/ShowInfo
                # flags. Suppress only our feedback until input/state changes.
                self.gui.Window(10000).setProperty(HIDDEN, 'true')
                self.visible_since=None
        except Exception:
            self.visible_since=None
