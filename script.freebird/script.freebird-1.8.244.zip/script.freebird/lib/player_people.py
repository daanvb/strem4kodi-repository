"""Cast and director overlay for the current playback session."""
from datetime import date
from hashlib import sha256
from pathlib import Path


def _date(value):
    try:
        return date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


def _complete_credits(data):
    return isinstance(data, dict) and all(isinstance(data.get(k), list) for k in ('cast', 'crew'))


def load_profile(pid, key, request):
    """Fetch both columns by exact person ID; recover a missing appended section."""
    path = 'person/' + pid
    try:
        data = request(key, path, append_to_response='combined_credits')
    except Exception:
        data = {}
    data = dict(data) if isinstance(data, dict) and str(data.get('id')) == pid else {}
    credits = data.get('combined_credits')
    if not _complete_credits(credits):
        try:
            separate = request(key, path + '/combined_credits')
        except Exception:
            separate = {}
        combined = dict(credits) if isinstance(credits, dict) else {}
        for role in ('cast', 'crew'):
            if (isinstance(separate, dict) and str(separate.get('id', pid)) == pid
                    and isinstance(separate.get(role), list)):
                combined[role] = separate[role]
        data['combined_credits'] = combined
    return data


def profile_columns(person, data, today=None):
    today = today or date.today()
    lines = [person['job']] if person.get('job') else []
    born, died = _date(data.get('birthday')), _date(data.get('deathday'))
    if born:
        end = died or today
        age = end.year - born.year - ((end.month, end.day) < (born.month, born.day))
        lines.append('Born %s  ·  %s %d' % (born.strftime('%d %B %Y'),
                     'Age at death' if died else 'Age', age))
    if died:
        lines.append('Died ' + died.strftime('%d %B %Y'))
    if data.get('place_of_birth'):
        lines.append('Place of birth: ' + data['place_of_birth'])
    aliases = data.get('also_known_as')
    if isinstance(aliases, list):
        names = list(dict.fromkeys(name.strip() for name in aliases if isinstance(name, str) and name.strip()))
        if names:
            lines.append('Also known as: ' + ', '.join(names))
    if data.get('biography'):
        lines.append(data['biography'])
    bio = '\n\n'.join(lines) or 'No biography available.'
    return bio, _filmography_text(data.get('combined_credits'))


def _filmography_text(credits):
    credits = credits if isinstance(credits, dict) else {}
    films = []
    seen = set()
    for section in ('cast', 'crew'):
        rows = credits.get(section)
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict) or row.get('adult'):
                continue
            role = row.get('job') if section == 'crew' else row.get('character')
            if section == 'crew' and role != 'Director':
                continue
            title = row.get('title') or row.get('name') or row.get('original_title') or row.get('original_name')
            if not title:
                continue
            released = row.get('release_date') or row.get('first_air_date') or ''
            media = {'tv': 'TV', 'movie': 'Film'}.get(row.get('media_type'), '')
            identity = (row.get('media_type'), row.get('id') or (title, released), section, role)
            if identity in seen:
                continue
            seen.add(identity)
            films.append((released, '  ·  '.join(filter(None, [released[:4], title, media, role]))))
    films.sort(key=lambda credit: credit[0], reverse=True)
    film_text = '\n'.join(line for _, line in films)
    if not _complete_credits(credits):
        film_text = (film_text + '\n\n' if film_text else '') + 'Full filmography unavailable.'
    return film_text or 'No acting or directing credits available.'


def episode_roster(credits, photo):
    directors = [p for p in credits.get('crew', []) if p.get('job') == 'Director']
    entries = directors + credits.get('cast', []) + credits.get('guest_stars', [])
    return [dict(name=p['name'], job=p.get('character') or p.get('job'),
                 tmdb_person_id=p.get('id'), poster=photo(p.get('profile_path')))
            for p in entries if p.get('name')]


def show():
    import xbmc
    import xbmcgui
    import xbmcvfs
    from account import Store
    from addon_state import get_addon
    from lib.backend import details, providers
    from lib.player_controls import menu_session_active
    from lib.ui_dialogs import dialog as themed_dialog
    from lib.theme import window
    from lib.title_metadata import people
    from metadata_bridge import cast_menu
    from tmdb_metadata import request, identity as tmdb_identity, photo

    addon = get_addon()
    player = xbmc.Player()
    file = player.getPlayingFile()
    context = Store(Path(xbmcvfs.translatePath(addon.getAddonInfo('profile'))) / 'playback').load()
    if context.get('url_hash') != sha256(file.encode()).hexdigest():
        return
    kind, identity = context.get('kind'), str(context.get('id') or '').split(':')[0]
    if kind not in ('movie', 'series') or not identity:
        return
    meta = dict(details(kind, identity, providers=providers('metadata')) or {}, type=kind, id=identity)
    people_rows = cast_menu(meta, people)
    # Series metadata describes the whole show. Prefer episode-specific credits
    # when the provider supplies them, including guest stars and its director.
    key = addon.getSetting('tmdb_api_key').strip()
    season, episode = xbmc.getInfoLabel('VideoPlayer.Season'), xbmc.getInfoLabel('VideoPlayer.Episode')
    if key and kind == 'series' and season.isdecimal() and episode.isdecimal():
        try:
            resolved = tmdb_identity(meta, key)
            if resolved:
                credits = request(key, 'tv/%s/season/%s/episode/%s/credits' % (resolved[1], season, episode))
                episode_rows = episode_roster(credits, photo)
                if episode_rows:
                    people_rows = episode_rows
        except Exception:
            pass
    if not menu_session_active(player, file):
        return
    if not people_rows:
        themed_dialog().notification('Cast & Director', 'No credits available for this title.')
        return
    class Panel(xbmcgui.WindowXMLDialog):
        def onInit(self):
            self.detail = False
            self.profiles = {}
            self.roster = self.getControl(50)
            items = []
            for person in people_rows:
                item = xbmcgui.ListItem(person['name'], person.get('job') or '')
                item.setArt({'thumb': person.get('poster') or 'DefaultActor.png'})
                items.append(item)
            self.roster.addItems(items)
            self.setFocus(self.roster)

        def onClick(self, control):
            if control != 50 or self.detail:
                return
            if not menu_session_active(player, file):
                self.close()
                return
            position = self.roster.getSelectedPosition()
            if not 0 <= position < len(people_rows):
                return
            person = people_rows[position]
            pid = str(person.get('tmdb_person_id') or '')
            data = self.profiles.get(pid)
            if data is None and pid.isdecimal() and key:
                data = load_profile(pid, key, request)
                if data.get('id') and _complete_credits(data.get('combined_credits')):
                    self.profiles[pid] = data
            if not menu_session_active(player, file):
                self.close()
                return
            data = data or {}
            self.detail = True
            self.setProperty('profile', 'true')
            self.getControl(52).setImage(person.get('poster') or photo(data.get('profile_path')) or 'DefaultActor.png')
            self.getControl(53).setLabel(data.get('name') or person['name'])
            bio, credits = profile_columns(person, data)
            self.getControl(54).setText(bio)
            self.getControl(57).setText(credits)
            self.getControl(57).scroll(0)
            self.getControl(54).scroll(0)
            self.setFocusId(55)

        def onAction(self, action):
            if action.getId() in (10, 92, 216, 247):
                if self.detail:
                    self.detail = False
                    self.clearProperty('profile')
                    self.setFocus(self.roster)
                else:
                    self.close()

    dialog = window(Panel, 'script-freebird-player-people.xml', addon.getAddonInfo('path'), 'Main', '1080i')
    home = xbmcgui.Window(10000)
    home.setProperty('strem4kodi.player.people', 'true')
    try:
        dialog.doModal()
    finally:
        home.clearProperty('strem4kodi.player.people')
