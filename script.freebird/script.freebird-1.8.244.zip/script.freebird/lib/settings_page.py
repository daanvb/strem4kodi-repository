"""Addon-owned full-screen settings UI for Strem4Kodi."""
from pathlib import Path
import textwrap

import xbmc
import xbmcgui
import xbmcvfs

from addon_state import get_addon
from account import Store
from lib.credits_sync import summary as credits_summary
from lib.saved_lists_sync import summary as lists_summary
from lib.home_state_sync import summary as home_state_summary
from lib.format_sync import summary as formats_summary
from lib.theme import window as themed_window
from lib.ui_dialogs import dialog as themed_dialog

ADDON = get_addon()
PROFILE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")))
BACK = (10, 92, 216, 247)

THEMES = ("Charcoal", "Black", "Blue", "Green", "Gold", "Purple")
FOCUS = ("Original", "Purple", "Blue", "Green", "Gold", "Theme")
START_DELAYS = ("Immediately", "1 second", "2 seconds", "3 seconds", "5 seconds")
TRAILER_QUALITY = ("1080p", "720p", "480p")
TRAILER_SCOPE = ("While browsing and on details pages", "While browsing only", "On details pages only")
TRAILER_DELAY = ("3 seconds", "5 seconds", "10 seconds", "15 seconds", "30 seconds", "1 second")
CATEGORIES = (
    ("General", "general"), ("Profiles", "profiles"), ("Account & Stremio", "account"),
    ("Providers", "providers"), ("Sources", "sources"), ("Auto Play", "autoplay"),
    ("Playback", "playback"), ("Subtitles", "subtitles"), ("Skip & Up Next", "episodes"),
    ("Trailers", "trailers"), ("Appearance", "appearance"), ("Ratings", "ratings"),
    ("API keys", "api"), ("Cache", "cache"), ("Troubleshooting", "diagnostics"),
)
CATEGORY_HELP = {
    'profiles': 'Switch viewer, create an empty profile or copy Master.',
    'api': 'Connect optional rating and metadata services.',
    'providers': 'Choose add-ons for catalogues, title details and streams.',
    'general': 'Language, region and startup preferences.',
    'account': 'Sign-in, saved lists and sharing between devices.',
    'playback': 'Player behaviour and audio/video output.',
    'sources': 'Stream quality, audio, language and provider preferences.',
    'autoplay': 'Automatic source selection for movies and series.',
    'trailers': 'Preview timing, quality and where trailers play.',
    'episodes': 'Intros, credits and next-episode behaviour.',
    'subtitles': 'Subtitle language, appearance and automatic selection.',
    'appearance': 'Theme, browsing layout and what appears on screen.',
    'ratings': 'Choose which scores appear for titles and episodes.',
    'cache': 'How long responses are kept and how to clear them.',
    'diagnostics': 'Playback tests, request status and performance details.',
    'exit': 'Press OK to close freeBird and return to Kodi.',
}

# Concise descriptions for the two-line panel. Full explanations remain on
# each row for the Details reader, including limitations and safety guidance.
HELP_PREVIEWS = {
    'review_progress_conflicts': 'Review pending watch-progress differences without switching profiles.',
    'viewer_profiles': 'Switch, create, rename or remove viewer profiles.',
    'startup_autostart': 'Open freeBird automatically when Kodi starts.',
    'startup_delay': 'Choose how long to wait before launching automatically.',
    'discover_opening': 'Choose which list opens in Discover.',
    'locale_language': 'Choose the preferred language for title information.',
    'locale_region': 'Choose the region used for regional title information.',
    'account_refresh': 'Refresh the library and retry queued progress uploads.',
    'account_disconnect': 'Sign out on this device and remove its account-synced add-ons.',
    'account_signin': 'Sign in to Stremio using a QR code.',
    'device_setup_publish': 'Copy portable preferences and API keys to your private setup server.',
    'device_setup_enroll': 'Import preferences and API keys from your private setup profile.',
    'device_setup_undo': 'Restore the settings backed up before device setup.',
    'device_setup_server': 'Enter the HTTPS address of your private setup server.',
    'addons': 'Manage the add-ons connected to your Stremio account.',
    'lists_github_enabled': 'Share saved lists and Home state using private sync.',
    'formats_github_enabled': 'Share known source formats with your other devices.',
    'credits_github_enabled': 'Share learned credits timings with your other devices.',
    'credits_github_token': 'Enter the token used for private sync and diagnostics.',
    'manifest': 'Choose the fallback catalogue used by compatibility views.',
    'auto_source_attempts': 'Limit how many sources Auto Play tries before returning to the picker.',
    'kodi_buffering': 'Open Kodi’s device-wide stream caching settings.',
    'unpause_rewind_enabled': 'Rewind a little when you resume after a long pause.',
    'unpause_rewind_pause': 'Set the minimum pause before an automatic rewind.',
    'unpause_rewind_seconds': 'Set how far playback rewinds when you unpause.',
    'resume_rewind_seconds': 'Start slightly before saved progress when resuming.',
    'coreelec_preset': 'Reduce interface work on slower devices.',
    'source_sort': 'Choose the order of sources in the manual picker.',
    'source_group_duplicates': 'Group matching releases so you can choose between providers.',
    'source_quality': 'Prefer a resolution when ranking sources.',
    'source_max_quality': 'Hide sources above this device’s maximum resolution.',
    'source_dynamic': 'Prefer a reported video format when ranking sources.',
    'source_type': 'Prefer a release type when ranking sources.',
    'source_provider': 'Prefer a provider in the manual source picker.',
    'source_audio': 'Prefer an audio format in the manual source picker.',
    'source_language': 'Prefer sources reporting this audio language.',
    'source_remember_filters': 'Keep source-picker filters between visits.',
    'fel_labels': 'Show reported and community FEL hints on sources.',
    'trailers_enabled': 'Allow manual trailers and automatic previews.',
    'trailers_quality': 'Choose the preferred resolution for trailers.',
    'trailers_auto': 'Play a preview after you pause on an eligible title.',
    'trailers_auto_scope': 'Choose where automatic previews can play.',
    'trailers_delay': 'Set how long to wait before starting a preview.',
    'up_next_enabled': 'Show the next episode card near the end of an episode.',
    'up_next_autoplay': 'Play the next aired episode when playback ends naturally.',
    'up_next_smart': 'Estimate credits timing when an episode has no marker.',
    'up_next_lead': 'Choose when to show Up Next if no credits timing is available.',
    'introdb_enabled': 'Show skip buttons for community-marked segments.',
    'introdb_intro': 'Show Skip Intro when an intro marker is available.',
    'introdb_recap': 'Show Skip Recap when a recap marker is available.',
    'introdb_outro': 'Show Skip Outro when an outro marker is available.',
    'introdb_post_credits': 'Show Skip Post-Credits when a marker is available.',
    'playback_back_action': 'Choose what Back does during fullscreen video.',
    'prerolls_enabled': 'Play a short audio introduction before eligible movies.',
    'prerolls_dts': 'Choose whether DTS movies get a Dolby introduction.',
    'scrub_commit': 'Choose whether releasing or pressing OK confirms a seek.',
    'playback_controls_hide': 'Set when playback controls hide after inactivity.',
    'chaptersdb_enabled': 'Offer ChaptersDB chapters when embedded chapters are unavailable.',
    'subtitles_default_off': 'Start videos with full subtitles off.',
    'forced_subtitles_mode': 'Choose whether to select forced subtitles automatically.',
    'forced_subtitles_language': 'Choose the language used for automatic forced subtitles.',
    'live_tv_setup': 'Manage broadcaster sign-in, Widevine and BBC picture quality.',
    'player_skin': 'Open Kodi’s skin settings for the matching player appearance.',
    'catalogue_layout': 'Choose poster or wide thumbnails for each catalogue.',
    'ui_theme': 'Choose the colours used in freeBird windows.',
    'ui_focus_color': 'Choose the accent for focused controls; cards enlarge without a coloured frame.',
    'ui_animations': 'Show animated transitions in freeBird.',
    'ui_dim_rows': 'Dim content while the side menu is selected.',
    'ui_show_logo': 'Show a graphic title logo when available.',
    'episode_spoilers': 'Choose how unwatched episode artwork is displayed.',
    'ui_show_plot': 'Show descriptions for the highlighted title.',
    'ui_show_rating': 'Show rating badges for titles.',
    'ui_show_genres': 'Show genres for the highlighted title.',
    'ui_show_runtime': 'Show the running time for the highlighted title.',
    'rating_mdblist': 'Show the MDBList score for movies and series.',
    'episode_rating_mdblist': 'Show MDBList episode scores when available.',
    'rating_letterboxd': 'Show Letterboxd ratings supplied by MDBList.',
    'cache_clear_selected_custom': 'Choose one category of cached responses to clear.',
    'cache_clear_all_custom': 'Clear cached responses and freeBird artwork.',
    'cache_size': 'Limit the disk space used by cached provider responses.',
    'artwork_refresh': 'Fetch preferred artwork again for the current page.',
    'tmdb_api_key': 'Enter your TMDB key for photos, recommendations and episode ratings.',
    'mdblist_api_key': 'Enter your MDBList key for lists and additional ratings.',
    'live_football_api_key': 'Enter your key for verified football kick-off times.',
    'diagnostics_github_enabled': 'Save and upload private playback diagnostic reports.',
    'source_search_timings': 'View the latest saved source-search timing report.',
    'source_search_report': 'Review the latest source-search report before sending it.',
    'send_diagnostics': 'Capture and send a private diagnostic report.',
    'report_wrong_episode': 'Report the playing release as the wrong episode.',
    'undo_wrong_episode': 'Remove a previous wrong-episode report.',
    'clear_failed_sources': 'Allow previously blacklisted links to be tried again.',
}

AUTO_HELP_PREVIEWS = {
    'mode': 'Choose manual selection, a highlighted recommendation or Auto Play.',
    'priority': 'Choose best available quality or the fastest suitable start.',
    'quality': 'Choose the resolution preferred by this profile.',
    'dynamic': 'Choose the video format preferred by this profile.',
    'source_type': 'Choose the release type preferred by this profile.',
    'language': 'Choose the audio language preferred by this profile.',
}


def information_pages(text, width=58):
    """Fixed readable pages for long diagnostics, without scrolling text."""
    lines = []
    for paragraph in str(text or '').splitlines():
        lines.extend(textwrap.wrap(paragraph, width=width) or [''])
    return ['\n'.join(lines[i:i + 12]) for i in range(0, len(lines), 12)] or ['No further details.']


def help_preview(row):
    """Two conservatively wrapped lines; the Info hint has its own control."""
    identity = row.get('id', '') or row.get('action', '')
    text = HELP_PREVIEWS.get(identity)
    for profile in ('movie', 'series', 'animation'):
        prefix = 'auto_' + profile + '_'
        if identity.startswith(prefix):
            text = AUTO_HELP_PREVIEWS.get(identity[len(prefix):], text)
            break
    if not text and identity.startswith('episode_rating_'):
        text = 'Show episode scores from ' + row.get('label', '').rsplit(' - ', 1)[-1] + ' when available.'
    elif not text and identity.startswith('rating_'):
        text = 'Show movie and series ratings from ' + row.get('label', '').rsplit(' - ', 1)[-1] + '.'
    elif not text and identity.startswith('cache_ttl:'):
        text = 'Choose how long to keep these responses before fetching fresh data.'
    text = text or row.get('help', '')
    value = summary(row)
    if value and len(value) > 30:
        text = str(value) + '\n' + text
    lines = information_pages(text, width=44)[0].splitlines()
    return '\n'.join(lines[:2]) + ('...' if len(lines) > 2 else '')


def status_color(row):
    """Health colours describe statuses, never whether a preference is on/off."""
    if row.get('kind') != 'info' and row.get('action') != 'review_progress_conflicts':
        return ''
    if row.get('health') in ('ok', 'error'):
        return 'FF75DE9B' if row['health'] == 'ok' else 'FFFF8C8C'
    value = str(row.get('summary') or '').strip().lower()
    if value in ('connected', 'ready', 'synced', 'updated', 'cached', 'active', 'uploaded to private github', 'source-search report uploaded and verified') or value.startswith('synced ') or value == 'shared format database up to date':
        return 'FF75DE9B'
    if value in ('off', 'idle', 'not recorded', 'no requests recorded', 'other playback', 'included in viewer sync', 'saved on this device', 'profiles not enabled', 'not sent', 'source-search upload cancelled', 'no source-search measurements to upload') or 'pending' in value or value.startswith('waiting '):
        return ''
    sync = row.get('label') in ('Account sync', 'Progress upload status', 'Stremio account', 'Viewer sync',
                              'Saved lists sync', 'Home state sync', 'Format database sync', 'Smart credits sync',
                              'Diagnostic export', 'Source-search upload')
    if sync or value == 'failed' or any(term in value for term in ('not connected', 'unavailable', 'required', 'no eligible installed add-ons')):
        return 'FFFF8C8C'
    return ''


def _enum(setting, label, values, help_text):
    return {"kind": "enum", "id": setting, "label": label, "values": values, "help": help_text}


def _bool(setting, label, help_text):
    return {"kind": "bool", "id": setting, "label": label, "help": help_text}


def _action(action, label, help_text, summary="Open"):
    return {"kind": "action", "action": action, "label": label, "help": help_text, "summary": summary}


def _secret(setting, label, help_text):
    return {"kind": "secret", "id": setting, "label": label, "help": help_text}


def _text(setting, label, help_text):
    if setting.startswith('auto_') and setting.rsplit('_', 1)[-1] in ('provider', 'language'):
        from lib.preference_choices import choices
        from addons_core import active_addons
        base = 'source_' + setting.rsplit('_', 1)[-1]
        labels, values, _ = choices(base, '', list(active_addons(Store(PROFILE).load())))
        from lib.source_preferences import preferences
        inherited = preferences(ADDON)[setting.rsplit('_',1)[-1]] or 'Any provider'
        labels = ['Source preferences · ' + inherited] + labels
        values = ['__inherit__'] + ['__any__' if v in ('', 'Any') else v for v in values]
        current = ADDON.getSetting(setting) or '__inherit__'
        if current not in values:values.append(current);labels.append(current)
        return _choice(setting, label, labels, values, values.index(current), help_text)
    if setting in ('source_provider', 'source_language', 'manifest'):
        from lib.preference_choices import choices
        from addons_core import active_addons
        labels, values, selected = choices(setting, ADDON.getSetting(setting).strip(), list(active_addons(Store(PROFILE).load())))
        return _choice(setting, label, labels, values, selected, help_text)
    return {"kind": "text", "id": setting, "label": label, "help": help_text}


def _info(label, summary, help_text):
    return {"kind": "info", "label": label, "summary": summary, "help": help_text}


def _viewer_sync_summary(profile, addon, viewer, connected):
    if not viewer:
        return 'Profiles not enabled'
    if addon.getSetting('lists_github_enabled') != 'true':
        return 'Saved on this device'
    if not connected:
        return 'Connect Stremio first'
    if not addon.getSetting('credits_github_token').strip():
        return 'Add a private GitHub sync token'
    return Store(profile/'viewer-sync-status').load().get('status') or 'Waiting for first viewer sync'


def _diagnostic_export_summary(export, addon):
    if addon.getSetting('diagnostics_github_enabled') != 'true':
        return 'Off'
    if not addon.getSetting('credits_github_token').strip():
        return 'Add a private GitHub sync token'
    return export.get('status') or 'Waiting for first report'


def _progress_upload_summary(profile, connected):
    if not connected:
        return 'Not connected'
    return Store(profile/'progress-sync-status').load().get('error') or 'Ready'


def _choice(identity, label, labels, values, selected, help_text):
    return {
        "kind": "choice", "id": identity, "label": label,
        "labels": tuple(labels), "values": tuple(values), "selected": int(selected),
        "summary": str(labels[selected]) if labels and 0 <= selected < len(labels) else "Choose",
        "help": help_text,
    }


def _kodi(setting, label, help_text):
    return {"kind": "kodi", "id": setting, "label": label, "help": help_text}


def _kodi_definition(setting_id):
    try:
        from setup_profile import rpc
        settings = rpc("Settings.GetSettings", {"level": "expert"}).get("settings", [])
        return next((item for item in settings if item.get("id") == setting_id), None)
    except Exception:
        return None


def _kodi_options(definition):
    if not definition:
        return []
    try:
        from settings_ui import setting_options
        return setting_options(definition)
    except Exception:
        return []


def _kodi_rows():
    return [
        _kodi("subtitles.fontsize", "Subtitle text size", 'Set Kodi’s text-subtitle size for playback on this device. Image-based subtitles keep their original appearance.'),
        _kodi("subtitles.fontname", "Subtitle font", 'Choose Kodi’s font for text subtitles on this device. Image-based subtitles are unaffected.'),
        _kodi("subtitles.style", "Subtitle style", 'Choose normal, bold or italic text subtitles where supported. Applies to Kodi playback on this device.'),
        _kodi("subtitles.colorpick", "Subtitle color", 'Choose Kodi’s text-subtitle colour on this device. Embedded styles may take priority unless overridden below.'),
        _kodi("subtitles.align", "Subtitle position", 'Choose where Kodi places text subtitles vertically on this device.'),
        _kodi("subtitles.backgroundtype", "Background style", 'Choose whether Kodi draws a background behind text subtitles and which style it uses.'),
        _kodi("subtitles.bordercolorpick", "Border color", 'Choose the outline colour around Kodi’s text subtitles.'),
        _kodi("subtitles.bgcolorpick", "Background color", 'Choose the colour behind Kodi’s text subtitles when a background is enabled.'),
        _kodi("subtitles.shadowcolor", "Shadow color", 'Choose the shadow colour for Kodi’s text subtitles.'),
        _kodi("subtitles.overridestyles", "Override embedded styles", 'Choose whether Kodi replaces styles embedded in subtitle files with your settings above. Applies to Kodi playback on this device.'),
    ]


def _rows_for(category):
    if category == 'profiles':
        from lib.viewer_profiles import state
        viewer=state(PROFILE)
        name=viewer.get('records',{}).get(viewer.get('active'),{}).get('name','Set up')
        return [_action('viewer_profiles','Switch or manage profiles',
                        'Switch viewers, rename profiles, or create an empty profile or an independent copy of Master.',name)]
    if category == "general":
        from lib.settings import load_setup
        from lib.windows import LANGUAGES, REGIONS
        setup = load_setup()
        language = setup.get("language") or LANGUAGES[0]
        region = setup.get("region") or REGIONS[0]
        language_index = next((i for i, row in enumerate(LANGUAGES) if tuple(row) == tuple(language)), 0)
        region_index = next((i for i, row in enumerate(REGIONS) if tuple(row) == tuple(region)), 0)
        return [
            _bool("startup_autostart", "Launch when Kodi starts", 'Open freeBird automatically when Kodi starts. Startup delay below controls how long Kodi waits.'),
            _enum("startup_delay", "Startup delay", START_DELAYS, 'Wait this long after Kodi starts before opening freeBird. Applies only when Launch when Kodi starts is on.'),
            _action('discover_opening', 'Discover opening list', 'Choose a movie or series list, Most Anticipated, or the last visited list. Applies when opening Discover from the sidebar and is saved on this device.'),
            _choice("locale_language", "Language", [row[0] for row in LANGUAGES], LANGUAGES,
                    language_index, 'Choose the preferred language for freeBird metadata. This does not change Kodi’s interface language or the audio language of streams.'),
            _choice("locale_region", "Location / region", [row[0] for row in REGIONS], REGIONS,
                    region_index, 'Choose the region used for regional metadata and age-rating preferences. This does not change stream availability.'),
        ]
    if category == "account":
        token=Store(PROFILE).load().get("token")
        connected = bool(token)
        from lib.progress_outbox import summary
        sync_status=summary(PROFILE,token)
        from lib.viewer_profiles import state as viewer_state
        viewer=viewer_state(PROFILE)
        viewer_status = _viewer_sync_summary(PROFILE, ADDON, viewer, connected)
        rows = [
            _action('review_progress_conflicts', 'Viewer sync', 'Select to review pending progress conflicts without switching profiles. Viewer profiles sync through the private GitHub saved-list sync option. Each device keeps its own selected viewer.', viewer_status),
            _info("Account sync", sync_status, 'Playback progress is saved every 30 seconds. With viewer profiles enabled, progress is kept locally and private GitHub viewer sync runs about once a minute while playback is idle. Otherwise Stremio supplies shared watch progress. Pending updates are queued watch-progress changes, not app updates.'),
            _info("Progress upload status", _progress_upload_summary(PROFILE, connected), 'Shows the last watch-progress upload result. Failed changes remain queued and retry automatically. Sync account now requests another attempt.'),
            _info("Stremio account", "Connected" if connected else "Not connected",
                  'Shows whether this device is signed in. The account supplies your library, installed addons and shared watch progress.'),
        ]
        rows += ([
            _action("account_refresh", "Sync account now", 'Refresh your Stremio library and retry queued watch-progress uploads in the background. Library refresh runs when playback is idle; check Account sync for the result.', "Sync"),
            _action("account_disconnect", "Disconnect this device", 'Sign out on this device and remove its account-synced addons. Other devices remain signed in.', "Disconnect"),
        ] if connected else [
            _action("account_signin", "Connect Stremio account", 'Sign in using the QR code. Use the same Stremio account on every device to share your library and watch progress.', "Connect"),
        ])
        rows += [
            _action('device_setup_publish', 'Copy setup profile from this device', 'Approve the export on your phone. Send portable freeBird preferences and API keys to your private setup server. Use your Shield as the master. Account sessions, audio, display and custom remote keymaps are excluded.'),
            _action('device_setup_enroll', 'Set up this device from my profile', 'Pair with your private setup server to import the master preferences and API keys. Existing settings are backed up first.'),
            _action('device_setup_undo', 'Undo device setup', 'Restore the settings backed up before setup, preserving changes you made afterwards.'),
            _text('device_setup_server', 'Private setup server', 'HTTPS address for your private setup service. No API keys or pairing secrets belong in this address.'),
            _bool("lists_github_enabled", "Sync saved lists and Home", 'Share Favourites, Watch Later, Continue Watching removals and You May Also Like cards through your private GitHub repository. Enable this and add the private GitHub sync token on each device using the same Stremio account. Saved titles and progress still sync through Stremio.'),
            _info("Saved lists sync", lists_summary(PROFILE, ADDON), 'Shows private GitHub tag sync status. Changes normally sync within a minute while Kodi is running. Each device needs this option enabled and access to the same private repository.'),
            _info("Home state sync", home_state_summary(PROFILE, ADDON), 'Shows whether Continue Watching removals and You May Also Like cards reached your private GitHub repository. Enable Sync saved lists and Home on every client.'),
            _bool("formats_github_enabled", "Share format database between devices", 'Reuse technical format information on every device through your existing private GitHub sync repository. Uses the same private GitHub token. No stream links, credentials or watch progress are shared. Known formats are retained; opening a title can refresh them within the existing request budget.'),
            _info("Format database sync", formats_summary(PROFILE, ADDON), 'Local lookups need no network. Sharing requires the private GitHub sync token on each device. Updates run at startup and every five minutes.'),
            _bool("credits_github_enabled", "Sync smart credits between devices", 'Share learned credits timings and series overrides between your devices using the same private GitHub repository. Add a private GitHub sync token under API keys on each device. Stremio watch-progress sync is separate.'),
            _secret("credits_github_token", "Private GitHub sync token", 'Add a fine-grained GitHub token for the private freeBird-sync repository with Contents read/write access. Use the same repository on each device and enable the desired list/credits sync under Account & Stremio. Opens the Kodi keyboard for phone-app typing or pasting.'),
            _info("Smart credits sync", credits_summary(PROFILE, ADDON), 'Shows the status of learned credits and series-override sharing. Each device needs smart credits sync enabled and access to the same private GitHub repository. Watch progress uses Stremio separately.'),
        ]
        viewer_color = status_color(rows[0])
        for row in rows:
            if row.get('label') in ('Saved lists sync', 'Home state sync') and row.get('summary') == 'Included in viewer sync':
                row['health'] = {'FF75DE9B': 'ok', 'FFFF8C8C': 'error'}.get(viewer_color, '')
        order = ('Stremio account', 'account_signin', 'account_refresh', 'account_disconnect',
                 'Account sync', 'Progress upload status', 'review_progress_conflicts',
                 'lists_github_enabled', 'Saved lists sync', 'Home state sync',
                 'formats_github_enabled', 'Format database sync', 'credits_github_enabled',
                 'Smart credits sync', 'device_setup_server',
                 'device_setup_enroll', 'device_setup_publish', 'device_setup_undo')
        positions = {key: index for index, key in enumerate(order)}
        return sorted(rows, key=lambda row: positions.get(row.get('id') or row.get('action') or row.get('label'), len(order)))
    if category == 'autoplay':
        rows = []
        for scope, label in (('movie', 'Movies'), ('series', 'Series'), ('animation', 'Animated series')):
            for row in _category_rows('auto_' + scope):
                if row['kind'] == 'info':
                    continue
                row['label'] = label + ' · ' + row['label']
                rows.append(row)
        rows.append(_enum('auto_source_attempts', 'Maximum automatic attempts', ('3 sources', '5 sources', '10 sources', '25 sources'), 'Try up to this many different eligible sources when automatic playback fails. Confirmed failed links stay blacklisted across searches and app restarts until explicitly reset in Troubleshooting. Different links for the same release remain available. If attempts run out, open the source picker to choose another source.'))
        return rows
    if category in ('auto_movie', 'auto_series', 'auto_animation'):
        return [
            _enum(category + '_mode', 'Source selection', ('Off — choose manually', 'Highlight best match', 'Auto play best match'), 'Off opens the source picker. Choose Best available quality for the full technical hierarchy or Fastest start for the first suitable source. Highlight best match waits for completed results without starting playback. Known episode conflicts and failed sources are excluded first. Maximum stream quality and manual filters still apply. Cached complete searches are reused.'),
            _enum(category + '_priority', 'Auto Play priority', ('Best available quality', 'Fastest start'), 'Preferred source provider applies first after episode checks, quality limits, filters and language rules. Best available quality waits for the completed search and ranks eligible sources within that provider. Fastest start takes its first suitable healthy arrival; other providers wait until the search completes and the preferred provider has no eligible healthy result. With no preferred provider, Fastest start can use any suitable arrival. Recent confirmed successful sources can be reused within the eligible provider shortlist. Comparable episode titles still require a matching filename for early playback.'),
            _enum(category + '_quality', 'Preferred quality', ('Use source preferences', 'Any', '4K', '1080p', '720p'), 'Prefer this resolution within the same video-format tier. Any chooses the highest reported resolution within Maximum stream quality. Resolution comes before source type, audio, bitrate, size and provider.'),
            _enum(category + '_dynamic', 'Preferred video format', ('Use source preferences', 'Any', 'Dolby Vision', 'HDR10', 'P7 / FEL reported'), 'Automatic hierarchy: P7 or FEL reported, Dolby Vision, HDR10+, HDR10, other HDR, SDR, then unreported. P7 and FEL reports share the top tier; original labels stay visible. A chosen format family leads its tier. Reports do not prove FEL or device compatibility.'),
            _enum(category + '_source_type', 'Preferred source type', ('Use source preferences', 'Any', 'Remux', 'Blu-ray', 'WEB-DL', 'WEBRip', 'HDTV'), 'Automatic hierarchy: Remux, Blu-ray encode, WEB-DL, WEBRip, HDTV, then other or unreported. An explicit preferred type leads this stage; other types remain fallbacks. Applies equally to movies and series.'),
            _text(category + '_language', 'Preferred audio language', 'Prefer streams reporting this audio language for this profile. Use source preferences inherits Sources; Any removes the language preference. Unknown languages can still be used.'),
        ]
    if category == "playback":
        return [
            _action('live_tv_setup', 'Live TV setup', 'Manage ITVX sign-in, Widevine playback support and BBC picture quality on this device.'),
            _action('kodi_buffering', 'Stream buffering', 'Open Kodi Services settings, then Caching (Advanced settings level). Buffer internet streams and choose a modest memory size. More buffering can smooth short connection dips but adds live delay and cannot fix a persistently slow source. These are device-wide settings; adaptive streams may manage their own buffers.'),
            _bool("unpause_rewind_enabled", "Unpause rewind", 'After a long pause, rewind once as you press Play. Only affects freeBird movies and episodes. Manual seeks cancel the recap; live TV and pre-rolls are unaffected.'),
            _enum("unpause_rewind_pause", "Rewind after pausing for", ("5 seconds", "10 seconds", "15 seconds", "30 seconds", "1 minute", "2 minutes", "5 minutes"), 'Minimum pause duration before a recap rewind. Playback stays paused until you press Play.'),
            _enum("unpause_rewind_seconds", "Rewind on resume by", ("3 seconds", "5 seconds", "7 seconds", "10 seconds", "12 seconds", "15 seconds", "20 seconds", "30 seconds"), 'How far to rewind when you press Play after the minimum pause duration. Stops at the beginning of the video.'),
            _enum("resume_rewind_seconds", "Rewind when resuming saved progress", ("Off", "3 seconds", "5 seconds", "10 seconds", "15 seconds", "20 seconds", "30 seconds", "1 minute"), 'Start this much before your saved position when resuming a movie or episode, including from Continue Watching. Independent of Unpause rewind. Applies once before playback starts, stops at the beginning and does not change saved progress until playback is recorded normally. Play from beginning, new episodes, live streams and pre-rolls are unaffected.'),
            _enum("source_sort", "Source order", ("Recommended", "Provider order", "Smallest first", "Largest first", "Highest bitrate first"), 'Manual picker order. Autoplay uses its technical hierarchy within the preferred provider when one is selected. Best available quality breaks technical ties with reported TorBox (TB) ahead of Real-Debrid (RD), then AIOStreams for remaining ties. Fastest start keeps arrival order. Highest bitrate sorts reported rates first, then the largest file. Missing rates and sizes follow known values.'),
            _bool("source_group_duplicates", "Group duplicate releases", 'Combine releases with the same filename and matching reported video and audio details. Select a grouped release to choose between its providers.'),
            _enum("source_quality", "Preferred stream quality", ("Any", "4K", "1080p", "720p"), 'Prefer this resolution in source ranking. Autoplay Any selects the highest reported resolution within Maximum stream quality, after video format. This is a preference; Maximum stream quality is the device ceiling.'),
            _enum("source_max_quality", "Maximum stream quality", ("Any", "4K", "1080p", "720p"), 'Hide known resolutions above this limit on this device, including during autoplay. Sources with unknown resolution remain available. Choose 1080p for a Full HD screen.'),
            _enum("source_dynamic", "Preferred video format", ("Any", "Dolby Vision", "HDR10", "P7 / FEL reported"), 'Rank sources reporting this video format first. P7 and FEL reports are interchangeable preferences; actual labels remain distinct and are not proof of FEL or compatibility.'),
            _enum("source_type", "Preferred source type", ("Any", "Remux", "Blu-ray", "WEB-DL", "WEBRip", "HDTV"), 'Rank sources reporting this release type first. This is a preference, not a filter; other source types remain available as fallbacks.'),
            _text("source_provider", "Preferred source provider", 'Prefer AIOStreams, Usenet or Pengu in manual ranking and Auto Play. Auto Play tries eligible healthy sources from this provider first, ranking their technical quality normally. Other providers remain fallbacks when no eligible healthy preferred source is available. Episode checks, quality limits, filters, language rules and failed-source exclusions apply before this preference.'),
            _enum("source_audio", "Preferred audio", ("Any", "Atmos", "TrueHD", "Dolby Digital Plus", "AAC"), 'Manual source-ranking preference. Autoplay always uses Atmos, TrueHD, DD+, DD, DTS, then other audio. These labels do not establish device support.'),
            _text("source_language", "Preferred audio language", 'Rank streams reporting this audio language first. English is the default. Sources with other or unknown languages remain available.'),
            _bool("source_remember_filters", "Remember source filters", 'Keep your Source, Audio, Video and Quality filters between source-picker visits on this device. Clear filters restores all results within Maximum stream quality.'),
            _bool("fel_labels", "Show FEL source hints", 'Show filename claims and community disc hints for FEL. A disc hint does not confirm that the selected stream contains FEL. The public hints list downloads in the background without sending your viewing history.'),
            _bool("trailers_enabled", "Allow trailers", 'Allow manual trailers and automatic previews where a direct IMDb trailer is available. Turn this off to disable both.'),
            _enum("trailers_quality", "Trailer quality", TRAILER_QUALITY, 'Prefer this trailer resolution when available. Reduced interface load may lower it. This does not change movie or episode playback quality.'),
            _bool("trailers_auto", "Play trailers automatically", 'Start a trailer after focus stays on an eligible title for the selected delay. Requires Allow trailers. Continue Watching items are excluded.'),
            _enum("trailers_auto_scope", "Where to play trailers", TRAILER_SCOPE, 'Choose whether automatic previews run while browsing, on details pages, or both. Requires Allow trailers and Play trailers automatically.'),
            _enum("trailers_delay", "Wait before playing a trailer", TRAILER_DELAY, 'Keep the same title highlighted for this long before its automatic trailer starts. Moving to another item resets the wait.'),
            _bool("up_next_enabled", "Up Next floating card", 'Show a floating card for the next episode when credits begin or the fallback time is reached. Play Next uses that episode’s Auto Play profile.'),
            _bool("up_next_autoplay", "Automatically play next episode", "Start the next aired episode after the current episode ends naturally, using its Auto Play profile and source recovery. A continuous autoplay session stops after three episodes. Dismiss Up Next or stop playback to cancel."),
            _bool("up_next_smart", "Estimate missing credits timing", 'Estimate typical credits length from at least three consistent episodes with IntroDB markers or manually marked credits starts. Use this estimate when an episode has no marker. Manual episode markers and series overrides take priority; smart credits sync shares samples and overrides between devices.'),
            _enum("up_next_lead", "Up Next fallback timing", ("60 seconds", "2 minutes", "3 minutes", "5 minutes"), 'Show Up Next this long before the end only when there is no IntroDB credits marker, series override or reliable learned timing. Short episodes may need a shorter fallback.'),
            _bool("introdb_enabled", "IntroDB skip buttons", 'Enable skip buttons using community timestamps from IntroDB. No API key is needed. Buttons appear only when that episode has a matching marker and its switch below is on.'),
            _bool("introdb_intro", "Show Skip Intro", 'Show Skip Intro during a marked opening sequence. Requires IntroDB skip buttons and an intro marker for the episode.'),
            _bool("introdb_recap", "Show Skip Recap", 'Show Skip Recap during a marked recap. Requires IntroDB skip buttons and a recap marker for the episode.'),
            _bool("introdb_outro", "Show Skip Outro", 'Show Skip Outro during marked closing credits. Requires IntroDB skip buttons and an outro marker for the episode.'),
            _bool("introdb_post_credits", "Show Skip Post-Credits", 'Show Skip Post-Credits during a marked post-credits section. Requires IntroDB skip buttons and a matching marker for the episode.'),
            _enum("playback_back_action", "Back during fullscreen playback", ("Kodi default", "Stop with one press", "Stop with two presses"), 'Choose how Back behaves during fullscreen video on this device. With two presses, press Back again within three seconds to stop and return to browsing. Applies to all Kodi fullscreen videos; player menus keep their normal Back behaviour.'),
            _bool("prerolls_enabled", "Movie audio pre-rolls", 'Play a short Dolby introduction before starting a movie from the beginning. Matches the source’s reported audio, including TrueHD or Digital Plus when known. Prefer SDR and smaller variants of the same clip. Press OK, then Skip pre-roll to start the movie. Back cancels playback. Clips stream from GitHub; a clip that cannot start or stops progressing for ten seconds is skipped. Episodes and resumes skip them.'),
            _enum("prerolls_dts", "DTS movie pre-roll", ("Play Dolby Digital pre-roll", "Skip pre-roll"), 'Choose what to do when the selected movie source reports DTS without a Dolby audio option. This controls the introduction only; it does not convert the movie’s DTS audio.'),
            _enum("scrub_commit", "Scrub seek confirmation", ("Seek on release", "Press OK to seek"), 'Choose how to jump to the time shown above the timeline. Seek on release: move with Left/Right, then let go to jump automatically. Press OK to seek: releasing keeps the preview without moving the video; press OK when ready. Back cancels a pending preview. Tap moves 10 seconds; holding gradually moves faster.'),
            _enum("playback_controls_hide", "Hide playback controls after", ("Kodi default", "5 seconds", "10 seconds", "15 seconds", "3 seconds", "7 seconds", "12 seconds"), 'Hide Kodi’s control bar after this much inactivity during freeBird playback. Controls stay visible while paused, seeking or adjusting audio/subtitle settings. Kodi default leaves hiding to Kodi and your skin. Other Kodi videos are unaffected.'),
            _bool("chaptersdb_enabled", "ChaptersDB fallback", 'When embedded chapters are absent or their start times cannot be read, look up chapter lists on ChaptersDB from the player Settings menu. Choose the matching edition before seeking; chapter timings may differ between releases. Results are cached locally for 24 hours. No account key is sent.'),
        ]

    if category == "subtitles":
        common = [
            _bool("subtitles_default_off", "Start with subtitles off", 'Start freeBird videos without full subtitles, regardless of Kodi’s saved defaults. Automatic forced subtitles below can still enable matching forced tracks. Manual selections are respected. Turn off to retain Kodi’s subtitle defaults.'),
            _enum("forced_subtitles_mode", "Automatic forced subtitles", ("Off", "Embedded tracks only", "Embedded + matching download"), 'Use English forced subtitles for foreign dialogue when full subtitles are off. Prefer marked tracks in the video; downloads require an explicitly forced result with the exact release filename from your Stremio subtitle addons. Manual subtitle choices take priority.'),
            _enum("forced_subtitles_language", "Forced subtitle language", ("English", "Kodi preferred subtitle language"), 'English is the default. Kodi preferred subtitle language follows this device’s Kodi language setting. Forced-only or original uses the active audio language. No subtitles are selected when that language is unknown.'),
        ]
        return common + _kodi_rows()
    if category == "appearance":
        return [
            _action("player_skin", "Player appearance", "freeBird Player is installed alongside the app from our repository on Kodi 21 or later. Choose it under Kodi Interface > Skin to activate the matching playback bar and audio controls. This opens that page; you can switch back to your previous skin there too.", "Kodi skins"),
            _enum("coreelec_preset", "Reduce interface load", ("Normal quality", "Reduced load"), 'Reduce interface animations, trailer resolution and background work for devices that need it. Does not change video decoding or maximum stream quality. Reopen freeBird after changing.'),
            _enum("ui_theme", "Theme", THEMES, 'Choose the colour theme for freeBird windows. Kodi’s own skin is unaffected.'),
            _enum("ui_focus_color", "Focus accent colour", FOCUS, 'Choose the accent for focused controls. Posters and cards enlarge without a coloured selection frame. Theme follows the selected freeBird theme.'),
            _bool("ui_animations", "Animations", 'Animate transitions in freeBird. Turn this off for a steadier interface or lower interface load.'),
            _bool("ui_dim_rows", "Dim rows with side menu", 'Darken the content rows while the side menu has focus, making navigation easier to see.'),
            _bool("ui_show_logo", "Title logos", 'Use a title’s graphic logo when available. A text title is used when no logo is supplied.'),
            _enum("episode_spoilers", "Episode spoiler protection", ("Off", "Blur unwatched episodes", "Blur unless provider artwork"), "Off uses the supplied artwork, including any provider blur. Blur unwatched episodes softens all unwatched thumbnails. Blur unless provider artwork keeps supplied thumbnails untouched and softens fallback artwork only. Watched episodes use the original supplied image."),
            _bool("ui_show_plot", "Descriptions", 'Show the highlighted title’s description on browsing and details pages.'),
            _bool("ui_show_rating", "Ratings", 'Show rating badges in the browsing hero and on details pages. Choose providers under Ratings; episode-card visibility has separate switches there.'),
            _action("catalogue_layout", "Catalogue thumbnails", 'Choose Posters or Wide thumbnails separately for each installed catalogue. Changes apply when you return to browsing.', "Choose"),
            _bool("ui_show_genres", "Genres", 'Show genres alongside the highlighted title’s year and runtime on browsing and details pages.'),
            _bool("ui_show_runtime", "Runtime", 'Show the supplied running time for the highlighted movie or series on browsing and details pages.'),
        ]
    if category == "ratings":
        rows = []
        for key, label in (("imdb", "IMDb"), ("tmdb", "TMDB"), ("trakt", "Trakt"),
                           ("tomatoes", "Rotten Tomatoes"), ("tomatoesaudience", "Popcornmeter"), ("metacritic", "Metacritic")):
            rows.append(_bool("rating_" + key, "Show Movie Rating - " + label,
                              "Show " + label + " ratings on movies and series, and allow them on episode cards. Turning this off also hides this provider on episodes. Scores appear only when supplied; additional title ratings may require the MDbList API key."))
            requirement = ("TMDB episode scores require your TMDB API key." if key == "tmdb" else
                           "The metadata provider must supply an actual episode score. MDbList title ratings cannot supply missing episode scores.")
            rows.append(_bool("episode_rating_" + key, "Show Episode Rating - " + label,
                              "Show " + label + " on episode cards when Show Movie Rating above is on. This does not change movie or series ratings. " + requirement))
        rows += [
            _bool("rating_mdblist", "Show Movie Rating - MDBList score", "Show the MDBList combined score on movies and series, and enable MDBList episode ratings. Requires your MDBList API key."),
            _bool("episode_rating_mdblist", "Show Episode Rating - MDBList", "Show MDBList's episode score when Show Movie Rating - MDBList score is on. Requires an API key from an MDBList Supporter account. Free accounts provide only an overall summary, which is never used as an episode rating. IMDb, TMDB and Rotten Tomatoes switches remain separate."),
            _bool("rating_letterboxd", "Show Movie Rating - Letterboxd", "Show Letterboxd ratings on movies and series when MDbList supplies them. Requires your MDbList API key; episode cards do not use this provider."),
        ]
        return rows

    if category == "cache":
        from lib.cache_policy import GROUPS, setting_id, parse_duration, parse_size, format_duration, format_size
        from lib.maintenance import PRESETS, SIZES
        rows = []
        duration_labels = [format_duration(parse_duration(value)) for value in PRESETS]
        for group, label, default in GROUPS:
            current = ADDON.getSetting(setting_id(group)) or default
            values = list(PRESETS)
            labels = list(duration_labels)
            if current not in values:
                try:
                    labels.append(format_duration(parse_duration(current)))
                    values.append(current)
                except ValueError:
                    current = default
            selected = values.index(current)
            rows.append(_choice("cache_ttl:" + group, label, labels, values, selected,
                                'Keep responses in this category for this long before fetching fresh data. Shorter times update more often; longer times reduce repeated requests.'))
        current_size = ADDON.getSetting("cache_max_mb") or "64"
        size_labels = [format_size(parse_size(value)) for value in SIZES]
        size_values = list(SIZES)
        if current_size not in size_values:
            try:
                size_labels.append(format_size(parse_size(current_size)))
                size_values.append(current_size)
            except ValueError:
                current_size = "64"
        size_selected = size_values.index(current_size)
        rows.append(_choice("cache_size", "Maximum response data", size_labels, size_values, size_selected,
                            'Limit disk space used by cached provider responses. Older entries are removed as needed. Does not limit Kodi’s artwork cache.'))
        rows += [
            _action("cache_clear_selected_custom", "Clear one cache category",
                    'Choose one category of cached responses to remove. New responses are fetched when needed. Sign-in, library and saved playback progress are kept.', "Choose"),
            _action("cache_clear_all_custom", "Clear responses and artwork",
                    'Remove cached responses and freeBird artwork for a fresh reload. Sign-in, library, progress and source-format facts are kept. AIOmetadata and PostersPlus server caches are managed separately.', "Clear"),
        ]
        return rows
    return []


def _provider_information(state, installed):
    """Provider configuration details for troubleshooting, without private URLs."""
    from lib.provider_config import hostname
    from provider_roles import name, overlaps
    rows = [_info(name(provider) + ' host', hostname(provider),
                  'Installed add-on hostname. Compare it with your self-hosted instance. '
                  'This does not confirm a live request. Passwords, configuration paths and tokens are hidden.')
            for provider in installed]
    for role, suppliers, primary in overlaps(state):
        rows.append(_info(role.title() + ' suppliers', suppliers,
                          suppliers + '. These add-ons advertise compatible resources. Metadata support alone does not prove that posters or ratings are included. Use Providers to set priority or limit requests.'))
    return rows


def _category_rows(category):
    """One home for each setting; saved setting IDs remain compatible."""
    if category == 'providers':
        from lib.provider_config import state as provider_state, hostname
        from provider_roles import choices, preference, selected, key
        from addons_core import active_addons
        state = provider_state(PROFILE)
        installed = list(active_addons(state))
        hosts = {key(p):hostname(p) for p in installed}
        rows = [_action("addons", "Stremio addons", 'Manage the Stremio addons available to this account, including catalogue, stream and subtitle providers.', "Manage"),
                _text("manifest", "Fallback catalogue", 'Choose the fallback catalogue manifest for compatibility views. Account Home and Discover use enabled installed catalogues.')]
        definitions = (
            ('metadata', 'Title and episode details', 'Use this add-on first for descriptions, seasons and episode details. Other enabled metadata add-ons fill missing fields; Cinemeta is the final fallback.'),
            ('artwork', 'Posters and artwork', 'Use this add-on for posters across Home, Continue Watching, Up Next, Library, search and catalogues. Episode thumbnails also prefer this provider when supplied. Automatic uses AIOMetadata when enabled. Missing posters keep catalogue artwork.'),
            ('ratings', 'Metadata rating priority', 'Prefer ratings if this metadata add-on supplies them. Metadata support does not guarantee ratings or episode scores. TMDB and MDbList enrichment and rating visibility are controlled under Ratings and API keys.'),
            ('search', 'Movie and series search', 'Use this add-on first for both suggestions and full search. Other enabled search add-ons and Cinemeta fill full-search results. Suggestions fall back when the chosen provider returns no relevant titles. Automatic keeps fast IMDb suggestions.'),
            ('streams', 'Stream add-ons', 'Use all enabled stream add-ons, or restrict source requests to one add-on. Source filters still control which returned releases appear.'),
            ('subtitles', 'Subtitle add-ons', 'Use all enabled subtitle add-ons, or restrict downloaded subtitles to one add-on. Embedded subtitles stay available. Forced subtitle rules and language preferences still apply.'),
        )
        for role, label, help_text in definitions:
            labels, values, index = choices(state, role)
            labels = [label + (' · ' + hosts[value] if value in hosts else '')
                      for label,value in zip(labels,values)]
            if preference(state, role) and selected(state, role) is None:
                help_text += ' Your previous choice is disabled or uninstalled; the automatic fallback is active.'
            if len(values) == 1:
                rows.append(_info(label, 'No eligible installed add-ons', help_text +
                                  ' No enabled installed add-on advertises this capability in its saved manifest. Check Stremio addons above.'))
            else:
                rows.append(_choice('provider_role:' + role, label, labels, values, index, help_text))
        rows.append(_action('artwork_refresh', 'Refresh artwork', 'Fetch preferred posters again for the current page. Catalogue lists, sign-in and watched progress are kept. Providers and Kodi may still cache unchanged image URLs.', 'Refresh'))
        return rows
    if category == 'diagnostics':
        from lib.troubleshooting import settings_rows
        local_rows = settings_rows(PROFILE)
        source_rows = [row for row in local_rows if row.get('action') in
                       ('source_search_timings', 'source_search_report') or row.get('label') == 'Source-search upload']
        from lib.provider_health import summary as provider_health_summary
        from account import Store
        export = Store(PROFILE/'diagnostic-export').load()
        from lib.wrong_episode import reports as wrong_episode_reports
        from lib.provider_config import state as provider_state
        from addons_core import active_addons
        from account import AccountError
        try:
            state = provider_state(PROFILE)
            provider_info = _provider_information(state, list(active_addons(state)))
        except (AccountError, OSError):
            provider_info = [_info('Provider configuration', 'Unavailable',
                                   'Provider details could not be loaded on this device.')]
        return source_rows + [_action('report_wrong_episode', 'Report wrong episode',
                      'Report the currently playing source so automatic playback avoids only this release for this episode.', 'Report'),
                _action('undo_wrong_episode', 'Undo wrong-episode report',
                      'Remove a previous report so automatic playback may choose that release again.', 'Undo'),
                _info('Wrong-episode reports', str(len(wrong_episode_reports(PROFILE))),
                      'Reports are saved on this device and apply only to automatic picks for the reported episode.'),
                _info('Automatic provider health', provider_health_summary(PROFILE),
                      'Repeated provider error videos or unplayable links temporarily move that provider behind other eligible matches on this device. No provider is disabled. Penalties decay every 30 minutes and recover after a minute of successful playback. Episode identity and quality limits still apply.'), _info('Diagnostic report ID', export.get('client', 'Not created yet'),
                      'Identifies this client report in the private GitHub diagnostics folder. Only an Uploaded status confirms it reached GitHub.'), _bool('diagnostics_github_enabled', 'Automatic private diagnostic reports',
                      'Automatically save a report when your movie, episode or live playback ends, stops or fails. Keep the latest 10 reports per device with redacted Kodi logs. Upload while idle to your private freeBird-sync repository; regular checks also run every 15 minutes. Requires the private GitHub token. Free-form error text is scrubbed but may still contain personal information.'),
                _action('clear_failed_sources','Clear failed-source blacklist',
                        'Allow previously failed playback links to be tried again on this device. Failed link hashes otherwise remain excluded across searches and app restarts; different links for the same release remain available.', 'Reset'),
                _info('Diagnostic export', _diagnostic_export_summary(export, ADDON),
                      'The latest report is in diagnostics. The last 10 playback reports, each with its own available Kodi logs, are in diagnostic-playback. Recent rolling logs remain in diagnostic-logs and are captured locally every minute and after restart. Android crash-buffer access is attempted for Kodi only; missing evidence is reported explicitly. Binary crash dumps and other apps are not collected.'),
                _action('send_diagnostics', 'Send diagnostic report now',
                        'Capture and upload app diagnostics, redacted current/previous Kodi technical logs and accessible Kodi-only Android crash evidence now. Automatic reports and the private sync token must be configured. The report confirms which evidence was available.', 'Send')] + [row for row in local_rows if row not in source_rows] + provider_info
    if category == 'api':
        return [_secret('tmdb_api_key', 'TMDB API key', 'Add your TMDB API key for cast photos, recommendations and TMDB episode ratings. Stored on this device. This product uses the TMDB API but is not endorsed or certified by TMDB. www.themoviedb.org'),
                _secret('mdblist_api_key', 'MDbList API key', 'Add your MDbList API key for public list search and browsing, plus additional movie and series ratings including Rotten Tomatoes and Metacritic. Opens the Kodi keyboard for phone-app typing or pasting.'),
                _secret('live_football_api_key', 'Live Football API key', 'Add your live-football-api.com key to enrich football guide rows with verified UTC kick-off times. The key stays on this device unless you explicitly copy your private setup profile.'),
                _secret('credits_github_token', 'Private GitHub sync token', 'Add a fine-grained GitHub token for the private freeBird-sync repository with Contents read/write access. Use the same repository on each device and enable the desired list/credits sync under Account & Stremio. Opens the Kodi keyboard for phone-app typing or pasting.')]
    if category in ('playback', 'sources', 'trailers', 'episodes'):
        groups = {'sources': ('source_', 'fel_'), 'trailers': ('trailers_',),
                  'episodes': ('up_next_', 'introdb_')}
        rows = _rows_for('playback')
        def group(row):
            identity = row.get('id', '')
            return next((key for key, prefixes in groups.items() if identity.startswith(prefixes)), 'playback')
        return [row for row in rows if group(row) == category]
    return [row for row in _rows_for(category) if row["kind"] != "secret"]


def rows_for(category):
    from lib.settings_dependencies import applicable
    rows = applicable(_category_rows(category), ADDON.getSetting)
    if category == 'subtitles':
        # One capability request per page, rather than querying for every row.
        from setup_profile import rpc
        try:
            definitions = rpc('Settings.GetSettings', {'level': 'expert'}).get('settings', [])
        except Exception:
            definitions = []
        supported = {row.get('id'): row for row in definitions if row.get('enabled', True)}
        missing = any(row['kind'] == 'kodi' and row['id'] not in supported for row in rows)
        rows = [dict(row, definition=supported[row['id']]) if row['kind'] == 'kodi' else row
                for row in rows if row['kind'] != 'kodi' or row['id'] in supported]
        if missing:
            rows.append(_info('Additional subtitle appearance controls', 'Unavailable on this device',
                              'Only controls supported by this Kodi build are shown. Your saved subtitle preferences are kept.'))
    for index, row in enumerate(rows):
        identity = row.get('id', '')
        parent = identity in ('startup_autostart', 'unpause_rewind_enabled', 'forced_subtitles_mode', 'trailers_enabled', 'trailers_auto', 'introdb_enabled',
                              'up_next_enabled', 'prerolls_enabled', 'formats_github_enabled', 'rating_imdb', 'rating_tmdb',
                              'rating_trakt', 'rating_tomatoes', 'rating_tomatoesaudience', 'rating_metacritic', 'rating_mdblist')
        if parent or (identity.startswith('auto_') and identity.endswith('_mode')):
            row = row.copy()
            row['help'] = row.get('help', '') + ' Related options appear when enabled; hidden preferences are kept.'
            rows[index] = row
    return rows


def _index_value(setting, values):
    try:
        index = int(ADDON.getSetting(setting) or {"auto_source_attempts":"1", "forced_subtitles_mode":"2"}.get(setting, "0"))
    except (TypeError, ValueError):
        index = 0
    return values[index] if 0 <= index < len(values) else values[0]


def summary(row):
    kind = row["kind"]
    if kind == "bool":
        return "On" if ADDON.getSetting(row["id"]).lower() == "true" else "Off"
    if kind == "enum":
        return _index_value(row["id"], row["values"])
    if kind == "secret":
        return "Configured" if ADDON.getSetting(row["id"]).strip() else "Not set"
    if kind == "text":
        value = ADDON.getSetting(row["id"]).strip()
        if row["id"] == "manifest":
            return "Official Cinemeta" if "v3-cinemeta.strem.io" in value else ("Custom" if value else "Default")
        return value or "Not set"
    if kind == "choice":
        return row.get("summary", "Choose")
    if kind == "kodi":
        definition = row.get("definition") or _kodi_definition(row["id"])
        if not definition:
            return "Unavailable"
        value = definition.get("value")
        options = _kodi_options(definition)
        match = next((str(option.get("label")) for option in options
                      if option.get("value") == value), None)
        if match:
            return match
        if isinstance(value, bool):
            return "On" if value else "Off"
        return str(value)
    return row.get("summary", "")


def _set_bool(row):
    current = ADDON.getSetting(row["id"]).lower() == "true"
    ADDON.setSetting(row["id"], "false" if current else "true")


def _set_text(row):
    current = ADDON.getSetting(row["id"]).strip()
    value = themed_dialog().input(row["label"], defaultt=current, type=xbmcgui.INPUT_ALPHANUM)
    if not value.strip():
        return False
    if row["id"] == "manifest":
        from protocol import base_url
        try:
            base_url(value.strip())
        except Exception:
            themed_dialog().ok("Catalog manifest", "Use an HTTP(S) URL ending in /manifest.json.")
            return False
    ADDON.setSetting(row["id"], value.strip())
    return True


def run_action(action, owner=None):
    if action == 'review_progress_conflicts':
        from lib.viewer_ui import review_conflicts
        from account import AccountError
        from lib.credits_sync import SyncError
        import sqlite3
        try:
            review_conflicts(PROFILE)
        except (ValueError, RuntimeError, OSError, sqlite3.Error, AccountError, SyncError) as error:
            themed_dialog().ok('Progress conflicts', str(error))
            return
        # Progress review publishes its own refresh signal. Keep Settings and
        # the current browse window alive; only a real viewer switch reloads them.
        return
    if action=='viewer_profiles':
        from lib.viewer_ui import manage
        if manage(PROFILE) and owner is not None:
            owner.profiles_changed=True
            owner.close()
        return
    if action == 'clear_failed_sources':
        from lib.source_failures import clear
        clear(PROFILE)
        themed_dialog().notification('Failed sources','Blacklist cleared. Close and reopen the title to retry previously failed links.')
        return
    if action == 'send_diagnostics':
        if ADDON.getSetting('diagnostics_github_enabled') != 'true' or not ADDON.getSetting('credits_github_token').strip():
            themed_dialog().notification('Diagnostic report', 'Enable private reports and configure the private sync token first.')
            return
        from lib.diagnostic_export import MANUAL_REQUEST
        xbmcgui.Window(10000).setProperty(MANUAL_REQUEST, 'true')
        themed_dialog().notification('Diagnostic report', 'Upload requested. Check Diagnostic export for the result.')
        return
    if action in ('report_wrong_episode', 'undo_wrong_episode') and owner is not None:
        from lib.wrong_episode import current, reports
        if action == 'report_wrong_episode':
            active = current(PROFILE)
            if active is None:
                themed_dialog().notification('Wrong episode', 'No freeBird episode is playing right now.')
                return
            if any(item['id'] == active['id'] for item in reports(PROFILE)):
                themed_dialog().notification('Wrong episode', 'This playing source is already reported. Use Undo to remove it.')
                return
            owner.open_command('report_wrong_episode_choice', 'Report playing source',
                               ['Report this source', 'Cancel'], [active['id'], 'cancel'],
                               active['label'] + '\n\nOnly this release will be avoided automatically for this episode.')
            return
        entries = reports(PROFILE)
        if not entries:
            themed_dialog().notification('Wrong episode', 'No reports to undo.')
            return
        owner.open_command('undo_wrong_episode_choice', 'Undo wrong-episode report',
                           [item['label'] for item in entries] + ['Cancel'],
                           [item['id'] for item in entries] + ['cancel'],
                           'Choose a report to remove. Automatic selection may use that release again.')
        return
    if action in ('source_search_report', 'source_search_send'):
        from lib.troubleshooting import source_search_details
        from lib.perf_report import build_payload
        payload = build_payload(PROFILE, source_only=True)
        if not payload:
            themed_dialog().ok('Source-search report', source_search_details(PROFILE))
            return
        if ADDON.getSetting('diagnostics_github_enabled') != 'true' or not ADDON.getSetting('credits_github_token').strip():
            themed_dialog().ok('Source-search report', 'Private reporting is not configured. '
                'Enable private diagnostic reports and configure the private sync token first. '
                'Last source search remains available locally. Nothing was uploaded.')
            return
        if action == 'source_search_report':
            if owner is not None:
                owner.open_command('source_search_send', 'Send source-search report?',
                    ['Send', 'Cancel'], ['send', 'cancel'], source_search_details(PROFILE) +
                    '\n\nSend these bounded timings and software versions to your configured private repository? '
                    'No titles, stream links, account details or Kodi logs. Cancel sends nothing.')
            return
        from lib.diagnostic_export import MANUAL_REQUEST
        xbmcgui.Window(10000).setProperty(MANUAL_REQUEST, 'source_search')
        themed_dialog().notification('Source-search report', 'Upload requested. Check Source-search upload for the result.')
        return
    if action in ('source_search_timings', 'playback_timings'):
        if action == 'source_search_timings':
            from lib.troubleshooting import source_search_details
            heading, text = 'Last source search', source_search_details(PROFILE)
        else:
            from lib.playback_timing import details
            heading, text = 'Last playback loading', details()+(
                '\n\nLocal timings for the latest playback attempt in this Kodi session. '
                'Finding a source includes provider waits; preparation includes playback handoff, the resolver, details and subtitles. '
                'Resolver wait can include a pre-roll when enabled. Kodi opening includes connection and buffering. '
                'These measurements show where time was spent, not the underlying cause. No title names or source links are recorded.')
        themed_dialog().textviewer(heading, text)
        return
    if action == 'fel7_test':
        from lib.player_tests import play_fel7
        play_fel7(ADDON,PROFILE,themed_dialog(),xbmc,xbmcgui,owner)
        return
    if action == 'artwork_refresh':
        if owner is not None:
            owner.clear_cached_data('metadata')
        else:
            from lib.maintenance import clear_cache
            clear_cache('metadata')
        return
    if action == 'startup_benchmark':
        from lib.low_power_benchmark import run
        from lib.troubleshooting import benchmark_summary
        from lib.ui_dialogs import progress_bg
        progress = progress_bg()
        try:
            progress.create('Startup checks', 'Measuring cached browsing on this device…')
            result = run(PROFILE)
        finally:
            progress.close()
        themed_dialog().ok('Cached browsing checks', benchmark_summary(result))
        if owner is not None:
            owner.refresh_rows()
        return
    if action == 'live_tv_setup':
        from lib.live_tv_playback import setup
        import xbmcaddon
        setup(xbmcgui, xbmcaddon)
        return
    if action == 'player_skin':
        if owner is not None:
            owner.close()
        xbmc.executebuiltin('ActivateWindow(10032)')
        return
    if action == 'discover_opening' and owner is not None:
        from lib import backend as api
        from lib.discover_preferences import Preferences
        preferences = Preferences(PROFILE)
        labels, values = preferences.opening_options(api.discover_choices())
        opening = preferences.data.get('opening', {})
        selected = next((i for i, value in enumerate(values) if value['mode'] == opening.get('mode', 'last') and (value['mode'] != 'list' or (value['catalog']['kind'], value['catalog']['id']) == (opening.get('kind'), opening.get('id')))), 0)
        owner.open_command('discover_opening_choice', 'Discover opening list', labels, values,
                           'Choose what opens when you enter Discover. Saved on this device.', selected=selected)
        return
    if action == 'catalogue_layout' and owner is not None:
        from lib import backend as api
        rows = api.discover_choices()
        if not rows:
            themed_dialog().notification('Catalogue thumbnails', 'No installed catalogues are available.')
            return
        owner.open_command('catalogue_choose', 'Choose catalogue', [r['label'] + ' · ' + r['addon'] for r in rows], rows,
                           'Choose the catalogue whose thumbnail layout you want to change.')
        return
    if action == "account_signin":
        from lib.signin import show_signin
        show_signin()
    elif action in ('device_setup_publish', 'device_setup_enroll', 'device_setup_undo'):
        from lib.device_setup_ui import run, undo
        if action == 'device_setup_undo':undo()
        elif action == 'device_setup_publish':
            run('publish')  # Owner approval on the phone authorises export.
        else:
            run()
            if owner is not None:
                owner.appearance_changed = True
                owner.providers_changed = True
    elif action == "account_refresh":
        xbmcgui.Window(10000).setProperty("strem4kodi.sync.manual", "true")
        xbmcgui.Window(10000).setProperty("strem4kodi.sync.request", "true")
        themed_dialog().notification("Account sync requested", "Progress uploads will retry now. Your library refreshes when playback is idle.")
    elif action == "account_disconnect" and owner is not None:
        owner.open_command(
            "account_disconnect", "Disconnect this device",
            ["Disconnect this device", "Cancel"], ["disconnect", "cancel"],
            "Removes this device login and account-synced addons. Your online Stremio account is unchanged."
        )
    elif action == "addons":
        if owner is not None:
            owner.request_page = "addons"
            owner.close()
    elif action == "kodi_buffering":
        from lib.player_buffering import open_settings
        open_settings(themed_dialog(), xbmc, owner)
    elif action == "cache_clear_selected_custom" and owner is not None:
        from lib.cache_policy import GROUPS
        labels = [label for _, label, _ in GROUPS] + ["Older entries", "Cancel"]
        values = [key for key, _, _ in GROUPS] + ["legacy", "cancel"]
        owner.open_command(
            "cache_clear_one", "Clear one cache category", labels, values,
            "Clears the selected responses. Metadata, catalogue and search clears also reset freeBird artwork. Login, library and playback data stay."
        )
    elif action == "cache_clear_all_custom" and owner is not None:
        owner.open_command(
            "cache_clear_all", "Clear responses and artwork",
            ["Clear responses and artwork", "Cancel"], ["clear", "cancel"],
            "Clears responses and freeBird artwork. Login, library, progress and source-format facts stay. Server caches are managed separately."
        )


class SettingsWindow(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.resume_state = kwargs.pop("resume_state", None) or {}
        self.ready_cover = kwargs.pop("ready_cover", None)
        self.closed = False
        self.category_index = self.resume_state.get("category", 0)
        self.rows = []
        self.appearance_changed = False
        self.providers_changed = False
        self.cache_cleared = False
        self.discover_changed = False
        self.request_page = None
        self.exit_requested = False
        self.subpage = None
        self.subpage_row = None
        self.subpage_options = []
        self.subpage_values = []
        self.return_position = 0
        self.feedback_kind = None
        self.feedback_category = None
        self.feedback_title = None
        self.feedback_description = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            categories = self.getControl(100)
            categories.reset()
            for label, key in CATEGORIES:
                item = xbmcgui.ListItem(label)
                item.setProperty("key", key)
                categories.addItem(item)
            categories.selectItem(self.category_index)
            self.load_category(self.category_index)
            position = self.resume_state.get("position", 0)
            if self.rows:
                self.getControl(200).selectItem(min(max(0, position), len(self.rows) - 1))
            self.setFocusId(200 if self.resume_state.get("focus") == 200 and self.rows else 100)
            import threading
            if not getattr(self,'_sync_watcher_started',False):
                self._sync_watcher_started=True
                threading.Thread(target=self.watch_sync, daemon=True).start()
        finally:
            if self.ready_cover is not None:
                self.ready_cover.finish()
                self.ready_cover = None

    def close(self):
        # Read focus while this dialog still owns it; Kodi clears focus on close.
        self.resume_state = {"category": self.category_index,
                             "position": max(0, self.getControl(200).getSelectedPosition()),
                             "focus": self.getFocusId()}
        self.closed = True
        super().close()

    def watch_sync(self):
        try:
            monitor=xbmc.Monitor()
            while not self.closed and not monitor.waitForAbort(0.15):
                if not self.subpage and self.getFocusId()==100:self.preview_category()
                import time
                now=time.monotonic()
                if now-getattr(self,'_last_sync_refresh',0)<2:continue
                self._last_sync_refresh=now
                if self.subpage or CATEGORIES[self.category_index][1] != "account":continue
                original_rows=self.rows
                rows=rows_for("account")
                if (self.closed or self.subpage or self.rows is not original_rows
                        or CATEGORIES[self.category_index][1]!='account'
                        or len(rows)!=len(original_rows)):continue
                for index,row in enumerate(rows):
                    if self.closed or self.rows is not original_rows or self.subpage:break
                    if row["kind"]=="info" or row.get('action') == 'review_progress_conflicts':
                        self.rows[index]=row
                        self.getControl(200).getListItem(index).setLabel2(summary(row))
                        self.getControl(200).getListItem(index).setProperty('help', help_preview(row))
                        self.getControl(200).getListItem(index).setProperty('status_color', status_color(row))
        except Exception:
            return

    def preview_category(self):
        if self.subpage:return
        position=self.getControl(100).getSelectedPosition()
        if position!=self.category_index:self.load_category(position)

    def onFocus(self, control_id):
        if control_id == 100:
            if self.subpage:
                self.setFocusId(200)
            else:
                self.preview_category()
        elif control_id == 200 and not self.subpage:
            # A fast category change followed by Right can beat the sync
            # watcher. Load that category before its first setting is used.
            self.preview_category()

    def layout(self, reading=False):
        self.getControl(200).setHeight(198 if reading else 660)
        self.getControl(302).setPosition(520, 420 if reading else 858)
        self.getControl(300).setPosition(550, 455 if reading else 880)
        self.getControl(300).setHeight(535 if reading else 82)
        self.getControl(300).setWidth(1210 if reading else 920)
        self.getControl(306).setPosition(520, 435 if reading else 870)
        self.getControl(306).setHeight(565 if reading else 130)
        self.setProperty('settings_reading', 'true' if reading else '')

    def load_category(self, index):
        if not 0 <= index < len(CATEGORIES):
            return
        self.category_index = index
        label, key = CATEGORIES[index]
        self.setProperty('settings_details_available', '' if key == 'exit' else 'true')
        self.setProperty('settings_category', key)
        self.getControl(307).setLabel(CATEGORY_HELP.get(key, 'Choose an option.') + ('' if key == 'exit' else ' Changes save immediately.'))
        self.layout()
        self.getControl(301).setLabel(label)
        self.rows = [] if key == "exit" else rows_for(key)
        listing = self.getControl(200)
        listing.reset()
        for row in self.rows:
            item = xbmcgui.ListItem(row["label"], summary(row))
            item.setProperty("help", help_preview(row))
            item.setProperty("kind", row["kind"])
            item.setProperty('status_color', status_color(row))
            item.setProperty('help_hint', 'Press Right for Details.')
            listing.addItem(item)
        if self.rows:
            listing.selectItem(0)

    def refresh_rows(self):
        listing = self.getControl(200)
        position = max(0, listing.getSelectedPosition())
        self.load_category(self.category_index)
        if self.rows:
            listing.selectItem(min(position, len(self.rows) - 1))
            self.setFocusId(200)

    def open_subpage(self, row, labels, values=None, selected=0, help_text=None):
        self.layout()
        self.return_position = max(0, self.getControl(200).getSelectedPosition())
        self.subpage = "picker"
        self.setProperty("settings_details_available", "")
        self.subpage_row = row
        self.subpage_options = list(labels)
        self.subpage_values = list(values if values is not None else range(len(labels)))
        self.getControl(301).setLabel(row["label"])
        listing = self.getControl(200)
        listing.reset()
        for index, label in enumerate(self.subpage_options):
            item = xbmcgui.ListItem(str(label), "Selected" if index == selected else "")
            detail = help_text or row.get("help", "")
            if row.get('id') != 'information':
                detail = help_preview(dict(kind='choice', summary=str(label), help=detail))
            item.setProperty("help", detail)
            item.setProperty('help_hint', '' if row.get('id') == 'information' else 'Press Back, then Right for Details.')
            listing.addItem(item)
        if self.subpage_options:
            listing.selectItem(max(0, min(selected, len(self.subpage_options) - 1)))
        self.setFocusId(200)

    def close_subpage(self):
        self.subpage = None
        self.subpage_row = None
        self.subpage_options = []
        self.subpage_values = []
        self.load_category(self.category_index)
        if self.rows:
            self.getControl(200).selectItem(min(self.return_position, len(self.rows) - 1))
            self.setFocusId(200)

    def open_enum(self, row):
        try:
            current = int(ADDON.getSetting(row["id"]) or {"auto_source_attempts":"1", "forced_subtitles_mode":"2"}.get(row["id"], "0"))
        except (TypeError, ValueError):
            current = 0
        if not 0 <= current < len(row["values"]):
            current = 0
        from lib.settings_time_order import order
        indices = order(row['values'])
        if indices != list(range(len(indices))):
            self.open_subpage(row, [row['values'][i] for i in indices],
                              values=indices, selected=indices.index(current))
            return
        self.open_subpage(row, row["values"], selected=current)

    def open_choice(self, row):
        if row['id'].startswith('cache_ttl:'):
            from lib.settings_time_order import order
            indices = order(row['values'])
            self.open_subpage(row, [row['labels'][i] for i in indices],
                              values=[row['values'][i] for i in indices],
                              selected=indices.index(row.get('selected', 0)))
            return
        self.open_subpage(row, row["labels"], values=row["values"],
                          selected=row.get("selected", 0))

    def open_command(self, identity, label, labels, values, help_text, selected=0):
        if identity == 'information':
            self.information_pages = information_pages(help_text)
            self.information_page = 0
            labels = ['Back'] + (['Previous page', 'Next page'] if len(self.information_pages) > 1 else [])
            values = ['cancel'] + ([-1, 1] if len(self.information_pages) > 1 else [])
            help_text = self.information_pages[0]
        row = {"kind": "command", "id": identity, "label": label, "help": help_text}
        self.open_subpage(row, labels, values=values, selected=selected, help_text=help_text)
        if identity == 'information':
            self.layout(reading=True)

    def open_feedback_type(self):
        self.open_command(
            "feedback_type", "Report a bug / request a feature",
            ["Bug report", "Feature request", "Report last error", "Cancel"],
            ["bug", "feature", "last", "cancel"],
            "Feedback is public on GitHub after the final addon-owned review screen. Never include credentials, links or personal details."
        )

    def open_last_error_custom(self):
        from lib.last_error import load_last_error
        from lib.error_report import show_report_dialog
        record = load_last_error()
        if record is None:
            themed_dialog().notification("Report last error", "No saved error is available.")
            return
        payload = record["payload"]
        summary = "{}: {}\nAddon {} | {}".format(
            payload.get("context", "Last error"), payload.get("errorType", "Error"),
            payload.get("addonVersion", "unknown"), payload.get("platform", "unknown")
        )
        show_report_dialog(payload, summary, replay=True)

    def finish_feedback(self, frequency):
        from lib.report_feedback import CATEGORIES, attach_feedback, report_labels
        from lib.error_report import build_payload, show_report_dialog
        payload = attach_feedback(build_payload("Manual report"), {
            "kind": self.feedback_kind,
            "category": self.feedback_category,
            "title": self.feedback_title,
            "description": self.feedback_description,
            "frequency": frequency,
        })
        labels = ", ".join(report_labels(payload, initial=True))
        kind = "Feature request" if self.feedback_kind == "feature" else "Bug report"
        show_report_dialog(payload, "{}\n{}\n\n{}".format(kind, self.feedback_title, labels))


    def open_secret(self, row):
        configured = bool(ADDON.getSetting(row["id"]).strip())
        labels = ["Replace key", "Remove key"] if configured else ["Add key"]
        self.open_subpage(row, labels, values=labels, selected=0,
                          help_text="API keys stay hidden. Use the Kodi keyboard or send text from your paired Kodi remote app.")

    def open_kodi(self, row):
        definition = _kodi_definition(row["id"])
        if not definition or not definition.get("enabled", True):
            themed_dialog().notification("freeBird", "This setting is unavailable on this device.")
            return
        value = definition.get("value")
        if isinstance(value, bool):
            from setup_profile import rpc
            rpc("Settings.SetSettingValue", {"setting": row["id"], "value": not value})
            self.refresh_rows()
            return
        options = _kodi_options(definition)
        if not options:
            themed_dialog().notification("freeBird", "No supported choices were reported for this setting.")
            return
        labels = [str(option.get("label")) for option in options]
        values = [option.get("value") for option in options]
        selected = next((i for i, option in enumerate(options) if option.get("value") == value), 0)
        self.open_subpage(row, labels, values=values, selected=selected)

    def execute_command(self, identity, value):
        if value in ("cancel", None):
            return
        if identity == 'source_search_send':
            if value == 'send':run_action('source_search_send', self)
            return
        if identity in ('report_wrong_episode_choice', 'undo_wrong_episode_choice'):
            from lib.wrong_episode import add_current, undo
            changed = (add_current if identity == 'report_wrong_episode_choice' else undo)(PROFILE, value)
            themed_dialog().notification('Wrong episode',
                ('Report saved' if identity == 'report_wrong_episode_choice' else 'Report removed') if changed else 'Playing source changed or is no longer available.')
            self.refresh_rows()
            return
        if identity == 'discover_opening_choice':
            from lib.discover_preferences import Preferences
            Preferences(PROFILE).set_opening(value['mode'], value.get('catalog'))
            self.discover_changed = True
            themed_dialog().notification('Discover', 'Opening list saved')
            return
        if identity == 'catalogue_choose':
            self.open_command('catalogue_mode', 'Catalogue thumbnails', ['Posters','Wide thumbnails'],
                              [dict(catalog=value, layout='posters'), dict(catalog=value, layout='wide')],
                              'Saved for this catalogue on this device, on Home and Discover.')
            return
        if identity == 'catalogue_mode':
            from lib.catalogue_layout import save
            save(PROFILE, value['catalog'], value['layout'])
            themed_dialog().notification('Catalogue thumbnails', 'Saved: '+('Wide thumbnails' if value['layout']=='wide' else 'Posters'))
            self.appearance_changed = True
            return
        if identity == "account_disconnect" and value == "disconnect":
            state = Store(PROFILE).load()
            local = [item for item in state.get("addons", []) if item.get("account") is not True]
            disabled = set(state.get("disabledAddons", []))
            Store(PROFILE).save({
                "addons": local,
                "disabledAddons": sorted(disabled & {item.get("id") for item in local}),
            })
            for folder in ("streams", "playback", "subtitle-results"):
                Store(PROFILE / folder).forget()
            return
        if identity == "cache_clear_one":
            self.clear_cached_data(str(value))
            return
        if identity == "cache_clear_all" and value == "clear":
            self.clear_cached_data()
            return
        if identity == "feedback_type":
            if value == "last":
                self.open_last_error_custom()
                return
            if value in ("bug", "feature"):
                from lib.report_feedback import CATEGORIES
                self.feedback_kind = value
                self.open_command(
                    "feedback_category", "Feedback category",
                    [label for _, label in CATEGORIES] + ["Cancel"],
                    [key for key, _ in CATEGORIES] + ["cancel"],
                    "Choose the area that best matches this feedback."
                )
            return
        if identity == "feedback_category" and value != "cancel":
            from lib.report_feedback import feedback_text
            self.feedback_category = value
            title = themed_dialog().input(
                "Feature request title" if self.feedback_kind == "feature" else "Bug title"
            )
            if not title:
                return
            description = themed_dialog().input(
                "Describe the idea and why it helps" if self.feedback_kind == "feature"
                else "Steps to reproduce, expected result and what happens instead"
            )
            if not description:
                return
            try:
                self.feedback_title = feedback_text(title, 5, 100)
                self.feedback_description = feedback_text(description, 10, 1000)
            except ValueError:
                themed_dialog().notification("Feedback", "Check the title/description and remove links or credentials.")
                return
            if self.feedback_kind == "feature":
                self.finish_feedback("not-applicable")
            else:
                self.open_command(
                    "feedback_frequency", "How often does it happen?",
                    ["Every time", "Sometimes", "After restart", "Not retested", "Cancel"],
                    ["always", "sometimes", "after-restart", "not-retested", "cancel"],
                    "Choose how consistently the bug can be reproduced."
                )
            return
        if identity == "feedback_frequency" and value != "cancel":
            self.finish_feedback(str(value))
            return

    def apply_choice(self, row, value):
        identity = row.get("id", "")
        if identity.startswith('provider_role:'):
            from lib.provider_config import choose
            choose(PROFILE, identity.split(':', 1)[1], str(value))
            self.providers_changed = True
            return
        if identity in ('source_provider', 'source_language', 'manifest') or identity.startswith('auto_'):
            ADDON.setSetting(identity, str(value))
            return
        if identity in ("locale_language", "locale_region"):
            # This is an addon preference. Never switch Kodi's global language
            # while an addon-owned modal window is open: Kodi unloads/reloads the
            # skin and invalidates the active Strem4Kodi windows.
            from lib.settings import load_setup, save_setup
            setup = load_setup()
            setup["language" if identity == "locale_language" else "region"] = tuple(value)
            save_setup(setup)
            return
        if identity.startswith("cache_ttl:"):
            from lib.cache_policy import setting_id
            ADDON.setSetting(setting_id(identity.split(":", 1)[1]), str(value))
            from lib.maintenance import apply_settings
            apply_settings()
            return
        if identity == "cache_size":
            ADDON.setSetting("cache_max_mb", str(value))
            from lib.maintenance import apply_settings
            apply_settings()
            return

    def apply_subpage(self, index):
        if not self.subpage_row or not 0 <= index < len(self.subpage_values):
            return
        row = self.subpage_row
        value = self.subpage_values[index]
        if row["kind"] == "enum":
            ADDON.setSetting(row["id"], str(value))
            if row['id'] == 'playback_back_action':
                ADDON.setSetting('playback_back_migrated', 'true')
                from lib.playback_settings import apply
                apply()
            if row.get("id", "").startswith("ui_"):
                self.appearance_changed = True
            self.close_subpage()
            return
        if row["kind"] == "choice":
            self.apply_choice(row, value)
            self.close_subpage()
            return
        if row["kind"] == "command":
            identity = row.get("id", "")
            if identity == 'information' and value in (-1, 1):
                self.information_page = (self.information_page + value) % len(self.information_pages)
                for item in range(len(self.subpage_options)):
                    self.getControl(200).getListItem(item).setProperty('help', self.information_pages[self.information_page])
                return
            self.close_subpage()
            self.execute_command(identity, value)
            return
        if row["kind"] == "secret":
            action = str(value)
            if action == "Remove key":
                ADDON.setSetting(row["id"], "")
                self.close_subpage()
                return
            entered = themed_dialog().input(
                row["label"], type=xbmcgui.INPUT_ALPHANUM,
                option=xbmcgui.ALPHANUM_HIDE_INPUT
            )
            if entered.strip():
                ADDON.setSetting(row["id"], entered.strip())
            self.close_subpage()
            return
        if row["kind"] == "kodi":
            from setup_profile import rpc
            rpc("Settings.SetSettingValue", {"setting": row["id"], "value": value})
            self.close_subpage()
            return

    def onClick(self, control_id):
        if control_id == 311:
            if self.subpage:
                return
            position = self.getControl(200).getSelectedPosition()
            if 0 <= position < len(self.rows):
                row = self.rows[position]
                text = summary(row) + '\n\n' + row.get('help', '')
                self.open_command('information', row['label'], ['Back'], ['cancel'], text)
            return
        if control_id == 100:
            if self.subpage:
                return
            position = self.getControl(100).getSelectedPosition()
            if 0 <= position < len(CATEGORIES) and CATEGORIES[position][1] == "exit":
                self.exit_requested = True
                self.close()
                return
            self.load_category(position)
            if self.rows:
                self.setFocusId(200)
            return
        if control_id != 200:
            return
        position = self.getControl(200).getSelectedPosition()
        if self.subpage:
            self.apply_subpage(position)
            return
        if not 0 <= position < len(self.rows):
            return
        row = self.rows[position]
        changed = False
        if row["kind"] == "info":
            # Keep status explanations readable on highlight/Info, without
            # presenting a read-only row as an editable settings page.
            return
        if row["kind"] == "bool":
            _set_bool(row)
            changed = True
        elif row["kind"] == "enum":
            self.open_enum(row)
            return
        elif row["kind"] == "choice":
            self.open_choice(row)
            return
        elif row["kind"] == "secret":
            self.open_secret(row)
            return
        elif row["kind"] == "kodi":
            self.open_kodi(row)
            return
        elif row["kind"] == "text":
            changed = _set_text(row)
        elif row["kind"] == "action":
            run_action(row["action"], self)
            # A sync request changes no setting. The status watcher refreshes
            # its values; rebuilding the list here races that worker and toast.
            if row['action']=='account_refresh':return
            # Opening a chooser must not immediately overwrite it with settings.
            if self.subpage:return
            changed = True
        if changed and row.get("id", "").startswith("ui_"):
            self.appearance_changed = True
        try:
            visible = self.isVisible()
        except Exception:
            visible = True
        if visible:
            self.refresh_rows()

    def clear_cached_data(self, category=None):
        from lib.maintenance import clear_cache
        self.cache_cleared = True
        try:
            count = clear_cache(category)
            self.open_command('information', 'Cache cleared', ['Back'], ['cancel'],
                              'Fresh responses will be loaded. {} cached artwork images removed.'.format(count))
        except Exception:
            self.open_command('information', 'Cache clear incomplete', ['Back'], ['cancel'],
                              'Kodi could not finish clearing the artwork cache. Close freeBird and try again.')

    def onAction(self, action):
        action_id = action.getId()
        if action_id in BACK:
            if self.subpage:
                self.close_subpage()
            elif self.getFocusId() == 311:
                self.setFocusId(200)
            elif self.getFocusId() == 200:
                self.setFocusId(100)
            else:
                self.close()
            return
        if self.subpage:
            if action_id == 1:
                self.close_subpage()
            return
        if action_id in (1, 3, 4) and self.getFocusId() == 311:
            self.setFocusId(200)
            return
        if action_id == 11 and self.getFocusId() in (200, 311):
            position = self.getControl(200).getSelectedPosition()
            if 0 <= position < len(self.rows):
                row = self.rows[position]
                text = summary(row) + '\n\n' + row.get('help', '')
                self.open_command('information', row['label'], ['Back'], ['cancel'], text)
            return
        if action_id == 1 and self.getFocusId() == 200:
            self.setFocusId(100)
            return
        # XML owns Right navigation in both columns. Kodi can move focus
        # before this callback, so routing Right again would skip a setting.


def show(resume_state=None, ready_cover=None):
    window = themed_window(
        SettingsWindow, "script-stremio-settings.xml",
        ADDON.getAddonInfo("path"), "Main", "1080i", resume_state=resume_state,
        ready_cover=ready_cover
    )
    window.doModal()
    result = {
        "appearance_changed": window.appearance_changed,
        "providers_changed": window.providers_changed,
        "cache_cleared": window.cache_cleared,
        "profiles_changed": getattr(window,'profiles_changed',False),
        "discover_changed": window.discover_changed,
        "request_page": window.request_page,
        "exit_requested": window.exit_requested,
        "resume_state": window.resume_state,
    }
    del window
    return result
