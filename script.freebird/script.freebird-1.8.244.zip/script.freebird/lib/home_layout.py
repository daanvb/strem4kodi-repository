"""Expand the bundled row template to the account's catalog count."""
import copy
import hashlib
import json
import os
import tempfile
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from lib.sidebar_nav import SIDEBAR_FOCUS


def _template_path(source=None):
    """Resolve the bundled template from this module, not Kodi's virtual addon path."""
    bundled = Path(__file__).resolve().parents[1] / 'resources/skins/Main/1080i/script-stremio-nimbus.xml'
    if bundled.is_file():
        return bundled
    # Compatibility fallback for source-tree callers and unusual packaging.
    if source:
        raw = str(source)
        if raw.startswith('special://'):
            try:
                import xbmcvfs
                raw = xbmcvfs.translatePath(raw)
            except Exception:
                raw = ''
        candidate = Path(raw) / 'resources/skins/Main/1080i/script-stremio-nimbus.xml'
        if candidate.is_file():
            return candidate
    raise RuntimeError('Bundled freeBird home template is unavailable.')


def build_layout(source, profile, count, appearance=None):
    template_path = _template_path(source)
    count = max(2, count)
    path = Path(profile) / 'home-layout'
    output = path / 'resources/skins/Main/1080i'
    destination = output / 'stremio-account-home.xml'
    marker = path / 'layout-key.txt'
    digest = hashlib.sha256()
    digest.update(json.dumps({'count': count, 'appearance': appearance or {}}, sort_keys=True).encode('utf-8'))
    digest.update(template_path.read_bytes())
    for name in ('home_layout', 'sidebar_nav', 'cinematic_cards', 'card_focus', 'catalogue_layout', 'poster_progress', 'discover_grid', 'discover_service_filters', 'recommendation_cards', 'addons_layout', 'appearance', 'theme', 'ui_style', 'browse_text', 'text_metrics'):
        digest.update(Path(__file__).with_name(name + '.py').read_bytes())
    cache_key = digest.hexdigest()
    try:
        if destination.is_file() and marker.read_text(encoding='ascii') == cache_key:
            cached = destination.read_bytes()
            if b'poster_sash_' not in cached and b'tag-rounded.png' not in cached:
                return destination.name, str(path), count
    except OSError:
        pass
    tree = ET.parse(template_path)
    # Build the footer from the same definition as future template ports.
    from lib.sidebar_nav import footer_control
    parents = {child: parent for parent in tree.iter() for child in parent}
    old_footer = parents[tree.find('.//control[@id="209"]')]
    sidebar_parent = parents[old_footer]
    slot = list(sidebar_parent).index(old_footer)
    sidebar_parent.remove(old_footer)
    sidebar_parent.insert(slot, footer_control())
    group = tree.find('.//control[@id="2000"]')
    template = copy.deepcopy(group.find('control'))
    for child in list(group.findall('control')):
        group.remove(child)
    count = max(2, count)
    for index in range(count):
        cid = 400 + index
        row = copy.deepcopy(template)
        for node in row.iter():
            def replace(text):
                if not text:
                    return text
                text = text.replace('400665', str(cid)+'665').replace('row400', 'row'+str(cid)).replace('has400', 'has'+str(cid))
                return re.sub(r'\b400\b', str(cid), text)
            node.text = replace(node.text)
            for key, value in list(node.attrib.items()):
                node.set(key, replace(value))
        listing = row.find("control[@type='fixedlist']")
        from lib.cinematic_cards import posters
        posters(listing)
        from lib.catalogue_layout import add_layouts
        add_layouts(listing, cid)
        # Cinematic cards replace the template's inset group. Keep their art
        # aligned with the 50px heading: 38px container + 12px poster inset.
        # The outer focus stroke then stays 42px inside the screen as well.
        left = listing.find('left')
        if left is None:left = ET.SubElement(listing, 'left')
        left.text = '38'
        # Native list paging uses the active layout's cell width and keeps
        # the final page full. A fixedlist's shared movement range either
        # clips portrait focus or leaves several empty slots at the row end.
        listing.set('type', 'list')
        for tag in ('focusposition', 'movement'):
            for node in listing.findall(tag):listing.remove(node)
        listing.find('height').text = '374'
        # The focused poster grows into the narrow gap between this row's
        # heading and the next-row preview label. Move the cards up and lift
        # their heading by the same amount so the existing top gap is kept,
        # while creating more room above the next-row label.
        listing.find('top').text = '-10'
        # A numeric self-target enables native Kodi wrapping. A builtin action
        # holds the selection at either end of the row.
        listing.find('onleft').text = 'SetFocus(%d)' % cid
        listing.find('onright').text = 'SetFocus(%d)' % cid
        listing.find('onup').text = str(cid-1) if index else str(cid)
        listing.find('ondown').text = str(cid+1) if index+1 < count else str(cid)
        heading = row.find("control[@type='group']")
        heading.find('top').text = '-50'
        # Row children are clipped by the scrolling container. Render the
        # active heading outside it, alongside the existing next-row preview.
        heading.findall('visible')[-1].text = 'false'
        group.append(row)
    from lib.discover_grid import build as build_grid
    build_grid(tree)
    menu = tree.find('.//control[@id="9000"]')
    menu.find('onright').text = 'SetFocus($INFO[Window.Property(first_row)])'
    tree.find('.//control[@id="209"]/onright').text = menu.findtext('onright')
    tree.find('.//control[@id="210"]/onright').text = menu.findtext('onright')
    controls = tree.getroot().find('controls')
    active_heading = copy.deepcopy(template.find("control[@type='group']"))
    active_heading.set('id', '9295')
    active_heading.find('top').text = '640'
    for animation in active_heading.findall('animation'):
        active_heading.remove(animation)
    for visible in active_heading.findall('visible'):
        active_heading.remove(visible)
    ET.SubElement(active_heading, 'visible').text = '!String.IsEmpty(Window.Property(current_row)) + Control.IsVisible(2000)'
    active_heading.find("control[@type='label']/label").text = '$INFO[Window.Property(current_row)]'
    ET.SubElement(active_heading, 'animation', effect='slide', start='0,0', end='0,-24', time='0',
                  condition='!String.IsEmpty(Window.Property(next_row))', reversible='true').text = 'Conditional'
    controls.append(active_heading)
    # Library and Discover have filter pills above their rows. Lift metadata into the
    # shorter browse-text lane so the pills do not cover either metadata row.
    hero = next(c for c in controls.findall('control') if c.find('./control[@id="9280"]') is not None)
    # Lift the complete Home metadata block equally. Animations preserve the
    # positions set later by the variable-height synopsis layout.
    for metadata in hero.findall('control'):
        if metadata.get('id') in ('9280', '9281', '9282') or metadata.get('type') == 'grouplist':
            ET.SubElement(metadata, 'animation', effect='slide', end='0,-40', time='0',
                          condition='String.IsEqual(Window.Property(page),Home)', reversible='true').text = 'Conditional'
    # Keep the original Home credit baseline beside its raised rating row.
    # Discover shares that baseline; Library retains its existing position.
    credits = next(c for c in controls.findall('control') if 'Window.Property(hero_cast)' in ''.join(c.itertext()))
    ET.SubElement(credits, 'animation', effect='slide', start='0,0', end='0,-49', time='0',
                  condition='String.IsEqual(Window.Property(page),Home) | String.IsEqual(Window.Property(page),Discover)', reversible='true').text = 'Conditional'
    for metadata in hero.findall('./control[@type="grouplist"]'):
        content = ''.join(metadata.itertext())
        if 'Window.Property(runtime_tag)' in content or 'Window.Property(rating0_value)' in content:
            ET.SubElement(metadata, 'animation', effect='slide', end='0,-65', time='0',
                          condition='String.IsEqual(Window.Property(page),Library) | String.IsEqual(Window.Property(page),Discover)', reversible='true').text = 'Conditional'
    # Compact readiness feedback is separate from metadata/format diagnostics.
    feedback = ET.SubElement(controls,'control',type='group')
    for key,value in dict(right='24',top='20',width='420',height='48',
            visible='[String.IsEqual(Window.Property(page),Home) + !String.IsEmpty(Window.Property(startup_message))] | String.IsEqual(Window.Property(input_busy),true)').items():
        ET.SubElement(feedback,key).text=value
    background=ET.SubElement(feedback,'control',type='image')
    for key,value in dict(left='0',top='0',width='420',height='48',
            texture='special://home/addons/script.freebird/resources/skins/Main/media/controls/local-card-rounded.png').items():
        ET.SubElement(background,key).text=value
    background.find('texture').set('border','14');background.find('texture').set('colordiffuse','F0242333')
    for label,visible in (('$INFO[Window.Property(startup_message)]','!String.IsEmpty(Window.Property(startup_message))'),
                          ('Please wait…','String.IsEmpty(Window.Property(startup_message))')):
        status=ET.SubElement(feedback,'control',type='label')
        for key,value in dict(left='18',top='0',width='384',height='48',font='font20',
                              textcolor='FFE5E5E7',aligny='center',label=label,visible=visible).items():
            ET.SubElement(status,key).text=value
    for index in range(3):
        button = ET.SubElement(controls, 'control', type='button', id=str(9200+index))
        tags = {'left':str(50+index*290), 'top':'535', 'width':'275', 'height':'60',
                'font':'font23', 'textcolor':'FFE5E5E7', 'focusedcolor':'FF15161D',
                'label':'', 'align':'left', 'textoffsetx':'20',
                'visible':'[String.IsEqual(Window.Property(page),Discover) | String.IsEqual(Window.Property(page),Sports) | String.IsEqual(Window.Property(page),Library)]',
                'onleft':str(9199+index) if index else '9200', 'onright':str(9200+min(index+1,2)),
                'onup':str(9200+index), 'ondown':'SetFocus($INFO[Window.Property(first_row)])',
                'texturefocus':'special://home/addons/script.freebird/resources/skins/Main/media/controls/local-pill-h60-v1.png',
                'texturenofocus':'special://home/addons/script.freebird/resources/skins/Main/media/controls/local-pill-h60-v1.png'}
        if index > 0:
            tags['visible'] += ' + !String.IsEqual(Window.Property(page),Sports)'
            tags['visible'] += ' + !String.IsEqual(Window.Property(collection_save_only),true)'
        for key,value in tags.items():
            node=ET.SubElement(button,key);node.text=value
            if key in ('texturefocus','texturenofocus'):
                node.set('border','30,0,30,0');node.set('colordiffuse','E6FFFFFF' if key=='texturefocus' else '78343B47')
        button.append(copy.deepcopy(group.find('animation')))
        ET.SubElement(button, 'animation', effect='slide', start='0,0', end='0,60', time='0',
                      condition='String.IsEqual(Window.Property(page),Discover) | String.IsEqual(Window.Property(page),Sports) | String.IsEqual(Window.Property(page),Library)', reversible='true').text = 'Conditional'
        # Reserve an independent lane for the arrow. Long filter names must
        # never run underneath it, including with enlarged appearance fonts.
        for focused in (False, True):
            label = ET.SubElement(controls, 'control', type='label',id=str(9240+index*2+int(focused)))
            for key, value in {'left':str(70+index*290),'top':'535','width':'208','height':'60',
                               'font':'font10','textcolor':'FF15161D' if focused else 'FFE5E5E7',
                               'aligny':'center','label':'$INFO[Window.Property(filter_label_%d)]' % index,
                               'visible':tags['visible'] + ' + ' + ('' if focused else '!') + 'Control.HasFocus(%d)' % (9200+index)}.items():
                ET.SubElement(label, key).text = value
            for animation in button.findall('animation'):label.append(copy.deepcopy(animation))
        arrow = ET.SubElement(controls, 'control', type='image',id=str(9260+index))
        for key,value in {'left':str(290+index*290),'top':'560','width':'16','height':'14',
                          'texture':'special://home/addons/script.freebird/resources/skins/Main/media/overlays/arrowdown.png',
                          'visible':tags['visible'] + (' + !String.IsEqual(Window.Property(page),Library)' if index == 2 else '')}.items(): ET.SubElement(arrow,key).text=value
        arrow.append(copy.deepcopy(group.find('animation')))
        ET.SubElement(arrow, 'animation', effect='slide', start='0,0', end='0,60', time='0',
                      condition='String.IsEqual(Window.Property(page),Discover) | String.IsEqual(Window.Property(page),Sports) | String.IsEqual(Window.Property(page),Library)', reversible='true').text = 'Conditional'
        if index==2:
            for focused in (False,True):
                icon=ET.SubElement(controls,'control',type='image',id=str(9272+int(focused)))
                visible='String.IsEqual(Window.Property(page),Library) + String.IsEqual(Window.Property(library_refreshing),true) + '+('' if focused else '!')+'Control.HasFocus(9202)'
                for key,value in dict(left='861',top='551',width='28',height='28',visible=visible,
                    texture='special://home/addons/script.freebird/resources/skins/Main/media/browse-local/refresh.png').items():ET.SubElement(icon,key).text=value
                icon.find('texture').set('colordiffuse','FF15161D' if focused else 'FFB5A4E8')
                icon.append(copy.deepcopy(group.find('animation')))
                ET.SubElement(icon, 'animation', effect='slide', end='0,60', time='0',
                              condition='String.IsEqual(Window.Property(page),Library)', reversible='true').text = 'Conditional'
                ET.SubElement(icon,'animation',effect='rotate',start='0',end='360',center='auto',time='1100',loop='true',condition='String.IsEqual(Window.Property(library_refreshing),true)').text='Conditional'
    selector = tree.find('.//control[@id="9202"]')
    selector.find('onright').set('condition', 'String.IsEmpty(Window.Property(discover_service_filter))')
    ET.SubElement(selector, 'onright', condition='String.IsEqual(Window.Property(page),Discover) + !String.IsEmpty(Window.Property(discover_service_filter))').text = '9204'
    group.find('top').text = '690'
    ET.SubElement(group, 'animation', effect='slide', start='0,0', end='0,-24', time='0',
                  condition='!String.IsEmpty(Window.Property(next_row))',
                  reversible='true').text = 'Conditional'
    # Sports keeps its existing list selector and gains a separate guide action.
    selector = tree.find('.//control[@id="9200"]')
    selector.find('onright').set('condition', '!String.IsEqual(Window.Property(page),Sports)')
    ET.SubElement(selector, 'onright', condition='String.IsEqual(Window.Property(page),Sports)').text = '9203'
    guide = ET.SubElement(controls, 'control', type='button', id='9203')
    for key, value in dict(left='340', top='535', width='200', height='60',
            font='font10', label='TV guide', textcolor='FFE5E5E7', focusedcolor='FF15161D',
            visible='String.IsEqual(Window.Property(page),Sports)',
            onleft='9200', onright='9203', onup='9203',
            ondown='SetFocus($INFO[Window.Property(first_row)])',
            texturefocus='special://home/addons/script.freebird/resources/skins/Main/media/controls/local-pill-h60-v1.png',
            texturenofocus='special://home/addons/script.freebird/resources/skins/Main/media/controls/local-pill-h60-v1.png').items():
        node = ET.SubElement(guide, key)
        node.text = value
        if key in ('texturefocus', 'texturenofocus'):
            node.set('border', '30,0,30,0')
            node.set('colordiffuse', 'E6FFFFFF' if key == 'texturefocus' else '78343B47')
    guide.append(copy.deepcopy(group.find('animation')))
    ET.SubElement(guide, 'animation', effect='slide', start='0,0', end='0,60', time='0',
                  condition='String.IsEqual(Window.Property(page),Sports)', reversible='true').text = 'Conditional'
    preview = tree.find('.//control[@id="2001"]')
    preview.find('label').text = '$INFO[Window.Property(next_row)]'
    preview.find('visible').text = '!String.IsEmpty(Window.Property(next_row))'
    from lib.addons_layout import build
    build(tree)
    # Keep the menu in its own clear lane; dim content beneath it, not the menu.
    sidebar = next(node for node in controls.findall('control')
                   if node.find('.//control[@id="9000"]') is not None)
    # The drawer overlays the current screen; keep hero, rows and filters still.
    for control in controls.findall('control'):
        if control is sidebar:
            continue
        for animation in list(control.findall('animation')):
            if animation.get('condition') == SIDEBAR_FOCUS:
                control.remove(animation)
    dimmer = ET.SubElement(controls, 'control', type='image')
    for key, value in {'left':'0', 'top':'0', 'width':'1920', 'height':'1080',
                       'visible':SIDEBAR_FOCUS,
                       'texture':'special://home/addons/script.freebird/resources/branding/white.png'}.items():
        ET.SubElement(dimmer, key).text = value
    dimmer.find('texture').set('colordiffuse', 'B8000000')
    ET.SubElement(dimmer, 'animation', effect='fade', start='0', end='100',
                  time='240', reversible='true').text = 'VisibleChange'
    controls.remove(sidebar)
    controls.append(sidebar)
    # Keep controls focusable while hiding their pixels for trailer viewing.
    for control in list(controls)[3:]:
        if not any(a.get('condition') == 'String.IsEqual(Window.Property(hero_clean),true) + Player.HasVideo' for a in control.findall('animation')):
            ET.SubElement(control, 'animation', effect='fade', start='100', end='0',
                          time='500', reversible='true',
                          condition='String.IsEqual(Window.Property(hero_clean),true) + Player.HasVideo').text = 'Conditional'
    # Apply animation preferences after the addon page has been added.
    from lib.appearance import apply
    apply(tree, appearance or {})
    from lib.theme import apply as apply_theme
    apply_theme(tree, (appearance or {}).get('theme', 0), (appearance or {}).get('color'))
    # Unique filename ensures the active global skin cannot substitute its own XML.
    path = Path(profile)/'home-layout'
    output = path/'resources/skins/Main/1080i'
    output.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output, suffix='.xml', delete=False) as handle:
            temporary = Path(handle.name)
            tree.write(handle, encoding='utf-8', xml_declaration=True)
        os.replace(temporary, destination)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    marker.write_text(cache_key, encoding='ascii')
    return 'stremio-account-home.xml', str(path), count
