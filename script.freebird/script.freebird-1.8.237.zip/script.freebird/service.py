"""Persistent service: startup shell and watch-progress sync."""
import sys
import threading
import time
from pathlib import Path

_CORE = Path(__file__).resolve().parent / "core"
if str(_CORE) not in sys.path:
    sys.path.insert(0, str(_CORE))

import xbmc
import xbmcgui
import xbmcvfs

from lib.identity_migration import ensure_migrated, HandoffPending
try:
    ensure_migrated()
except HandoffPending:
    raise SystemExit(0)

from account import Store
from addon_state import get_addon
from lib.playback_observer import ProgressPlayer, flush_pending
from lib.skip_segments import SkipSegmentWatcher
from lib.up_next import UpNextWatcher

ADDON = get_addon()
PROFILE = Path(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")))
SESSION_WINDOW_ID = 10000
STARTUP_LAUNCHED = "stremioforkodi.startup.launched"
APP_RUNNING = "stremioforkodi.running"
PROGRESS_READY = "stremioforkodi.progress.ready"
DELAYS = (0, 1, 2, 3, 5)


def configured_delay():
    try:
        index = int(ADDON.getSetting("startup_delay") or "0")
    except (TypeError, ValueError):
        index = 0
    return DELAYS[index] if 0 <= index < len(DELAYS) else 0


class ContinueIndexSync:
    INTERVAL = 60
    def __init__(self):
        self._next = 0
        self._maintenance_next = 0
        self._worker = None
        self._lock = threading.Lock()
    def tick(self):
        window=xbmcgui.Window(SESSION_WINDOW_ID)
        if window.getProperty("strem4kodi.sync.request"):
            window.clearProperty("strem4kodi.sync.request");self._next=0
            if window.getProperty("strem4kodi.sync.manual"):
                window.clearProperty("strem4kodi.sync.manual");self._maintenance_next=0
            from lib.progress_outbox import retry_now
            retry_now()
        now = time.time()
        if now < self._next:
            return
        with self._lock:
            if self._worker is not None and self._worker.is_alive():
                return
            self._next = now + self.INTERVAL
            try:
                self._worker = threading.Thread(target=self._run, daemon=True)
                self._worker.start()
            except RuntimeError:
                self._worker = None
    def _run(self):
        try:
            # Periodic account/CW sync is maintenance work; never compete with
            # active playback or overwrite progress while the watcher is writing it.
            if xbmc.Player().isPlayingVideo():
                return
            from lib.viewer_profiles import ViewerAccount
            store = ViewerAccount(PROFILE).freeze()
            state = store.load()
            token = state.get("token")
            if not token:
                return
            from account import AccountConflict, pull_library, pull_addons
            from addons_core import merge_account
            from lib import continue_index
            maintenance = time.time()>=self._maintenance_next
            if maintenance:
                try:
                    remote, _ = pull_addons(token)
                    state["addons"] = merge_account(state, remote)
                except Exception:
                    pass
            remote_library = state.get('library',[]) if getattr(state,'viewer_id',None) else pull_library(token)
            # Re-read after network I/O so unrelated concurrent state writes are
            # preserved. Merge only fields owned by this maintenance worker.
            latest = store.load()
            if getattr(latest,'viewer_id',None)!=getattr(state,'viewer_id',None):return
            if latest.get("token")!=token or xbmc.Player().isPlayingVideo():return
            # A progress write completed during the pull: retry instead of replacing it.
            if latest.get("library") != state.get("library"):self._next=0;return
            from lib.progress_outbox import reconcile_library
            remote_library = reconcile_library(store, token, latest.get("library"), remote_library)
            changed=latest.get("library")!=remote_library
            state["library"] = remote_library
            try:
                # Save against the pre-fetch snapshot. Only our changed fields
                # merge; edits or disconnects during either network call win.
                store.save(state)
            except AccountConflict:
                self._next = 0
                return
            from lib.viewer_profiles import directory as viewer_directory
            index_profile=viewer_directory(PROFILE,getattr(state,'viewer_id',None))
            from lib.progress_outbox import projected_library
            continue_index.seed(index_profile, projected_library(store))
            if changed:
                from lib.progress_signal import publish
                publish({"meta_id":"*","video_id":""})
            Store(PROFILE/'sync-status').save({'updated':time.time()})
            # Resolve completed/sentinel series in this daemon worker, not Home.
            from continue_playback import continue_series_target
            from lib import backend as home_api
            for media_id, row in continue_index.unresolved_series(index_profile, 8):
                try:
                    full = home_api.metadata(row)
                    target, resume_ms = continue_series_target(full.get("videos") or [], row)
                    projected = dict(row)
                    projected.update({k:v for k,v in full.items() if v not in ("",None,[],{})})
                    projected["id"] = media_id
                    status = str(full.get("status") or "").strip().lower()
                    confirmed = target is None and status in ("ended","canceled","cancelled")
                    continue_index.resolve_series(index_profile, media_id, projected, target, resume_ms, confirmed)
                except Exception:
                    continue
            if changed:
                from lib.progress_signal import publish
                publish({"meta_id":"*","video_id":""})
            if not maintenance:return
            self._maintenance_next=time.time()+900
            # Source lookups belong to explicit title/source opening. Shared
            # format facts are refreshed by FormatSync without provider scans.
        except Exception:
            return


def maybe_autostart(monitor):
    if ADDON.getSetting("startup_autostart") != "true":
        return
    session = xbmcgui.Window(SESSION_WINDOW_ID)
    if session.getProperty(STARTUP_LAUNCHED) == "true":
        return
    session.setProperty(STARTUP_LAUNCHED, "true")
    delay = configured_delay()
    if delay and monitor.waitForAbort(delay):
        return
    if not monitor.abortRequested() and session.getProperty(APP_RUNNING) != "true":
        from lib.browse_background import starting
        starting(session)
        xbmc.executebuiltin("RunScript(script.freebird,startup)")


def main():
    monitor = xbmc.Monitor()

    # Unit tests may execute main() with only the historical startup symbols.
    if "ProgressPlayer" not in globals():
        maybe_autostart(monitor)
        return

    player = ProgressPlayer()
    from lib.service_guard import ServiceGuard
    guard = ServiceGuard(lambda message: xbmc.log(message, xbmc.LOGWARNING), profile=PROFILE)
    class Disabled:
        def tick(self):pass
        def close(self):pass

    def component(module, name, *args, **kwargs):
        def construct():
            from importlib import import_module
            return getattr(import_module(module), name)(*args, **kwargs)
        return guard.run(name + ' setup', construct) or Disabled()

    session = xbmcgui.Window(SESSION_WINDOW_ID)
    player_display = file_chapters = up_next = skip_watcher = Disabled()
    live_tv = Disabled()
    try:
        def diagnostics():
            from lib.diagnostic_events import install
            install(PROFILE)
        guard.run('diagnostic setup', diagnostics)
        live_tv = component('lib.live_tv_server', 'LiveService', session, player)
        def load_rpc():
            from setup_profile import rpc
            return rpc
        rpc = guard.run('native RPC setup', load_rpc)
        if rpc is None:
            def rpc(*args, **kwargs):raise RuntimeError('Native RPC unavailable')
        player_osd = component('lib.player_osd', 'PlayerOSD', player, ADDON)
        player_display = component('lib.player_display', 'PlayerDisplay', player)
        file_chapters = component('lib.file_chapter_cache', 'Watcher', PROFILE, player, xbmc, session, rpc)
        forced_subtitles = component('lib.forced_subtitles', 'ForcedSubtitleWatcher', PROFILE, ADDON, player, xbmc, session, rpc)
        diagnostic_reporter = component('lib.diagnostic_export', 'Reporter', PROFILE, ADDON,
            xbmcvfs.translatePath('special://logpath/'), idle=lambda: not xbmc.Player().isPlayingVideo(), player=player)
        series_tracks = component('lib.series_tracks', 'Watcher', PROFILE, player, session, rpc)
        continue_sync = guard.run('account sync setup', ContinueIndexSync) or Disabled()
        skip_watcher = guard.run('skip segments setup', SkipSegmentWatcher, PROFILE) or Disabled()
        up_next = guard.run('up next setup', UpNextWatcher, PROFILE, player) or Disabled()
        credits_sync = component('lib.credits_sync', 'CreditsSync', PROFILE, ADDON)
        saved_lists_sync = component('lib.saved_lists_sync', 'SavedListsSync', PROFILE, ADDON)
        home_state_sync = component('lib.home_state_sync', 'HomeStateSync', PROFILE, ADDON)
        viewer_sync = component('lib.viewer_sync', 'ViewerSync', PROFILE, ADDON)
        preroll_catalogue = component('lib.preroll_catalog', 'Watcher', PROFILE, ADDON)
        format_sync = component('lib.format_sync', 'FormatSync', PROFILE, ADDON)
        def disc_formats():
            from lib.fel_catalog import request
            request(PROFILE)
        guard.run('disc formats', disc_formats)
        session.setProperty(PROGRESS_READY, "true")
        guard.run('autostart', maybe_autostart, monitor)
        # Service updates can restart while a video is already playing.
        startup_tasks=(('account sync',continue_sync.tick),('credits sync',credits_sync.tick),
                       ('saved lists',saved_lists_sync.tick),('home sync',home_state_sync.tick),
                       ('format sync',format_sync.tick),('prerolls',preroll_catalogue.tick),
                       ('up next',up_next.tick),('skip segments',skip_watcher.tick))
        from lib.browse_background import pending
        optional = {name for name, _ in startup_tasks[:6]} | {'viewer sync', 'diagnostics'}
        for name,callback in startup_tasks:
            if name not in optional or not pending(session):guard.run(name,callback)
        tasks=(('diagnostics',diagnostic_reporter.tick),('viewer sync',viewer_sync.tick))+startup_tasks[:6]+(
            ('progress',player.tick),('series tracks',series_tracks.tick),
            ('forced subtitles',forced_subtitles.tick),('player display',player_display.tick),
            ('file chapters',file_chapters.tick),
            ('player controls',player_osd.tick))+startup_tasks[6:]
        from lib.progress_outbox import tick as outbox_tick
        from lib.viewer_profiles import ViewerAccount
        progress_store=ViewerAccount(PROFILE)
        while not monitor.waitForAbort(1):
            guard.run('live TV', live_tv.tick)
            for name,callback in tasks:
                if name not in optional or not pending(session):guard.run(name,callback)
            while guard.run('progress queue',flush_pending,player):
                pass
            guard.run('progress upload',outbox_tick,progress_store)
        guard.run('final progress',player._finish,False)
        while guard.run('progress queue',flush_pending,player):
            pass
    finally:
        guard.run('live TV cleanup', live_tv.close)
        recovery = getattr(player, '_live_recovery', None)
        if recovery:
            guard.run('live cancel',recovery.cancel)
            guard.run('live cleanup',recovery.finish_covers)
        guard.run('display cleanup',player_display.close)
        guard.run('file chapters cleanup',file_chapters.close)
        guard.run('up next cleanup',up_next.close)
        guard.run('skip cleanup',skip_watcher.close)
        guard.run('service marker cleanup',session.clearProperty,PROGRESS_READY)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        try:
            from lib.diagnostic_events import record
            record('service', error, PROFILE)
        except Exception:pass
        raise
