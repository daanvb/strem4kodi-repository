"""Cast and director overlay for the current playback session."""
from datetime import date
from hashlib import sha256
from pathlib import Path


def profile_columns(person, data, today=None):
    today = today or date.today()
    lines = []
    try:
        born = date.fromisoformat(data.get('birthday') or '')
        end = date.fromisoformat(data['deathday']) if data.get('deathday') else today
        age = end.year - born.year - ((end.month, end.day) < (born.month, born.day))
        lines.append('Born %s  ·  %s %d' % (born.strftime('%d %B %Y'),
                     'Age at death' if data.get('deathday') else 'Age', age))
    except ValueError:
        pass
    lines.extend(filter(None, [data.get('place_of_birth'), data.get('biography')]))
    credits = data.get('combined_credits') or {}
    directors = [row for row in credits.get('crew', []) if row.get('job') == 'Director']
    rows = sorted(credits.get('cast', []) + directors,
                  key=lambda row: row.get('release_date') or row.get('first_air_date') or '', reverse=True)
    films = []
    for row in rows:
        title = row.get('title') or row.get('name')
        if title and not row.get('adult'):
            year = (row.get('release_date') or row.get('first_air_date') or '')[:4]
            line = '  ·  '.join(filter(None, [year, title, row.get('character') or row.get('job')]))
            if line not in films:
                films.append(line)
    bio = '\n\n'.join(lines) or person.get('job') or 'No further details available.'
    return bio, '\n'.join(films) or 'No credits available.'


def show():
    import xbmc
    import xbmcgui
    import xbmcvfs
    from account import Store
    from addon_state import get_addon
    from lib.backend import details, providers
    from lib.player_controls import menu_session_active
    from lib.ui_dialogs import dialog as themed_dialog
    from lib.theme import window
    from lib.title_metadata import people
    from tmdb_metadata import request, identity as tmdb_identity, photo

    addon = get_addon()
    player = xbmc.Player()
    file = player.getPlayingFile()
    context = Store(Path(xbmcvfs.translatePath(addon.getAddonInfo('profile'))) / 'playback').load()
    if context.get('url_hash') != sha256(file.encode()).hexdigest():
        return
    kind, identity = context.get('kind'), str(context.get('id') or '').split(':')[0]
    if kind not in ('movie', 'series') or not identity:
        return
    meta = dict(details(kind, identity, providers=providers('metadata')) or {}, type=kind, id=identity)
    people_rows = people(meta) + [p for p in people(meta, 'crew') if 'director' in (p.get('job') or '').lower()]
    # Series metadata describes the whole show. Prefer episode-specific credits
    # when the provider supplies them, including guest stars and its director.
    key = addon.getSetting('tmdb_api_key').strip()
    season, episode = xbmc.getInfoLabel('VideoPlayer.Season'), xbmc.getInfoLabel('VideoPlayer.Episode')
    if key and kind == 'series' and season.isdecimal() and episode.isdecimal():
        try:
            resolved = tmdb_identity(meta, key)
            if resolved:
                credits = request(key, 'tv/%s/season/%s/episode/%s/credits' % (resolved[1], season, episode))
                entries = credits.get('cast', []) + credits.get('guest_stars', [])
                entries += [p for p in credits.get('crew', []) if p.get('job') == 'Director']
                episode_rows = [dict(name=p['name'], job=p.get('character') or p.get('job'),
                                     tmdb_person_id=p.get('id'), poster=photo(p.get('profile_path')))
                                for p in entries if p.get('name')]
                if episode_rows:
                    people_rows = episode_rows
        except Exception:
            pass
    if not menu_session_active(player, file):
        return
    if not people_rows:
        themed_dialog().notification('Cast & Director', 'No credits available for this title.')
        return
    class Panel(xbmcgui.WindowXMLDialog):
        def onInit(self):
            self.detail = False
            self.profiles = {}
            self.roster = self.getControl(50)
            for person in people_rows:
                item = xbmcgui.ListItem(person['name'], person.get('job') or '')
                item.setArt({'thumb': person.get('poster') or 'DefaultActor.png'})
                self.roster.addItem(item)
            self.setFocus(self.roster)

        def onClick(self, control):
            if control != 50 or self.detail:
                return
            if not menu_session_active(player, file):
                self.close()
                return
            person = people_rows[self.roster.getSelectedPosition()]
            pid = str(person.get('tmdb_person_id') or '')
            key = addon.getSetting('tmdb_api_key').strip()
            if pid.isdecimal() and key and pid not in self.profiles:
                try:
                    self.profiles[pid] = request(key, 'person/' + pid, append_to_response='combined_credits')
                except Exception:
                    pass
            self.detail = True
            self.setProperty('profile', 'true')
            self.getControl(52).setImage(person.get('poster') or 'DefaultActor.png')
            self.getControl(53).setLabel(person['name'])
            bio, credits = profile_columns(person, self.profiles.get(pid) or {})
            self.getControl(54).setText(bio)
            self.getControl(57).setText(credits)
            self.getControl(57).scroll(0)
            self.getControl(54).scroll(0)
            self.setFocusId(55)

        def onAction(self, action):
            if action.getId() in (10, 92, 216, 247):
                if self.detail:
                    self.detail = False
                    self.clearProperty('profile')
                    self.setFocus(self.roster)
                else:
                    self.close()

    dialog = window(Panel, 'script-freebird-player-people.xml', addon.getAddonInfo('path'), 'Main', '1080i')
    home = xbmcgui.Window(10000)
    home.setProperty('strem4kodi.player.people', 'true')
    try:
        dialog.doModal()
    finally:
        home.clearProperty('strem4kodi.player.people')
