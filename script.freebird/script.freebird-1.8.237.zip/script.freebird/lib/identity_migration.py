"""One-time local identity migration; never fetch or log private profile values."""
import errno
import json
import time
from pathlib import Path
from xml.etree.ElementTree import ParseError

MARKER = '.freebird-identity-v1'
_ready = False


class MigrationRequired(RuntimeError):
    pass


class HandoffPending(MigrationRequired):
    pass


def failure_message(stage, error):
    """Explain the failed step without exposing paths, keys or profile values."""
    if isinstance(error, MigrationRequired):
        return str(error)
    reason = 'Kodi could not complete this step.'
    if isinstance(error, ParseError):
        reason = 'Kodi could not read a settings XML file.'
    elif isinstance(error, OSError):
        reason = {
            errno.ENOSPC: 'The profile storage is full.',
            errno.EACCES: 'The profile storage denied access.',
            errno.EPERM: 'The profile storage rejected the operation.',
            errno.EROFS: 'The profile storage is read-only.',
            errno.ENOTSUP: 'The profile storage does not support this operation.',
            errno.ENOSYS: 'This device does not support the required file operation.',
        }.get(error.errno, 'Kodi could not read or write profile data.')
    return f'Migration stopped while {stage}. {reason} Existing data is retained.'


def migrate_profiles(data_root, app, skin, legacy_enabled, active_skin, timeout=20):
    """Copy missing data after old writers stop; retries never replace new data."""
    from addon_state import migrate_profile
    root = Path(data_root)
    old = root / 'script.strem4kodi'
    if legacy_enabled:
        raise MigrationRequired('Disable the old app (script.strem4kodi), restart Kodi, then open freeBird again. Keep its data for migration.')
    if active_skin == 'skin.strem4kodi' or (active_skin == 'skin.freebird'
            and (root / 'skin.strem4kodi' / 'settings.xml').exists()
            and not (root / 'skin.freebird' / MARKER).exists()):
        raise MigrationRequired('Switch to Kodiâ€™s Estuary skin and restart Kodi before migrating. You can select freeBird Player afterwards.')
    if not old.is_dir():
        return
    target = root / 'script.freebird'
    if old.is_symlink() or target.is_symlink():
        raise MigrationRequired('Profile migration does not support linked profile directories.')
    target.mkdir(parents=True, exist_ok=True)
    lock = target / '.freebird-migration-lock'
    deadline = time.monotonic() + timeout
    while True:
        try:
            lock.mkdir()
            break
        except FileExistsError:
            if time.monotonic() >= deadline:
                raise MigrationRequired('Another migration is running or was interrupted. Restart Kodi; if this persists, follow the migration recovery guide.')
            time.sleep(0.1)
    try:
        old_skin = root / 'skin.strem4kodi'
        new_skin = root / 'skin.freebird'
        if old_skin.is_symlink() or new_skin.is_symlink():
            raise MigrationRequired('Profile migration does not support linked skin directories.')
        if old_skin.is_dir():
            migrate_profile(old_skin, new_skin, None, marker_name=MARKER, skin_settings=True)
        migrate_profile(old, target, app.setSetting, marker_name=MARKER)
    finally:
        lock.rmdir()


def ensure_migrated(interactive=False):
    global _ready
    if _ready:
        return
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    location = xbmcvfs.translatePath('special://profile/addon_data')
    root = Path(location)
    stage = 'checking the previous installation'
    try:
        if '://' in location:
            raise MigrationRequired('Automatic identity migration requires a local Kodi profile. Follow the migration guide before using a network profile.')
        # Query Kodi rather than infer enabled state from old files. Fail closed
        # when an old profile exists but Kodi cannot establish writer ownership.
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddonDetails',
            'params': {'addonid': 'script.strem4kodi', 'properties': ['enabled']}})))
        details = response.get('result', {}).get('addon')
        if details is None:
            if (root / 'script.strem4kodi').is_dir() and response.get('error', {}).get('code') != -32602:
                raise MigrationRequired('Kodi could not confirm that the old app has stopped. Restart Kodi and try again.')
            enabled = False  # Invalid-params means this specific addon is not installed.
        else:
            enabled = details.get('enabled')
            if not isinstance(enabled, bool):
                raise MigrationRequired('Kodi could not confirm the old app state. Restart Kodi and try again.')
        from lib import migration_wizard as wizard
        session = xbmcgui.Window(10000)
        if interactive and wizard.skin_change_pending(session, xbmc):
            raise HandoffPending('Reopen freeBird after Kodi finishes confirming the skin change.')
        skin_pending = xbmc.getSkinDir() == 'skin.strem4kodi' or (
            xbmc.getSkinDir() == 'skin.freebird' and (root / 'skin.strem4kodi' / 'settings.xml').exists()
            and not (root / 'skin.freebird' / MARKER).exists())
        if enabled or skin_pending or wizard.restart_pending(root, session):
            stage = 'preparing the handoff'
            if interactive:
                # Native dialogs survive the skin lifecycle; themed Python
                # windows can be recreated while Kodi reloads the old skin.
                ui = xbmcgui.Dialog()
                backend = wizard.KodiBackend()
                if enabled or skin_pending:
                    prepared = wizard.prepare(root, backend, ui)
                    if prepared:
                        wizard.offer_restart(backend, ui)
                    elif prepared is None and enabled:
                        backend.open_previous()
                else:
                    wizard.offer_restart(backend, ui)
            raise HandoffPending('Close and reopen Kodi to finish the update. Your old data is kept.')
        stage = 'copying settings and profile files'
        migrate_profiles(root, xbmcaddon.Addon('script.freebird'),
                         None, enabled, xbmc.getSkinDir())
        if interactive:
            stage = 'applying the player appearance'
            wizard.finish(root, wizard.KodiBackend(), xbmcgui.Dialog())
        _ready = True
    except Exception as error:
        from lib.migration_wizard import SkinChangePending
        if isinstance(error, SkinChangePending):
            if interactive:
                raise SystemExit(0) from None
            raise HandoffPending('Skin change is pending; reopen freeBird when Kodi is ready.') from None
        if isinstance(error, HandoffPending):
            if interactive:
                raise SystemExit(0) from None
            raise
        message = failure_message(stage, error)
        if interactive:
            xbmcgui.Dialog().ok('freeBird migration', message)
        xbmc.log('freeBird identity migration incomplete; startup stopped.', xbmc.LOGWARNING)
        raise MigrationRequired(message) from None
