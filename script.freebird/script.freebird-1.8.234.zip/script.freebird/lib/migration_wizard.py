"""Guided, restart-separated handoff. Stores only migration flags, never secrets."""
import json
import os
import uuid
from pathlib import Path

SESSION_KEY = 'freebird.migration.restart'
STATE_NAME = '.freebird-handoff.json'


class SkinChangePending(RuntimeError):
    """Stop this launch without opening a dialog over an unfinished reload."""


def read_state(root):
    folder = Path(root) / 'script.freebird'
    if folder.is_symlink():
        raise RuntimeError('Linked migration profile is unsupported')
    path = folder / STATE_NAME
    if not path.exists():
        return None
    if path.is_symlink():
        raise RuntimeError('Linked migration state is unsupported')
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or not isinstance(data.get('token'), str) or not isinstance(data.get('player'), bool):
        raise RuntimeError('Invalid migration state')
    return data


def save_state(root, state):
    target = Path(root) / 'script.freebird'
    if target.is_symlink():
        raise RuntimeError('Linked migration profile is unsupported')
    target.mkdir(parents=True, exist_ok=True)
    path = target / STATE_NAME
    temporary = target / (STATE_NAME + '.' + uuid.uuid4().hex)
    try:
        temporary.write_text(json.dumps(state), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def restart_pending(root, session):
    state = read_state(root)
    return bool(state and session.getProperty(SESSION_KEY) == state['token'])


def prepare(root, backend, ui):
    """Nothing changes before consent; partial handoffs remain safely retryable."""
    if backend.playing():
        ui.ok('Finish playback first', 'Stop the video, then open freeBird again to finish the update.')
        return False
    if not ui.yesno('Welcome to freeBird',
                    'We can move your settings for you. Your old data stays on this device. If Kodi asks to keep its skin change, choose Yes, then open freeBird again. We will then guide you through restarting Kodi.',
                    nolabel='Keep current app', yeslabel='Continue'):
        return None
    state = read_state(root) or {'token': uuid.uuid4().hex, 'player': backend.skin() in ('skin.strem4kodi', 'skin.freebird')}
    # Set the session gate BEFORE saving state or stopping any old components.
    # It survives script exits, but is cleared by a real Kodi restart.
    backend.session.setProperty(SESSION_KEY, state['token'])
    save_state(root, state)
    # Stop startup/service writers before reloading the skin: the old service
    # must not launch another Python window during the native confirmation.
    if backend.legacy_enabled():
        backend.disable_legacy()
        if backend.legacy_enabled():
            ui.ok('Update paused', 'Kodi could not stop the previous app. Your data is unchanged. Try again after restarting Kodi.')
            return False
    if backend.skin() in ('skin.strem4kodi', 'skin.freebird'):
        backend.set_skin('skin.estuary')
        # Kodi owns the confirmation after this script exits. Never create a
        # second dialog while ReloadSkin is using the native yes/no window.
        return False
    return True


def offer_restart(backend, ui):
    if ui.yesno('One last step', 'Close Kodi, then open it again from your Fire TV home screen. We will finish moving your settings automatically.',
                nolabel='Later', yeslabel='Close Kodi'):
        backend.quit()


def finish(root, backend, ui):
    state = read_state(root)
    if not state:
        return
    if state['player'] and backend.skin() != 'skin.freebird':
        if ui.yesno('Your settings are ready', 'Your old data has been kept. Use freeBird Player? Keep Kodi’s skin change, then open freeBird again.',
                    nolabel='Later', yeslabel='Use player'):
            backend.set_skin('skin.freebird')
            raise SkinChangePending('Reopen freeBird after confirming the player skin')
    else:
        ui.ok('You are ready', 'Your settings have been moved. Your old data has been kept on this device.')
    (Path(root) / 'script.freebird' / STATE_NAME).unlink()


class KodiBackend:
    def __init__(self):
        import xbmc
        import xbmcgui
        self.kodi = xbmc
        self.session = xbmcgui.Window(10000)

    def rpc(self, method, params):
        response = json.loads(self.kodi.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
        if 'error' in response or 'result' not in response:
            raise RuntimeError('Kodi migration action unavailable')
        return response['result']

    def playing(self):
        return self.kodi.Player().isPlaying()

    def skin(self):
        return self.kodi.getSkinDir()

    def set_skin(self, identity):
        # Settings.SetSettingValue queues ReloadSkin; its return does not mean
        # windows have been rebuilt. Opening our next Python modal immediately
        # can deadlock Kodi 21 during that rebuild.
        if self.skin() == identity:
            return
        self.kodi.executebuiltin('ActivateWindow(home)', True)
        self.rpc('Settings.SetSettingValue', {'setting': 'lookandfeel.skin', 'value': identity})

    def legacy_enabled(self):
        enabled = self.rpc('Addons.GetAddonDetails', {'addonid': 'script.strem4kodi', 'properties': ['enabled']})['addon']['enabled']
        if not isinstance(enabled, bool):
            raise RuntimeError('Kodi did not confirm the previous app state')
        return enabled

    def disable_legacy(self):
        self.rpc('Addons.SetAddonEnabled', {'addonid': 'script.strem4kodi', 'enabled': False})

    def open_previous(self):
        self.kodi.executebuiltin('RunScript(script.strem4kodi,legacy)')

    def quit(self):
        # Let the native confirmation and this Python invocation retire before
        # Kodi starts tearing down its Python/UI subsystems.
        self.kodi.executebuiltin('AlarmClock(freebird_migration_quit,Quit,00:00:02,silent,false)')
