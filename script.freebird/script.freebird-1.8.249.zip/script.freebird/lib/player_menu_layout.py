"""Size playback pickers to their contents while retaining a scrollable list."""
import xml.etree.ElementTree as ET


def compact_picker(tree, count):
    controls = tree.getroot().find('controls')
    listing = controls.find('control[@id="600"]')
    rows = max(1, min(5, count))
    height = rows * 100
    panel_height = height + 210
    top = (1080 - panel_height) // 2
    panel = controls.findall('control[@type="image"]')[1]
    panel.find('top').text = str(top)
    panel.find('height').text = str(panel_height)
    for control in list(controls):
        label = control.findtext('label', '')
        if label == 'Back to cancel':
            controls.remove(control)
        elif label == '$INFO[Window.Property(dialog_title)]':
            control.find('top').text = str(top + 30)
        elif label == '$INFO[Window.Property(dialog_help)]':
            control.find('top').text = str(top + 95)
    listing.find('top').text = str(top + 165)
    listing.find('height').text = str(height)
    ET.SubElement(listing, 'pagecontrol').text = '601'
    ET.SubElement(listing, 'onright').text = '601'
    bar = ET.SubElement(controls, 'control', type='scrollbar', id='601')
    for tag, value in (('left','1372'), ('top',str(top+165)), ('width','8'),
                       ('height',str(height)), ('orientation','vertical'),
                       ('showonepage','false'), ('onleft','600'), ('onright','600')):
        ET.SubElement(bar, tag).text = value


def compact_selection(tree, count, multi=False):
    controls = tree.getroot().find('controls')
    listing = controls.find('control[@id="600"]')
    height = max(1, min(7, count)) * 66
    panel_height = height + (190 if multi else 140)
    top = (1080 - panel_height) // 2
    panel = controls.findall('control[@type="image"]')[1]
    panel.find('top').text = str(top)
    panel.find('height').text = str(panel_height)
    controls.find('control[@type="label"]/top').text = str(top + 30)
    listing.find('top').text = str(top + 105)
    listing.find('height').text = str(height)
    ET.SubElement(listing, 'pagecontrol').text = '601'
    ET.SubElement(listing, 'onright').text = '601'
    for cid in ('201', '202'):
        controls.find('control[@id="' + cid + '"]/top').text = str(top + height + 115)
    bar = ET.SubElement(controls, 'control', type='scrollbar', id='601')
    for tag, value in (('left','1350'), ('top',str(top+105)), ('width','8'),
                       ('height',str(height)), ('orientation','vertical'),
                       ('showonepage','false'), ('onleft','600'), ('onright','600')):
        ET.SubElement(bar, tag).text = value
