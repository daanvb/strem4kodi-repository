"""Use queued scrubbing only for the owned companion player."""
def run(direction, kodi=None, gui=None):
    if kodi is None:
        import xbmc as kodi
    if gui is None:
        import xbmcgui as gui
    top = gui.getCurrentWindowDialogId()
    # Kodi's WINDOW_INVALID (9999) means there is no modal dialog.
    if top not in (-1, 0, 9999, 10115, 12901):
        return  # Never forward a seek through an options or chapter dialog.
    if (kodi.getSkinDir() == 'skin.freebird'
            and gui.Window(10000).getProperty('strem4kodi.player.active') == 'true'
            and kodi.Player().isPlayingVideo()):
        if gui.Window(10000).getProperty('strem4kodi.player.live') == 'true':
            if direction == 0:
                kodi.executebuiltin('ActivateWindow(videoosd)')
                kodi.executebuiltin('SetFocus(9001)' if kodi.getCondVisibility('Player.PauseEnabled') else 'SetFocus(9002)')
            elif kodi.getCondVisibility('Player.SeekEnabled'):
                kodi.executebuiltin('Action(StepBack)' if direction < 0 else 'Action(StepForward)')
            return
        if gui.Window(10000).getProperty('strem4kodi.player.scrubbing'):
            return
        if direction == 0:
            kodi.executebuiltin('ActivateWindow(videoosd)')
            kodi.executebuiltin('SetFocus(9001)')
            return
        from lib.player_scrub import show
        show(direction)
    else:
        kodi.executebuiltin('Action(BigStepBack)' if direction == 0 else 'Action(StepBack)' if direction < 0 else 'Action(StepForward)')
