"""Shared add-on identity and non-destructive migration from the former core."""
from pathlib import Path
import errno
import os
import shutil
import sys
import tempfile
import xml.etree.ElementTree as ET
import xbmcaddon
import xbmcvfs

ADDON_ID = 'script.freebird'


def _publish_without_replace(temporary, destination):
    """Publish a complete file atomically, including on Android shared storage."""
    try:
        os.link(temporary, destination)
        return
    except FileExistsError:
        return
    except OSError as error:
        if error.errno not in {errno.EACCES, errno.EPERM, errno.ENOSYS,
                               errno.ENOTSUP, errno.EOPNOTSUPP} and not (
                os.name == 'nt' and (isinstance(error, PermissionError)
                                    or getattr(error, 'winerror', None) in {1, 50})):
            raise
        if os.name == 'nt':
            try:
                os.rename(temporary, destination)
            except FileExistsError:
                pass
            return
        if not sys.platform.startswith('linux'):
            raise
        # Fire OS emulated storage rejects hard links but supports the kernel's
        # atomic no-replace rename. Never fall back to an overwriting rename.
        import ctypes
        libc = ctypes.CDLL(None, use_errno=True)
        rename = getattr(libc, 'renameat2', None)
        if rename is None:
            raise error
        rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int,
                           ctypes.c_char_p, ctypes.c_uint]
        rename.restype = ctypes.c_int
        if rename(-100, os.fsencode(temporary), -100, os.fsencode(destination), 1):
            number = ctypes.get_errno()
            if number != errno.EEXIST:
                raise OSError(number, 'Atomic profile publication failed')


def migrate_profile(source, target, set_setting, marker_name=".core-migrated-v1", skin_settings=False):
    """Copy missing legacy files once; never remove or replace either profile."""
    source, target = Path(source), Path(target)
    target.mkdir(parents=True, exist_ok=True)
    marker = target / marker_name
    if marker.exists():
        return
    if source.is_dir():
        current = target / 'settings.xml'
        old_settings = source / 'settings.xml'
        if current.is_symlink() or old_settings.is_symlink():
            raise ValueError('Linked settings files cannot be migrated')
        existing = {s.get('id') for s in ET.parse(current).iter('setting')
                    if s.get('default') != 'true'} if current.exists() else set()
        if old_settings.exists():
            previous = ET.parse(old_settings).getroot()
            if skin_settings:
                # Kodi skins use typed bool/string nodes, not Addon.setSetting.
                # Both skins must be inactive while the caller holds its lock.
                merged = ET.parse(current).getroot() if current.exists() else ET.Element('settings')
                if merged.tag != 'settings' or previous.tag != 'settings':
                    raise ValueError('Invalid skin settings document')
                owned = {node.get('id') for node in merged.findall('setting')}
                changed = False
                for setting in previous.findall('setting'):
                    key = setting.get('id')
                    if not key or key in owned:
                        continue
                    if setting.get('type') not in ('bool', 'string'):
                        raise ValueError('Invalid skin setting type')
                    merged.append(setting)
                    owned.add(key)
                    changed = True
                if changed:
                    fd, temporary = tempfile.mkstemp(dir=target, prefix='.skin-migration-')
                    try:
                        with os.fdopen(fd, 'wb') as out:
                            out.write(ET.tostring(merged, encoding='utf-8', xml_declaration=True))
                            out.flush()
                            os.fsync(out.fileno())
                        os.replace(temporary, current)
                    finally:
                        if os.path.exists(temporary):
                            os.unlink(temporary)
            else:
                for setting in previous.iter('setting'):
                    key = setting.get('id')
                    if key and key not in existing:
                        if set_setting(key, setting.get('value', setting.text or '')) is False:
                            raise OSError('Profile setting could not be saved')
        for old in source.rglob('*'):
            if not old.is_file() or old.is_symlink() or old.name.startswith('.') or old == old_settings:
                continue
            new = target / old.relative_to(source)
            if source.resolve() not in old.resolve().parents or target.resolve() not in new.resolve().parents:
                raise ValueError('Profile migration path escapes its directory')
            if new.exists():
                continue
            new.parent.mkdir(parents=True, exist_ok=True)
            fd, temporary = tempfile.mkstemp(dir=new.parent, prefix='.migration-')
            try:
                with os.fdopen(fd, 'wb') as out, old.open('rb') as inp:
                    shutil.copyfileobj(inp, out)
                _publish_without_replace(temporary, new)
            finally:
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass  # Windows fallback moved the completed temporary file.
    marker.touch()


def get_addon():
    # Adapted from upstream 0d24a03: recover only our own running context.
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
    except RuntimeError:
        addon = xbmcaddon.Addon()
        if addon.getAddonInfo('id') != ADDON_ID:
            raise RuntimeError('freeBird addon context unavailable') from None
    # Independent profile: do not import settings from the upstream addon.
    return addon
