"""Viewer identities and isolated library storage; credentials remain shared.

Main copies the legacy stores, retaining originals. New viewers start empty. Deletion is a tombstone,
never a recursive filesystem delete, so an offline client cannot resurrect it.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import time
import threading
import uuid

MAIN = 'main'
MAX_PROFILES = 12
_token_cache={}
_config_cache={}
_current_cache = {}
_current_lock = threading.Lock()
OWNED_STORES = frozenset(('progress-outbox', 'progress-outbox-unsupported',
    'progress-sync-status', 'sync-status', 'successful-sources', 'series-tracks',
    'home-snapshot', 'saved-lists-sync', 'home-state-sync'))


def valid_id(value):
    return value == MAIN or isinstance(value, str) and re.fullmatch(r'[0-9a-f]{32}', value) is not None


def clean(records):
    import math
    result = {}
    if not isinstance(records, dict):return result
    for identity, row in records.items():
        if not valid_id(identity) or not isinstance(row, dict):continue
        stamp = row.get('updated')
        name = row.get('name')
        if (type(stamp) not in (int, float) or not math.isfinite(stamp) or stamp < 0
                or not isinstance(name, str) or not name.strip() or len(name) > 40
                or any(ord(c) < 32 or c in '[]' for c in name)):
            continue
        result[identity] = dict(name=name.strip(), updated=stamp, deleted=row.get('deleted') is True)
    return result


def merge(left, right):
    result = clean(left)
    for identity, row in clean(right).items():
        old = result.get(identity)
        # Deletion is permanent for this ID. A replacement gets a fresh UUID.
        if old is None or (row['deleted'], row['updated'], row['name']) > (old['deleted'], old['updated'], old['name']):
            result[identity] = row
    return result


def _shared(root):
    from account import Store
    return Store(root).load()


def _token(root):
    path=Path(root)/'account.json'
    try:
        signature=_file_stamp(path)
    except OSError:return None
    key=str(path);cached=_token_cache.get(key)
    if cached and cached[0]==signature:return cached[1]
    token=_shared(root).get('token')
    if len(_token_cache)>64:_token_cache.clear()
    _token_cache[key]=(signature,token)
    return token


def _configuration(root, *, snapshot=True):
    """Do not repeatedly parse/copy the legacy Main library for new viewers."""
    from account import Snapshot
    path=Path(root)/'account.json'
    signature=_file_stamp(path);key=str(path)
    cached=_config_cache.get(key)
    if cached and cached[0] == signature:
        value = cached[1]
    else:
        value={k:v for k,v in _shared(root).items() if k!='library'}
        if len(_config_cache)>64:_config_cache.clear()
        _config_cache[key]=(signature,value)
    # Read-only callers need an isolated value, without a second copy for saving.
    return Snapshot(value) if snapshot else deepcopy(value)


def registry(root):
    from account import Store
    return Store(Path(root) / 'viewer-registry')


def _owner(token):
    return hashlib.sha256(str(token or '').encode()).hexdigest()


def state(root, token=None):
    if not (Path(root)/'viewer-registry'/'account.json').is_file():return {}
    token = _token(root) if token is None else token
    data = registry(root).load()
    if not token or data.get('owner') != _owner(token):return {}
    records = clean(data.get('records'))
    active = data.get('active')
    if not records:return {}
    if active not in records or records[active]['deleted']:
        active = next((key for key in sorted(records) if not records[key]['deleted']), None)
    return dict(owner=data['owner'], records=records, active=active)


def _file_stamp(path):
    value = path.stat()
    return (value.st_mtime_ns, value.st_ctime_ns, value.st_size, value.st_ino)


def current(root):
    # Home polls this four times a second. Reuse only the immutable viewer ID,
    # checking both files each time so account changes and external edits retire
    # the old window immediately. Errors are never cached.
    root = Path(root)
    key = str(root)
    account_path = root / 'account.json'
    registry_path = root / 'viewer-registry' / 'account.json'
    with _current_lock:
        try:
            stamp = (_file_stamp(registry_path), _file_stamp(account_path))
        except OSError:
            _current_cache.pop(key, None)
            return state(root).get('active')
        cached = _current_cache.get(key)
        if cached is not None and cached[0] == stamp:
            return cached[1]
        active = state(root).get('active')
        try:
            unchanged = stamp == (_file_stamp(registry_path), _file_stamp(account_path))
        except OSError:
            unchanged = False
        if unchanged:
            if len(_current_cache) >= 64:
                _current_cache.clear()
            _current_cache[key] = (stamp, active)
        return active


def root_directory(path):
    path=Path(path)
    if valid_id(path.name) and path.parent.parent.name=='viewers' and re.fullmatch(r'[0-9a-f]{64}',path.parent.name):
        return path.parent.parent.parent
    return path


def account_token(path):
    return _token(root_directory(path))


def storage_directory(store):
    if isinstance(store,ViewerAccount):return directory(store.directory,store.identity or current(store.directory))
    return store.directory


def directory(root, identity=None):
    root = Path(root)
    identity = current(root) if identity is None else identity
    if identity is None:return root
    if not valid_id(identity):raise ValueError('Invalid viewer identity')
    # Bind storage to the account too; signing into another account cannot read it.
    owner = _owner(_token(root))
    result = root / 'viewers' / owner / identity
    result.mkdir(parents=True, exist_ok=True)
    return result


def route_store(path):
    """Route only explicitly viewer-owned side stores, once at construction."""
    path = Path(path)
    if (path.name in OWNED_STORES or path.name.startswith(('home-recommendations-', 'home-upcoming-'))) and (path.parent / 'account.json').is_file():
        return directory(path.parent) / path.name
    return path


def enable(root):
    from account import AccountError, storage_lock
    with storage_lock(Path(root) / 'viewer-control'), storage_lock(Path(root)):
        data = state(root)
        if data:return data
        token = _shared(root).get('token')
        if not token:raise ValueError('Connect Stremio before creating viewer profiles.')
        _migrate_main(root)
        data = dict(owner=_owner(token), active=MAIN,
                    records={MAIN:dict(name='Master', updated=time.time(), deleted=False)})
        registry(root).save(data)
        confirmed = state(root, token)
        if confirmed.get('active') != MAIN:
            raise AccountError('Kodi could not activate viewer profiles. Your existing data was kept.')
        return confirmed


def _migrate_main(root):
    """Copy existing small viewer stores; keep every original as a backup.

    SQLite's backup API includes committed WAL data. A completion marker is
    written last, so a failed/interrupted first activation can safely retry.
    """
    import shutil
    import sqlite3
    from contextlib import closing
    from account import Store
    root=Path(root);destination=directory(root,MAIN)
    skipped=[]
    marker=Store(destination/'migration')
    names=set(OWNED_STORES)|{'home-state','saved-list-tags','continue_index.sqlite','search-history.json'}
    for name in names:
        source=root/name
        if not source.exists():continue
        files=source.rglob('*') if source.is_dir() else [source]
        for path in files:
            if (not path.is_file() or path.name == '.account.lock'
                    or path.name.endswith(('-wal','-shm'))):continue
            target=destination/path.relative_to(root)
            target.parent.mkdir(parents=True,exist_ok=True)
            try:
                if path.suffix=='.sqlite':
                    with closing(sqlite3.connect(str(path))) as old,closing(sqlite3.connect(str(target))) as new:old.backup(new)
                else:shutil.copy2(path,target)
            except (OSError,sqlite3.Error):
                # These stores are live while Kodi is running.  A worker may
                # rotate or briefly lock one file between the scan and copy.
                # Keep the migration moving; the source remains the recovery
                # copy and the affected cache/queue can be rebuilt later.
                skipped.append(str(path.relative_to(root)))
    Store(destination/'viewer-library').save(dict(library=deepcopy(_shared(root).get('library',[]))))
    marker.save(dict(complete=True, skipped=skipped[:32], skipped_count=len(skipped)))
    return skipped


def edit(root, action, identity=None, name=None, copy_master=False):
    from account import storage_lock
    if action not in ('create', 'rename', 'delete', 'switch'):raise ValueError('Unknown profile action')
    with storage_lock(Path(root) / 'viewer-control'), storage_lock(Path(root)):
        data = state(root)
        if not data:raise ValueError('Enable viewer profiles first.')
        records = data['records']
        if action in ('create', 'rename'):
            name = str(name or '').strip()
            sample = clean({'main':dict(name=name, updated=0)})
            if not sample:raise ValueError('Use a name of 1–40 characters without brackets or control characters.')
            if any(not r['deleted'] and r['name'].casefold() == name.casefold() and key != identity for key,r in records.items()):
                raise ValueError('That profile name is already in use.')
        if action == 'create':
            if sum(not r['deleted'] for r in records.values()) >= MAX_PROFILES:raise ValueError('Up to 12 viewer profiles are supported.')
            identity = uuid.uuid4().hex
            if copy_master:
                if MAIN not in records or records[MAIN]['deleted']:
                    raise ValueError('The Master profile is no longer available to copy.')
                _copy_viewer(root, MAIN, identity)
            records[identity] = dict(name=name, updated=time.time(), deleted=False)
        else:
            if identity not in records or records[identity]['deleted']:raise ValueError('That profile is no longer available.')
            if action == 'switch':data['active'] = identity
            elif action == 'rename':records[identity] = dict(records[identity], name=name, updated=time.time())
            elif action == 'delete':
                if sum(not r['deleted'] for r in records.values()) <= 1:raise ValueError('Keep at least one viewer profile.')
                records[identity] = dict(records[identity], deleted=True, updated=time.time())
                if data['active'] == identity:data['active'] = next(k for k,r in records.items() if not r['deleted'])
        registry(root).save(data)
        return identity


def share_progress(root, source, target, kind, media_id):
    """Copy one title's current progress once, preserving recipient lists."""
    from account import AccountError, storage_lock
    from datetime import datetime, timezone
    from lib.viewer_sync import pending_conflicts
    with storage_lock(Path(root)/'viewer-control'), storage_lock(Path(root)):
        data=state(root)
        live=data.get('records',{})
        if (source==target or source!=data.get('active') or
                any(key not in live or live[key]['deleted'] for key in (source,target))):
            raise AccountError('The selected profile changed. Open sharing again.')
        if kind not in ('movie','series') or not isinstance(media_id,str) or not media_id:
            raise AccountError('No title progress is available.')
        from account import Store
        from lib.progress_outbox import _worker
        if (( _worker is not None and _worker.is_alive()) or
                any(Store(directory(root,key)/'progress-outbox').load().get('rows') for key in (source,target))):
            raise AccountError('Progress is still being saved. Try again after syncing.')
        if kind+':'+media_id in pending_conflicts(root,target):
            raise AccountError('Resolve this title’s progress conflict in Settings before sharing.')
        original=next((row for row in read_library(root,source) if
                       isinstance(row,dict) and (row.get('type'),row.get('_id'))==(kind,media_id)),None)
        if original is None or not isinstance(original.get('state'),dict):
            raise AccountError('No saved progress is available for this title.')
        store=_library_store(root,target);snapshot=store.load()
        rows=snapshot.get('library',[])
        old=next((row for row in rows if isinstance(row,dict) and
                  (row.get('type'),row.get('_id'))==(kind,media_id)),None)
        copied=deepcopy(old if old is not None else original)
        if old is None:copied.update(removed=True,temp=True)
        stamp=datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
        copied['state']=deepcopy(original['state'])
        copied['state']['lastWatched']=stamp
        copied['_mtime']=stamp
        copied['_home_last_playback']=stamp
        snapshot['library']=[row for row in rows if not isinstance(row,dict) or
                             (row.get('type'),row.get('_id'))!=(kind,media_id)]+[copied]
        store.save(snapshot)


def _copy_viewer(root, source, target):
    """Seed independent viewer data before publishing its registry entry.

    Never clone sync baselines, conflicts or pending playback jobs: those
    belong to the original viewer. Rebuild derived caches for the new owner.
    """
    from account import Store
    from lib.saved_lists import SavedLists
    from lib.home_state import HomeState
    token = account_token(root)
    _library_store(root, target).save(dict(library=read_library(root, source)))
    SavedLists(root, token, viewer_id=target).merge(
        SavedLists(root, token, viewer_id=source).snapshot())
    HomeState(root, token, viewer_id=target).merge(
        HomeState(root, token, viewer_id=source).snapshot())
    for name in ('successful-sources', 'series-tracks'):
        Store(directory(root, target)/name).save(
            dict(Store(directory(root, source)/name).load()))
    history = directory(root, source)/'search-history.json'
    if history.is_file():
        from setup_profile import atomic_write
        atomic_write(directory(root, target)/history.name, history.read_bytes())


def _library_store(root, identity):
    from account import Store
    return Store(directory(root, identity) / 'viewer-library')


def read_library(root, identity):
    if identity is None:return deepcopy(_shared(root).get('library', []))
    return deepcopy(_library_store(root, identity).load().get('library', []))


def library_order(row):
    from datetime import datetime,timezone
    try:
        instant=datetime.fromisoformat(str(row.get('_mtime') or '').replace('Z','+00:00'))
        stamp=(instant if instant.tzinfo else instant.replace(tzinfo=timezone.utc)).timestamp()
    except (ValueError,TypeError,OverflowError,OSError):stamp=0
    return stamp,json.dumps(row,sort_keys=True)


def write_library(root, identity, library):
    from account import AccountConflict, Store, storage_lock
    with storage_lock(Path(root) / 'viewer-control'), storage_lock(Path(root)):
        data = state(root)
        if identity not in data.get('records', {}) or data['records'][identity]['deleted']:raise AccountConflict()
        target = _library_store(root, identity)
        latest = target.load()
        combined={(r.get('type'),r.get('_id')):deepcopy(r) for r in latest.get('library',[]) if isinstance(r,dict)}
        for row in library:
            if not isinstance(row,dict):continue
            key=(row.get('type'),row.get('_id'));old=combined.get(key)
            if old is None or library_order(row)>library_order(old):combined[key]=deepcopy(row)
        latest['library']=list(combined.values());target.save(latest)


def replace_library_if_unchanged(root, identity, expected, library):
    """Apply a reconciled sync snapshot without defeating a concurrent local edit."""
    from account import AccountConflict, storage_lock
    with storage_lock(Path(root) / 'viewer-control'), storage_lock(Path(root)):
        data = state(root)
        if identity not in data.get('records', {}) or data['records'][identity]['deleted']:raise AccountConflict()
        target = _library_store(root, identity)
        latest = target.load()
        if latest.get('library', []) != expected:return False
        if expected != library:
            latest['library'] = deepcopy(library)
            target.save(latest)
        return True


class ViewerAccount:
    """Shared login/provider config with a viewer-specific library snapshot."""
    def __init__(self, root, identity=None):
        self.directory = Path(root)
        self.identity = identity

    def load(self):
        identity = self.identity or current(self.directory)
        value = _configuration(self.directory) if identity else _shared(self.directory)
        if identity:
            value['library'] = read_library(self.directory, identity)
            value.baseline = deepcopy(dict(value))
        value.viewer_id = identity
        return value

    def save(self, value):
        from account import AccountConflict, Store
        identity = getattr(value, 'viewer_id', None) or self.identity or current(self.directory)
        raw = Store(self.directory)
        if not identity:return raw.save(value)
        latest = _configuration(self.directory)
        baseline = getattr(value, 'baseline', dict(value))
        if latest.get('token') != baseline.get('token'):raise AccountConflict()
        if 'library' in value and value.get('library') != baseline.get('library'):
            write_library(self.directory, identity, value['library'])
        # Shared addon changes retain the existing Store compare-and-set rules.
        desired = {k:deepcopy(v) for k,v in value.items() if k!='library'}
        before = {k:deepcopy(v) for k,v in baseline.items() if k!='library'}
        from account import Snapshot
        update = Snapshot(before);update.update(desired)
        if desired!=before:raw.save(update)
        if hasattr(value,'baseline'):
            value.baseline=deepcopy(dict(value))
            if value.get('token')!=baseline.get('token'):value.viewer_id=current(self.directory)

    def update_library(self, token, expected_library, library):
        value=self.load()
        if value.get('token') != token or value.get('library', []) != expected_library:return False
        value['library']=library;self.save(value);return True

    def forget(self):
        from account import Store
        Store(self.directory).forget()

    def freeze(self):
        return ViewerAccount(self.directory, self.load().viewer_id)


def library_transport(store):
    """Local datastore protocol for profiles; never send viewer writes to Stremio."""
    if not isinstance(store, ViewerAccount):return None
    snapshot = store.load();identity = snapshot.viewer_id
    if not identity:return None
    token = snapshot.get('token')
    observed=[None]
    def pull(expected):
        from account import AccountConflict
        if expected != token or _token(store.directory) != token:raise AccountConflict()
        rows=read_library(store.directory, identity)
        observed[0]=deepcopy(rows)
        return rows
    def put(url, payload):
        from account import AccountError,AccountConflict
        if payload.get('authKey') != token or payload.get('collection') != 'libraryItem':raise AccountError('Unsupported viewer update.')
        if _token(store.directory)!=token:raise AccountConflict()
        current=read_library(store.directory, identity)
        rows=deepcopy(current)
        for item in payload.get('changes') or []:
            key=(item.get('_id'),item.get('type'))
            expected=next((r for r in observed[0] or [] if (r.get('_id'),r.get('type'))==key),None)
            latest=next((r for r in current if (r.get('_id'),r.get('type'))==key),None)
            if observed[0] is not None and latest!=expected and latest!=item:raise AccountConflict()
            rows = [r for r in rows if (r.get('_id'),r.get('type')) != (item.get('_id'),item.get('type'))] + [deepcopy(item)]
        if not replace_library_if_unchanged(store.directory,identity,current,rows):raise AccountConflict()
        return {}
    return put,pull
