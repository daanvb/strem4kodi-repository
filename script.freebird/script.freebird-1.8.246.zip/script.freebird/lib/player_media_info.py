"""Local, session-bound media details. Source claims never become detections."""
import hashlib
import math
import re
from lib.player_audio import audio_description, detected_codec


def safe(value, limit=150):
    from lib.stream_presenter import line
    return line(value, limit).replace('[', '').replace(']', '')


def number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) and value > 0 else 0
    except (ValueError, TypeError):
        return 0


def dv_detail(value):
    match = re.fullmatch(r'\s*([578])(?:\.([0-9]))?\s*(FEL|MEL|EL)?\s*', str(value or ''), re.I)
    if not match:
        return ''
    profile = match[1] + ('.' + match[2] if match[2] else '')
    return 'Profile ' + profile + (' · ' + match[3].upper() if match[3] else '')


def coreelec_details(info):
    """Read P3i/CoreELEC runtime fields without inferring them from source names."""
    def process(name):
        return info('Player.Process(' + name + ')')
    rows = []
    profile = process('video.dovi.profile')
    if profile in ('5', '7', '8', '9', '10'):
        compatibility = process('video.dovi.bl.signal.compatibility')
        layer = {'full': 'FEL', 'minimum': 'MEL'}.get(process('video.dovi.el.type'), '')
        value = 'Profile ' + profile
        if compatibility.isdigit():
            value += '.' + compatibility
        if layer:
            value += ' · ' + layer
        rows.append(('Dolby Vision', value))
    for name, title in (
            ('video.dovi.codec.string', 'DV codec'),
            ('video.dovi.meta.version', 'DV metadata version'),
            ('amlogic.dv.backend', 'DV backend'),
            ('amlogic.vs10.mode', 'VS10 mode'),
            ('video.source.hdr.type', 'Source dynamic range'),
            ('video.hdr.type', 'Output dynamic range'),
            ('video.bit.depth', 'Video bit depth'),
            ('video.color.range', 'Color range'),
            ('video.color.primaries', 'Color primaries'),
            ('audio.object.layout', 'Audio object layout')):
        value = process(name)
        if value:
            rows.append((title, value))
    return rows


def source_details(stream):
    from lib.stream_presenter import presentation
    from lib.fel_catalog import badge
    view = presentation(stream)
    profile = stream.get('dolbyVisionProfile') or stream.get('dvProfile')
    layer = str(stream.get('enhancementLayer') or stream.get('dvEnhancementLayer') or '').upper()
    detail = dv_detail(str(profile or '') + (' ' + layer if layer in ('FEL', 'MEL', 'EL') else ''))
    if not detail:
        detail = badge(stream)
    selection = stream.get('_selection_details') if stream.get('_automatic_selection') is True else []
    selection = ' | '.join(safe(v) for v in selection[:5]) if isinstance(selection,list) else ''
    from lib.stream_presenter import edition
    from core.stream_ui import stream_card
    card = stream_card(stream)
    live = stream.get('isLive') is True or stream.get('_live_sports') is True
    fps = number(card.get('frame_rate'))
    return {key: safe(value, 700 if key=='selection' else 150) for key, value in {
        'source': view['title'], 'video': view['detail'], 'audio': view['audio'],
        'dv': detail, 'edition': edition(stream), 'selection': selection,
        'quality': (view['quality'] if view['quality'] != 'AUTO' else 'Not reported') if live else '',
        'bitrate': (card.get('bitrate') or 'Not reported') if live else '',
        'frame_rate': (('{:g} fps'.format(fps)) if fps else 'Not reported') if live else ''}.items() if value}


def resolution_format(width, height):
    width, height = number(width), number(height)
    if not width or not height:
        return '', ''
    if width >= 7680 or height >= 4320:
        return '8k', '8K UHD'
    if width >= 3840 or height >= 2160:
        return '4k', '4K UHD'
    if width <= 2048 and height <= 1080 and (width >= 1920 or height >= 1080):
        return '1080p', '1080p Full HD'
    if width <= 1366 and height <= 768 and (width >= 1280 or height >= 720):
        return '720p', '720p HD'
    return '', ''


def format_icons(hdr, codec, audio, active_codec='', width=0, height=0, runtime=None):
    # Only local known assets; track titles and source claims cannot set badges.
    audio = audio if isinstance(audio, dict) else {}
    base = detected_codec(audio, active_codec)
    audio_icon = {'ac3': 'ac3', 'eac3': 'eac3', 'truehd': 'truehd',
                  'eac3_ddp_atmos': 'atmos', 'truehd_atmos': 'atmos', 'atmos':'atmos',
                  'dca': 'dts', 'dts': 'dts', 'dtshd_ma': 'dtshd_ma',
                  'dtshd_hra': 'dtshd_hra', 'dtshd_ma_x':'dtshd_ma', 'dtshd_ma_x_imax':'dtshd_ma',
                  'aac': 'aac', 'aac_lc':'aac', 'he_aac':'aac', 'he_aac_v2':'aac', 'flac': 'flac'}.get(base, '')
    names = {'hdr': {'Dolby Vision': 'dolbyvision', 'HDR10': 'ui/hdr10', 'HDR10+': 'ui/hdr10plus', 'HDR': 'ui/hdr', 'HLG': 'ui/hlg'}.get(hdr, ''),
             'video': '', 'audio': audio_icon,
             'audio_base': {'truehd_atmos':'truehd', 'eac3_ddp_atmos':'eac3'}.get(base, ''),
             'resolution': ('ui/' + resolution_format(width, height)[0]) if resolution_format(width, height)[0] else ''}
    icons = {key: ('special://home/addons/script.freebird/resources/skins/Main/media/formats/display/player/' + name + '.png') if name else ''
             for key, name in names.items()}
    from lib.player_format_logos import AUDIO_LOGOS, logo, video_logo
    icons['hdr'] = video_logo(hdr, runtime or {}) or icons['hdr']
    player_audio = AUDIO_LOGOS.get(base, 'pcm' if base.startswith('pcm_') else '')
    if player_audio:
        icons['audio'] = logo(player_audio)
        # P3i Atmos logos already include TrueHD/DD+ in the same image.
        icons['audio_base'] = ''
    return icons


def snapshot(rpc, label, playing_file, context=None, language_name=None, playing_key=None, history=None):
    file = playing_file()
    players = rpc('Player.GetActivePlayers') or []
    player = next((p for p in players if p.get('type') == 'video'), None)
    if not file or not player:
        return None
    props = rpc('Player.GetProperties', {'playerid': player['playerid'],
                'properties': ['currentvideostream', 'currentaudiostream', 'currentsubtitle', 'subtitleenabled']}) or {}
    def info(name):
        try:
            return safe(label(name))
        except Exception:
            return ''
    video = props.get('currentvideostream') or {}
    audio = props.get('currentaudiostream') or {}
    width = number(video.get('width')) or number(info('Player.Process(VideoWidth)'))
    height = number(video.get('height')) or number(info('Player.Process(VideoHeight)'))
    codec = info('VideoPlayer.VideoCodec') or safe(video.get('codec'))
    codec = {'hevc': 'HEVC / H.265', 'h265': 'HEVC / H.265', 'h264': 'AVC / H.264', 'av1': 'AV1'}.get(codec.lower(), codec.upper())
    hdr = info('VideoPlayer.HdrType') or safe(video.get('hdrtype'))
    hdr = {'dolbyvision': 'Dolby Vision', 'hdr10': 'HDR10', 'hdr10plus': 'HDR10+', 'hlg': 'HLG', 'sdr': 'SDR'}.get(hdr.lower(), hdr)
    fps = number(info('Player.Process(VideoFPS)'))
    detail = dv_detail(info('VideoPlayer.HdrDetail')) if hdr == 'Dolby Vision' else ''
    resolution_name = resolution_format(width, height)[1]
    detected = [('Resolution', (resolution_name + ' | ' if resolution_name else '') + '{} × {}'.format(int(width), int(height)) if width and height else 'Not reported'),
                ('Video codec', codec or 'Not reported'),
                ('Frame rate', ('{:.3f}'.format(fps).rstrip('0').rstrip('.') + ' fps') if fps else 'Not reported'),
                ('Dynamic range', hdr or 'Not reported'),
                ('Dolby Vision', detail or ('Profile not reported by Kodi' if hdr == 'Dolby Vision' else 'Not reported')),
                ('Pixel format', info('Player.Process(PixFormat)') or 'Not reported'),
                ('Video decoder', info('Player.Process(VideoDecoder)') or 'Not reported'),
                ('Audio', audio_description(audio, language_name, info('VideoPlayer.AudioCodec'))),
                ('Audio sample rate', info('Player.Process(AudioSamplerate)') or 'Not reported'),
                ('Subtitles', safe((props.get('currentsubtitle') or {}).get('name') or 'Enabled') if props.get('subtitleenabled') else 'Off')]
    cache = info('Player.CacheLevel')
    try:
        cache_value = float(cache)
        cache = '{:g}%'.format(cache_value) if math.isfinite(cache_value) and 0 <= cache_value <= 100 else ''
    except (TypeError, ValueError):
        cache = ''
    detected.append(('Audio decoder', info('Player.Process(AudioDecoder)') or 'Not reported'))
    for title, value in coreelec_details(info):
        if title == 'Dolby Vision':
            # A CoreELEC runtime profile also works on builds without HdrDetail.
            detected = [(key, value if key == title else old) for key, old in detected]
        else:
            detected.append((title, value))
    stats = [('Cache', cache)] if cache else []
    # Changing a textbox label resets Kodi's scroll offset. Keep continuously
    # changing playback counters in the separate, non-scrolling statistics row.
    for name, title in (('amlogic.video.fps.info', 'AML frame rate'),
                        ('amlogic.video.fps.drop', 'AML dropped frames')):
        value = info('Player.Process(' + name + ')')
        if value:
            stats.append((title, value))
    context = context or {}
    # Kodi can expose the redirected transport URL for live sources. Only the
    # current item's opaque playback key may bridge that change; no time fallback.
    key = playing_key() if playing_key else ''
    matched = (context.get('playback_key') == key if key and context.get('playback_key')
               else context.get('url_hash') == hashlib.sha256(file.encode()).hexdigest())
    if context.get('isLive') is True and matched:
        detected.append(('Playback type', 'Live stream'))
        # Live bitrate/queue labels are available in Kodi 22. Preserve Kodi's
        # units and omit unavailable labels on Kodi 21; never infer throughput.
        for name, title in (('videolivebitrate', 'Video'),
                            ('audiolivebitrate', 'Audio'),
                            ('videoqueuelevel', 'Video queue'),
                            ('videoqueuedatalevel', 'Queue data')):
            value = info('Player.Process(' + name + ')')
            if value and re.search(r'\d', value):
                stats.append((title, value))
        detected.append(('Live delay', 'Unavailable: this source has no verified broadcast clock'))
    reported = context.get('media_info') if matched else {}
    reported = reported if isinstance(reported, dict) else {}
    claims = [(title, safe(reported.get(key), 700 if key=='selection' else 150)) for key, title in
              (('source', 'Source'), ('quality', 'Quality'), ('bitrate', 'Bitrate'), ('frame_rate', 'Frame rate'),
               ('video', 'Video'), ('audio', 'Audio'), ('dv', 'Dolby Vision'), ('edition', 'Edition'), ('selection', 'Automatic selection')) if reported.get(key)]
    runtime = {key: info('Player.Process(' + key + ')') for key in (
        'amlogic.vs10.mode', 'video.source.hdr.type.raw', 'video.dovi.el.type', 'video.bit.depth')}
    runtime['kodi.hdr.detail'] = info('VideoPlayer.HdrDetail')
    active_audio = info('VideoPlayer.AudioCodec')
    icons = format_icons(hdr, codec, audio, active_audio, width, height, runtime)
    from lib.player_format_logos import logo
    dv_layer = ('MEL' if runtime['video.dovi.el.type'] == 'minimum'
                and icons['hdr'] == logo('dolby_vision') else '')
    title = info('VideoPlayer.Title') or 'Current video'
    if playing_file() != file or (playing_key and playing_key() != key):
        return None
    result = {'file': file, 'title': title, 'detected': detected,
            'reported': claims, 'icons': icons, 'stats': stats, 'dv_layer': dv_layer,
            'note': 'Source-reported details are unverified. A FEL label does not confirm enhancement-layer processing.'}
    if history is not None:
        from lib.player_audio import codec_name
        def track_identity(track, extra):
            index = track.get('index')
            return (index,) + extra if type(index) is int and index >= 0 else None
        carrier = codec_name(audio.get('codec'))
        if carrier == 'truehd_atmos':
            carrier = 'truehd'
        result['format_evidence'] = dict(key=key, video=track_identity(video, (video.get('codec'), width, height)),
            audio=track_identity(audio, (carrier, audio.get('channels'), audio.get('language'))),
            active_audio=codec_name(active_audio), layer=runtime['video.dovi.el.type'],
            detail=runtime['kodi.hdr.detail'], source=runtime['video.source.hdr.type.raw'], mode=runtime['amlogic.vs10.mode'])
        return history.apply(result)
    return result



def visible_details(rows):
    """Keep meaningful zero counters, but omit missing metadata placeholders."""
    missing = ('not reported', 'unknown', 'n/a', 'none', 'unavailable')
    return [(key, value) for key, value in rows if str(value if value is not None else '').strip()
            and str(value).strip().casefold() not in missing
            and not str(value).casefold().startswith(('unavailable:', 'profile not reported'))]


def show():
    import threading
    import xbmc
    import xbmcgui
    import xbmcvfs
    from pathlib import Path
    from account import Store
    from setup_profile import rpc
    from addon_state import get_addon
    from lib.theme import window
    from lib.player_controls import menu_session_active
    player = xbmc.Player()
    profile = Path(xbmcvfs.translatePath(get_addon().getAddonInfo('profile')))
    context = Store(profile / 'playback').load()
    def playing_key():
        try:
            return player.getPlayingItem().getProperty('StremioPlaybackKey')
        except Exception:
            return ''
    from lib.player_format_state import FormatHistory
    history = FormatHistory()
    data = snapshot(rpc, xbmc.getInfoLabel, player.getPlayingFile, context,
                    lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME), playing_key, history)
    if not data:
        return
    def text(rows):
        return '[CR][CR]'.join('[B]' + key + '[/B][CR]' + safe(value) for key, value in visible_details(rows))
    class MediaWindow(xbmcgui.WindowXMLDialog):
        def onInit(self):
            self.closed = False
            if not menu_session_active(player, data['file']):
                self.close()
                return
            self.refresh(data)
            self.setFocusId(600)
            def watch():
                monitor = xbmc.Monitor()
                while not self.closed and not monitor.waitForAbort(1):
                    if not menu_session_active(player, data['file']):
                        self.close()
                        return
                    try:
                        fresh = snapshot(rpc, xbmc.getInfoLabel, player.getPlayingFile, context,
                                         lambda code: xbmc.convertLanguage(code, xbmc.ENGLISH_NAME), playing_key, history)
                        if fresh and not self.closed:
                            self.refresh(fresh)
                    except Exception:
                        pass
            threading.Thread(target=watch, daemon=True).start()
        def refresh(self, data):
            if getattr(self, 'last_data', None) == data:
                return
            self.last_data = data
            self.setProperty('media_title', data['title'])
            detected_text = text(data['detected'])
            reported_text = text(data['reported'])
            if getattr(self, 'detected_text', None) != detected_text:
                self.setProperty('media_detected', detected_text)
                self.detected_text = detected_text
            if getattr(self, 'reported_text', None) != reported_text:
                self.setProperty('media_reported', reported_text)
                self.reported_text = reported_text
            self.setProperty('media_stats', '  ·  '.join(key + ': ' + value for key, value in data.get('stats', [])))
            self.setProperty('media_note', data['note'] if reported_text else '')
            for key, value in data['icons'].items():
                self.setProperty('media_' + key + '_icon', value)
            self.setProperty('media_dv_layer', data.get('dv_layer', ''))
            from lib.player_format_logos import logo
            self.setProperty('media_atmos', 'true' if data['icons']['audio'] == logo('truehd_atmos') or data['icons']['audio'].endswith(('/atmos.png', '_atmos.png')) else '')
            self.setProperty('media_hdr_logo', 'true' if data['icons']['hdr'] in (logo('dolby_vision'), logo('dolby_vision_fel')) or data['icons']['hdr'].endswith('/dolbyvision.png') or '/b_dolby_vision' in data['icons']['hdr'] else '')
            self.setProperty('media_hdr_tint', 'FFFFFFFF')
            self.setProperty('media_audio_tint', 'FFFFFFFF')
            self.setProperty('media_audio_logo', 'true' if data['icons']['audio'] == logo('truehd_atmos') or any(data['icons'][key].endswith('/' + name + '.png') for key in ('audio', 'audio_base') for name in ('truehd', 'eac3', 'b_truehd', 'b_eac3', 'b_truehd_atmos', 'b_eac3_ddp_atmos')) else '')
        def close(self):
            self.closed = True
            super().close()
        def onClick(self, cid):
            if cid == 604:
                if menu_session_active(player, data['file']):
                    self.close()
                    xbmc.executebuiltin('ActivateWindow(PlayerProcessInfo)')
            elif cid == 602:
                self.close()
            elif cid == 603 and not getattr(self, 'sending', False):
                from lib.diagnostic_export import Reporter, player_summary
                if not menu_session_active(player, data['file']):
                    self.close()
                    return
                addon = get_addon()
                if addon.getSetting('diagnostics_github_enabled') != 'true':
                    self.setProperty('media_report_status', 'Enable private diagnostic reports in Settings > Troubleshooting first.')
                    return
                token = addon.getSetting('credits_github_token').strip()
                if not token:
                    self.setProperty('media_report_status', 'Configure your private GitHub sync token in Settings first.')
                    return
                stats = player_summary(xbmc.getInfoLabel, xbmc.getCondVisibility)
                self.sending = True
                self.setProperty('media_report_status', 'Sending private diagnostic report…')
                def send():
                    reference = None
                    try:
                        reference = Reporter(profile, addon, xbmcvfs.translatePath('special://logpath/')).run(token, stats, force=True)
                    except Exception:
                        pass
                    self.sending = False
                    message = ('Sent to private GitHub. Report: ' + reference if reference else
                               'Report failed. Check private GitHub token access and diagnostic settings; retry.')
                    if not self.closed:
                        self.setProperty('media_report_status', message)
                    from lib.ui_dialogs import dialog as themed_dialog
                    themed_dialog().notification('Diagnostic report', message)
                try:
                    threading.Thread(target=send, daemon=True).start()
                except RuntimeError:
                    self.sending = False
                    self.setProperty('media_report_status', 'Could not start report. Please retry.')
        def onAction(self, action):
            if action.getId() in (10, 92, 216, 247):
                self.close()
    dialog = window(MediaWindow, 'script-freebird-player-media.xml', get_addon().getAddonInfo('path'), 'Main', '1080i')
    dialog.doModal()
