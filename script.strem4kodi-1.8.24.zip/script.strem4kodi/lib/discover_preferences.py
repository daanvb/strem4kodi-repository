"""Small per-content Discover preferences; never persist provider URLs or items."""
from account import Store
from pathlib import Path


class Preferences:
    def __init__(self, profile):
        self.store = Store(Path(profile) / 'discover-preferences')
        try:
            self.data = self.store.load()
        except Exception:
            self.data = {}

    def remember(self, catalog, extras, overview, offset, skip, positions):
        if not catalog or catalog.get('kind') not in ('movie', 'series') or catalog.get('_search_collection'):
            return
        kind = catalog['kind']
        self.data[kind] = dict(id=catalog['id'], family=catalog.get('family'), label=catalog.get('label'),
                               extras={k: v for k, v in extras.items() if not k.startswith('_') and isinstance(v, str)},
                               overview=bool(overview), offset=max(0, int(offset)), skip=max(0, int(skip)),
                               positions={str(k): max(0, int(v)) for k, v in positions.items()})
        self.data['last_kind'] = kind

    def restore(self, choices, kind=None):
        from lib.discovery_groups import default_catalogue
        kind = kind or self.data.get('last_kind')
        saved = self.data.get(kind, {})
        catalog = next((c for c in choices if c.get('kind') == kind and c['id'] == saved.get('id')), None)
        if catalog is None:
            return default_catalogue(choices, kind) or default_catalogue(choices), {}
        # Validate filters against the current manifest, which may have changed.
        options = {e['name']: e.get('options', []) for e in catalog.get('extras', []) if e.get('name') not in ('skip', 'search')}
        state = dict(saved)
        state['extras'] = {k: v for k, v in saved.get('extras', {}).items() if k in options and v in map(str, options[k])}
        # Cursor-based merged pagination cannot be replayed from a numeric skip.
        state['skip'] = 0
        return catalog, state

    def save(self):
        self.store.save(self.data)
