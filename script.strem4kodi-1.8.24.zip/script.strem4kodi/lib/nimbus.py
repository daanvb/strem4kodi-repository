"""Strem4Kodi program windows. All navigation stays inside this addon."""
from lib.ui_dialogs import progress_bg as themed_progress_bg, dialog as themed_dialog
import re
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcaddon
from addon_state import get_addon
import xbmcgui

from lib import backend as api
from lib import mdblist
from lib.title_metadata import age_enrich
from lib.trailer_options import imdb_id, autoplay_delay, autoplay_enabled
from lib.sidebar_nav import menu_items, menu_action, home_index

ADDON = get_addon()
PATH = ADDON.getAddonInfo('path')
BACK = (10, 92, 216, 247)


from lib.theme import window as themed_window


def clean(value):
    return re.sub(r'<[^>]+>', '', str(value or ''))


_MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
           'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def episode_runtime(value):
    """Return compact TV-card runtime text without inventing missing metadata."""
    if value in (None, ''):
        return ''
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if value > 10000:
            minutes = int(round(value / 60000.0))
        elif value > 300:
            minutes = int(round(value / 60.0))
        else:
            minutes = int(round(value))
    else:
        text = str(value).strip()
        iso = re.fullmatch(r'PT(?:(\d+)H)?(?:(\d+)M)?', text, re.I)
        if iso:
            minutes = int(iso.group(1) or 0) * 60 + int(iso.group(2) or 0)
        else:
            hm = re.fullmatch(r'(?:(\d+)\s*h(?:ours?)?)?\s*(?:(\d+)\s*m(?:in(?:ute)?s?)?)?', text, re.I)
            if hm and (hm.group(1) or hm.group(2)):
                minutes = int(hm.group(1) or 0) * 60 + int(hm.group(2) or 0)
            else:
                plain = re.fullmatch(r'(\d+)\s*(?:m|min|mins|minutes)?', text, re.I)
                if not plain:
                    return text[:16]
                minutes = int(plain.group(1))
    if minutes <= 0:
        return ''
    hours, mins = divmod(minutes, 60)
    if hours and mins:
        return '{}h {}m'.format(hours, mins)
    if hours:
        return '{}h'.format(hours)
    return '{}m'.format(mins)


def episode_rating(row):
    """Use only provider-supplied episode rating metadata."""
    value = row.get('imdbRating')
    if value in (None, ''):
        value = row.get('rating')
    if value in (None, ''):
        return ''
    match = re.search(r'\d+(?:\.\d+)?', str(value))
    if not match:
        return ''
    try:
        rating = float(match.group(0))
    except ValueError:
        return ''
    if not 0 < rating <= 10:
        return ''
    return '{:.1f}'.format(rating)


def episode_date(row):
    """Format provider release dates like '20 Dec 2019'."""
    value = str(row.get('released') or row.get('releaseInfo') or '').strip()
    match = re.match(r'^(\d{4})-(\d{2})-(\d{2})(?:T|$)', value)
    if not match:
        return value[:16] if re.fullmatch(r'\d{4}', value) else ''
    year, month, day = map(int, match.groups())
    if not 1 <= month <= 12 or not 1 <= day <= 31:
        return ''
    return '{} {} {}'.format(day, _MONTHS[month - 1], year)


def item(row):
    li = xbmcgui.ListItem(clean(row.get('name') or row.get('title') or '') + (' · Catalogue' if row.get('_catalogue') else ''))
    li.setArt({'poster': row.get('poster', ''), 'thumb': row.get('thumbnail') or row.get('poster', ''),
               'fanart': row.get('background') or row.get('poster', '')})
    from lib.catalogue_layout import wide_art
    li.setProperty('wide_art', wide_art(row))
    li.setProperty('id', str(row.get('id', '')))
    li.setProperty('type', str(row.get('type', 'movie')))
    li.setProperty('plot', clean(row.get('description')))
    li.setProperty('release_label', row.get('_release_label', ''))
    if row.get('_catalogue_watched'):
        li.setProperty('watched', 'true')
        try:
            li.getVideoInfoTag().setPlaycount(1)
        except Exception:
            pass
    state = row.get('state') if isinstance(row.get('state'), dict) else {}
    try:
        offset = max(0.0, float(state.get('timeOffset') or 0) / 1000.0)
        duration = max(0.0, float(state.get('duration') or 0) / 1000.0)
    except (TypeError, ValueError):
        offset, duration = 0.0, 0.0
    if duration > 0 and offset >= 1 and offset < duration:
        progress = max(1, min(99, int(round(offset * 100.0 / duration))))
        li.setProperty('WatchedProgress', str(progress))
        try:
            li.getVideoInfoTag().setResumePoint(offset, duration)
        except Exception:
            pass
    else:
        li.setProperty('WatchedProgress', '0')
    return li


class NimbusWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.trailer_timer = None
        self.preview_generation = 0
        self.preview_url = None
        self.preview_window = None
        self.preview_lock = threading.Lock()
        self.preview_suspended = False

    def play_hero_trailer(self, window_id, meta=None, generation=None, deadline=0):
        if xbmc.Player().isPlaying():return
        from lib.trailer_options import resolve
        generation = self.preview_generation if generation is None else generation
        meta = meta or self.meta
        try:
            if generation != self.preview_generation:
                return
            self.setProperty('trailer_status', 'Loading trailerâ€¦')
            stream = resolve(imdb_id(meta),
                             getattr(self, 'season', -1) if meta.get('type') == 'series' else -1,
                             __import__('lib.coreelec', fromlist=['trailer_quality']).trailer_quality(ADDON))
            if not stream:
                if generation == self.preview_generation:
                    self.report('No trailer is available for this title.')
                    self.setProperty('trailer_status', 'No trailer available')
                return
            # Resolve during the selected delay, not after it. Navigation cancels
            # the pending preview without waiting for the network request.
            while time.monotonic() < deadline:
                if generation != self.preview_generation:
                    return
                xbmc.sleep(50)
            with self.preview_lock:
                if (self.preview_suspended or not stream or generation != self.preview_generation or
                        xbmcgui.getCurrentWindowId() != window_id or xbmc.Player().isPlaying()):
                    return
                entry = xbmcgui.ListItem(label=stream['title'], path=stream['url'])
                entry.setMimeType(stream['mime'])
                entry.setContentLookup(False)
                entry.setProperty('StartOffset', '0')
                entry.setProperty('script.trakt.exclude', '1')
                self.getControl(9102).setPosition(0, 0)
                self.getControl(9101).setHeight(731)
                self.preview_url = stream['url']
                self.preview_window = window_id
                self.setProperty('hero_trailer', 'true')
                self.setProperty('trailer_status', 'Starting trailerâ€¦')
                xbmc.Player().play(stream['url'], entry, windowed=True)
            # Kodi centers wide video within its native video rectangle. Move
            # that rectangle up by the letterbox inset, leaving fullscreen alone.
            for _ in range(80):
                if generation != self.preview_generation:
                    return
                self.maintain_hero_trailer()
                if xbmc.Player().isPlayingVideo():
                    self.setProperty('trailer_status', 'Trailer playing')
                    result = json.loads(xbmc.executeJSONRPC(json.dumps({
                        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                        'params': {'playerid': 1, 'properties': ['currentvideostream']}})))
                    aspect = float(((result.get('result') or {}).get('currentvideostream') or {}).get('aspect') or 0)
                    if aspect > 0:
                        height = min(731, round(1300 / aspect))
                        with self.preview_lock:
                            if generation != self.preview_generation:
                                return
                            self.getControl(9102).setPosition(0, -round((731 - height) / 2))
                            self.getControl(9101).setHeight(height)
                        return
                    return
                xbmc.sleep(100)
            if generation == self.preview_generation:
                self.clearProperty('hero_trailer')
                self.setProperty('trailer_status', 'Trailer did not start')
                self.report('Trailer could not start. Try the Trailer button.')
        except Exception as error:
            if generation == self.preview_generation:
                self.clearProperty('hero_trailer')
                self.setProperty('trailer_status', 'Trailer lookup failed')
                self.report('Trailer lookup failed. Try the Trailer button.')
                xbmc.log('Strem4Kodi preview failed: ' + type(error).__name__, xbmc.LOGWARNING)

    def maintain_hero_trailer(self):
        from lib.hero_preview import keep_windowed
        with self.preview_lock:
            if not self.preview_suspended:
                keep_windowed(xbmc, xbmcgui, xbmc.Player(), self.preview_url,
                              getattr(self, 'preview_window', None))

    def cancel_trailer(self):
        if self.trailer_timer:
            self.trailer_timer.cancel()
            self.trailer_timer = None
        with self.preview_lock:
            self.preview_generation += 1
            self.clearProperty('hero_trailer')
            self.clearProperty('trailer_status')
            if self.preview_url:
                player = xbmc.Player()
                try:
                    # play() is asynchronous: also stop a queued preview before
                    # clearing its ownership, even if isPlaying() is still false.
                    if not player.isPlaying() or player.getPlayingFile() == self.preview_url:
                        player.stop()
                except RuntimeError:
                    pass
                self.preview_url = None
                self.preview_window = None

    def report(self, text):
        self.setProperty('status', text)

    def busy(self, label, fn):
        progress = themed_progress_bg()
        progress.create('Strem4Kodi', label)
        try:
            return fn()
        except Exception:
            # Provider exception strings can contain credentials.
            xbmc.log('Strem4Kodi: request failed (' + label + ')', xbmc.LOGWARNING)
            self.report('Unable to load this section. Please try again.')
            return None
        finally:
            progress.close()

    def set_hero(self, row):
        row = dict(row)
        from lib.catalogue_layout import sports, wide_art
        if sports(row):
            row['background'] = wide_art(row)
        if row.get('_release_label'):
            row['description'] = row['_release_label'] + '. Availability depends on source providers.\n\n' + str(row.get('description') or '')
        if ADDON.getSetting('rating_imdb') == 'false':
            row.pop('imdbRating', None)
        for setting, fields in {
            'ui_show_logo': ('logo',), 'ui_show_plot': ('description',),
            'ui_show_genres': ('genres',), 'ui_show_rating': ('rating_text', 'imdbRating'),
            'ui_show_runtime': ('runtime',),
        }.items():
            if ADDON.getSetting(setting) == 'false':
                for field in fields:
                    row.pop(field, None)
        values = {'title': clean(row.get('name')), 'plot': clean(row.get('description')),
                  'fanart': (row.get('background') or '') if row.get('background') != row.get('poster') else '',
                  'logo': row.get('logo') or '',
                  'genres': ' Â· '.join(row.get('genres') or []),
                  'facts': '  Â·  '.join(str(v) for v in (
                      row.get('releaseInfo') or row.get('year'),
                      row.get('runtime'), {'series':'Series', 'movie':'Movie'}.get(row.get('type'), str(row.get('type') or '').title())) if v)}
        from lib.hero_tags import tags
        values.update(tags(row))
        ratings = [badge for badge in row.get('rating_badges', []) if ADDON.getSetting('rating_'+badge.get('source',''))!='false']
        if not ratings and row.get('imdbRating') and ADDON.getSetting('rating_imdb') != 'false':
            from lib.rating_format import ten_point
            ratings = [{'value': ten_point(row['imdbRating']), 'icon': 'imdb.png'}]
        if ADDON.getSetting('ui_show_rating') == 'false':
            ratings = []
        for index in range(10):
            badge = ratings[index] if index < len(ratings) else {}
            from lib.rating_format import ten_point
            value=badge.get('value','')
            if value and '%' not in value:value=ten_point(value) or value
            self.setProperty('rating%d_value' % index, value)
            self.setProperty('rating%d_icon' % index, (PATH + '/resources/skins/Main/media/ratings/' + badge['icon']) if badge.get('icon') else '')
            self.setProperty('rating%d_label' % index, badge.get('label', ''))
        for key, value in values.items():
            self.setProperty(key, value)

    def details(self, row, auto_source=None, focus_video_id=None):
        if '_discover_more' in row:
            self.discover_overview_offset = row['_discover_more']
            self.load_discover()
            return
        if row.get('_catalogue'):
            self.discover_catalog = dict(row['_catalogue'])
            self.discover_sports = False
            self.discover_extras = {}
            self.discover_skip = 0
            self.load_discover()
            return
        from lib.launch_guard import mark_window, unmark_window
        if hasattr(self,'row_labels') and self.row_labels.get(self.getFocusId()) in ('Continue Watching', 'Up Next', 'Upcoming Episodes'):
            row=dict(row,_continue_watching=True)
        focus_video_id = focus_video_id or row.get('_focus_video_id')
        self.preview_suspended = True
        self.cancel_trailer()
        window = None
        try:
            window = themed_window(InfoWindow, 'script-stremio-info.xml', PATH, 'Main', '1080i',
                                   meta=row, auto_source=auto_source,
                                   focus_video_id=focus_video_id)
            mark_window(window, 'info')
            window.doModal()
        finally:
            unmark_window(window)
            self.preview_suspended = False
            if hasattr(self, 'account_rows') and self.getProperty('page') == 'Home':
                self.refresh_home_local()


from lib.addons_page import AddonsPage


class HomeWindow(AddonsPage, NimbusWindow):
    def __init__(self, *args, **kwargs):
        self.account_rows = kwargs.pop('account_rows', [])
        self._browse_state = kwargs.pop('browse_state', None)
        self._last_browse_control = None
        self.launch_started = kwargs.pop('launch_started', None)
        self.row_count = kwargs.pop('row_count', 2)
        self.discover_skip = 0
        self.discover_page_size = 100
        self.discover_catalog = None
        self.discover_extras = {}
        self.discover_sports = False
        self.discover_overview = True
        self.discover_overview_offset = 0
        self.discover_row_specs = {}
        from lib.discover_preferences import Preferences
        self.discover_preferences = Preferences(api.STORE.directory)
        self._discover_memory = {}
        self._discover_restore_positions = {}
        self.library_kind = 'all'
        self.library_order = 'recent'
        self.library_entries = []
        self.hero_cache = {}
        self.hero_request = None
        self.hero_loading = False
        self.closed = False
        self.exit_requested = False
        self.home_refreshing = False
        self.home_row_specs = {}
        self.home_row_loading = set()
        self.home_row_exhausted = set()
        self.home_row_cursor = {}
        self._progress_revision = ''
        self._progress_worker = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        xbmcgui.Window(10000).setProperty("strem4kodi.sync.request", "true")
        from lib.perf_trace import now as perf_now, log as perf_log
        init_started = perf_now()
        if getattr(self, 'initialized', False):
            return
        self.initialized = True
        self.rows = {400+i: [] for i in range(self.row_count)}
        self.hero_key = None
        self.getControl(9000).addItems(menu_items(xbmcgui))
        self.getControl(9000).selectItem(home_index())
        if self._browse_state:
            self.restore_browse_state(self._browse_state)
        else:
            self.load_home()
        self._start_progress_watch()
        perf_profile = None
        try:
            perf_profile = api.STORE.directory
        except (NameError, AttributeError):
            pass
        if isinstance(self.account_rows, (list, tuple)):
            perf_log('ui.home.initial', init_started, profile=perf_profile, rows=len(self.account_rows),
                     items=sum(len(row.get('items') or []) for row in self.account_rows
                               if isinstance(row, dict)))
        else:
            perf_log('ui.home.initial', init_started, profile=perf_profile)
        if getattr(self, 'launch_started', None) is not None:
            perf_log('startup.visible', self.launch_started, profile=perf_profile)
            self.launch_started = None
        self.setFocusId(9000)
        self.refresh_home_async()

    def load_home(self):
        dirty = getattr(self, '_providers_dirty', False)
        if dirty:
            self.account_rows = api.account_home(False)
            self._providers_dirty = False
        self.populate_rows('Home', self.account_rows)
        if dirty:
            self.refresh_catalog_posters(self.account_rows)
            self.refresh_home_async()

    @staticmethod
    def _home_row_key(row):
        if not isinstance(row, dict): return ''
        if row.get('label') == 'Continue Watching': return '__continue__'
        if row.get('label') == 'Up Next': return '__next__'
        return str(row.get('_key') or '|'.join(str(row.get(k) or '') for k in ('provider','kind','catalog_id')))

    def retain_current_artwork(self, catalogs):
        from lib.catalog_poster import Posters, retain_preferred
        from lib.provider_config import state
        try:
            signature = Posters(state(api.STORE.directory, api.STORE.load())).signature
            current = [row for rows in self.rows.values() for row in rows]
            current += [row for catalog in self.account_rows or [] for row in catalog.get('items', [])]
            return retain_preferred(catalogs, current, signature)
        except Exception:
            return catalogs

    def patch_home_rows(self, fresh):
        from lib.poster_enhancement import prepare_catalogs
        fresh=prepare_catalogs(self.retain_current_artwork(list(fresh or [])),api.STORE.load())
        current=list(self.account_rows or []);fresh=list(fresh or [])
        if [self._home_row_key(r) for r in current] != [self._home_row_key(r) for r in fresh]: return False
        changed=0
        for index,(old,new) in enumerate(zip(current,fresh)):
            if old == new: continue
            cid=400+index
            if cid not in self.rows: return False
            control=self.getControl(cid);position=control.getSelectedPosition();rows=list(new.get('items') or [])
            self.rows[cid]=rows;self.row_labels[cid]=new.get('label','')
            self.home_row_specs[cid]={k:new.get(k) for k in ('url','kind','catalog_id','provider') if new.get(k) is not None}
            self.home_row_cursor[cid]=len(rows);self.home_row_exhausted.discard(cid)
            control.reset();control.addItems([item(row) for row in rows])
            self.setProperty('row'+str(cid),self.row_labels[cid]);self.setProperty('has'+str(cid),'true' if rows else '')
            if rows: control.selectItem(min(max(0,position),len(rows)-1))
            changed+=1
        self.account_rows=fresh
        return changed

    def refresh_home_local(self):
        """Patch progress locally, then revalidate posters off the UI thread."""
        if self.closed or self.getProperty('page') != 'Home' or self.preview_suspended:
            return False
        try:
            fresh = api.account_home(False)
            focus = self.getFocusId()
            position = self.getControl(focus).getSelectedPosition() if focus in self.rows else None
            patched = self.patch_home_rows(fresh)
            if patched is False:
                self.account_rows = fresh
                self.populate_rows('Home', fresh)
            if focus == 9000:
                self.setFocusId(9000)
            elif focus in self.rows and self.rows[focus]:
                if position is not None:
                    self.getControl(focus).selectItem(min(max(0, position), len(self.rows[focus]) - 1))
                self.setFocusId(focus)
            self.refresh_catalog_posters([{'items': rows} for rows in self.rows.values()])
            return True
        except Exception:
            return False

    def _start_progress_watch(self):
        from lib.progress_signal import snapshot
        self._progress_revision = snapshot()[0]
        if self._progress_worker is not None and self._progress_worker.is_alive():
            return
        def watch():
            while not self.closed:
                if not self.preview_suspended:
                    self.maintain_hero_trailer()
                    self.update_hero()
                revision, _, _ = snapshot()
                if not self.preview_suspended and self.getProperty('page') == 'Library' and revision and revision != self._progress_revision:
                    self._progress_revision=revision
                    focus=self.getFocusId()
                    pos=self.getControl(focus).getSelectedPosition() if focus in self.rows else 0
                    self.library_entries=api.account_library(False)
                    self.load_library()
                    if focus in self.rows and self.rows[focus]:
                        self.getControl(focus).selectItem(min(pos,len(self.rows[focus])-1));self.setFocusId(focus)
                    elif focus==9000:self.setFocusId(9000)
                if not self.preview_suspended and self.getProperty('page') == 'Home':
                    if revision and revision != self._progress_revision:
                        self._progress_revision = revision
                        self.refresh_home_local()
                    # Some Kodi/Fire OS fixedlists consume horizontal D-pad actions
                    # without forwarding every move to WindowXML.onAction. Poll the
                    # selected position so lazy pagination remains device-independent.
                    self.maybe_load_more_home()
                xbmc.sleep(250)
        try:
            self._progress_worker = threading.Thread(target=watch, daemon=True)
            self._progress_worker.start()
        except RuntimeError:
            self._progress_worker = None

    def refresh_home_async(self):
        if self.home_refreshing or self.closed:
            return
        self.home_refreshing = True
        requested_generation = self._poster_generation

        def refresh():
            from lib.perf_trace import now as perf_now, log as perf_log
            refresh_started = perf_now()
            try:
                fresh = api.account_home(True)
                if self.closed or self._poster_generation != requested_generation:
                    return
                if self.getProperty('page') != 'Home' or self.preview_suspended:
                    self.account_rows = self.retain_current_artwork(fresh)
                    return
                focus=self.getFocusId();position=self.getControl(focus).getSelectedPosition() if focus in self.rows else None
                patch_started=perf_now();patched=self.patch_home_rows(fresh)
                if patched is False:
                    self.account_rows=fresh;self.populate_rows('Home',fresh);mode='full';changed=len(fresh)
                else:
                    mode='incremental';changed=patched
                perf_log('ui.home.'+mode,patch_started,profile=api.STORE.directory,rows=len(fresh),items=sum(len(row.get('items') or []) for row in fresh),changed=changed)
                perf_log('ui.home.background.total',refresh_started,profile=api.STORE.directory)
                if focus==9000:self.setFocusId(9000)
                elif focus in self.rows and self.rows[focus]:
                    if position is not None:self.getControl(focus).selectItem(min(max(0,position),len(self.rows[focus])-1))
                    self.setFocusId(focus)
                # Display Home first, then fill configured posters in small
                # background batches without blocking the initial screen.
                from lib.catalog_poster import configured
                generation=self._poster_generation
                cancelled=lambda: (self.closed or self.getProperty('page') != 'Home' or self.preview_suspended
                                   or self._poster_generation != generation)
                for artwork_rows in configured(api.STORE.load()).refresh(fresh, cancelled):
                    if cancelled():
                        break
                    self.patch_catalog_posters(artwork_rows)
            except Exception:
                # Cached/snapshot Home stays usable and the next launch retries.
                pass
            finally:
                self.home_refreshing = False

        threading.Thread(target=refresh, daemon=True).start()

    def patch_catalog_posters(self, catalogs):
        """Change only artwork; retain focus, progress and paginated items."""
        from lib.catalog_poster import identity, Posters
        from lib.catalogue_layout import wide_art
        from lib.provider_config import state
        try:
            signature = Posters(state(api.STORE.directory, api.STORE.load())).signature
        except Exception:
            signature = None
        def newer(row, fresh):
            return (fresh and not (row.get('_poster_signature') and
                    row.get('_poster_signature') == fresh.get('_poster_signature') and
                    row.get('_poster_resolved_at', 0) > fresh.get('_poster_resolved_at', 0)))
        artwork={identity(row):row for catalog in catalogs for row in catalog.get('items', [])
                 if identity(row) and row.get('poster') and row.get('_poster_provider')
                 and row.get('_poster_preferred')
                 and (not signature or not row.get('_poster_signature') or row['_poster_signature'] == signature)}
        for cid, rows in self.rows.items():
            for position, row in enumerate(rows):
                fresh=artwork.get(identity(row))
                if newer(row, fresh):
                    changed = fresh['poster'] != row.get('poster')
                    row.update(poster=fresh['poster'],_poster_provider=fresh['_poster_provider'],
                               _poster_preferred=fresh.get('_poster_preferred', False),
                               _poster_response=fresh.get('_poster_response', 'Not recorded'),
                               _poster_signature=fresh.get('_poster_signature', ''),
                               _poster_resolved_at=fresh.get('_poster_resolved_at', 0))
                    if changed:
                        listing=self.getControl(cid).getListItem(position)
                        listing.setArt({'poster':fresh['poster'],'thumb':fresh['poster']})
                        listing.setProperty('wide_art',wide_art(row))
        for catalog in self.account_rows or []:
            for row in catalog.get('items', []):
                fresh=artwork.get(identity(row))
                if newer(row, fresh):
                    row.update(poster=fresh['poster'],_poster_provider=fresh['_poster_provider'],
                               _poster_preferred=fresh.get('_poster_preferred', False),
                               _poster_response=fresh.get('_poster_response', 'Not recorded'),
                               _poster_signature=fresh.get('_poster_signature', ''),
                               _poster_resolved_at=fresh.get('_poster_resolved_at', 0))

    def populate(self, section, first, second=(), labels=('Movies', 'Series')):
        self.populate_rows(section, [{'label': labels[0], 'items': first},
                                     {'label': labels[1], 'items': second}])

    def populate_rows(self, section, catalogs):
        self._poster_generation=getattr(self,'_poster_generation',0)+1
        from lib.poster_enhancement import prepare_catalogs
        catalogs=prepare_catalogs(self.retain_current_artwork(catalogs),api.STORE.load())
        self.cancel_trailer()
        self.setProperty('page', section)
        self.setProperty('next_row', '')
        self.set_hero({})
        self.hero_key = None
        self.row_labels = {}
        self.discover_row_specs = {}
        if section == 'Home':
            self.home_row_loading.clear()
            self.home_row_exhausted.clear()
            self.home_row_cursor.clear()
        for index, cid in enumerate(self.rows):
            catalog = catalogs[index] if index < len(catalogs) else {}
            rows = catalog.get('items', [])
            self.rows[cid] = rows
            self.row_labels[cid] = catalog.get('label', '')
            if section in ('Discover', 'Sports'):
                self.discover_row_specs[cid] = {k: v for k, v in catalog.items() if k != 'items'}
            if section == 'Home':
                self.home_row_specs[cid] = {k:catalog.get(k) for k in ('url','kind','catalog_id','provider') if catalog.get(k) is not None}
                self.home_row_cursor[cid] = len(rows)
            from lib.catalogue_layout import load as catalogue_layout
            self.setProperty('layout'+str(cid), 'wide' if section == 'Sports' else catalogue_layout(api.STORE.directory, catalog))
            listing = self.getControl(cid)
            listing.reset()
            listing.addItems([item(row) for row in rows])
            self.setProperty('row'+str(cid), self.row_labels[cid])
            self.setProperty('has'+str(cid), 'true' if rows else '')
        available = [cid for cid, rows in self.rows.items() if rows]
        for index, cid in enumerate(available):
            up = available[index-1] if index else (9200 if section in ('Discover', 'Sports', 'Library') else 9000)
            down = available[index+1] if index+1 < len(available) else cid
            self.getControl(cid).setNavigation(self.getControl(up), self.getControl(down),
                                               self.getControl(9000), self.getControl(cid))
        self.setProperty('first_row', str(available[0] if available else 9000))
        failed = sum(bool(c.get('failed')) for c in catalogs)
        self.report(('Some account catalogs could not load. Reopen the addon to retry.' if failed else '')
                    if available else ('Your library has no saved titles for this filter.' if section == 'Library' else 'No titles available for this selection.'))
        selected = available[0] if available else 9000
        self.setFocusId(selected)
        self.update_hero()

    def maybe_load_more_home(self):
        if self.getProperty('page') != 'Home':return
        cid=self.getFocusId()
        if cid not in self.rows or cid in self.home_row_loading or cid in self.home_row_exhausted:return
        rows=self.rows[cid];spec=self.home_row_specs.get(cid) or {}
        if not rows or len(rows)<12 or len(rows)-self.getControl(cid).getSelectedPosition()>4:return
        if not all(spec.get(k) for k in ('url','kind','catalog_id')):return
        self.home_row_loading.add(cid);skip=self.home_row_cursor.get(cid,len(rows))
        generation = self._poster_generation
        def work():
            try:
                from core.protocol import fetch,resource_url
                from lib.home_catalogs import load_more
                more,advanced=load_more(spec,fetch,resource_url,skip)
                if self.closed or self.getProperty('page') != 'Home' or self._poster_generation != generation:return
                self.home_row_cursor[cid]=skip+advanced
                known={(r.get('type'),r.get('id')) for r in self.rows.get(cid,[])}
                fresh=[r for r in more if (r.get('type'),r.get('id')) not in known]
                if fresh:
                    self.rows[cid].extend(fresh)
                    self.getControl(cid).addItems([item(r) for r in fresh])
                    self.refresh_catalog_posters([dict(spec, items=fresh)])
                # Exhaust only when the provider returned a short/empty page. A
                # duplicate-only full page must advance cursor and remain pageable.
                if advanced<16:self.home_row_exhausted.add(cid)
            except Exception:pass
            finally:
                if self._poster_generation == generation:self.home_row_loading.discard(cid)
        threading.Thread(target=work,daemon=True).start()

    def update_hero(self):
        from lib.coreelec import enabled
        if enabled(ADDON) and xbmc.Player().isPlayingVideo() and not self.getProperty("hero_trailer"):return
        if self.getProperty('page') == 'Addons':
            self.update_addon_selection()
            return
        if self.preview_suspended:
            return
        cid = self.getFocusId()
        if cid not in self.rows:
            self.cancel_trailer()
            self.hero_key = None
            return
        following = next((key for key in self.rows if key > cid and self.rows[key]), None)
        self.setProperty('next_row', self.row_labels.get(following, ''))
        pos = self.getControl(cid).getSelectedPosition()
        if 0 <= pos < len(self.rows[cid]):
            row = self.rows[cid][pos]
            key = (cid, pos, row['id'])
            if key != self.hero_key:
                self.cancel_trailer()
                self.hero_key = key
                cached = self.hero_cache.get((row.get('type'), row.get('id')))
                hero = dict(cached or row)
                if row.get('_upcoming_episode'):
                    hero.update({k: row[k] for k in ('name', 'description', '_release_label', '_upcoming_episode') if k in row})
                self.set_hero(hero)
                self.request_hero(key, row)
                if (self.row_labels.get(cid) not in ('Continue Watching', 'Up Next') and (self.getProperty('page') in ('Home', 'Discover', 'Library') or self.getProperty('page').startswith('Search:')) and imdb_id(row) and
                        ADDON.getSetting('trailers_enabled') != 'false' and
                        autoplay_enabled(ADDON.getSetting('trailers_auto'),
                                         ADDON.getSetting('trailers_auto_scope'), 'home')):
                    delay = autoplay_delay(ADDON.getSetting('trailers_delay'))
                    generation = self.preview_generation
                    window_id = xbmcgui.getCurrentWindowId()
                    self.trailer_timer = threading.Timer(0.25, self.play_hero_trailer,
                        args=(window_id, dict(row), generation, time.monotonic() + delay))
                    self.trailer_timer.daemon = True
                    self.trailer_timer.start()

    def request_hero(self, key, row):
        if row.get('_catalogue') or '_discover_more' in row:
            return
        if row.get('_upcoming_episode'):
            self.set_hero(row)
            return
        identity = (row.get('type'), row.get('id'))
        if identity in self.hero_cache:
            self.set_hero(self.hero_cache[identity])
            return
        from lib import mdblist
        if row.get('background') and row.get('background') != row.get('poster') and row.get('description') and not mdblist.enabled() and not ADDON.getSetting('tmdb_api_key'):
            return
        self.hero_request = (key, dict(row), self.getProperty('page'), self._poster_generation)
        if self.hero_loading:
            return
        self.hero_loading = True
        def enrich():
            try:
                while self.hero_request and not self.closed:
                    request = self.hero_request
                    self.hero_request = None
                    request_key, preview, page, generation = request
                    try:
                        full = preview if preview.get('background') and preview.get('background') != preview.get('poster') and preview.get('description') else api.metadata(preview)
                        full = age_enrich(mdblist.enrich(full))
                        if self._poster_generation != generation:
                            continue
                        self.hero_cache[(preview.get('type'), preview.get('id'))] = full
                        if not self.closed and self.hero_key == request_key and self.getProperty('page') == page:
                            self.set_hero(full)
                    except Exception:
                        pass
            finally:
                self.hero_loading = False
        threading.Thread(target=enrich, daemon=True).start()

    def close(self):
        self.remember_discover()
        try:
            self.discover_preferences.save()
        except Exception:
            pass
        self.cancel_trailer()
        self.closed = True
        self.hero_request = None
        super().close()

    def load_sports(self):
        self.discover_sports = True
        self.discover_catalog = None
        self.discover_skip = 0
        self.discover_extras = {}
        self.load_discover()

    def load_collection(self):
        catalog = self.discover_catalog
        values = dict(self.discover_extras)
        unwatched = values.pop('_unwatched', False)
        if self.discover_skip:
            values['skip'] = str(self.discover_skip)
        raw = self.busy('Loading catalogue', lambda: api.discover_items(catalog, values))
        if raw is None:
            raw = []
        self.discover_page_size = len(raw)
        rows = api.collection_progress(raw, unwatched)
        self.setProperty('filter_label_0', 'Movies and series' if catalog['kind'] == 'all' else 'Catalogue')
        self.setProperty('filter_label_1', 'List sources')
        self.setProperty('filter_label_2', 'Unwatched only' if unwatched else 'All titles')
        self.setProperty('filters', catalog['label'] + ' · Supplied order')
        self.populate_rows('Discover', [dict(catalog, items=rows)])
        self.refresh_catalog_posters([dict(catalog, items=rows)])
        if not rows:
            self.report('No matching titles on this page. Use More options for the next page.' if raw else 'No titles returned for this catalogue.')
            self.setFocusId(9202)

    def edit_collection_filters(self, direct=None):
        from lib.nimbus_select import Dialog
        dialog = Dialog(PATH)
        catalog = self.discover_catalog
        paging = any(e['name'] == 'skip' for e in catalog['extras'])
        options = ['All titles', 'Unwatched only', 'List sources'] + (['Next page', 'First page'] if paging else [])
        if direct == 1:
            option = 2
        else:
            option = dialog.select('Catalogue', options)
        if option < 0:
            return
        if option == 2:
            dialog.select('List sources', [catalog.get('addon', 'Addon') + ' — ' + catalog['label']])
            return
        if option in (0, 1):
            self.discover_extras['_unwatched'] = option == 1
        elif option == 3:
            if not self.discover_page_size:
                self.report('No further titles returned.')
                return
            self.discover_skip += self.discover_page_size
        elif option == 4:
            self.discover_skip = 0
        self.load_collection()

    def remember_discover(self):
        if self.getProperty('page') != 'Discover' or not self.discover_catalog or self.discover_catalog.get('_search_collection'):
            return
        positions = {cid: self.getControl(cid).getSelectedPosition() for cid in self.rows}
        self.discover_preferences.remember(self.discover_catalog, self.discover_extras,
                                           self.discover_overview, self.discover_overview_offset,
                                           self.discover_skip, positions)
        self._discover_memory[self.discover_catalog['kind']] = self.capture_browse_state()

    def restore_discover_preferences(self, choices, kind=None):
        catalog, saved = self.discover_preferences.restore(choices, kind)
        self.discover_catalog = catalog
        self.discover_extras = saved.get('extras', {})
        self.discover_skip = saved.get('skip', 0)
        self.discover_overview = saved.get('overview', catalog.get('label') != 'Most Anticipated')
        self.discover_overview_offset = saved.get('offset', 0)
        self._discover_restore_positions = saved.get('positions', {})

    def restore_discover_positions(self):
        for key, pos in self._discover_restore_positions.items():
            cid = int(key)
            if self.rows.get(cid):
                self.getControl(cid).selectItem(min(pos, len(self.rows[cid]) - 1))
        self._discover_restore_positions = {}
        self.hero_key = None
        self.update_hero()

    def load_discover(self):
        if self.discover_catalog and self.discover_catalog.get('_search_collection'):
            self.load_collection()
            return
        sports = getattr(self, 'discover_sports', False)
        section = 'Sports' if sports else 'Discover'
        choices = api.discover_choices(sports=sports)
        if not choices:
            self.setProperty('filters', 'Discover Â· No account catalogs')
            self.populate_rows(section, [])
            self.setFocusId(9200)
            return
        if not self.discover_catalog and not sports and hasattr(self, 'discover_preferences'):
            self.restore_discover_preferences(choices)
        if not self.discover_catalog or not any(c['id'] == self.discover_catalog['id'] for c in choices):
            from lib.discovery_groups import default_catalogue
            self.discover_catalog = choices[0] if sports else default_catalogue(choices)
            self.discover_overview = not (self.discover_catalog.get('label') == 'Most Anticipated')
            self.discover_overview_offset = 0
        catalog = self.discover_catalog
        if getattr(self, 'discover_overview', True) and not sports:
            from lib.discovery_groups import overview
            self.setProperty('filter_label_0', {'movie': 'Movies', 'series': 'Series'}.get(catalog['kind'], catalog['kind'].title()))
            self.setProperty('filter_label_1', catalog.get('family') or 'Lists')
            self.setProperty('filter_label_2', 'All lists')
            self.setProperty('filters', catalog['kind'].title() + ' · ' + str(catalog.get('family') or 'Lists'))
            sections = self.busy('Loading Discover lists', lambda: overview(choices, catalog, api.discover_items, getattr(self, 'discover_overview_offset', 0))) or []
            self.populate_rows(section, sections)
            self.refresh_catalog_posters(sections)
            if hasattr(self, 'discover_preferences'):
                self.restore_discover_positions()
            if not any(c.get('items') for c in sections):
                self.setFocusId(9202)
            return
        values = dict(catalog['defaults']); values.update(self.discover_extras)
        if self.discover_skip:
            values['skip'] = str(self.discover_skip)
        self.setProperty('filter_label_0', {'movie': 'Movies', 'series': 'Series', 'sport': 'Sports'}.get(catalog['kind'], catalog['kind'].title()))
        self.setProperty('filter_label_1', catalog.get('family') or catalog['label'])
        self.setProperty('filter_label_2', catalog['label'])
        summary = ' · '.join([catalog['kind'].title(), catalog['label']] + [str(value) for key, value in values.items() if not key.startswith('_')])
        self.setProperty('filters',  summary)
        rows = self.busy('Loading Discover', lambda: api.discover_items(catalog, values))
        if rows: self.discover_page_size = len(rows)
        if self.discover_skip:
            from lib.discovery_groups import item_key
            seen = set(getattr(self, '_discover_seen', set()))
            fresh_rows = [r for r in rows or [] if item_key(r) not in seen]
            rows = fresh_rows
        else:
            self._discover_seen = set()
        from lib.discovery_groups import item_key
        self._discover_seen.update(item_key(r) for r in rows or [])
        self.populate_rows(section, [dict(catalog, label=catalog['label'], items=rows or [])])
        self.refresh_catalog_posters([dict(catalog,items=rows or [])])
        if hasattr(self, 'discover_preferences'):
            self.restore_discover_positions()
        if not rows:
            self.setFocusId(9200)

    def refresh_catalog_posters(self, catalogs):
        from lib.catalog_poster import configured
        generation=self._poster_generation
        page=self.getProperty('page')
        cancelled=lambda: (self.closed or self.preview_suspended or self.getProperty('page') != page
                           or self._poster_generation != generation)
        def work():
            try:
                posters=configured(api.STORE.load())
                if cancelled():return
                self.patch_catalog_posters(posters.cached(catalogs))
                for fresh in posters.refresh(catalogs,cancelled):
                    if cancelled():break
                    self.patch_catalog_posters(fresh)
            except Exception:
                pass
        threading.Thread(target=work,daemon=True).start()

    def load_library(self):
        from lib.browse import library_sections, library_kinds
        if self.library_kind not in library_kinds(self.library_entries):
            self.library_kind = 'all'
        labels = {'recent':'Recently added', 'watched':'Last watched', 'name':'Name'}
        self.setProperty('filter_label_0', self.library_kind.title())
        self.setProperty('filter_label_1', labels[self.library_order])
        self.setProperty('filter_label_2', 'Refresh')
        self.setProperty('filters',  self.library_kind.title() + ' Â· ' + labels[self.library_order])
        sections = library_sections(self.library_entries, self.library_kind, self.library_order)
        self.populate_rows('Library', sections)
        self.refresh_catalog_posters(sections)
        if not any(self.rows.values()):
            self.setFocusId(9200)

    def edit_filters(self, direct=None):
        if self.getProperty('page') == 'Discover' and self.discover_catalog and self.discover_catalog.get('_search_collection'):
            self.edit_collection_filters(direct)
            return
        if self.getProperty('page') == 'Discover' and getattr(self, 'discover_overview', True) and direct is None:
            from lib.nimbus_select import Dialog
            option = Dialog(PATH).select('Discover options', ['Type', 'Browse group', 'List', 'Options for this row', 'First lists'])
            if option < 0:
                return
            if option < 3:
                self.edit_filters(option)
            elif option == 4:
                self.discover_overview_offset = 0
                self.load_discover()
            else:
                cid = self.getFocusId()
                spec = getattr(self, 'discover_row_specs', {}).get(cid, {})
                if not spec.get('members'):
                    self.report('Select a list row to open its options.')
                    return
                self.discover_catalog = dict(spec)
                self.discover_overview = False
                self.discover_extras = {}
                self.discover_skip = 0
                self.load_discover()
                self.edit_filters()
            return
        from lib.nimbus_select import Dialog
        dialog = Dialog(PATH, left=50 + (direct or 0)*290,
                        top=660 if self.getProperty('page') == 'Discover' else 600)
        if self.getProperty('page') in ('Discover', 'Sports'):
            choices = api.discover_choices(sports=getattr(self, 'discover_sports', False))
            if not choices:
                return
            current = self.discover_catalog or choices[0]
            extras = [e for e in current['extras'] if e.get('name') not in ('skip','search') and e.get('options')]
            paging = any(e.get('name') == 'skip' for e in current['extras'])
            options = ['Type', 'Browse group', 'List'] + [e['name'].title() for e in extras] + ['List sources', 'Thumbnail layout']
            option = direct if direct is not None else dialog.select('Discover options', options + (['Next page', 'First page'] if paging else []))
            if option == 2:
                if current.get('family'):
                    matching = [c for c in choices if c['kind'] == current['kind'] and c.get('family') == current['family']]
                    labels = ([] if getattr(self, 'discover_sports', False) else ['All lists']) + [c['label'] for c in matching]
                    selected = dialog.select(current['family'], labels)
                    if selected >= 0:
                        all_lists = not getattr(self, 'discover_sports', False) and selected == 0
                        self.discover_overview = all_lists
                        self.discover_overview_offset = 0
                        self.discover_catalog = current if all_lists else matching[selected if getattr(self, 'discover_sports', False) else selected - 1]
                        self.discover_extras = {}
                        self.discover_skip = 0
                        self.load_discover()
                    return
                return
            if option < 0:
                return
            if paging and option >= len(options):
                if option == len(options):
                    self.discover_extras['_source_cursors'] = current.get('_next_cursors', {})
                else:
                    self.discover_extras.pop('_source_cursors', None)
                self.discover_skip = self.discover_skip + self.discover_page_size if option == len(options) else 0
                self.load_discover()
                return
            if option == len(options)-2:
                dialog.select('List sources', [m.get('addon', 'Addon') + ' — ' + m['label'] for m in current.get('members', [])])
                return
            if option == len(options)-1:
                from lib.catalogue_layout import load, save, sports
                if sports(current) or getattr(self, 'discover_sports', False):
                    dialog.select('Catalogue thumbnails', ['Wide thumbnails (automatic for sports)'], preselect=0)
                    return
                layout = dialog.select('Catalogue thumbnails', ['Posters','Wide thumbnails'], preselect=1 if load(api.STORE.directory,current)=='wide' else 0)
                if layout >= 0:
                    save(api.STORE.directory,current,('posters','wide')[layout])
                    self.load_discover()
                return
            if option == 0:
                types = list(dict.fromkeys(c['kind'] for c in choices))
                selected = dialog.select('Type', [{'movie': 'Movies', 'series': 'Series', 'sport': 'Sports'}.get(t, t.title()) for t in types])
                if selected < 0: return
                target_kind = types[selected]
                if not self.discover_sports and target_kind in ('movie', 'series'):
                    self.remember_discover()
                    if target_kind in self._discover_memory:
                        self.restore_browse_state(self._discover_memory[target_kind])
                    else:
                        self.restore_discover_preferences(choices, target_kind)
                        self.load_discover()
                    return
                self.discover_overview = True
                self.discover_overview_offset = 0
                from lib.discovery_groups import default_catalogue
                self.discover_catalog = next((c for c in choices if c['kind'] == target_kind and c.get('family') == current.get('family') and c['label'] == current['label']),
                                             default_catalogue(choices, target_kind))
                if self.discover_catalog.get('label') == 'Most Anticipated':
                    self.discover_overview = False
                self.discover_extras = {}
            elif option == 1:
                matching = [c for c in choices if c['kind'] == current['kind']]
                categories = [c for c in matching if not c.get('family')]
                families = list(dict.fromkeys(c['family'] for c in matching if c.get('family')))
                selected = dialog.select('Browse group', [c['label'] for c in categories] + families)
                if selected < 0: return
                self.discover_overview = True
                self.discover_overview_offset = 0
                self.discover_catalog = categories[selected] if selected < len(categories) else next(c for c in matching if c.get('family') == families[selected-len(categories)])
                self.discover_extras = {}
            else:
                extra = extras[option-3]
                required = extra['name'] in current['defaults'] or any(extra['name'] in m.get('defaults', {}) or any(e.get('name') == extra['name'] and e.get('isRequired') for e in m.get('extras', [])) for m in current.get('members', []))
                values = list(extra['options'])
                selected = dialog.select(extra['name'].title(), ([] if required else ['All']) + [str(v) for v in values])
                if selected < 0: return
                if not required and selected == 0:
                    self.discover_extras.pop(extra['name'], None)
                else:
                    self.discover_extras[extra['name']] = str(values[selected if required else selected-1])
            self.discover_skip = 0
            self.discover_extras.pop('_source_cursors', None)
            self.load_discover()
        elif self.getProperty('page') == 'Library':
            option = direct if direct is not None else dialog.select('Library', ['Type', 'Sort', 'Refresh from account'])
            if option == 0:
                from lib.browse import library_kinds
                kinds = library_kinds(self.library_entries)
                selected = dialog.select('Type', [t.title() for t in kinds])
                if selected < 0: return
                self.library_kind = kinds[selected]
            elif option == 1:
                selected = dialog.select('Sort', ['Recently added', 'Last watched', 'Name'])
                if selected < 0: return
                self.library_order = ['recent', 'watched', 'name'][selected]
            elif option == 2:
                rows = self.busy('Syncing your library', api.account_library)
                if rows is not None: self.library_entries = rows
            else:
                return
            self.load_library()

    def onFocus(self, control_id):
        if getattr(self, 'initialized', False):
            if control_id in self.rows and self.rows[control_id]:
                self._last_browse_control = control_id
                self.setProperty('first_row', str(control_id))
            self.update_hero()

    def home_media_context_menu(self):
        cid = self.getFocusId()
        if cid not in self.rows:
            return False
        if self.getProperty('page') != 'Home' or self.row_labels.get(cid) != 'Continue Watching':
            pos = self.getControl(cid).getSelectedPosition()
            if not 0 <= pos < len(self.rows[cid]):
                return False
            row = self.rows[cid][pos]
            if row.get('type') not in ('movie', 'series'):
                return False
            from lib.media_action_menu import choose
            options = [{'action': 'artwork', 'label': 'Artwork details', 'icon': 'info'}]
            if self.getProperty('page') in ('Discover', 'Sports', 'Library'):
                options.append({'action': 'filters', 'label': 'Browse options', 'icon': 'info'})
            selected = choose(PATH, options)
            if selected == 'artwork':
                from lib.artwork_diagnostics import show
                show(row)
            elif selected == 'filters':
                self.edit_filters()
            return True
        pos = self.getControl(cid).getSelectedPosition()
        if not 0 <= pos < len(self.rows[cid]):
            return False
        row = self.rows[cid][pos]
        saved = api.saved(row)
        state = saved.get('state') or {}
        target_id = str(state.get('video_id') or row.get('id') or '')
        from lib.media_action_menu import choose
        try:
            offset = max(0, int(float(state.get('timeOffset') or 0)))
            duration = max(0, int(float(state.get('duration') or 0)))
        except (TypeError, ValueError):
            offset, duration = 0, 0
        # A current partial rewatch is not treated as watched merely because an
        # older flaggedWatched value remains on the Stremio library item.
        partial = offset > 1 and (not duration or offset < duration * 0.90)
        watched = bool(state.get('flaggedWatched')) and not partial
        from context_options import continue_options
        options = continue_options(row.get('type'), watched)
        options.append({'action': 'artwork', 'label': 'Artwork details', 'icon': 'info'})
        selected = choose(PATH, options)
        if selected is None:
            return True
        if selected == 'artwork':
            from lib.artwork_diagnostics import show
            show(row)
            return True
        full = self.busy('Loading media', lambda: age_enrich(mdblist.enrich(api.metadata(row)))) or row
        if selected == 'restart':
            identity = target_id if row.get('type') == 'series' else str(row.get('id') or '')
            self.details(full, auto_source=(identity, 0), focus_video_id=target_id)
        elif selected == 'episode':
            self.details(full, focus_video_id=target_id)
        elif selected in ('series', 'info'):
            self.details(full)
        elif selected == 'toggle-watched':
            if row.get('type') == 'series':
                from lib.episode_state import watched_ids
                is_watched = target_id in watched_ids(full.get('videos', []), api.saved(full))
                result = self.busy('Updating watched state',
                                   lambda: api.mark_episode(full, target_id, not is_watched))
            else:
                result = self.busy('Updating watched state',
                                   lambda: api.mark_movie(full, not watched))
            if result is not None:
                self.account_rows = api.account_home(False)
                self.load_home()
        elif selected == 'remove-continue':
            result = self.busy('Updating Continue Watching', lambda: api.remove_continue(full))
            if result is not None:
                self.account_rows = api.account_home(False)
                self.load_home()
        if cid in self.rows and self.rows[cid]:
            self.setFocusId(cid)
            self.getControl(cid).selectItem(min(pos, len(self.rows[cid]) - 1))
        return True

    def onAction(self, action):
        if isinstance(getattr(xbmcgui, '__name__', None), str):
            from lib.ui_dialogs import dialog as themed_dialog
        else:
            themed_dialog = xbmcgui.Dialog
        aid = action.getId()
        if aid in BACK:
            # Restore the original proven two-press exit guard. The first Back
            # only cancels preview, focuses the sidebar and arms exit. A later
            # physical Back opens the confirmation dialog.
            if not getattr(self, 'exit_armed', False):
                self.cancel_trailer()
                try:
                    sidebar = self.getControl(9000)
                    sidebar.selectItem(home_index())
                except Exception:
                    pass
                self.setFocusId(9000)
                self.exit_armed = True
                return
            self.exit_armed = False
            if themed_dialog().yesno(
                    'Exit Strem4Kodi',
                    'Do you want to exit Strem4Kodi?',
                    nolabel='Cancel', yeslabel='Exit'):
                self.exit_requested = True
                self.exit_window_id = xbmcgui.getCurrentWindowId()
                from lib.launch_guard import defer_relaunch
                defer_relaunch()
                self.close()
            return
        if aid in (1, 2, 3, 4, 7, 11, 100, 101):
            self.exit_armed = False
        if aid == 117 and self.home_media_context_menu():
            return
        if aid == 117 and self.getProperty('page') in ('Discover', 'Sports'):
            self.edit_filters()
            return
        if aid == 11 and self.getFocusId() in self.rows:
            self.onClick(self.getFocusId())
        else:
            self.update_hero()
            self.maybe_load_more_home()

    def capture_browse_state(self):
        """Keep loaded pages and selections when a theme change rebuilds the window."""
        if self.getProperty('page') == 'Addons':
            return None
        catalogs = []
        positions = {}
        for cid, rows in self.rows.items():
            spec = dict(self.home_row_specs.get(cid) or {}) if self.getProperty('page') == 'Home' else dict(getattr(self, 'discover_row_specs', {}).get(cid) or self.discover_catalog or {}) if self.getProperty('page') in ('Discover', 'Sports') else {}
            catalogs.append(dict(spec, label=self.row_labels.get(cid, ''), items=list(rows)))
            positions[cid] = self.getControl(cid).getSelectedPosition()
        return dict(page=self.getProperty('page'), catalogs=catalogs, positions=positions,
                    last_control=self._last_browse_control,
                    properties={name:self.getProperty(name) for name in ('filters','filter_label_0','filter_label_1','filter_label_2')},
                    discover_catalog=self.discover_catalog, discover_extras=dict(self.discover_extras), discover_sports=self.discover_sports,
                    discover_skip=self.discover_skip, discover_page_size=self.discover_page_size,
                    discover_seen=set(getattr(self, '_discover_seen', set())),
                    discover_overview=getattr(self, 'discover_overview', True), discover_overview_offset=getattr(self, 'discover_overview_offset', 0),
                    library_kind=self.library_kind, library_order=self.library_order,
                    library_entries=list(self.library_entries))

    def restore_browse_state(self, state):
        for name in ('discover_catalog','discover_extras','discover_skip','discover_page_size','discover_sports',
                     'library_kind','library_order','library_entries'):
            setattr(self, name, state.get(name, False) if name == 'discover_sports' else state[name])
        self._discover_seen = set(state.get('discover_seen', set()))
        self.discover_overview = state.get('discover_overview', True)
        self.discover_overview_offset = state.get('discover_overview_offset', 0)
        self.populate_rows(state['page'], state['catalogs'])
        for name, value in state['properties'].items():
            self.setProperty(name, value)
        for cid, position in state['positions'].items():
            if self.rows.get(cid):
                self.getControl(cid).selectItem(min(max(0, position), len(self.rows[cid])-1))
        self._last_browse_control = state['last_control']
        self.resume_browse()

    def resume_browse(self):
        """Return to the existing catalogue without refetching or resetting it."""
        cid = self._last_browse_control
        if cid not in self.rows or not self.rows[cid]:
            cid = next((key for key, rows in self.rows.items() if rows), 9000)
        self.setFocusId(cid)
        self.hero_key = None
        self.update_hero()

    def open_settings(self):
        from lib.settings_page import show as show_settings
        browse_state = self.capture_browse_state()
        result = show_settings()
        from lib.playback_settings import apply
        apply()
        if result.get('providers_changed'):
            self._poster_generation = getattr(self, '_poster_generation', 0) + 1
            self.hero_cache.clear()
            self._discover_memory.clear()
            self.hero_request = None
            self.discover_catalog = None
            self.refresh_catalog_posters([{'items': rows} for rows in self.rows.values()])
        self.hero_key = None
        self.update_hero()
        if result.get('request_page') == 'addons':
            self.load_addons()
        elif result.get('appearance_changed'):
            self.reload_browse_state = browse_state
            self.reload_appearance = True
            self.close()

    def onClick(self, cid):
        if isinstance(getattr(xbmcgui, '__name__', None), str):
            from lib.ui_dialogs import dialog as themed_dialog
        else:
            themed_dialog = xbmcgui.Dialog
        self.exit_armed = False
        if cid in (9300, 9301, 9302, 9303, 9304):
            self.addon_click(cid)
            return
        self.cancel_trailer()
        self.hero_key = None
        if cid in (9200, 9201, 9202):
            self.edit_filters(cid-9200)
            return
        if cid == 9000:
            pos = self.getControl(9000).getSelectedPosition()
            cid = menu_action(pos)
        if cid in self.rows:
            pos = self.getControl(cid).getSelectedPosition()
            if 0 <= pos < len(self.rows[cid]):
                selected_row = self.rows[cid][pos]
                self.details(selected_row)
                if selected_row.get('_catalogue') or '_discover_more' in selected_row:
                    return
                if self.getProperty('page') == 'Discover' and self.discover_catalog and self.discover_catalog.get('_search_collection'):
                    self.load_collection()
                    if not self.rows.get(cid):
                        return
                    pos = min(pos, len(self.rows[cid]) - 1)
                self.setFocusId(cid)
                self.getControl(cid).selectItem(pos)
            return
        if cid in (202, 203, 204, 207) and self.getProperty('page') == {202:'Home',203:'Discover',204:'Library',207:'Sports'}[cid]:
            self.resume_browse()
            return
        if cid in (201, 202, 203, 204, 205, 206, 207):
            self.remember_discover()
        if cid == 202:
            self.load_home()
        elif cid == 201:
            from lib.search_box import show as search_box
            query = search_box(api.STORE.directory, api.suggestions)
            if isinstance(query, dict):
                self.details(query)
            elif query:
                result = self.busy('Searching', lambda: api.search_titles(query)) or []
                from search_match import title_relevance
                exact = [r for r in result if r.get('type') != 'collection' and title_relevance(query, r) == 0]
                if len(exact) == 1 and not any(r.get('_catalogue') for r in result):
                    self.details(exact[0])
                else:
                    catalogues = [r for r in result if r.get('_catalogue')]
                    if catalogues:
                        self.populate_rows('Search: ' + query, [
                            {'label': 'Catalogues', 'items': catalogues},
                            {'label': 'Movies', 'items': [r for r in result if r.get('type') == 'movie']},
                            {'label': 'Series', 'items': [r for r in result if r.get('type') == 'series']}])
                    else:
                        self.populate('Search: ' + query, [r for r in result if r.get('type') == 'movie'],
                                      [r for r in result if r.get('type') == 'series'])
                    self.refresh_catalog_posters([{'items': result}])
        elif cid == 203:
            self.discover_sports = False
            if self.discover_catalog and (self.discover_catalog.get('kind') == 'sport' or self.discover_catalog.get('_search_collection')):
                self.discover_catalog = None
                self.discover_skip = 0
                self.discover_extras = {}
            kind = (self.discover_catalog or {}).get('kind')
            if kind in self._discover_memory:
                self.restore_browse_state(self._discover_memory[kind])
            else:
                self.load_discover()
        elif cid == 207:
            self.load_sports()
        elif cid == 204:
            entries = self.busy('Syncing your library', api.account_library)
            self.library_entries = entries if entries is not None else api.account_library(False)
            self.load_library()
        elif cid == 205:
            self.load_addons()
        elif cid == 206:
            self.open_settings()


from lib.inline_streams import InlineStreams


class InfoWindow(InlineStreams, NimbusWindow):
    def __init__(self, *args, **kwargs):
        self.preview = kwargs.pop('meta')
        self.auto_source = kwargs.pop('auto_source', None)
        self.focus_video_id = kwargs.pop('focus_video_id', None)
        super().__init__(*args, **kwargs)
        self.initialized = False
        self.menu_mode = None
        self.section = ''
        self.section_cache = {}
        self.cards = []
        self.play_target = ''
        self.resume_ms = 0
        self.closed = False
        self._progress_revision = ''
        self._progress_worker = None
        self.init_streams()

    def onInit(self):
        xbmcgui.Window(10000).setProperty("strem4kodi.sync.request", "true")
        if self.initialized:
            return
        self.initialized = True
        self.meta = self.preview
        self.set_hero(self.meta)
        self.meta = self.busy('Loading details', lambda: age_enrich(mdblist.enrich(api.metadata(self.preview)))) or self.preview
        self.set_hero(self.meta)
        series = self.meta.get('type') == 'series'
        self.setProperty('series', 'true' if series else '')
        self.available_seasons = api.seasons(self.meta)
        regular = [r for r in self.available_seasons if r['season'] > 0]
        self.season = (regular or self.available_seasons or [{'season': 1}])[0]['season']
        saved = api.saved(self.meta)
        from lib.episode_state import watched_ids
        self.watched_episodes = watched_ids(self.meta.get('videos', []), saved)
        if series:
            next_video, self.resume_ms = api.next_series_episode(self.meta.get('videos', []), self.meta['id'], saved)
            if next_video and next_video['id'] in self.watched_episodes and not api.resume_seconds(self.resume_ms):
                regular = [v for season in api.seasons(self.meta) if season['season'] > 0
                           for v in api.episodes(self.meta, season['season'])]
                next_video = next((v for v in regular if v['id'] not in self.watched_episodes), next_video)
                self.resume_ms = 0
            if next_video:
                self.play_target = next_video['id']
                self.season = int(next_video.get('season', self.season))
            if self.focus_video_id:
                focus_video = next((v for v in self.meta.get('videos', [])
                                    if str(v.get('id') or '') == str(self.focus_video_id)), None)
                if focus_video:
                    self.season = int(focus_video.get('season', self.season))
                    self.play_target = focus_video['id']
                    if str((saved.get('state') or {}).get('video_id') or '') != str(self.play_target):
                        self.resume_ms = 0
        else:
            self.play_target = self.meta['id']
            self.resume_ms = (saved.get('state') or {}).get('timeOffset') or 0
        self.refresh_primary_action()
        self.prefetch_streams(self.play_target)
        self.setProperty('hastrailer', 'true' if ADDON.getSetting('trailers_enabled') != 'false' and imdb_id(self.meta) else '')
        self.refresh_library()
        self.select_section('Episodes' if series else 'Similar')
        if series and self.focus_video_id:
            pos = next((i for i, row in enumerate(self.cards)
                        if str(row.get('id') or '') == str(self.focus_video_id)), None)
            if pos is not None:
                self.getControl(501).selectItem(pos)
        self.setFocusId(501 if series and self.cards else 21001)
        self._start_progress_watch()
        if self.auto_source:
            identity, resume = self.auto_source
            self.choose_source(identity, resume_ms=resume)
            self.auto_source = None
            return
        if (autoplay_enabled(ADDON.getSetting('trailers_auto'),
                             ADDON.getSetting('trailers_auto_scope'), 'info')
                and self.getProperty('hastrailer') and not self.preview.get('_continue_watching') and not api.resume_seconds(self.resume_ms)):
            window_id = xbmcgui.getCurrentWindowId()
            delay = autoplay_delay(ADDON.getSetting('trailers_delay'))
            generation = self.preview_generation
            deadline = time.monotonic() + delay
            def autoplay():
                if not self.closed and generation == self.preview_generation and not xbmc.Player().isPlaying():
                    self.play_hero_trailer(window_id, generation=generation, deadline=deadline)
            self.trailer_timer = threading.Timer(0.25, autoplay)
            self.trailer_timer.daemon = True
            self.trailer_timer.start()

    def close(self):
        self.closed = True
        self.stop_streams()
        self.cancel_trailer()
        super().close()

    def _start_progress_watch(self):
        from lib.progress_signal import snapshot
        self._progress_revision = snapshot()[0]
        if self._progress_worker is not None and self._progress_worker.is_alive():
            return
        def watch():
            while not self.closed:
                self.maintain_hero_trailer()
                self.recover_stream_tick()
                self.refresh_episode_description()
                revision, meta_id, _ = snapshot()
                if revision and revision != self._progress_revision:
                    current_meta = str(self.meta.get('id') or '')
                    if meta_id not in (current_meta, "*"):
                        self._progress_revision = revision
                    elif not xbmc.Player().isPlayingVideo():
                        # Do not consume our revision until Kodi has actually
                        # returned from the player; the next 250ms pass retries.
                        self._progress_revision = revision
                        if self.section == 'Episodes' and self.cards:
                            pos = self.getControl(501).getSelectedPosition()
                            keep_focus = self.getFocusId() == 501
                            self._refresh_episode_cards(pos, focus_episode=keep_focus)
                        else:
                            self._resume_marker = None
                            self.refresh_resume_state()
                xbmc.sleep(250)
        try:
            self._progress_worker = threading.Thread(target=watch, daemon=True)
            self._progress_worker.start()
        except RuntimeError:
            self._progress_worker = None

    def play_trailer(self):
        self.cancel_trailer()
        if ADDON.getSetting('trailers_enabled') == 'false':
            return
        self.report('')
        window_id = xbmcgui.getCurrentWindowId()
        generation = self.preview_generation
        self.trailer_timer = threading.Timer(0, self.play_hero_trailer,
                                             args=(window_id,), kwargs={'generation': generation})
        self.trailer_timer.daemon = True
        self.trailer_timer.start()

    def refresh_library(self):
        self.setProperty('librarylabel', 'In library' if api.in_library(self.meta) else 'Add to library')

    def refresh_primary_action(self):
        from lib.auto_source import configured
        mode,_=configured(ADDON,self.meta)
        if mode!=getattr(self,'_primary_mode',mode):self._manual_source_only=False
        self._primary_mode=mode
        automatic=mode==2 and not getattr(self,'_manual_source_only',False)
        self.setProperty('source_auto','true' if automatic else '')
        self.setProperty('playlabel',('Resume' if api.resume_seconds(self.resume_ms) else 'Play') if automatic else 'Choose source')

    def show_more_actions(self):
        actions=[]
        if self.getProperty('source_auto')=='true':actions.append(('Choose source manually','source'))
        if api.resume_seconds(self.resume_ms):actions.append(('Play from beginning','restart'))
        if self.getProperty('hastrailer'):actions.append(('Watch trailer','trailer'))
        actions.append(('Remove from library' if self.getProperty('librarylabel')=='In library' else 'Add to library','library'))
        selected=themed_dialog().select('More actions',[label for label,_ in actions])
        if not 0<=selected<len(actions):return
        action=actions[selected][1]
        if action=='restart' and self.play_target:self.choose_source(self.play_target,resume_ms=0)
        elif action=='source' and self.play_target:self.choose_source(self.play_target,resume_ms=self.resume_ms,allow_auto=False)
        elif action=='trailer':self.play_trailer()
        elif action=='library':self.onClick(21005)

    def select_section(self, section):
        self.section = section
        self.setProperty('section', section)
        self.setProperty('seasonlabel', 'Specials' if self.season == 0 else 'Season ' + str(self.season))
        self.clearProperty('menu')
        self.menu_mode = None
        self.report('')
        if section == 'Episodes':
            rows = api.episodes(self.meta, self.season)
            rating_key='episode-ratings:'+str(self.season)
            if rating_key not in self.section_cache:
                from lib.title_metadata import episode_scores
                self.section_cache[rating_key]=self.busy('Loading episode details',lambda:episode_scores(self.meta,self.season,rows)) or rows
            rows=self.section_cache[rating_key]
        elif section in ('Cast', 'Crew'):
            if section not in self.section_cache:
                self.section_cache[section] = self.busy('Loading ' + section.lower(),
                    lambda: api.people(self.meta, section.lower())) or []
            rows = self.section_cache[section]
        elif section == 'Languages':
            rows = api.languages(self.meta)
        else:
            if 'Similar' not in self.section_cache:
                self.section_cache['Similar'] = self.busy('Loading similar titles',
                    lambda: api.recommendations(self.meta, api.providers())) or []
            rows = self.section_cache['Similar']
        self.cards = rows
        self.active_list = 500 if section in ('Cast', 'Crew') else 502 if section == 'Languages' else 503 if section == 'Similar' else 501
        for cid in (500, 501, 502, 503):
            self.getControl(cid).reset()
        items = []
        episode_progress = {}
        if section == 'Episodes':
            saved = api.saved(self.meta)
            state = saved.get('state') if isinstance(saved, dict) else {}
            if isinstance(state, dict):
                active_id = str(state.get('video_id') or '')
                try:
                    offset = max(0.0, float(state.get('timeOffset') or 0) / 1000.0)
                    duration = max(0.0, float(state.get('duration') or 0) / 1000.0)
                except (TypeError, ValueError):
                    offset, duration = 0.0, 0.0
                if active_id and duration > 0 and offset >= 1 and offset < duration:
                    episode_progress[active_id] = (offset, duration)
        for row in rows:
            li = item(row)
            li.setProperty('initials', row.get('code') or ''.join(p[:1] for p in row.get('name', '').split()[:2]).upper())
            li.setProperty('job', row.get('job', ''))
            if section == 'Episodes':
                li.setProperty('watched', 'true' if row.get('id') in self.watched_episodes else '')
                number = row.get('episode') or row.get('number') or ''
                title = clean(row.get('name') or row.get('title') or 'Episode')
                season = row.get('season', self.season)
                if isinstance(season, int) and isinstance(number, int):
                    episode_code = 'S{:02d}E{:02d}'.format(season, number)
                else:
                    episode_code = 'Ep. {}'.format(number) if number != '' else 'Episode'
                li.setProperty('episode_code', episode_code)
                li.setProperty('episode_title', title)
                li.setProperty('episode_heading', '{} - {}'.format(episode_code, title))
                li.setProperty('episode_runtime', episode_runtime(
                    row.get('runtime') if row.get('runtime') not in (None, '') else row.get('duration')))
                li.setProperty('episode_imdb', episode_rating(row) if ADDON.getSetting('rating_imdb')!='false' and ADDON.getSetting('episode_rating_imdb')!='false' else '')
                from lib.episode_ratings import badges
                ratings=badges(row,ADDON.getSetting)
                for index in range(6):
                    badge=ratings[index] if index<len(ratings) else {}
                    li.setProperty('episode_rating'+str(index),badge.get('value',''))
                    li.setProperty('episode_rating_icon'+str(index),
                        'special://home/addons/script.strem4kodi/resources/skins/Main/media/ratings/'+(('rtfresh' if float(badge['value'].rstrip('%'))>=60 else 'rtrotten') if badge['source']=='tomatoes' else badge['source'])+'.png' if badge else '')
                li.setProperty('episode_date', episode_date(row))
                progress = episode_progress.get(str(row.get('id') or ''))
                if progress and row.get('id') not in self.watched_episodes:
                    offset, duration = progress
                    percent = max(1, min(99, int(round(offset * 100.0 / duration))))
                    li.setProperty('WatchedProgress', str(percent))
                    try:
                        li.getVideoInfoTag().setResumePoint(offset, duration)
                    except Exception:
                        pass
                else:
                    li.setProperty('WatchedProgress', '0')
                li.setLabel('{} - {}'.format(episode_code, title))
                from lib.episode_artwork import thumbnail
                li.setArt({'thumb': thumbnail(row, self.meta.get('background', ''),
                    row.get('id') in self.watched_episodes, ADDON.getSetting('episode_spoilers'))})
            elif section == 'Similar':
                li.setArt({'poster': row.get('poster', ''), 'thumb': row.get('background') or row.get('poster', '')})
            items.append(li)
        self.getControl(self.active_list).addItems(items)
        if section == 'Episodes' and rows:
            target = next((i for i, row in enumerate(rows) if row.get('id') == self.play_target), None)
            if target is None:
                target = next((i for i, row in enumerate(rows) if row.get('id') not in self.watched_episodes), 0)
            self.getControl(self.active_list).selectItem(target)
        self.setProperty('hascards', 'true' if rows else '')
        if section == 'Similar' and rows:
            origin = rows[0].get('recommendation_source')
            if origin:self.report('Recommendations from TMDB' if origin == 'TMDB' else 'Similar titles based on matching genres')
        if not rows:
            self.report('No {} provided for this title.'.format(section.lower()))

    def open_menu(self, mode):
        self.menu_mode = mode
        self.setProperty('menu_kind', mode)
        self.menu_entries = ([r['season'] for r in self.available_seasons] if mode == 'seasons' else
                             (['Episodes'] if self.meta['type'] == 'series' else []) + ['Cast', 'Crew', 'Languages', 'Similar'])
        if not self.menu_entries:
            self.report('No seasons provided for this series.')
            return
        listing = self.getControl(600)
        listing.reset()
        for value in self.menu_entries:
            label = ('Specials' if value == 0 else 'Season ' + str(value)) if mode == 'seasons' else value
            selected = value == (self.season if mode == 'seasons' else self.section)
            li = xbmcgui.ListItem(label)
            li.setProperty('selected', 'âœ“' if selected else '')
            listing.addItem(li)
        self.setProperty('menu', 'true')
        self.setFocusId(600)
        current = self.season if mode == 'seasons' else self.section
        if current in self.menu_entries:
            listing.selectItem(self.menu_entries.index(current))

    def _refresh_episode_cards(self, pos, focus_episode=True):
        saved = api.saved(self.meta)
        from lib.episode_state import watched_ids
        self.watched_episodes = watched_ids(self.meta.get('videos', []), saved)
        self._resume_marker = None
        self.refresh_resume_state()
        self.select_section('Episodes')
        self.getControl(501).selectItem(min(pos, max(0, len(self.cards) - 1)))
        if focus_episode:
            self.setFocusId(501)

    def episode_context_menu(self):
        if self.section != 'Episodes' or self.getFocusId() != 501:
            return False
        pos = self.getControl(501).getSelectedPosition()
        if not 0 <= pos < len(self.cards):
            return False
        episode = self.cards[pos]
        target_id = str(episode.get('id') or '')
        if not target_id:
            return False
        watched = target_id in self.watched_episodes
        from episode_actions import through_is_watched
        prefix_watched = through_is_watched(
            self.meta.get('videos') or [], target_id, self.watched_episodes)
        from lib.media_action_menu import choose
        from context_options import episode_options
        resume = bool(target_id == self.play_target and api.resume_seconds(self.resume_ms))
        options = episode_options(watched, prefix_watched, resume)
        options.append({'action':'artwork','label':'Artwork details','icon':'info'})
        options.append({'action':'credits-timing','label':'Up Next Timing for This Series','icon':'info'})
        selected = choose(PATH, options)
        if selected is None:
            return True
        if selected == 'play':
            resume = self.resume_ms if target_id == self.play_target else 0
            self.choose_source(target_id, resume_ms=resume)
            return True
        if selected == 'manual-source':
            resume = self.resume_ms if target_id == self.play_target else 0
            self.choose_source(target_id, resume_ms=resume, allow_auto=False)
            return True
        if selected == 'artwork':
            from lib.artwork_diagnostics import show
            show(episode, background=self.meta.get('background', ''), watched=watched,
                 mode=ADDON.getSetting('episode_spoilers'), provider=episode.get('_thumbnail_provider', ''))
            return True
        if selected == 'credits-timing':
            from lib.smart_credits import choose_timing
            choose_timing(api.STORE.directory, target_id, self.meta.get('name'))
            return True
        if selected == 'restart':
            self.choose_source(target_id, resume_ms=0)
            return True
        if selected == 'info':
            title = episode.get('name') or episode.get('title') or 'Episode'
            plot = clean(episode.get('description') or episode.get('overview') or 'No episode description is available.')
            themed_dialog().textviewer(title, plot)
            return True
        operation = None
        if selected in ('mark-watched', 'mark-unwatched'):
            operation = lambda: api.mark_episode(self.meta, target_id, selected == 'mark-watched')
        elif selected == 'through-watched':
            operation = lambda: api.mark_episodes_through(self.meta, target_id, True)
        elif selected == 'through-unwatched':
            operation = lambda: api.mark_episodes_through(self.meta, target_id, False)
        if operation is not None:
            result = self.busy('Updating watched episodes', operation)
            if result is not None:
                self._refresh_episode_cards(pos)
        return True

    def refresh_episode_description(self):
        plot = clean(self.meta.get('description'))
        if self.section == 'Episodes' and self.cards:
            position = self.getControl(501).getSelectedPosition()
            if 0 <= position < len(self.cards):
                episode = self.cards[position]
                synopsis = clean(episode.get('description') or episode.get('overview'))
                if synopsis:
                    title = clean(episode.get('title') or episode.get('name'))
                    plot = ('[B][COLOR FFFFFFFF]' + title + '[/COLOR][/B]\n\n' if title else '') + synopsis
        if self.getProperty('plot') != plot:
            self.setProperty('plot', plot)

    def refresh_episode_artwork(self):
        """Apply imported watched history to visible cards without moving focus."""
        if getattr(self, 'section', None) != 'Episodes':
            return
        from lib.episode_artwork import thumbnail
        listing = self.getControl(501)
        for index, row in enumerate(getattr(self, 'cards', [])):
            item = listing.getListItem(index)
            watched = row.get('id') in self.watched_episodes
            item.setProperty('watched', 'true' if watched else '')
            item.setArt({'thumb': thumbnail(row, self.meta.get('background', ''),
                watched, ADDON.getSetting('episode_spoilers'))})
            if watched:
                item.setProperty('WatchedProgress', '0')

    def refresh_resume_state(self):
        if not self.initialized or xbmc.Player().isPlayingVideo():
            return
        saved = api.saved(self.meta)
        state = saved.get('state') or {}
        marker = (saved.get('_mtime'), state.get('video_id'), state.get('timeOffset'),
                  state.get('watched'), ADDON.getSetting('episode_spoilers'))
        if marker == getattr(self, '_resume_marker', None):
            return
        self._resume_marker = marker
        from lib.episode_state import watched_ids
        self.watched_episodes = watched_ids(self.meta.get('videos', []), saved)
        self.refresh_episode_artwork()
        if self.meta.get('type') == 'series':
            next_video, self.resume_ms = api.next_series_episode(
                self.meta.get('videos', []), self.meta['id'], saved)
            if next_video:
                self.play_target = next_video['id']
        else:
            self.resume_ms = state.get('timeOffset') or 0
        self.refresh_primary_action()
        self.prefetch_streams(self.play_target)

    def onFocus(self, control_id):
        if self.initialized:
            self.refresh_resume_state()
            self.streams_focus(control_id)

    def onAction(self, action):
        if isinstance(getattr(xbmcgui, '__name__', None), str):
            from lib.ui_dialogs import dialog as themed_dialog
        else:
            themed_dialog = xbmcgui.Dialog
        self.refresh_resume_state()
        if self.streams_action(action):
            return
        was_preview = bool(self.preview_url)
        self.cancel_trailer()
        aid = action.getId()
        if aid == 117 and self.episode_context_menu():
            return
        if aid in BACK and was_preview:
            return
        if aid in BACK:
            if self.menu_mode:
                target = 22011 if self.menu_mode == 'seasons' else 22001
                self.clearProperty('menu')
                self.menu_mode = None
                self.setFocusId(target)
            else:
                self.close()
        elif aid == 4 and self.getFocusId() in (21001, 21006, 21007):
            self.setFocusId(22001)

    def onClick(self, cid):
        if isinstance(getattr(xbmcgui, '__name__', None), str):
            from lib.ui_dialogs import dialog as themed_dialog
        else:
            themed_dialog = xbmcgui.Dialog
        if self.streams_click(cid):
            return
        self.cancel_trailer()
        if cid == 22001:
            self.open_menu('sections')
        elif cid == 22011:
            self.open_menu('seasons')
        elif cid == 600:
            pos = self.getControl(600).getSelectedPosition()
            if 0 <= pos < len(self.menu_entries):
                if self.menu_mode == 'seasons':
                    self.season = self.menu_entries[pos]
                    self.select_section('Episodes')
                else:
                    self.select_section(self.menu_entries[pos])
                self.setFocusId(self.active_list if self.cards else 22001)
        elif cid == 21001:
            if self.play_target:
                self.choose_source(self.play_target, resume_ms=self.resume_ms,allow_auto=(getattr(self,'_primary_mode',0)==1 or self.getProperty('source_auto')=='true'))
            else:
                self.report('Select an episode when episode metadata is available.')
        elif cid == 21002:
            self.play_trailer()
        elif cid == 21007:
            self.show_more_actions()
        elif cid == 21006:
            if self.play_target:
                self.choose_source(self.play_target, resume_ms=self.resume_ms, allow_auto=False)
            else:self.report('Select an episode when episode metadata is available.')
        elif cid == 21005:
            if not api.STORE.load().get('token'):
                self.report('Connect your Stremio account in Settings first.')
                return
            self.busy('Updating library', lambda: api.toggle_library(self.meta))
            self.refresh_library()
        elif cid in (500, 501, 502, 503):
            pos = self.getControl(cid).getSelectedPosition()
            if not 0 <= pos < len(self.cards):
                return
            row = self.cards[pos]
            if self.section == 'Similar':
                self.details(row)
            elif self.section == 'Episodes':
                self.choose_source(row['id'], resume_ms=self.resume_ms if row['id'] == self.play_target else 0)
            elif self.section in ('Cast', 'Crew'):
                themed_dialog().ok(row['name'], row.get('job', self.section))

