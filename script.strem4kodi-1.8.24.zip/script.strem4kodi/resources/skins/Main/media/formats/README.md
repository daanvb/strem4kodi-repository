Format logos are shown only for Kodi-reported formats, not source claims.

`atmos.png`: unmodified Dolby Atmos Horizontal logo from Dolby Newsroom:
https://news.dolby.com/en-WW/assets/228229/

Other assets reuse the format flags bundled with the Kodi Estuary companion
skin. Original product names and logos belong to their respective owners.
