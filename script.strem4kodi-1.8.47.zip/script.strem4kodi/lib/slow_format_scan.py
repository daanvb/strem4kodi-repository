"""Opt-in, shared five-minute slots for one AIOStreams lookup while browsing."""
import base64
import json
import math
import threading
import time
from pathlib import Path

from account import Store
from lib.credits_sync import request

INTERVAL = 300
BACKOFF = 1800
FILE = '/contents/format-scan-slot.json'


def reserve(token, delay=INTERVAL, transport=request, now=None, extend=False):
    """GitHub SHA compare-and-swap prevents synced clients spending the same slot.

    Failure/conflict stops the scan. Only a timestamp is shared, never providers
    or title identifiers. A consumed slot is not refunded after cancellation.
    """
    now = time.time() if now is None else now
    try:
        if transport(token).get('private') is not True:
            return False
        response = transport(token, FILE)
        deadline, sha = 0, None
        if response is not None:
            if response.get('encoding') != 'base64' or not isinstance(response.get('sha'), str):
                return False
            raw = base64.b64decode(response['content'].encode('ascii').translate(None, b' \t\r\n'), validate=True)
            if len(raw) > 1024:
                return False
            data = json.loads(raw)
            deadline = data.get('next_check')
            if data.get('version') != 1 or type(deadline) not in (float, int) or not math.isfinite(deadline) or deadline < 0:
                return False
            sha = response['sha']
        if not extend and deadline > now:
            return False
        raw = json.dumps(dict(version=1, next_check=max(deadline, now + delay))).encode()
        payload = dict(message='Reserve slow format scan slot', content=base64.b64encode(raw).decode())
        if sha:
            payload['sha'] = sha
        transport(token, FILE, payload)
        return True
    except Exception:
        return False


def aio_provider(providers, kind, target):
    from provider_roles import name
    from sources import supports
    for provider in providers:
        if 'aiostreams' in ''.join(c for c in name(provider).lower() if c.isalnum()) and supports(provider.get('manifest') or {}, kind, target):
            return provider
    return None


class Scanner:
    def __init__(self, profile, addon):
        self.profile, self.addon = profile, addon
        self.store = Store(Path(profile) / 'slow-format-scan')
        self.busy = False
        self.next_tick = time.monotonic() + INTERVAL

    def enabled(self):
        return (self.addon.getSetting('formats_slow_scan') == 'true'
                and self.addon.getSetting('formats_github_enabled') != 'false'
                and bool(self.addon.getSetting('credits_github_token').strip()))

    def tick(self, rows, api, current=lambda: True, playing=lambda: False):
        if self.busy or time.monotonic() < self.next_tick:
            return
        self.next_tick = time.monotonic() + INTERVAL
        if not self.enabled() or not current() or playing():
            return
        self.busy = True
        def work():
            try:
                self.scan(rows, api, current, playing)
            except Exception:
                # Optional discovery must never interrupt the browsing window.
                pass
            finally:
                self.busy = False
        try:
            threading.Thread(target=work, daemon=True).start()
        except RuntimeError:
            self.busy = False

    def scan(self, rows, api, current, playing):
        from lib.available_formats import display_formats
        from lib.catalog_poster import identity
        from lib.format_budget import claim, cooldown, retry_after
        from sources import collect
        now = time.time()
        state = self.store.load()
        if state.get('next_check', 0) > now or retry_after(self.profile, now=now) not in (None, 1):
            return
        attempts = state.get('attempts') or {}
        seen = set()
        for row in rows:
            title = identity(row)
            if not title or title in seen or row.get('_catalogue'):
                continue
            seen.add(title)
            key = ':'.join(title)
            if attempts.get(key, 0) > now or display_formats(row, api):
                continue
            target = title[1] if title[0] == 'movie' else row.get('_focus_video_id')
            # Check that this addon is installed before reserving a shared slot.
            active = api.providers('streams')
            if not aio_provider(active, title[0], target or row.get('id') or ''):
                continue
            token = self.addon.getSetting('credits_github_token').strip()
            if not self.enabled() or not current() or playing() or not reserve(token):
                return
            state['next_check'] = now + INTERVAL
            attempts[key] = now + 86400
            # Retry unknown/failed titles at most daily, with a bounded local queue.
            state['attempts'] = {k:v for k,v in attempts.items() if v > now}
            self.store.save(state)
            meta = dict(row, id=title[1])
            if title[0] == 'series' and not target:
                if not meta.get('videos'):
                    meta.update(api.availability_metadata(meta))
                video, _ = api.next_series_episode(meta.get('videos') or [], meta['id'], api.saved(meta))
                target = video.get('id') if video else None
            provider = aio_provider(active, title[0], target or '')
            if (not target or not provider or not self.enabled() or not current() or playing()
                    or token != self.addon.getSetting('credits_github_token').strip()
                    or display_formats(row, api) or not claim(self.profile, cost=1)):
                return
            timing = []
            try:
                result, _, failed = collect([provider], title[0], target, timing=timing)
            except Exception:
                result, failed = [], True
            if failed or any(t.get('rate_limited') for t in timing):
                cooldown(self.profile)
                reserve(token, delay=BACKOFF, extend=True)
                state['next_check'] = time.time() + BACKOFF
                self.store.save(state)
                return
            if result:
                api.remember_availability(meta, target, result, complete=True)
            return  # Exactly one addon request per slot, never a fan-out.
