"""Portable technical facts. No stream URLs, provider configuration or progress.

Observed formats are retained; disc release facts are a separate fallback, never proof
that a provider offers that release. Episode observations also teach a broader
series overview without changing the selected stream's information.
"""
import json
import math
import re
import sqlite3
import time
from contextlib import closing
from pathlib import Path

MAX_AGE = 30 * 86400
TAGS = ('4K', '1080p', '720p', '480p', '360p', 'Dolby Vision', 'HDR10+',
        'HDR10', 'HDR', 'Atmos', 'TrueHD', 'DTS-HD MA', 'Dolby Digital Plus',
        'DTS', 'Dolby Digital')


# Stable identifiers, not quality scores. Never renumber existing entries.
FORMAT_IDS = {tag: index for index, tag in enumerate(TAGS)}


def retained_tags(values):
    return [tag for tag in TAGS if tag in values]


def source_sets(rows):
    """Anonymous per-source capabilities, with no URLs, names or credentials."""
    from core.stream_ui import stream_card
    found = set()
    for row in rows:
        if not isinstance(row, dict) or row.get('_session_failed'):
            continue
        card = stream_card(row)
        tags = [card.get('quality')] + card.get('video_tags', [])
        tags += [tag.split(' 2.')[0].split(' 5.')[0].split(' 7.')[0]
                 for tag in card.get('audio_tags', [])]
        codes = tuple(sorted({FORMAT_IDS[tag] for tag in tags if tag in FORMAT_IDS}))
        if codes:
            found.add(codes)
    return [list(codes) for codes in sorted(found)]


def unpack(raw, updated, complete):
    value = json.loads(raw)
    result = dict(value) if isinstance(value, dict) else dict(formats=value)
    result.update(updated=updated, complete=bool(complete))
    return result


def pack(row):
    return json.dumps({k: row[k] for k in ('formats', 'sources') if k in row})


def key(kind, identity):
    if isinstance(identity, str) and identity.startswith('imdb:'):
        identity = identity[5:]
    pattern = r'tt\d{1,12}' if kind in ('movie', 'overview') else r'tt\d{1,12}:\d{1,4}:\d{1,5}' if kind == 'series' else r'(?!)'
    return kind + ':' + identity if isinstance(identity, str) and re.fullmatch(pattern, identity) else ''


def clean(data, now=None):
    now = time.time() if now is None else now
    result = {}
    if not isinstance(data, dict):
        return result
    for identity, row in data.items():
        if not isinstance(identity, str) or ':' not in identity or not isinstance(row, dict):
            continue
        kind, target = identity.split(':', 1)
        updated = row.get('updated')
        values = row.get('formats')
        if (key(kind, target) != identity or not isinstance(updated, (int, float))
                or isinstance(updated, bool) or not math.isfinite(updated)
                or not 0 <= updated <= now + 300
                or not isinstance(values, list) or any(v not in TAGS for v in values)
                or not isinstance(row.get('complete'), bool)):
            continue
        result[identity] = dict(formats=retained_tags(values),
                                updated=updated, complete=row['complete'])
        sources = row.get('sources')
        if isinstance(sources, list) and len(sources) <= 4096 and all(
                isinstance(group, list) and len(group) <= len(TAGS) and all(
                    type(code) is int and 0 <= code < len(TAGS) for code in group)
                for group in sources):
            result[identity]['sources'] = [list(v) for v in sorted({tuple(sorted(set(g))) for g in sources if g})]
    return result


def merge(left, right, now=None):
    """Newest movie/episode result wins; series overviews combine known formats."""
    left, right = clean(left, now), clean(right, now)
    result = dict(left)
    for identity, row in right.items():
        old = result.get(identity)
        if old is not None and identity.startswith('overview:'):
            result[identity] = dict(formats=retained_tags(old['formats'] + row['formats']),
                                    updated=max(old['updated'], row['updated']), complete=True)
            continue
        if old is None or (row['updated'], row['complete'], json.dumps(row, sort_keys=True)) > (
                old['updated'], old['complete'], json.dumps(old, sort_keys=True)):
            result[identity] = row
    return clean(result, now)


class Database:
    def __init__(self, profile):
        self.path = Path(profile) / 'cache' / 'formats.sqlite'

    def connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(self.path, timeout=2)
        db.execute('CREATE TABLE IF NOT EXISTS facts (identity TEXT, origin TEXT, formats TEXT, updated REAL, complete INTEGER, PRIMARY KEY(identity,origin))')
        return db

    def snapshot(self, now=None):
        with closing(self.connect()) as db:
            rows = db.execute("SELECT identity,formats,updated,complete FROM facts WHERE origin='sources'").fetchall()
        return clean({k: unpack(v, t, c) for k, v, t, c in rows}, now)

    def merge(self, remote, now=None):
        # Re-read and merge under the write lock: a foreground source lookup can
        # finish while GitHub is being read. Never overwrite that newer result.
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            rows = db.execute("SELECT identity,formats,updated,complete FROM facts WHERE origin='sources'").fetchall()
            local = {k: unpack(v, t, c) for k, v, t, c in rows}
            result = merge(local, remote, now)
            self._write_changes(db, local, result)
        return result

    @staticmethod
    def _write_changes(db, local, result):
        # An unchanged sync should not rewrite every learned title or hold the
        # writer lock while inserting thousands of identical records.
        db.executemany("DELETE FROM facts WHERE identity=? AND origin='sources'",
                       [(k,) for k in local.keys() - result.keys()])
        db.executemany('INSERT OR REPLACE INTO facts VALUES (?,?,?,?,?)',
            [(k, 'sources', pack(v), v['updated'], int(v['complete']))
             for k, v in result.items() if local.get(k) != v])

    def remember(self, kind, identity, values, complete=True, now=None, sources=None):
        now = time.time() if now is None else now
        identity = key(kind, identity)
        if not identity:
            return
        # Partial provider replies stay local to the short-lived availability
        # cache. Sharing them could replace a complete result on another device.
        if not complete:
            return
        if sources is not None:
            values = retained_tags(list(values) + [TAGS[code] for group in sources for code in group])
        observations = {identity: dict(formats=values, updated=now, complete=True)}
        if sources is not None:
            observations[identity]['sources'] = sources
        if kind == 'series':
            # An episode can refresh/downgrade independently; the overview keeps
            # formats known to exist somewhere in the series across devices.
            observations[key('overview', identity.split(':')[1])] = dict(formats=values, updated=now, complete=True)
        # Foreground discoveries touch at most the exact title/episode and its
        # series overview, independently of the total catalogue size.
        with closing(self.connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            slots = ','.join('?' for _ in observations)
            rows = db.execute("SELECT identity,formats,updated,complete FROM facts WHERE origin='sources' AND identity IN (" + slots + ")",
                              tuple(observations)).fetchall()
            local = {k: unpack(v, t, c) for k, v, t, c in rows}
            self._write_changes(db, local, merge(local, observations, now))

    def get(self, kind, identity, now=None):
        now = time.time() if now is None else now
        identity = key(kind, identity)
        if not identity:
            return None
        try:
            with closing(self.connect()) as db:
                rows = db.execute('SELECT origin,formats,updated,complete FROM facts WHERE identity=?', (identity,)).fetchall()
            source = next((r for r in rows if r[0] == 'sources'), None)
            row = source or next((r for r in rows if r[0] == 'disc'), None)
            if row:
                from lib.available_formats import merge_formats
                return dict(formats=merge_formats(unpack(row[1], row[2], row[3])['formats']), origin=row[0], updated=row[2],
                            complete=bool(row[3]), stale=row[0] != 'sources' or now - row[2] > 3600)
        except (sqlite3.Error, OSError, ValueError, TypeError):
            pass
        return None

    def series_formats(self, identity, now=None):
        """Series seed and observed formats; never an exact-stream claim."""
        canonical = key('overview', identity)
        if not canonical:
            return None
        identity = canonical.split(':', 1)[1]
        now = time.time() if now is None else now
        from lib.series_catalogue import formats as catalogue_formats
        seed = catalogue_formats(identity)
        try:
            with closing(self.connect()) as db:
                prefix = 'series:' + identity + ':'
                rows = db.execute("SELECT formats,updated FROM facts WHERE origin='sources' AND identity>=? AND identity<? "
                                  "UNION ALL SELECT formats,updated FROM facts WHERE origin='sources' AND identity=?",
                                  (prefix, prefix + '\uffff', canonical)).fetchall()
            from lib.available_formats import merge_formats
            found = merge_formats(seed, *(unpack(row[0], row[1], True)['formats'] for row in rows))
            if found:
                return dict(formats=found, origin='series', updated=max((row[1] for row in rows), default=0),
                            complete=False, stale=True)
        except (sqlite3.Error, OSError, ValueError, TypeError):
            pass
        return None

    def import_releases(self, releases, now=None):
        """Use explicit disc fields, not FEL membership or title-name guesses."""
        from lib.available_formats import catalogue_formats, merge_formats
        now = time.time() if now is None else now
        result = {}
        for row in releases:
            if not isinstance(row, dict) or row.get('media_type') != 'movie':
                continue
            identity = key('movie', row.get('imdb_id'))
            hdr, audio = row.get('hdr_formats'), row.get('audio_formats')
            if not identity or not isinstance(hdr, list) or not isinstance(audio, list):
                continue
            # This feed describes UHD discs. Require an explicit 4K disc link
            # before adding resolution, and explicit fields for HDR and audio.
            quality = '4K' if '-4K-Blu-ray/' in str(row.get('bluray_url', '')) else ''
            found = catalogue_formats(dict(quality=quality, videoFormats=hdr, audioFormats=audio))
            if found:
                result[identity] = merge_formats(result.get(identity, []), found)
        if not result:
            return 0  # A failed/empty update must not erase the offline database.
        with closing(self.connect()) as db, db:
            db.execute("DELETE FROM facts WHERE origin='disc'")
            db.executemany('INSERT INTO facts VALUES (?,?,?,?,?)',
                [(k, 'disc', json.dumps(v), now, 1) for k, v in result.items()])
        self.path.with_suffix('.disc-ready').write_bytes(b'1')
        return len(result)

    def migrate(self, profile):
        """Import retained pre-database observations once, without querying providers."""
        marker = self.path.with_suffix('.migrated')
        if marker.exists():
            return
        old = Path(profile) / 'cache' / 'availability.sqlite'
        if old.exists():
            with closing(sqlite3.connect(old, timeout=2)) as db:
                rows = db.execute('SELECT kind,target,formats,updated FROM badges ORDER BY updated').fetchall()
            candidates = {}
            for kind, target, raw, updated in rows:
                try:
                    payload = json.loads(raw)
                except (TypeError, ValueError):
                    continue
                values = payload.get('formats', []) if isinstance(payload, dict) else payload
                complete = payload.get('complete', True) if isinstance(payload, dict) else True
                identity = key(kind, target)
                if identity and complete:
                    candidates[identity] = dict(formats=values, updated=updated, complete=True)
            self.merge(candidates)
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_bytes(b'1')
