"""Independent per-addon queues for badge-only background source requests."""
import hashlib
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from sources import collect, supports
from lib.available_formats import formats, merge_formats


class Requests:
    def __init__(self, workers=4, wait=0.1, collector=collect):
        self.workers, self.wait, self.collector = workers, wait, collector
        self.lock = threading.RLock()
        self.pools = {}
        self.requests = OrderedDict()

    def request(self, key, providers, kind, target, changed, subscriber=None):
        selected, seen = [], set()
        for provider in providers:
            url = provider.get('transportUrl')
            if url and url not in seen and supports(provider.get('manifest') or {},kind,target):
                selected.append(provider)
                seen.add(url)
        signature = tuple(hashlib.sha256(p['transportUrl'].encode()).hexdigest() for p in selected)
        request_key = (key,kind,target,signature)
        with self.lock:
            existing = self.requests.get(request_key)
            if existing and (not existing['done'] or time.monotonic()-existing['finished'] < 120):
                state = existing
                self.requests.move_to_end(request_key)
            else:
                state = {'event':threading.Event(),'groups':{},'remaining':len(selected),
                         'complete':not selected,'done':not selected,'failed':False,
                         'finished':time.monotonic() if not selected else 0,
                         'formats':[],'callbacks':{subscriber:changed},'lock':threading.RLock()}
                if not selected:state['event'].set()
                self.requests[request_key] = state
                for index, provider in enumerate(selected):
                    pool_key = (key,signature[index])
                    pool = self.pools.get(pool_key)
                    if pool is None:
                        pool = ThreadPoolExecutor(max_workers=self.workers,thread_name_prefix='format-addon')
                        self.pools[pool_key] = pool
                    pool.submit(self._one,state,index,provider,kind,target)
                # Retain only compact format summaries, never playback URLs.
                for old_key, old in list(self.requests.items()):
                    if len(self.requests) <= 512:break
                    if old['done']:self.requests.pop(old_key,None)
        with state['lock']:
            state['callbacks'][subscriber] = changed
        state['event'].wait(self.wait)
        with state['lock']:
            # Reapply a shared result to the caller's current episode/cache scope.
            try:changed(list(state['formats']),state['complete'])
            except Exception:pass
            return {'formats':list(state['formats']),'complete':state['complete'],'done':state['done']}

    def _one(self, state, index, provider, kind, target):
        try:
            rows, _, failed = self.collector([provider],kind,target)
            found = formats(rows)
        except Exception:
            found, failed = [], True
        with state['lock']:
            state['groups'][index] = found
            state['remaining'] -= 1
            state['done'] = state['remaining'] == 0
            state['failed'] = state['failed'] or bool(failed)
            state['complete'] = state['done'] and not state['failed']
            state['formats'] = merge_formats(*(state['groups'][i] for i in sorted(state['groups'])))
            if state['done']:state['finished'] = time.monotonic()
            for changed in state['callbacks'].values():
                try:changed(list(state['formats']),state['complete'])
                except Exception:pass
            if state['formats'] or state['done']:state['event'].set()

    def close(self):
        with self.lock:
            for pool in self.pools.values():pool.shutdown(wait=True)


_requests = Requests()
