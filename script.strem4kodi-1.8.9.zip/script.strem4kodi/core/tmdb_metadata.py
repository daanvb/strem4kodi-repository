"""Exact-title TMDB credits and recommendations, using the viewer's API key."""
import re
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor
from protocol import fetch


def request(key, path, fetcher=fetch, **params):
    return fetcher('https://api.themoviedb.org/3/' + path + '?' +
                   urlencode(dict(api_key=key, language='en-US', **params)))


def identity(meta, key, fetcher=fetch):
    kind = {'series': 'tv', 'movie': 'movie'}.get(meta.get('type'))
    if not kind or not key:
        return None
    imdb = str(meta.get('imdb_id') or meta.get('id') or '').split(':')[0]
    # IMDb lookup avoids confusing TMDB season/episode IDs with series IDs.
    if re.fullmatch(r'tt\d+', imdb):
        matches = request(key, 'find/' + imdb, fetcher,
                          external_source='imdb_id').get(kind + '_results', [])
        if len(matches) == 1:
            return kind, str(matches[0]['id'])
        return None
    value = str(meta.get('moviedb_id') or '')
    if re.fullmatch(r'[1-9]\d*', value):
        return kind, value
    return None


def photo(path):
    return 'https://image.tmdb.org/t/p/w342' + path if isinstance(path, str) and re.fullmatch(r'/[\w./-]+', path) else ''


def season_ratings(meta, season, key, fetcher=fetch):
    resolved=identity(meta,key,fetcher)
    if not resolved or resolved[0]!='tv':return []
    payload=request(key,'tv/'+resolved[1]+'/season/'+str(int(season)),fetcher)
    return [{'episode':e['episode_number'],'tmdbRating':e['vote_average']} for e in payload.get('episodes',[])
            if isinstance(e,dict) and type(e.get('episode_number')) is int and
            isinstance(e.get('vote_count'),int) and e['vote_count']>0 and isinstance(e.get('vote_average'),(int,float))]


def certificate_gb(meta, key, fetcher=fetch):
    """Use actual GB classifications, preferring home releases over cinema cuts."""
    resolved = identity(meta, key, fetcher)
    if not resolved:return ''
    kind, tid = resolved
    endpoint = '/release_dates' if kind == 'movie' else '/content_ratings'
    payload = request(key, kind + '/' + tid + endpoint, fetcher)
    allowed = {'U', 'PG', '12', '12A', '15', '18', 'R18'}
    for country in payload.get('results', []):
        if not isinstance(country, dict) or country.get('iso_3166_1') != 'GB':continue
        if kind == 'tv':
            value = str(country.get('rating') or '').upper().strip()
            return value if value in allowed else ''
        rows = [r for r in country.get('release_dates', []) if isinstance(r, dict)]
        priority = {4: 0, 5: 1, 6: 2, 3: 3, 2: 4, 1: 5}
        for row in sorted(rows, key=lambda r: priority.get(r.get('type'), 6)):
            value = str(row.get('certification') or '').upper().strip()
            if value in allowed:return value
    return ''


def credits(meta, key, role='cast', fetcher=fetch):
    resolved = identity(meta, key, fetcher)
    if not resolved:
        return []
    kind, tid = resolved
    payload = request(key, kind + '/' + tid + ('/aggregate_credits' if kind == 'tv' else '/credits'), fetcher)
    rows = []
    for entry in payload.get('crew' if role == 'crew' else 'cast', []):
        if not isinstance(entry, dict) or not entry.get('name'):
            continue
        jobs = entry.get('jobs' if role == 'crew' else 'roles') or []
        job = ' / '.join(dict.fromkeys(str(j.get('job' if role == 'crew' else 'character') or '') for j in jobs if isinstance(j, dict)))
        job = job or entry.get('job' if role == 'crew' else 'character') or ('Crew' if role == 'crew' else 'Cast')
        if role == 'cast' and job != 'Cast':
            job = 'as ' + job
        rows.append({'name': entry['name'], 'job': job, 'poster': photo(entry.get('profile_path'))})
    return rows[:80]


def recommendations(meta, key, limit=24, fetcher=fetch):
    resolved = identity(meta, key, fetcher)
    if not resolved:
        return []
    kind, tid = resolved
    candidates = request(key, kind + '/' + tid + '/recommendations', fetcher).get('results', [])
    def convert(row):
        try:
            if not isinstance(row, dict) or row.get('adult') or not str(row.get('id', '')).isdigit():
                return None
            imdb = request(key, kind + '/' + str(row['id']) + '/external_ids', fetcher).get('imdb_id')
            if not re.fullmatch(r'tt\d+', str(imdb or '')):
                return None
            return {'id': imdb, 'imdb_id': imdb, 'moviedb_id': row['id'], 'type': meta['type'],
                    'name': row.get('title') or row.get('name') or '',
                    'description': row.get('overview') or '',
                    'poster': photo(row.get('poster_path')),
                    'background': 'https://image.tmdb.org/t/p/w780' + row['backdrop_path'] if row.get('backdrop_path') else '',
                    'recommendation_source': 'TMDB'}
        except Exception:
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        return [r for r in pool.map(convert, candidates[:limit]) if r and r['id'] != meta.get('id')][:limit]
