"""Search with native Kodi edit input, phone paste and debounced suggestions."""
import threading
import time
import xbmc
import xbmcgui
from lib.ui_dialogs import InputWindow, BACK
from lib.theme import window as themed_window
from lib.search_history import recent, remember, clear
from lib.title_suggestions import entries
from pathlib import Path


class SearchWindow(InputWindow):
    def __init__(self, *args, **kwargs):
        self.profile = kwargs.pop('profile')
        self.searcher = kwargs.pop('searcher')
        self.closed = False
        self.query_generation = 0
        self.matches = []
        self.last_query = None
        self.recent_queries = recent(self.profile)
        self.suggestion_rows = []
        self.cache = {}
        self.inflight = set()
        self.mailbox = []
        self.lock = threading.Lock()
        super().__init__(*args, title='Search movies and series', **kwargs)

    def _display(self):
        self.getControl(301).setText(self.value)

    def onInit(self):
        self.setProperty('dialog_title', self.title)
        self._display(); self._render(); self.render_suggestions('')
        self.setFocusId(600)
        threading.Thread(target=self.watch, daemon=True).start()

    def render_suggestions(self, query, matches=()):
        self.suggestion_rows = entries(query, self.recent_queries, matches)
        self.setProperty('suggestion_heading', 'Movies and series' if query.strip() else 'Recent searches')
        self.setProperty('suggestion_empty', '' if self.suggestion_rows else ('Type at least two letters to find a title.' if len(query.strip())<2 else 'Keep typing, or select Search to see all results.'))
        listing = self.getControl(601);listing.reset()
        items=[]
        for row in self.suggestion_rows:
            item=xbmcgui.ListItem(label=row['name'])
            item.setProperty('subtitle',row['subtitle']);item.setProperty('kind',row['kind'])
            item.setArt({'thumb':row['poster']});items.append(item)
        listing.addItems(items)

    def watch(self):
        pending = None
        changed = 0
        monitor = xbmc.Monitor()
        while not self.closed and not monitor.abortRequested():
            try:
                query = self.getControl(301).getText().strip()[:200]
                if query != self.last_query:
                    self.value = query;self.last_query = query
                    self.query_generation += 1;pending = query;changed = time.monotonic()
                    self.render_suggestions(query, self.cache.get(query.casefold(), []))
                self.accept_results()
                if pending is not None and time.monotonic() - changed >= .25:
                    term = pending
                    if len(term) < 2 or term.casefold() in self.cache:pending=None
                    elif self.queue_fetch(term,self.query_generation):pending=None
            except Exception:
                pass
            xbmc.sleep(50)

    def queue_fetch(self, term, generation):
        with self.lock:
            if self.closed or len(self.inflight)>=2:return False
            token=(term,generation);self.inflight.add(token)
        try:threading.Thread(target=self.fetch_suggestions,args=(term,generation),daemon=True).start()
        except RuntimeError:
            with self.lock:self.inflight.discard(token)
            return False
        return True

    def fetch_suggestions(self, term, generation):
        try:rows=self.searcher(term) or []
        except Exception:rows=[]
        with self.lock:
            self.inflight.discard((term,generation))
            if not self.closed:self.mailbox.append((term,generation,rows))

    def accept_results(self):
        with self.lock:ready,self.mailbox=self.mailbox,[]
        for term,generation,rows in ready:
            if self.closed:return
            if len(self.cache)>=32:self.cache.pop(next(iter(self.cache)))
            self.cache[term.casefold()]=rows
            if generation==self.query_generation and term==self.last_query:self.render_suggestions(term,rows)

    def onClick(self, cid):
        if cid == 302:
            keyboard = xbmc.Keyboard(self.getControl(301).getText(), 'Search movies and series')
            keyboard.doModal()
            if keyboard.isConfirmed():self.value = keyboard.getText()[:200];self._display()
            self.setFocusId(301)
        elif cid == 601:
            pos = self.getControl(601).getSelectedPosition()
            if 0 <= pos < len(self.suggestion_rows):self.finish(self.suggestion_rows[pos]['query'])
        elif cid == 303:
            clear(self.profile);self.recent_queries=[];self.render_suggestions(self.value)
        elif cid == 204:
            self.finish(self.getControl(301).getText())
        elif cid == 301:
            self.value = self.getControl(301).getText()
        else:
            self.value = self.getControl(301).getText()
            super().onClick(cid)

    def finish(self, query):
        self.result = str(query).strip()[:200]
        if self.result:
            try:remember(self.profile, self.result)
            except OSError:pass
        self.close()

    def close(self):
        self.closed = True;self.query_generation += 1
        super().close()


def show(profile, searcher, native=False):
    root = str(Path(__file__).resolve().parents[1])
    default = ''
    if native:
        keyboard = xbmc.Keyboard('', 'Search movies and series')
        keyboard.doModal()
        if not keyboard.isConfirmed():return ''
        default = keyboard.getText()
    window = themed_window(SearchWindow, 'script-strem4kodi-search.xml', root, 'Main', '1080i', profile=profile, searcher=searcher, default=default)
    window.doModal()
    return window.result
