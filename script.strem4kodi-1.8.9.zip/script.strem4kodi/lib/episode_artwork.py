"""Spoiler-safe episode artwork using Kodi's local texture resizing."""
from urllib.parse import quote, unquote


def thumbnail(row, background, watched, mode='0'):
    supplied = row.get('thumbnail') or ''
    artwork = supplied or background or ''
    # Off leaves existing provider blur untouched; it cannot reconstruct artwork.
    blur = not watched and (mode == '1' or (mode == '2' and not supplied))
    if not artwork or not blur:
        return artwork
    if artwork.startswith('image://'):
        artwork = unquote(artwork[len('image://'):].split('/', 1)[0])
    # A tiny locally cached texture is smoothly enlarged by Kodi. No image proxy,
    # Python image library, network analyser or full-resolution copy is required.
    return 'image://' + quote(artwork, safe='') + '/?width=8&height=5&scaling_algorithm=bilinear'
