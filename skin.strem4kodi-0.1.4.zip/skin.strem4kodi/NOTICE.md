Strem4Kodi Player by daanvb.

Based on Kodi Estuary from xbmc/xbmc Omega, commit
f8815ee40f49a700c047982d752be4b2a61420e2.
Original Estuary authors: phil65 and Team Kodi (see LICENSE.txt).
Estuary code: GPL version 2; artwork: CC BY-SA 4.0.
Strem4Kodi modifications retain those licenses. Font licenses are in fonts/.
Modified files: addon.xml, VideoOSD.xml, VideoOSDBookmarks.xml, DialogSeekBar.xml,
Custom_1109_TopBarOverlay.xml, Includes.xml, Font.xml, colors/defaults.xml and resources branding.
New files: Includes_Strem4KodiPlayer.xml and media/strem4kodi/.
This is an independent companion skin, not an official Kodi product.

Inter font by the Inter Project Authors, SIL Open Font License 1.1; see fonts/Inter-OFL.txt.
