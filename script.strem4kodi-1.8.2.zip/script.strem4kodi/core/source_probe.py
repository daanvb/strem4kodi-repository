"""Recognise provider error slates before treating them as playable titles."""
import json
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError


def error_video(url):
    try:
        parsed = urlsplit(str(url))
        return parsed.hostname == 'slate.elfhosted.com'
    except ValueError:return False


def unavailable(url, opener=urlopen):
    if error_video(url):return 'provider-error-video'
    try:
        # Small bounded GET follows the same redirects as playback. HEAD may lie
        # or be unsupported; file size / short duration alone never imply failure.
        response = opener(Request(url, headers={'Range':'bytes=0-4095'}), timeout=8)
        try:
            if error_video(response.geturl()):return 'provider-error-video'
            kind = response.headers.get('Content-Type', '').split(';')[0].lower()
            if kind == 'application/json':
                try:payload = json.loads(response.read(4096))
                except (ValueError, UnicodeError):return ''
                if isinstance(payload, dict) and (payload.get('error') or payload.get('errorCode')):
                    return 'provider-error-response'
        finally:response.close()
    except HTTPError as error:
        code = error.code
        error.close()
        if code not in (405, 416):return 'http-unavailable'
    except Exception:
        # Unknown transport / range failures are left to Kodi, not guessed.
        pass
    return ''
