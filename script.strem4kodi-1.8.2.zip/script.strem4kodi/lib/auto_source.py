"""Per-device, per-content source selection; never bypass the quality ceiling."""
from lib.source_preferences import preferences, rank_rows, limit_quality
from lib.stream_presenter import stream_traits, presentation, filter_rows
import re

PROFILES = ('movie', 'series', 'animation')
FIELDS = {'quality': ('Any', '4K', '1080p', '720p'),
          'dynamic': ('Any', 'Dolby Vision', 'HDR10', 'FEL reported'),
          'audio': ('Any', 'Atmos', 'TrueHD', 'Dolby Digital Plus', 'AAC'),
          'sort': ('recommended', 'provider', 'smallest', 'largest')}


def profile(meta):
    genres = meta.get('genres') or []
    if isinstance(genres, str):genres = [genres]
    if any(str(g).casefold() == 'animation' for g in genres):return 'animation'
    return 'series' if meta.get('type') == 'series' else 'movie'


def configured(addon, meta):
    scope = profile(meta)
    prefs = preferences(addon)
    for field, values in FIELDS.items():
        try:index = int(addon.getSetting('auto_' + scope + '_' + field) or '0') - 1
        except (ValueError, TypeError):index = -1
        if 0 <= index < len(values):prefs[field] = values[index]
    for field in ('provider', 'language'):
        value = addon.getSetting('auto_' + scope + '_' + field)
        if value and value != '__inherit__':prefs[field] = '' if value == '__any__' else value
    try:mode = int(addon.getSetting('auto_' + scope + '_mode') or '0')
    except (ValueError, TypeError):mode = 0
    return mode if mode in (0, 1, 2) else 0, prefs


def matches(row, prefs):
    traits = stream_traits(row)
    if prefs.get('provider') and traits['provider'].casefold() != prefs['provider'].casefold():return False
    if prefs.get('quality') not in (None, 'Any') and traits['quality'] != prefs['quality']:return False
    if prefs.get('dynamic') not in (None, 'Any') and prefs['dynamic'] not in traits['dynamic']:return False
    audio = presentation(row)['audio']
    if prefs.get('audio') not in (None, 'Any') and prefs['audio'].casefold() not in audio.casefold():return False
    language = prefs.get('language', '').casefold()
    if language and language != 'any':
        aliases = {'english', 'eng', 'en'} if language in ('english', 'eng', 'en') else {language}
        if not aliases & set(re.findall(r'[a-z]+', audio.partition(' | Language: ')[2].casefold())):return False
    return True


def select(rows, addon, meta, filters=('All', 'All', 'All')):
    mode, prefs = configured(addon, meta)
    if mode == 0:return mode, None, False
    eligible = [r for r in filter_rows(limit_quality(rows, prefs['maximum']), *filters)
                if r.get('url') and not r.get('_session_failed')]
    ranked = rank_rows(eligible, prefs)
    exact = [r for r in ranked if matches(r, prefs)]
    closest = rank_rows(ranked, dict(prefs, sort='recommended'))
    return mode, (exact or closest or [None])[0], bool(ranked and not exact)
