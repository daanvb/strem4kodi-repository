"""Clean, consistent poster cards with a quiet frame and clear remote focus."""
import xml.etree.ElementTree as ET

BASE = 'special://home/addons/script.strem4kodi/resources/skins/Main/media/cinematic/'


def control(parent, kind, **values):
    node = ET.SubElement(parent, 'control', type=kind)
    for key, value in values.items():ET.SubElement(node, key).text = str(value)
    return node


def posters(listing):
    for tag in ('itemlayout', 'focusedlayout'):
        layout = listing.find(tag)
        if layout is None:continue
        for child in list(layout):layout.remove(child)
        focused = tag == 'focusedlayout'
        control(layout, 'image', left=12, top=12, width=206, height=309,
                texture=BASE+'poster-mask.png', colordiffuse='FF181B20')
        for art, visible in (('poster','!String.IsEmpty(ListItem.Art(poster))'),
                             ('thumb','String.IsEmpty(ListItem.Art(poster))')):
            image = control(layout, 'image', left=12, top=12, width=206, height=309,
                    texture='$INFO[ListItem.Art(%s)]' % art, aspectratio='scale', visible=visible)
            image.find('texture').set('diffuse', BASE+'poster-mask.png')
        control(layout, 'image', left=12, top=12, width=206, height=309,
                texture=BASE+('poster-focus.png' if focused else 'poster-outline.png'))
        control(layout, 'progress', left=19, top=310, width=192, height=4,
                info='ListItem.Property(WatchedProgress)',
                visible='!String.IsEmpty(ListItem.Property(WatchedProgress))',
                texturebg=BASE+'solid.png', lefttexture='', righttexture='',
                midtexture=BASE+'solid.png', colordiffuse='FF6EC3FF')
        control(layout, 'label', left=16, top=333, width=198, height=32,
                label='$INFO[ListItem.Label]', font='font23_title' if focused else 'font23',
                textcolor='FFFFFFFF' if focused else 'FFBFC4CE', scroll='true' if focused else 'false')
        control(layout, 'label', left=16, top=366, width=198, height=24,
                label='$INFO[ListItem.Property(UnwatchedEpisodes),, episodes left]',
                font='font20', textcolor='FF929AA6')
