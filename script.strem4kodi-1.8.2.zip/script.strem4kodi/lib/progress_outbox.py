"""Durable account-bound progress updates with retry and pre-write snapshots."""
from datetime import datetime, timezone
import hashlib
import threading
import time
import uuid
from account import Store

_lock=threading.RLock()
_worker=None
_next=0

def owner(token):return hashlib.sha256(str(token).encode()).hexdigest()

def enqueue(store,pending):
    token=store.load().get('token')
    if not token:return False
    queue=Store(store.directory/'progress-outbox')
    with _lock:
        data=queue.load();rows=data.get('rows') or []
        row=dict(pending,owner=owner(token),captured_at=datetime.now(timezone.utc).isoformat(timespec='milliseconds'),event_id=uuid.uuid4().hex)
        prior=next((r for r in reversed(rows) if row.get('session') and r.get('owner')==row['owner'] and r.get('session')==row.get('session') and not r.get('prepared') and not r.get('in_flight')),None)
        if prior:
            row['watched_ms']+=prior.get('watched_ms',0)
            rows.remove(prior)
        rows.append(row);queue.save({'rows':rows})
    return True

def process_one(store,syncer=None):
    from core.playback_progress import sync_progress
    syncer=syncer or sync_progress
    token=store.load().get('token')
    if not token:return False
    queue=Store(store.directory/'progress-outbox')
    with _lock:
        rows=queue.load().get('rows') or []
        pending=next((r for r in rows if r.get('owner')==owner(token)),None)
        if pending is None:return False
        pending['in_flight']=True
        queue.save({'rows':rows})
        pending=dict(pending)
    def prepare(item):
        with _lock:
            rows=queue.load().get('rows') or []
            for r in rows:
                if r['event_id']==pending['event_id']:r['prepared']=item
            queue.save({'rows':rows})
    remote=syncer(store,pending['context'],pending['position_ms'],pending['duration_ms'],pending['watched_ms'],
        ended=pending['ended'],checkpoint=pending.get('checkpoint',False),captured_at=pending['captured_at'],
        prepared_item=pending.get('prepared'),prepare_func=prepare)
    if remote is None:return False
    with _lock:
        rows=queue.load().get('rows') or []
        queue.save({'rows':[r for r in rows if r['event_id']!=pending['event_id']]})
    Store(store.directory/'sync-status').save({'updated':time.time()})
    from lib.playback_refresh import refresh_continue_index
    from lib.progress_signal import publish
    refresh_continue_index(store,pending['context'],remote)
    publish(pending['context'])
    return True

def summary(profile,token):
    if not token:return 'Connect Stremio first'
    try:
        rows=Store(profile/'progress-outbox').load().get('rows') or []
        count=sum(r.get('owner')==owner(token) for r in rows)
        if count:return '{} updates pending'.format(count)
        stamp=Store(profile/'sync-status').load().get('updated')
        return 'Synced '+time.strftime('%H:%M',time.localtime(stamp)) if stamp else 'Ready'
    except Exception:return 'Sync status unavailable'

def tick(store):
    global _worker,_next
    if time.monotonic()<_next:return
    with _lock:
        if _worker is not None and _worker.is_alive():return
        _next=time.monotonic()+5
        def run():
            global _next
            try:
                while process_one(store):pass
            except Exception:_next=time.monotonic()+60
        _worker=threading.Thread(target=run,daemon=True);_worker.start()

def retry_now():
    global _next
    _next=0
