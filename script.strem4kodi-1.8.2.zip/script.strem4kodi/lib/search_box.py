"""Search with native Kodi edit input, phone paste and debounced suggestions."""
import threading
import time
import xbmc
import xbmcgui
from lib.ui_dialogs import InputWindow, BACK
from lib.theme import window as themed_window
from lib.search_history import recent, remember, clear, suggestions
from pathlib import Path


class SearchWindow(InputWindow):
    def __init__(self, *args, **kwargs):
        self.profile = kwargs.pop('profile')
        self.searcher = kwargs.pop('searcher')
        self.closed = False
        self.query_generation = 0
        self.matches = []
        self.last_query = None
        self.recent_queries = recent(self.profile)
        self.suggestion_rows = []
        self.cache = {}
        self.loading = False
        super().__init__(*args, title='Search movies and series', **kwargs)

    def _display(self):
        self.getControl(301).setText(self.value)

    def onInit(self):
        self.setProperty('dialog_title', self.title)
        self._display(); self._render(); self.render_suggestions('')
        self.setFocusId(600)
        threading.Thread(target=self.watch, daemon=True).start()

    def render_suggestions(self, query, matches=()):
        self.suggestion_rows = suggestions(query, self.recent_queries, matches)
        self.setProperty('suggestion_heading', 'Suggestions' if query.strip() else 'Recent searches')
        listing = self.getControl(601);listing.reset()
        listing.addItems([xbmcgui.ListItem(label=s) for s in self.suggestion_rows])

    def watch(self):
        pending = None
        changed = 0
        while not self.closed and not xbmc.Monitor().abortRequested():
            try:
                query = self.getControl(301).getText().strip()[:200]
                if query != self.last_query:
                    self.value = query;self.last_query = query
                    self.query_generation += 1;pending = query;changed = time.monotonic()
                    self.render_suggestions(query, self.cache.get(query.casefold(), []))
                if pending is not None and not self.loading and time.monotonic() - changed >= 0.6:
                    term = pending;pending = None
                    if len(term) >= 2 and term.casefold() not in self.cache:
                        generation = self.query_generation
                        self.loading = True
                        threading.Thread(target=self.fetch_suggestions, args=(term,generation), daemon=True).start()
            except Exception:
                pass
            xbmc.sleep(100)

    def fetch_suggestions(self, term, generation):
        try:
            rows = self.searcher(term) or []
            if self.closed or generation != self.query_generation:
                return
            if len(self.cache) >= 16:self.cache.clear()
            self.cache[term.casefold()] = rows
            self.render_suggestions(term, rows)
        except Exception:
            pass
        finally:
            self.loading = False

    def onClick(self, cid):
        if cid == 302:
            keyboard = xbmc.Keyboard(self.getControl(301).getText(), 'Search — phone keyboard / paste')
            keyboard.doModal()
            if keyboard.isConfirmed():self.value = keyboard.getText()[:200];self._display()
            self.setFocusId(600)
        elif cid == 601:
            pos = self.getControl(601).getSelectedPosition()
            if 0 <= pos < len(self.suggestion_rows):self.finish(self.suggestion_rows[pos])
        elif cid == 303:
            clear(self.profile);self.recent_queries=[];self.render_suggestions(self.value)
        elif cid == 204:
            self.finish(self.getControl(301).getText())
        elif cid == 301:
            self.value = self.getControl(301).getText()
        else:
            self.value = self.getControl(301).getText()
            super().onClick(cid)

    def finish(self, query):
        self.result = str(query).strip()[:200]
        if self.result:
            try:remember(self.profile, self.result)
            except OSError:pass
        self.close()

    def close(self):
        self.closed = True;self.query_generation += 1
        super().close()


def show(profile, searcher, native=False):
    root = str(Path(__file__).resolve().parents[1])
    default = ''
    if native:
        keyboard = xbmc.Keyboard('', 'Search movies and series')
        keyboard.doModal()
        if not keyboard.isConfirmed():return ''
        default = keyboard.getText()
    window = themed_window(SearchWindow, 'script-strem4kodi-search.xml', root, 'Main', '1080i', profile=profile, searcher=searcher, default=default)
    window.doModal()
    return window.result
