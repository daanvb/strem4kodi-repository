"""Local recent searches; no account credentials or remote upload."""
import json
from pathlib import Path
from setup_profile import atomic_write


def recent(profile):
    try:
        rows = json.loads((Path(profile) / 'search-history.json').read_text(encoding='utf-8'))
        return [s for s in rows if isinstance(s, str) and s.strip()][:20] if isinstance(rows, list) else []
    except Exception:
        return []


def remember(profile, query):
    value = str(query or '').strip()[:200]
    rows = [r for r in recent(profile) if r.casefold() != value.casefold()]
    if value:
        rows.insert(0, value)
    atomic_write(Path(profile) / 'search-history.json', json.dumps(rows[:20], ensure_ascii=False).encode('utf-8'))


def clear(profile):
    atomic_write(Path(profile) / 'search-history.json', b'[]')


def suggestions(query, history, matches=()):
    key = str(query or '').strip().casefold()
    rows = [r for r in history if not key or key in r.casefold()]
    rows += [str(r.get('name') or '') for r in matches if isinstance(r, dict) and r.get('name')]
    output, seen = [], set()
    for value in rows:
        if value.casefold() not in seen:
            output.append(value);seen.add(value.casefold())
    return output[:8]
