"""Share neutral format observations using the existing private GitHub token."""
import base64
import json
import threading
import time
from pathlib import Path
from account import Store
from lib.credits_sync import request, SyncError
from lib.format_database import Database, clean, merge

FILE = '/contents/formats.json'
# Keep below the GitHub Contents API inline-file boundary; never prune to fit.
MAX_BYTES = 800 * 1024


def decode(response):
    if response is None:
        return {}, None
    try:
        if response.get('encoding') != 'base64' or not isinstance(response.get('sha'), str):
            raise ValueError()
        raw = base64.b64decode(response['content'], validate=True)
        data = json.loads(raw)
        if len(raw) > MAX_BYTES or data.get('version') != 1 or not isinstance(data.get('titles'), dict):
            raise ValueError()
        return clean(data['titles']), response['sha']
    except Exception:
        raise SyncError('Invalid format database; local formats were kept') from None


def synchronize(memory, token, still_current=lambda: True, transport=request):
    if transport(token).get('private') is not True:
        raise SyncError('Format sync requires a private repository')
    if not still_current():
        return False
    remote, sha = decode(transport(token, FILE))
    if not still_current():
        return False
    local = memory.merge(remote)
    if local == remote:
        return True
    raw = json.dumps({'version': 1, 'titles': local}, sort_keys=True, separators=(',', ':')).encode()
    if len(raw) > MAX_BYTES:
        raise SyncError('Format database is too large; local formats were kept')
    payload = {'message': 'Merge technical format database', 'content': base64.b64encode(raw).decode()}
    if sha:
        payload['sha'] = sha
    if not still_current():
        return False
    transport(token, FILE, payload)
    verified, _ = decode(transport(token, FILE))
    if merge(verified, local) != verified:
        raise SyncError('Format upload could not be confirmed; retrying')
    if not still_current():
        return False
    memory.merge(verified)
    return True


def summary(profile, addon):
    if addon.getSetting('formats_github_enabled') == 'false':
        return 'Off'
    if not addon.getSetting('credits_github_token').strip():
        return 'Local database ready; add a private GitHub sync token to share'
    return str(Store(Path(profile) / 'format-sync').load().get('status') or 'Waiting for first sync')


class FormatSync:
    def __init__(self, profile, addon):
        self.memory = Database(profile)
        self.profile, self.addon = profile, addon
        self.status = Store(Path(profile) / 'format-sync')
        self.busy = False
        self.next_check = 0

    def config(self):
        return (self.addon.getSetting('formats_github_enabled'), self.addon.getSetting('credits_github_token').strip())

    def tick(self):
        # A bounded background transfer, not a scan per title or row. Five-minute
        # polling also retries optimistic GitHub conflicts between devices.
        config = self.config()
        if self.busy or config[0] == 'false' or not config[1] or time.monotonic() < self.next_check:
            return
        self.busy = True
        self.next_check = time.monotonic() + 300
        try:
            threading.Thread(target=self.run, args=(config,), daemon=True).start()
        except RuntimeError:
            self.busy = False

    def run(self, config):
        try:
            self.memory.migrate(self.profile)
            if synchronize(self.memory, config[1], lambda: self.config() == config):
                self.status.save({'status': 'Shared format database up to date', 'last_sync': time.time()})
        except SyncError as error:
            self.status.save({'status': str(error)})
        except Exception:
            try:
                self.status.save({'status': 'Sync will retry; local formats were kept'})
            except Exception:
                pass
        finally:
            self.busy = False
