Format logos are shown only for Kodi-reported formats, not source claims.

`atmos.png`: unmodified Dolby Atmos Horizontal logo from Dolby Newsroom:
https://news.dolby.com/en-WW/assets/228229/

Other assets reuse the format flags bundled with the Kodi Estuary companion
skin. Original product names and logos belong to their respective owners.

Resolution flags (720p, 1080p, 4K and 8K) reuse the bundled Estuary videoresolution assets. Resolution names and icons use decoded stream dimensions, including common cropped widescreen sizes; unknown sizes retain their exact dimensions without an invented format badge. Dolby Atmos is shown alongside its reported Dolby Digital Plus or TrueHD base format.

Updated Dolby logos retain their original artwork and aspect ratios:
- dolbyvision.png: official Dolby Vision Horizontal PNG, https://news.dolby.com/en-WW/assets/228231/
- eac3.png: Dolby Digital Plus SVG by Dolby Laboratories, rendered to PNG at 700px without changing paths or colours, https://commons.wikimedia.org/wiki/File:Dolby-Digital-Plus.svg
- truehd.png: Dolby TrueHD SVG by Dolby Laboratories, rendered to PNG at 700px without changing paths or colours, https://commons.wikimedia.org/wiki/File:Dolby_TrueHD.svg
Black logos are displayed on light tiles for contrast; the Atmos logo remains the original Dolby asset. Other formats retain the attributed Estuary flags.
