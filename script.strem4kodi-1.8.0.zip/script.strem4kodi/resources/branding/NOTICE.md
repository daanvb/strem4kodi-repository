# Strem4Kodi branding

Original blue folded-play mark and Strem4Kodi wordmark.
Unofficial community addon; not endorsed by Stremio or Kodi.
Software copyright and GPL notices remain preserved.
