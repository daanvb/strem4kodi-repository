"""Resolve configured AIOMetadata posters independently of catalogue membership."""
import hashlib
import re
import time
from concurrent.futures import ThreadPoolExecutor

from addons_core import active_addons
from protocol import fetch, resource_url
from sources import supports


def identity(row):
    kind = row.get('type')
    if kind not in ('movie', 'series'):
        return None
    value = str(row.get('imdb_id') or row.get('imdbId') or row.get('id') or row.get('_id') or '')
    imdb = re.fullmatch(r'(?:imdb:)?(tt\d+)(?::\d+:\d+)?', value)
    return (kind, imdb[1] if imdb else value) if value else None


class Posters:
    def __init__(self, state, cache=None, fetcher=None):
        self.providers = [provider for provider in active_addons(state)
                          if 'aiometadata' in re.sub(r'\W', '', str((provider.get('manifest') or {}).get('name')
                                                                  or (provider.get('manifest') or {}).get('id') or '')).casefold()]
        self.signature = hashlib.sha256(repr([p.get('transportUrl') for p in self.providers]).encode()).hexdigest()
        self.cache = cache
        self.fetcher = fetcher or (lambda url: fetch(url, timeout=4, use_cache=False))

    def key(self, title):
        return 'configured-poster-v1:' + self.signature + ':' + title[0] + ':' + title[1]

    def known(self, catalogs):
        result = {}
        if not self.providers:
            return result
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                owner = catalog.get('addon') or ''
                if title and row.get('poster') and 'aiometadata' in re.sub(r'\W', '', str(owner)).casefold():
                    result.setdefault(title, {'poster': row['poster'], '_poster_provider': owner})
        if self.cache is not None:
            for catalog in catalogs:
                for row in catalog.get('items', []):
                    title = identity(row)
                    if title and title not in result:
                        try:
                            cached = self.cache.get(self.key(title))
                            if isinstance(cached, dict) and cached.get('expires', 0) > time.time():
                                result[title] = cached.get('artwork') or {}
                        except Exception:
                            pass
        return result

    @staticmethod
    def apply(catalogs, known):
        return [dict(catalog, items=[dict(row, **known.get(identity(row), {}))
                                     for row in catalog.get('items', [])]) for catalog in catalogs]

    def cached(self, catalogs):
        return self.apply(catalogs, self.known(catalogs))

    def refresh(self, catalogs, cancelled=lambda: False):
        known = self.known(catalogs)
        pending = []
        for catalog in catalogs:
            for row in catalog.get('items', []):
                title = identity(row)
                if title and title not in known and title not in pending:
                    pending.append(title)
        if not self.providers:
            return

        def lookup(title):
            if cancelled():
                return title, {}
            kind, media_id = title
            for provider in self.providers:
                if not supports(provider.get('manifest') or {}, kind, media_id, 'meta'):
                    continue
                try:
                    payload = self.fetcher(resource_url(provider['transportUrl'], 'meta', kind, media_id))
                    meta = payload.get('meta') if isinstance(payload, dict) else None
                    poster = meta.get('poster') if isinstance(meta, dict) else None
                    if (isinstance(meta, dict) and meta.get('type', kind) == kind
                            and identity(dict(meta, type=kind)) == title and isinstance(poster, str)
                            and poster.startswith(('https://', 'http://'))):
                        name = (provider.get('manifest') or {}).get('name') or 'AIOMetadata'
                        return title, {'poster': poster, '_poster_provider': name}
                except Exception:
                    # URLs may contain private configuration: never log them.
                    continue
            return title, {}

        for offset in range(0, len(pending), 8):
            if cancelled():
                return
            with ThreadPoolExecutor(max_workers=4) as pool:
                results = list(pool.map(lookup, pending[offset:offset + 8]))
            if cancelled():
                return
            changed = False
            for title, artwork in results:
                if self.cache is not None:
                    ttl = 900 if artwork else 60
                    try:
                        self.cache.put(self.key(title), {'artwork': artwork, 'expires': time.time() + ttl}, ttl)
                    except Exception:
                        pass
                if artwork:
                    known[title] = artwork
                    changed = True
            if changed:
                yield self.apply(catalogs, known)


def configured(state):
    from lib.cache_policy import open_cache, read_policy
    posters = Posters(state)
    if posters.providers:
        posters.cache = open_cache('metadata', read_policy())
    return posters
