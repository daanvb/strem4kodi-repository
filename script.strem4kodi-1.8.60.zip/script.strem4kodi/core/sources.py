"""Read-only source aggregation; no account token is sent to providers."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlsplit
import time
from protocol import fetch, resource_url


class RateLimitError(ValueError):
    pass


def rate_limit_message(value):
    text = str(value or '').casefold()
    return any(term in text for term in ('rate limit', 'rate_limit', 'limit exceeded', 'too many requests'))


def supports(manifest, kind, identity, resource_name='stream'):
    for resource in manifest.get('resources', []):
        spec = manifest if resource == resource_name else resource
        if not isinstance(spec, dict):
            continue
        if resource != resource_name and spec.get('name') != resource_name:
            continue
        types = spec.get('types', manifest.get('types', []))
        prefixes = spec.get('idPrefixes')
        if kind in types and (prefixes is None or any(identity.startswith(p) for p in prefixes)):
            return True
    return False


def direct_url(stream):
    url = stream.get('url', '')
    if not isinstance(url, str) or '|' in url or any(ord(c) < 32 for c in url):
        return False
    parsed = urlsplit(url)
    hints = stream.get('behaviorHints') or {}
    # A playable direct URL remains valid even when a Stremio provider also
    # includes infoHash/externalUrl metadata. Some debrid providers do this
    # (for example Torrentio-style responses). Only reject URLs that Kodi
    # cannot safely play without extra proxy/header handling.
    return (parsed.scheme in ('http', 'https') and bool(parsed.netloc)
            and not parsed.username and not parsed.password
            and isinstance(hints, dict) and not hints.get('proxyHeaders'))


def embedded_sources(meta, identity):
    """Adapt upstream 0d24a03 using our existing AV-preserving stream parser."""
    video = next((v for v in meta.get('videos', []) if isinstance(v, dict)
                  and v.get('id') == identity), None)
    if not video or not isinstance(video.get('streams'), list):
        return None
    kind = meta.get('type') or 'movie'
    provider = {'transportUrl': 'https://embedded.invalid/manifest.json',
                'manifest': {'name': 'Stored video', 'types': [kind], 'resources': ['stream']}}
    return collect([provider], kind, identity,
                   fetcher=lambda url: {'streams': video['streams']})


def collect(providers, kind, identity, fetcher=fetch, timing=None, on_results=None, on_progress=None):
    selected, seen = [], set()
    for provider in providers:
        url = provider.get('transportUrl')
        if url and url not in seen and supports(provider.get('manifest', {}), kind, identity):
            seen.add(url)
            selected.append(provider)

    def query(provider):
        started = time.monotonic()
        name = provider.get('manifest', {}).get('name') or 'Addon'
        try:
            result = fetcher(resource_url(provider['transportUrl'], 'stream', kind, identity))
            if result.get('error'):
                if rate_limit_message(result['error']):
                    raise RateLimitError()
                raise ValueError('Addon returned an error')
            streams = result.get('streams', [])
            if not isinstance(streams, list):
                raise ValueError('Invalid streams')
            if streams and all(isinstance(s, dict) and rate_limit_message(str(s.get('name') or '') + ' ' + str(s.get('title') or '')) for s in streams):
                raise RateLimitError()
            good, skipped = [], 0
            for stream in streams:
                if not isinstance(stream, dict) or not direct_url(stream):
                    skipped += 1
                    continue
                detail = stream.get('title') or stream.get('name') or 'Stream'
                hints = stream.get('behaviorHints') or {}
                good.append({'url': stream['url'],
                             'label': '{} · {}'.format(name, detail),
                             'provider': name,
                             'detail': detail,
                             'name': stream.get('name') or '',
                             'title': stream.get('title') or '',
                             'isLive': kind in ('sports','sport','tv','channel','live') or stream.get('isLive') is True,
                             'subtitles': stream.get('subtitles', []),
                             'videoSize': hints.get('videoSize', stream.get('videoSize')),
                             'quality': stream.get('quality') or hints.get('quality'),
                             'resolution': stream.get('resolution') or hints.get('resolution'),
                             'height': stream.get('height') or hints.get('height'),
                             'audio': stream.get('audio') or hints.get('audio'),
                             **{key: stream.get(key, hints.get(key)) for key in ('videoCodec','audioCodec','audioCodecs','audioTracks','audioStreams','channels','languages','hdr','bitDepth','frameRate','bitrate')},
                             'source': stream.get('source') or hints.get('source'),
                             'filename': hints.get('filename', stream.get('filename','')),
                             'dvProfile': stream.get('dvProfile',hints.get('dvProfile')),
                             'dolbyVisionProfile':stream.get('dolbyVisionProfile',hints.get('dolbyVisionProfile')),
                             'enhancementLayer':stream.get('enhancementLayer',hints.get('enhancementLayer')),
                             'dvEnhancementLayer':stream.get('dvEnhancementLayer',hints.get('dvEnhancementLayer'))})
            return good, skipped, 0, name, int((time.monotonic()-started)*1000), False
        except Exception as error:
            # Never expose configured URLs or provider exception messages.
            return [], 0, 1, name, int((time.monotonic()-started)*1000), isinstance(error, RateLimitError) or getattr(error, 'code', None) == 429

    output, skipped, failed = [], 0, 0
    completed = {}
    limited_count = 0
    def progress():
        if on_progress is not None:
            try:
                on_progress({'total': len(selected), 'completed': len(completed),
                             'rows': len(output), 'failed': failed, 'rate_limited': limited_count,
                             'pending': [str(p.get('manifest', {}).get('name') or 'Add-on')[:80]
                                         for i, p in enumerate(selected) if i not in completed]})
            except Exception:
                pass  # Optional UI feedback must not break playback.
    progress()
    with ThreadPoolExecutor(max_workers=4) as pool:
        if on_results is None and on_progress is None:
            results = enumerate(pool.map(query, selected))
        else:
            futures = {pool.submit(query, provider): i for i, provider in enumerate(selected)}
            results = ((futures[future], future.result()) for future in as_completed(futures))
        for index, result in results:
            entries, ignored, errors, provider_name, elapsed_ms, rate_limited = result
            completed[index] = result
            output.extend(entries)
            skipped += ignored
            failed += errors
            limited_count += int(rate_limited)
            if entries and on_results is not None:
                try:
                    on_results([row for i in sorted(completed) for row in completed[i][0]])
                except Exception:
                    pass
            if timing is not None:
                timing.append({'provider': str(provider_name)[:80], 'ms': max(0, elapsed_ms), 'failed': bool(errors), 'rows': len(entries), 'rate_limited': rate_limited})
            progress()
    output = [row for i in sorted(completed) for row in completed[i][0]]
    return output, skipped, failed
